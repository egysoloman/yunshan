import assert from 'node:assert/strict';
import { dirname, join } from 'node:path';
import { readFile, writeFile, mkdir, readdir, copyFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { connect } from 'node:net';

// Scheduling guard: this script is READY_NOT_RUN until root grants the single GPU slot.
assert.equal(process.env.YUNSHAN_COMPILED12_APPROVED, '1', 'NOT_RUN: wait for explicit root coherent12 CPU-ended/GPU approval');
const here = dirname(new URL(import.meta.url).pathname);
const contract = JSON.parse(await readFile(join(here, 'source-contract.json'), 'utf8'));
const sourceRoot = contract.sourceRoot, sharedRoot = '/workspace/yunshan';
const evidenceRoot = process.env.YUNSHAN_BROWSER12_EVIDENCE ?? join(here, 'browser11-evidence');
const nonExecutable = new Set(['.gitattributes', '.gitignore', 'AGENTS.md', '开发备忘录.md', '提示词.md']);
const executableInputs = Object.keys(contract.copiedHashes).filter(name => !nonExecutable.has(name));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const hashes = async (root, names) => Object.fromEntries(await Promise.all(names.map(async name => [name, hash(await readFile(join(root, name)))])));
const vacant = port => new Promise((resolve, reject) => {
  const socket = connect({ host: '127.0.0.1', port });
  socket.once('connect', () => { socket.destroy(); resolve(false); });
  socket.once('error', error => { socket.destroy(); if (error.code === 'ECONNREFUSED') resolve(true); else reject(error); });
});
const jsonFile = (name, value) => writeFile(join(evidenceRoot, name), JSON.stringify(value, null, 2) + '\n');
assert.equal(contract.state, 'BOUND_AFTER_ROOT_FREEZE');
assert.equal(contract.inputCount, 106); assert.equal(executableInputs.length, 101);
const entries = await readdir(evidenceRoot).catch(error => { if (error.code === 'ENOENT') return []; throw error; });
assert.equal(entries.length, 0, 'Preserve previous raw evidence: choose a new empty output directory');
await mkdir(evidenceRoot, { recursive: true });
const frozenBefore = await hashes(sourceRoot, Object.keys(contract.copiedHashes));
assert.deepEqual(frozenBefore, contract.copiedHashes, 'All 106 frozen inputs must match coherent12');
assert.equal(hash(await readFile(contract.snapshotManifest)), contract.snapshotManifestSHA256);
const sharedExecutableBefore = await hashes(sharedRoot, executableInputs);
assert.deepEqual(sharedExecutableBefore, Object.fromEntries(executableInputs.map(name => [name, contract.copiedHashes[name]])));
const sharedNonExecutableBefore = await hashes(sharedRoot, [...nonExecutable]);
const originalScript = join(sourceRoot, 'scripts/browser-test.mjs');
assert.equal(hash(await readFile(originalScript)), contract.originalBrowserHarnessSHA256);
const html = await readFile(join(sourceRoot, 'dist/index.html'), 'utf8');
assert.equal(html.match(/<script[^>]+src="([^"]+\.js)"/)?.[1], contract.distEntry);
assert.equal(hash(await readFile(join(sourceRoot, 'dist', contract.distEntry.slice(1)))), contract.distEntrySHA256);
const sourceMapsBefore = Object.fromEntries(await Promise.all(contract.sourceMaps.map(async row => [row.assetPath, hash(await readFile(join(sourceRoot, 'dist', row.assetPath.slice(1))))])));
assert.deepEqual(sourceMapsBefore, Object.fromEntries(contract.sourceMaps.map(row => [row.assetPath, row.sha256])));
assert.equal(await vacant(4173), true, 'Port 4173 already has an owner; never use or stop their server');
const existingArtifacts = await readdir(join(sourceRoot, 'artifacts')).catch(error => { if (error.code === 'ENOENT') return []; throw error; });
assert.equal(existingArtifacts.includes('browser-results.json'), false, 'Original script would overwrite a prior browser run; preserve it and stop');
const originalOutputNames = [...(await readFile(originalScript, 'utf8')).matchAll(/['"]artifacts\/([^'"/]+)['"]/g)].map(match => match[1]);
assert.deepEqual(existingArtifacts.filter(name => originalOutputNames.includes(name)), [], 'Original script would overwrite prior raw outputs; preserve them and stop');
const externalStart = { wrapper: hash(await readFile(new URL(import.meta.url))), contract: hash(await readFile(join(here, 'source-contract.json'))) };
await jsonFile('run-start.json', { atUTC: new Date().toISOString(), state: 'RUNNING_AFTER_ROOT_APPROVAL', sourceRoot, inputCount: 106,
  executableInputCount: 101, frozenBefore, sharedExecutableBefore, sharedNonExecutableBefore, externalStart,
  buildEntry: contract.distEntry, entrySHA256: contract.distEntrySHA256, originalScript, originalHarnessSHA256: contract.originalBrowserHarnessSHA256,
  scope: 'Unmodified original browser11 only. Controlled original fixtures retained. Extra wrapper checks are provenance/ownership, not art, Mac or performance assertions.' });
let raw = '', child, observedHTTP = null, httpTask = null, spawnError = null;
const observeHTTP = async () => {
  const response = await fetch(`http://127.0.0.1:4173${contract.distEntry}`, { signal: AbortSignal.timeout(5000) });
  const bytes = Buffer.from(await response.arrayBuffer());
  return { status: response.status, bytes: bytes.length, sha256: hash(bytes),
    scope: 'Independent read of the same owned preview endpoint; not a browser-network interception' };
};
try {
  child = spawn(process.execPath, [originalScript], { cwd: sourceRoot, stdio: ['ignore', 'pipe', 'pipe'] });
  const onOutput = bytes => {
    const text = bytes.toString(); raw += text; process.stdout.write(text);
    if (!httpTask && raw.includes('PASS world boots in first person')) httpTask = observeHTTP().then(value => { observedHTTP = value; }).catch(error => { observedHTTP = { error: String(error) }; });
  };
  child.stdout.on('data', onOutput); child.stderr.on('data', onOutput);
  const exit = await new Promise(resolve => { child.once('error', error => { spawnError = String(error); resolve({ code: null, signal: null }); }); child.once('exit', (code, signal) => resolve({ code, signal })); });
  if (httpTask) await httpTask;
  await writeFile(join(evidenceRoot, 'browser.log'), raw);
  const afterArtifacts = await readdir(join(sourceRoot, 'artifacts'), { withFileTypes: true }).catch(() => []);
  const outputs = afterArtifacts.filter(entry => entry.isFile() && !existingArtifacts.includes(entry.name)).map(entry => entry.name);
  for (const name of outputs) await copyFile(join(sourceRoot, 'artifacts', name), join(evidenceRoot, name));
  let results = null;
  try { results = JSON.parse(await readFile(join(evidenceRoot, 'browser-results.json'), 'utf8')); } catch {}
  let portReleased = false;
  for (let attempt = 0; attempt < 40; attempt++) { if (await vacant(4173)) { portReleased = true; break; } await wait(100); }
  const frozenAfter = await hashes(sourceRoot, Object.keys(contract.copiedHashes));
  const sharedExecutableAfter = await hashes(sharedRoot, executableInputs);
  const sharedNonExecutableAfter = await hashes(sharedRoot, [...nonExecutable]);
  const externalEnd = { wrapper: hash(await readFile(new URL(import.meta.url))), contract: hash(await readFile(join(here, 'source-contract.json'))) };
  const entryEndSHA256 = hash(await readFile(join(sourceRoot, 'dist', contract.distEntry.slice(1))));
  const sourceMapsAfter = Object.fromEntries(await Promise.all(contract.sourceMaps.map(async row => [row.assetPath, hash(await readFile(join(sourceRoot, 'dist', row.assetPath.slice(1))))])));
  const checks = { sourceMapsStable: JSON.stringify(sourceMapsBefore) === JSON.stringify(sourceMapsAfter), originalExit0: exit.code === 0, original11: results?.results?.length === 11 && !results.failure && results.errors?.length === 0,
    resultEntryMatches: results?.buildEntry === contract.distEntry, originalHarnessMatches: results?.harnessSHA256 === contract.originalBrowserHarnessSHA256,
    frozen106Stable: JSON.stringify(frozenBefore) === JSON.stringify(frozenAfter), sharedExecutable101Stable: JSON.stringify(sharedExecutableBefore) === JSON.stringify(sharedExecutableAfter),
    externalStable: JSON.stringify(externalStart) === JSON.stringify(externalEnd), entryStable: entryEndSHA256 === contract.distEntrySHA256,
    servedEntryMatches: observedHTTP?.status === 200 && observedHTTP?.sha256 === contract.distEntrySHA256, ownedPortReleased: portReleased };
  const passed = Object.values(checks).every(Boolean);
  await jsonFile('run-manifest.json', { atUTC: new Date().toISOString(), originalExit: exit, spawnError, checks, observedHTTP, sourceMapsBefore, sourceMapsAfter,
    sourceRoot, inputCount: 106, executableInputCount: 101, frozenBefore, frozenAfter, sharedExecutableBefore, sharedExecutableAfter,
    sharedNonExecutableBefore, sharedNonExecutableAfter, nonExecutableDifferences: [...nonExecutable].filter(name => sharedNonExecutableBefore[name] !== sharedNonExecutableAfter[name]),
    externalStart, externalEnd, buildEntry: contract.distEntry, entrySHA256: contract.distEntrySHA256, entryEndSHA256,
    originalHarnessSHA256: contract.originalBrowserHarnessSHA256, originalChildPID: child.pid, newArtifactFiles: outputs,
    wrapperExitCode: passed ? 0 : 1, scope: 'Original compiled browser11. Frozen106 and shared executable101 are separate contracts. Shared memo changes are reported separately. No native-home result or visual/Mac/benchmark acceptance.' });
  if (!passed) process.exitCode = 1;
  console.log('WRAPPER_FINAL', JSON.stringify({ checks, childExit: exit, wrapperExitCode: process.exitCode ?? 0 }));
} catch (error) {
  await writeFile(join(evidenceRoot, 'browser.log'), raw);
  await jsonFile('wrapper-error.json', { atUTC: new Date().toISOString(), error: String(error), spawnError, childPID: child?.pid,
    caution: 'No broad process termination is used. Confirm owned preview/browser release before starting the native scope.' });
  process.exitCode = 1; console.error(error);
}

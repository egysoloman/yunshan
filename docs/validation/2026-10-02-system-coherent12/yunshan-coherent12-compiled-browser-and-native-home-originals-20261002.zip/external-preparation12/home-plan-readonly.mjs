import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';

let raw = ''; for await (const chunk of process.stdin) raw += chunk;
const input = JSON.parse(raw), source = resolve(input.sourceRoot);
const provider = await import(pathToFileURL(resolve(source, 'src/architecture-floor-plan.ts')).href);
const rest = await import(pathToFileURL(resolve(source, 'src/simulation/home-rest.ts')).href);
const access = await import(pathToFileURL(resolve(source, 'src/access.ts')).href);
const worldAPI = await import(pathToFileURL(resolve(source, 'src/world.ts')).href);
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
const routeLength = points => points.slice(1).reduce((sum, point, i) => sum + distance(point, points[i]), 0);

if (input.operation === 'assemble') {
  const partition = await import(pathToFileURL(resolve(source, 'src/persistence/partition.ts')).href);
  console.log(JSON.stringify({ json: partition.assembleSave(input.parts) }));
} else if (input.operation === 'route') {
  const route = provider.findFloorPlanRoute(input.building, 0, input.from, input.to, .35);
  if (!route) throw Error('No authoritative floor-zero route between actual feet and target');
  console.log(JSON.stringify({ points: route, metres: routeLength(route), purpose: 'Read-only physical planning; these points are not movement evidence' }));
} else if (input.operation === 'plan') {
  const b = input.world.buildings.find(b => b.id === input.buildingId);
  if (!b || b.kind !== 'home' || !provider.getBuildingBody(b)) throw Error('Selected actual world has no marked v4 home');
  if (!access.canAccessFloor(b, 0, input.player)) throw Error('Actual player cannot access the selected ground floor');
  const floor = provider.getBuildingFloorPlan(b, 0), entrance = provider.getBuildingEntrance(b);
  const localEntrance = provider.buildingLocalPosition(b, entrance);
  const point = offset => {
    const p = provider.buildingWorldPosition(b, { x: localEntrance.x, y: floor.y, z: localEntrance.z + offset });
    p.y = worldAPI.getWalkHeight(input.world, p.x, p.z, entrance.y);
    return p;
  };
  const stage = point(3.2), approach = point(1.2);
  const stageSupport = provider.floorPlanSupport(b, 0, stage, .35);
  if (stageSupport && ['room', 'stairs'].includes(stageSupport.kind)) throw Error('Controlled starting point is not outside the home');
  const expectedDoorExit = provider.buildingWorldPosition(b, { x: localEntrance.x, y: floor.y, z: localEntrance.z - 2 });
  const sides = rest.homeRestPoints(b, 0);
  const services = provider.getFloorPlanUsePoints(b, 0).filter(p => p.purpose === 'service'
    && provider.floorPlanSupport(b, 0, p.position, .35)?.kind === 'room'
    && sides.every(side => distance(side.position, p.position) > 1));
  const choices = [];
  for (const service of services) for (const side of sides) {
    const toService = provider.findFloorPlanRoute(b, 0, expectedDoorExit, service.position, .35);
    const toBed = provider.findFloorPlanRoute(b, 0, service.position, side.position, .35);
    if (toService && toBed) choices.push({ service, side, toService, toBed, metres: routeLength(toService) + routeLength(toBed) });
  }
  choices.sort((a, b) => a.metres - b.metres || a.side.id.localeCompare(b.side.id));
  const selected = choices[0];
  if (!selected) throw Error('No actual accessible ground-floor service/bed-side pair with a legal shared route');
  console.log(JSON.stringify({ building: b, floor: 0, stage, approach, stageSupport,
    expectedDoorExit, entrance, service: selected.service, bed: selected.side, allGroundRestPoints: sides,
    plannedRouteToService: selected.toService, plannedRouteToBed: selected.toBed,
    staticPlannedMetres: selected.metres, bodyRadius: .35, eyeHeight: 1.72, restPointRadius: .4,
    restFootHeightTolerance: 1e-7, note: 'Static actual source provider planning only; no Simulation, position writes or traversal claim' }));
} else throw Error('Unknown read-only operation');

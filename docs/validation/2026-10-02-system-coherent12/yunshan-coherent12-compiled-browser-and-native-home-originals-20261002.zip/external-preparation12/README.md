# coherent12 compiled 功能验证准备

READY_NOT_RUN。当前没有启动server/browser/Simulation/GPU；只读核对与外部脚本复制、node --check完成。

冻结源 /tmp/yunshan-system-coherent-12/source；完整106输入已核对copiedHashes，当前共享101可执行输入同SHA（5个非执行文本另列，不用它们的后续文档变化冒源码变化）。manifest SHA 4bf2a896201c52b80da241115283fbe590270e41194234574973ff6585254458。

实际entry /assets/index-DWmMW8H6.js / 649278B / SHA e2767355343e047b2ec4428616bf3e2d1d2781727f667cc655069e5699cb6b51。两个actual sourceMaps的字节/hash在source-contract.json，均初始核对，运行还会核起止。dist不作为source输入自己的变化相互混算。

## 正式 browser11

先等待root相关Node已实际结束和明确独占GPU GO，再执行：

`YUNSHAN_COMPILED12_APPROVED=1 node /tmp/yunshan-coherent12-compiled-validation-ready-01/run-browser11.mjs`

wrapper直接运行该冻结源中的scripts/browser-test.mjs，不复制改执行脚本。它是root已接受的ground-sale受控fixture e5e098…；54原assert行/11labels/全部timeout（包括原90秒boot/航空60秒return）与历史cd7c原件相同。此补丁只建立同店合法sale前提，不当普通W门到柜台证据；原10启动0/11不会被覆盖。原测试内部已有明确受控市政/汽车/航空设置保持；不是自然资格旅程。

自有4173 strictPort preview；启动前必须空闲；源码/build/header/script/entry/地图sourceMaps契约始末。外部HTTP只在原第一项PASS后观察，它若仍boot超时则HTTPbody=null，必须据实保留，不能声称已加载实际body。这一既有观察边界已显式声明；原脚本仍检查servedHTML entry。正式异常及所有原输出归browser11-evidence，不扩超时、不改变产品状态迎合PASS。旧source目录或artifacts有同名旧原件时直接停，不能覆盖。

## 独立 native W/真实IndexedDB

正式browser11结束且ownedserver/browser确认释放后，仍需另一次root GO：

`YUNSHAN_COMPILED_VALIDATION_APPROVED=1 YUNSHAN_HOME_NATIVE_APPROVED=1 node /tmp/yunshan-coherent12-compiled-validation-ready-01/native-home-rest.mjs`

独立native-home-evidence与port4189，fresh非persistent浏览器context，不接触r10普通profile。只一次合法住宅外controlled staging，之后普通1x W/E/原UI租80、床侧rest开始/离开暂停/回原侧显式续休/完成20实际在场分钟/取消；不注钱、需求、身份、时间、天气或NPC/床占用。view-only yaw声明，几何plan不当移动证据。

原UI save/load创建实际IndexedDB新generation；readonly transaction捕获全部manifest parts及对应records完整JSON，核每ref的store/id/recordId/checksum、逐JSON和assembled/storage/live完整相等，load再完整JSON/实际feet恢复。localStorage fallback或toast不能替代，API save/load/import不作输入。真实占床或碰撞阻碍原样FAIL，不强移。

所有业务步行/进度/操作timeout保持原native准备预算。browser.close新增有界10s，超时记录未释放，不broad-kill；preview只正常TERM自有child。未确认资源释放不得开下一个GPU。root另据actualPID/startTicks/profile决定精准清理。

本次仅binding与syntax READY。此前Linux Node缓存候选收益和RSS代价不充当SwiftShader/正式browser/Mac性能；本次也不追加美术验收或Library操作。

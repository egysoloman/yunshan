from pathlib import Path
import json, hashlib, gzip, re, zipfile, datetime

ready = Path('/tmp/yunshan-coherent12-compiled-validation-ready-01')
source = Path('/tmp/yunshan-system-coherent-12/source')
rootdocs = Path('/workspace/yunshan/docs/validation/2026-10-02-system-coherent12')
delivery = ready / 'delivery'
delivery.mkdir(exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()
manifest_path = Path('/tmp/yunshan-system-coherent-12/source-snapshot.json')
manifest_bytes = manifest_path.read_bytes()
assert sha(manifest_bytes) == '4bf2a896201c52b80da241115283fbe590270e41194234574973ff6585254458'
manifest = json.loads(manifest_bytes)
assert len(manifest['copiedHashes']) == 106
payload = {}
origins = {}
def add(arc, path):
    assert arc not in payload
    payload[arc] = path.read_bytes()
    origins[arc] = str(path)
for name, expected in manifest['copiedHashes'].items():
    path = source / name
    assert sha(path.read_bytes()) == expected, name
    add('source/' + name, path)
for path in sorted((source / 'dist').rglob('*')):
    if path.is_file(): add('dist/' + path.relative_to(source / 'dist').as_posix(), path)
add('provenance/source-snapshot.json', manifest_path)
for path in sorted(rootdocs.rglob('*')):
    if path.is_file(): add('root-coherent12/' + path.relative_to(rootdocs).as_posix(), path)
for path in sorted(ready.iterdir()):
    if path.is_file() and path.name != 'package-originals.py': add('external-preparation12/' + path.name, path)
for part in ['browser11-evidence', 'native-home-evidence']:
    for path in sorted((ready / part).rglob('*')):
        if path.is_file(): add(part + '/' + path.relative_to(ready / part).as_posix(), path)
for history in ['yunshan-coherent08-native-home-rest-01', 'yunshan-coherent09-compiled-validation-ready-01', 'yunshan-coherent10-compiled-validation-ready-01']:
    base = Path('/tmp') / history
    assert base.exists(), history
    for path in sorted(base.iterdir()):
        if path.is_file(): add('historical-preparation/' + history + '/' + path.name, path)
old10 = Path('/tmp/yunshan-coherent10-compiled-validation-ready-01/browser11-evidence')
for path in sorted(old10.rglob('*')):
    if path.is_file(): add('historical-coherent10-browser-first-failure/' + path.relative_to(old10).as_posix(), path)

native = json.loads((ready / 'native-home-evidence/native-home-results.json').read_text())
formal = json.loads((ready / 'browser11-evidence/run-manifest.json').read_text())
movement = json.loads((ready / 'native-home-evidence/native-movement.json').read_text())
assert native['exitCode'] == 1 and native['results'] == []
assert native['sourceStable'] and native['sharedExecutableStable'] and native['externalStable'] and native['sourceMapsStable'] and native['entryStable']
assert len(native['sourceStart']) == 106 and len(native['sharedExecutableStart']) == 101
positions = sorted({tuple(row[key]['body'][axis] for axis in ('x','y','z')) for row in movement for key in ('before','after')})
nonzero = [row for row in movement if row['actualDelta'] > .005]
assert len(movement) == 100 and len(nonzero) == 17 and len(positions) == 2
assert not native['finalBody']['commands'] and native['finalBody']['player']['homeId'] is None
readout = {
  'scope': 'Read-only original-run analysis; not a new simulation/browser/test',
  'nativeExitCode': 1, 'completedNativeScopes': 0, 'nativeEInputs': 0,
  'pulseCount': 100, 'zeroObservedMovementCount': 83, 'nonzeroObservedMovementCount': 17,
  'observedBodyPositions': positions, 'horizontalMetresPerNonzeroChange': 4.8,
  'approach': movement[0]['target'], 'finalBody': native['finalBody']['body'],
  'inputTemporalEvidence': [
    'source/main.ts182-193 caps raw frame delta at 1s and applies current controller input to every <=1/30s movement catch-up step',
    'source/controller.ts37-47 stores current keys without event time boundaries;194-207 integrates current key/yaw at 4.8m/s',
    'external-preparation12/native-home-rest.mjs108-133 aims at <=.18m waypoint; both observed endpoints request200ms W; overshooting reverses view direction',
    'Native observers did not record browser accepted keydown/up event.timeStamp or rAF timing;200ms is host requested wait, not proven accepted key duration'
  ],
  'supportedConclusion': 'The 17 exact4.8m horizontal changes and source path strongly support a slow-frame/current-key input-time attribution problem; the original movement crossed the opening in both directions, not a persistent geometry blockage.',
  'notProven': ['actual accepted each key duration<=200ms','unique rendering/GPU causality','exact approach full support before arrival','bed occupancy/rest/native IDB completion'],
  'recommendedContractNotImplemented': 'Preserve input transition time intervals and their overlap with the retained frame window, integrate only held durations with unchanged speed/collision subdivision, including press+release between frames; blur/hidden ends holds. No patch in this artifact.',
  'eDistanceAlternative': 'Initial stage is already3.2m horizontally from entrance within E<=6. It may be tested as separate limited native portal interaction, never as W approach success or bedside navigation proof.',
  'cleanup': json.loads((ready / 'native-home-evidence/owned-cleanup-receipt.json').read_text())
}
payload['readout/native-first-waypoint-readout.json'] = (json.dumps(readout, ensure_ascii=False, indent=2)+'\n').encode()
origins['readout/native-first-waypoint-readout.json'] = 'Generated solely from preserved original run and frozen source; no rerun'
readme = '''# 冻结12：构建／正式浏览器／原生住宅原件

本包是2026-10-02冻结12独立原件，不是完整目标、美术验收、Mac性能或普通从spawn全程验证。

* root原严格构建exit0与renderer/world/public-offer相关28项exit0：root-coherent12/。
* 正式compiled browser：11/11，errors[]，原脚本exit0、wrapper exit0。时间17:00:48.027–17:07:19.737Z。原54断言／11labels／所有timeout与60秒返航保留。市场sale受控定位迁移已公开；业务夹具不等于普通玩家步行。
* 独立原生住宅：17:13:59.625–17:16:54.805Z，exit1，completed scope0。在唯一明确受控门外stage之后，100真实W脉冲未到达第一个exterior-approach路点。原目标(-390.8,76.46415094339623,334.6)，终点(-390.8,76.6,331.7999999999993)。没有执行E、租80、床侧20分钟休息／暂停／续休／取消或nativeIndexedDB保存恢复；这些均NOT_RUN。2张原PNG、原失败全存档与100条body观测完整保留。钱包一直600、homeIdnull；自然需求衰减未覆写。
* movement只有2种观测位置，17次水平4.8m往返跨门、83次0。main把cap1秒整帧拆小步但使用当前keys，controller不记录输入时间；支持慢帧输入预算问题。200ms是host请求等待，未采集浏览器实际accepted key边界，因此不虚报精确持键时间或唯一GPU原因。不改变.18m路点／真实支撑阈值，也没有调整源或重跑。
* browser11与native分别确证source106、sharedExecutable101、external脚本、actualentry及maps起止一致；原native浏览器实际HTTP200载入DWmMW8H6/e276…（完整SHA见原JSON）。source保存冻结时asof备忘录；不以当前工作树新memo替换。
* 独占清理已核：正式4173关闭；nativebrowser.close resolved，ownedNode166756/start9719660已不存在，非Z Chromium0，4189connect_ex111。没有外部强制信号。见双方原cleanupreceipt。

目录：source/严格106个冻结输入；dist/完整实际7个构建文件（含两份maps）；provenance/原source-snapshot；external-preparation12/原绑定程序／node-check／scope；browser11-evidence/正式全部raw、PNG、源码绑定；native-home-evidence/住宅全部原raw、PNG、失效存档；root-coherent12/根原构建、28项log/status、candidate equivalence及copyreceipt。readout/仅原件只读推导，不是新测试。

historical-preparation/原08/09/10准备文件均原字节：08尚未实际运行，缺playwright依赖是准备阶段发现，不是业务FAIL；09准备改用已有playwright-core。historical-coherent10-browser-first-failure/保原90秒启动0/11，不被12通过覆盖。历史manifest与代码有不同源范围，不能归为12测试。当前prepared文件即使名称含pending也依原内容绑定状态解读。

没有profile/node_modules/凭据/API密钥、参考图库或付费生成资产。全部payload与原来源逐SHA对照，ZIP全CRC、每成员SHA与gzip展开敏感模式扫描由外部validation记录；Library回执不自指写入已上传ZIP。新13若产生另封包，本包原12失败不覆盖。
'''
payload['README.md'] = readme.encode()
origins['README.md'] = 'New delivery scope report'
add('reproduction/package-originals.py', Path(__file__))
index = {arc:{'bytes':len(data),'sha256':sha(data),'originalPath':origins[arc]} for arc,data in payload.items()}
payload['payload-index.json'] = (json.dumps({'createdAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payloadCount':len(index),'payloadBytes':sum(v['bytes'] for v in index.values()),'files':index},ensure_ascii=False,indent=2)+'\n').encode()
raw_bytes=sum(map(len,payload.values()))
print('PRECHECK',json.dumps({'members':len(payload),'uncompressedBytes':raw_bytes,'sourceInputs':106,'distFiles':len(list((source/'dist').rglob('*.js')))+len(list((source/'dist').rglob('*.map'))),'maxFastPathBytes':50*1024*1024}),flush=True)
patterns = {
 'awsAccessKey': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
 'privateKey': rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
 'openaiKey': rb'\bsk-[A-Za-z0-9_-]{30,}\b',
 'bearerCredential': rb'Bearer\s+[A-Za-z0-9_-]{24,}(?:\.[A-Za-z0-9_-]{10,})*',
 'signedURL': rb'https?://[^\s"<>]+[?&](?:X-Amz-Signature|X-Goog-Signature|Signature|access_token|token|sig)=[A-Za-z0-9%_-]{8,}'
}
hits={name:0 for name in patterns};decoded_gzip=0
for arc,data in payload.items():
    candidates=[data]
    if arc.endswith('.gz'):
        candidates.append(gzip.decompress(data));decoded_gzip+=1
    for b in candidates:
        for name,pat in patterns.items():hits[name]+=len(re.findall(pat,b,re.I if name in ['signedURL','bearerCredential'] else 0))
assert not any(hits.values()),hits
zip_path=delivery/'yunshan-coherent12-compiled-browser-and-native-home-originals-20261002.zip'
with zipfile.ZipFile(zip_path,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for arc,data in payload.items():z.writestr(arc,data)
assert zip_path.stat().st_size < 50*1024*1024
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))==len(payload)
    for arc,original in payload.items():assert z.read(arc)==original,arc
for arc,record in index.items():
    if record['originalPath'].startswith('/'):
        assert sha(Path(record['originalPath']).read_bytes())==record['sha256'],arc
for name,expected in manifest['copiedHashes'].items():assert sha((source/name).read_bytes())==expected,name
validation={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'zip':str(zip_path),'zipBytes':zip_path.stat().st_size,'zipSHA256':sha(zip_path.read_bytes()),'members':len(payload),'indexedPayloadCount':len(index),'uncompressedBytes':raw_bytes,'fullCRC':'PASS','everyMemberByteEqual':'PASS','originalSourceFilesStartEndEqual':'PASS','frozenSource106Stable':'PASS','distFiles':7,'sourceManifestSHA256':sha(manifest_bytes),'sensitivePatternHitCounts':hits,'gzipExpandedMembers':decoded_gzip,'createRoute':'one new local ZIP under50MiB; current Library skill direct-create fast path; once only','scope':{'rootBuild':0,'rootRelatedTests':'28/28 exit0','formalBrowser':'11/11 errors[] exit0','nativeHome':'exit1 first W waypoint; no E/rent/rest/nativeIDB'}}
(delivery/'payload-index.json').write_bytes(payload['payload-index.json'])
(delivery/'README.md').write_bytes(payload['README.md'])
(delivery/'native-first-waypoint-readout.json').write_bytes(payload['readout/native-first-waypoint-readout.json'])
(delivery/'zip-validation.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2)+'\n')
print('VALIDATION',json.dumps(validation,ensure_ascii=False),flush=True)

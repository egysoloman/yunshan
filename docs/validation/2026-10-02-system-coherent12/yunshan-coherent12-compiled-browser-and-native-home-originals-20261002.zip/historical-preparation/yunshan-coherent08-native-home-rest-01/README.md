# compiled08 原生第一人称住宅床侧脚本

状态：**READY / NOT_RUN**。尚未启动预览、浏览器或 GPU，没有图像与业务通过结果。必须等根明确通知 08 全套 CPU 运行结束，并安排独占 GPU，再设置 `YUNSHAN_HOME_NATIVE_APPROVED=1` 执行。原 `npm run test:browser` 应先独立运行并退出；本脚本是新增的独立 scope，不能合并成原 11/11 或 DOM 35/35。

固定输入 `/tmp/yunshan-system-coherent-08/source` 的 102 文件，入口 `/assets/index-Bw4gqTMG.js`，SHA256 `d41a1ddb3e7ddf25bfb6baf020b2cda1f74585c085206a05047e5d1692e94968`。脚本不重建、不修改输入。默认独立端口 4189，必须为空；只启动自有 strictPort server，并核对实际 HTTP 已加载入口的 SHA，保起止 102 源及外部脚本 SHA。

`native-home-rest.mjs` 在实际 compiled 页面读出世界/玩家，`home-plan-readonly.mjs` 只调用同源纯 provider 推导 market-b24 的 floor0 外门、实际合法 service 点、床侧点和物理路线。没有第二个 Simulation、伪造家具/用途点或生成模拟步进。规划路线不是实际步行通过证据。

唯一 controlled setup 是住宅外真实 ground support 上起点及一次 Controller 同步；脚本明确不声称从 spawn 普通全程步行。设置当场核对钱、needs、身份、homeId、tick/clock 和全部 NPC 不变。之后没有直接写人物位置、脚高、现金、needs、身份、天气或时钟；没有 Simulation.step 或 API save/load/import 代替原生按钮。方向调整是明示的 view-only yaw/resetView。W 是原生输入，所有步行必须在 1x 未全局暂停中进行，不冻结 NPC 通路。原生 E 只跨既有门洞；床操作用明确的原生 rest 按钮，避免 E 被附近楼梯或 NPC 优先处理。

原生流程：W 接近 → E 进门 → W 至真实 service 点 → rent80（记录 wallet/public funds 严格对账）→ table rest disabled/no command → W 到派生床侧 → start0/no instant credit → 实际分钟推进 → W 离场/人物阶段自然暂停 → 返回原侧仍 paused → 明确点击继续 → 原生设置页 save → 真实 IndexedDB v2 manifest/全部 records 原样观察 → 原生取消使 model 变更 → 原生 load 恢复完整保存字节 → 1x 实际累计20床侧分钟完成 → 新会话真实部分分钟后原生取消。不会 API import 一个预制状态替代 load。

暂停仅通过用户可操作的原生按钮，用于静止截图、disabled-button 原子观察和真实 save/load 精确比较；每次 W 前都会原生恢复运行。Command 观察器只同步委托原 command 一次、返回原结果并记录前后值，从不自行发业务命令。程序读到的 IndexedDB 与所选 storage JSON 必须同原源码 assemble 的实际记录相等，并拒绝 fallback 作为 IndexedDB 成功。

尚未验证的实际风险：床侧半径只有0.4m，脚高 EPS 为1e-7；W 的低帧率输入脉冲可能过点或不推进；自然居民占床/实墙/体素/门场景可能阻塞，均原样 FAIL，不移居民、不调宽阈值。service/bed 的可达性由实际源静态规划提供，不证明 Native W 已走过。save/load 异步且每30秒自动保存，原生取消与 load 之间若 checkpoint 被真实 autosave 覆盖，会保留 FAIL 而不重写它。初始需求实际可能饱和，模型直接观察实际进度/即时无信用，不能以肉眼需要变化取代进度。镜头姿态与 FPS 不属于保存字段。

成功与失败 PNG 都是原始截图，保 body/eye/session/clock/cash/实际命令/原保存/HTTP/source/hash；只证明记录到的功能范围，未评美术，不属于 Mac 性能/普通路线/自然 NPC 入床验收。

未来获根批准后的单次命令：

```sh
YUNSHAN_HOME_NATIVE_APPROVED=1 node /tmp/yunshan-coherent08-native-home-rest-01/native-home-rest.mjs
```

输出默认 `/tmp/yunshan-coherent08-native-home-rest-01/evidence`；如需改变端口或输出目录，用 `YUNSHAN_HOME_NATIVE_PORT` / `YUNSHAN_HOME_EVIDENCE`。不得用未匹配的新 source/入口套本脚本的 08 SHA。

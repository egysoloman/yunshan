# coherent10 compiled browser preparation — READY_NOT_RUN

No test, Simulation, server, browser, GPU or model generation was started by this preparation. Official09's whole suite remains active. Wait for root's explicit CPU-ended/single-GPU GO before executing either script. Original08 and09 preparation bytes remain unchanged.

## Bound source and build

- Frozen source: `/tmp/yunshan-system-coherent-10/source`, **103 inputs**; shared executable inputs checked separately: **98**.
- Exact original manifest SHA256: `5991bab08a2e09ba96b15e991849c6ae22e8a043556eb67d93bf43224991f926`.
- Actual entry read after root's successful build: `/assets/index-IZpNJKPR.js`, 647,004 bytes, SHA256 `fe863519166c8abc0c7db84fc53517089532434948903fb777e1e28f0afd247b`.
- Original browser script SHA256 remains `cd7c4d616753d2c74233ca7afdc761760cfc0b4fba4096f758d22ea5cc0c95d5`.

`source-contract.json` contains all frozen103 hashes plus the separate shared98 contract. The five shared nonexecutable inputs are `.gitattributes`, `.gitignore`, `AGENTS.md`, `开发备忘录.md`, and `提示词.md`. Frozen103 must remain exact. Changes to shared memo/text are reported separately; they are not claimed as runtime changes. Generated dist is excluded from source hashes and checked separately by index/entry bytes and actual served/loaded asset SHA.

The root's declared unchanged world geometry does not make09 validation prove new10 runtime behavior. This is a separate prepared10 binding for the dynamic NPC bed-side/final guard update. No business PASS count exists here.

## Original compiled11 first

The external wrapper executes `/tmp/yunshan-system-coherent-10/source/scripts/browser-test.mjs` from that source directory, not a modified copy. `browser-test-original.mjs` is archival only and byte-identical. All original assertions, fixtures, loops and timeouts, including both original60-second native aircraft return assertions, stay unchanged.

Only after root GO:

```sh
YUNSHAN_COMPILED10_APPROVED=1 node /tmp/yunshan-coherent10-compiled-validation-ready-01/run-browser11.mjs
```

The wrapper requires an empty port4173 and fresh output directory, refuses to overwrite original outputs, and checks frozen103/shared98, original script and actual entry hashes. The original child must declare its own strictPort readiness and confirm served HTML. The wrapper's asset request is an independent read of that owned endpoint, not a browser-network interception. Original cleanup closes its Chromium and signals its own preview; the wrapper additionally records port release. A remaining owner or interrupted child blocks the second scope. It never kills unrelated processes. Default raw output: `browser11-evidence/`; use a fresh `YUNSHAN_BROWSER10_EVIDENCE` only if needed.

Original door-based market fixtures may fail the real v4 point gate. This risk is NOT_RUN; preserve the actual first failure rather than quietly changing fixture or assertion.

## Independent native home/IndexedDB second

After original11 exits and its browser/preview are released, obtain root's next single-GPU GO:

```sh
YUNSHAN_COMPILED10_APPROVED=1 YUNSHAN_HOME_NATIVE_APPROVED=1 node /tmp/yunshan-coherent10-compiled-validation-ready-01/native-home-rest.mjs
```

Default port4189 must be empty; only its owned strictPort server is signalled in cleanup. Default evidence: `native-home-evidence/`, with fresh optional `YUNSHAN_HOME_EVIDENCE`. The package/executable adapter remains the reviewed09 `playwright-core` plus `/usr/bin/chromium`; no further engine/behavior adaptation occurs. The readonly planner is byte-identical to09 and was not imported or executed during readiness checks.

The unchanged native contract is: one declared legal exterior staged start, then actual W and native E doorway; real service-point rent80/wallet-public cash conservation; table-rest disabled with no command; derived real bed-side rest starts at zero with no instant credit; actual onsite minutes; W departure/natural pause; original-side W return/explicit resume; native settings save into actual IndexedDB generation/records; native cancel; native load restores the complete paused model exactly; real1x20 credited minutes complete; second real partial session/native cancellation.

After that single staged start, no positions, feet, cash, needs, roles, clock or weather are assigned. View-only yaw/resetView is declared. No Simulation.step, API save/load/import substitutes, removed NPCs, manufactured availability, forced disabled clicks, enlarged tolerances or timeouts. Existing dynamic NPC/voxel obstruction remains an actual FAIL with original body/eye/clock/command/save/PNG evidence; geometric planning is not native traversal proof. Natural autosave replacing the checkpoint remains a failure rather than being bypassed.

Neither scope proves ordinary spawn-to-home travel, natural all-NPC sleeping, visual acceptance, macOS or performance. The user's satellite view is a generated expression from the real2D map, not an actual CityRenderer screenshot. No extra Library write is part of this preparation.

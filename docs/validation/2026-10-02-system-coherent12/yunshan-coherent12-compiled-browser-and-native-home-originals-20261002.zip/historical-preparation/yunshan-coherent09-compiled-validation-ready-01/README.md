# coherent09 compiled functional validation — READY_NOT_RUN

This directory contains preparation only. No server, browser, CityRenderer, GPU, Simulation, business case or test was started. Only file reads/writes and pure `node --check` are authorized now. Root's official09 full suite is still running; await its explicit CPU-ended/single-GPU GO. The user's satellite picture is an expression made from our real 2D map, not a screenshot of the renderer.

The coherent08 preparation remains unchanged at `/tmp/yunshan-coherent08-native-home-rest-01/`, READY_NOT_RUN. It was never run. Its undeclared `playwright` package dependency was found during preparation, not a business failure. Only this new09 native harness uses the project's existing `playwright-core` and the same `/usr/bin/chromium` executable used by the original standard browser script. No model/game behavior changes are included.

## Fixed identity

- Source: `/tmp/yunshan-system-coherent-09/source`.
- All 102 frozen input hashes: `source-contract.json`; exact original manifest copy: `source-snapshot-original.json`.
- Manifest SHA256: `46840299e7fa38d822797048eebbd361cb33e238404f5c0d20aaa04af459dc5d`.
- Actual built entry: `/assets/index-CkjRleb2.js`, 646,929 bytes, SHA256 `1bf1dda5f9042194420aa8d42258ff489c2c77c01febdbf177dc1f6f2464e8d6`.
- Unmodified original standard script SHA256: `cd7c4d616753d2c74233ca7afdc761760cfc0b4fba4096f758d22ea5cc0c95d5`.

Frozen102 are checked separately from the shared executable97. The five excluded shared text/metadata inputs are `.gitattributes`, `.gitignore`, `AGENTS.md`, `开发备忘录.md`, and `提示词.md`. All 102 frozen inputs must stay exact. All 97 shared executable inputs must match the freeze. Shared memo/text changes are observed separately and do not masquerade as runtime changes. Source checks exclude generated `dist`; actual dist/index entry and JS bytes get their own start/end checks.

## First scope: original compiled browser11

`run-browser11.mjs` is an external wrapper. It executes the **original** `/tmp/yunshan-system-coherent-09/source/scripts/browser-test.mjs` from that source directory. `browser-test-original.mjs` is an untouched archival copy, not an adapted test. None of the original assertions, controlled fixtures, loops, inputs or timeouts change; both original 60-second native aircraft return limits remain.

The wrapper refuses an occupied port4173 or prior original output files. The original script starts its own strictPort preview, checks its child's readiness marker and actual served HTML, then runs one browser. The wrapper additionally records frozen102/shared97, script hashes, build bytes, original process exit/results and an independent HTTP read of the same owned preview asset. This HTTP observation is not represented as browser network interception. The original script's `finally` closes its browser and signals its own preview; the wrapper waits up to four seconds for port4173 release and records failure if still occupied. It never stops unrelated Node/Chrome/servers. An interrupted or unreleased process blocks the next scope until root verifies ownership and cleanup.

Only after root GO:

```sh
YUNSHAN_COMPILED09_APPROVED=1 node /tmp/yunshan-coherent09-compiled-validation-ready-01/run-browser11.mjs
```

Default raw output: `browser11-evidence/`. A prior run is never overwritten; `YUNSHAN_BROWSER09_EVIDENCE` can choose a fresh directory. Preserve the standard script's original failure and partial counts if it fails. Existing door-based controlled transaction fixtures may encounter the newer v4 point gate: this is NOT_RUN and must be diagnosed from the real result, without silently changing the script.

## Second scope: independent native home/IndexedDB

Wait for the first original scope to exit, release its browser/preview, and for root to grant the next single-GPU slot. `native-home-rest.mjs` requires both explicit09 and native-scope approval flags. Default port4189 must be empty; only its own strictPort child is signalled during cleanup. It pins the actual09 manifest/102 sources, separately checks shared executable97, verifies owned HTML/actual loaded entry response SHA and all external files at start/end. `home-plan-readonly.mjs` is byte-identical to the old prepared planner and is not executed during readiness checks.

Only after root's second-scope GO:

```sh
YUNSHAN_COMPILED09_APPROVED=1 YUNSHAN_HOME_NATIVE_APPROVED=1 node /tmp/yunshan-coherent09-compiled-validation-ready-01/native-home-rest.mjs
```

Default raw output: `native-home-evidence/`; override only with a fresh `YUNSHAN_HOME_EVIDENCE` directory. Optional port override: `YUNSHAN_HOME_NATIVE_PORT`. The fixed source/entry contract rejects another build.

One controlled initial exterior body placement is explicitly declared and verified on real support. It is not ordinary travel from spawn. All later movement is actual W/E; yaw/resetView only changes declared view. No later position/foot-height, cash, needs, role, weather or clock assignments; no Simulation.step, API import/save/load substitutes, cleared NPCs, forced enabled state, widened tolerances/timeouts or manufactured bed availability.

The unchanged business sequence is native doorway → real service point rent80/wallet-public cash → disabled table-rest/no command → actual derived bed side/start0/no immediate credit → real minute progress → W departure/natural pause → W original-side return/explicit continuation → native settings save/real IndexedDB generation and records → native cancel → native load/entire paused save exact → real1x20 credited minutes completion → second partial/native cancellation. Physical planning is not traversal evidence. A blocked wall, occupied bed, missed tiny standing radius, absent callback or autosave checkpoint replacement remains a genuine failure with original PNG/model/command/clock/provenance.

Both scopes are functional software-GPU checks only. No visual acceptance, ordinary full-route/NPC-night proof, macOS performance, new paid asset generation or Library writes are authorized here. No PASS counts exist for this prepared09 directory yet.

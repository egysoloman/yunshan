import os,sys,json,time,hashlib,pathlib,subprocess,signal,datetime
base=pathlib.Path(__file__).resolve().parents[1]; candidate=base/'candidate'
name=sys.argv[1];limit=float(sys.argv[2]);command=sys.argv[3:];folder=base/'scopes'/name
folder.mkdir(parents=True,exist_ok=False)
def manifest():
 return {str(p.relative_to(candidate)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(candidate.rglob('*')) if p.is_file() and 'node_modules' not in p.parts and 'dist' not in p.parts and 'artifacts' not in p.parts}
def proc(pid):
 try:
  stat=pathlib.Path(f'/proc/{pid}/stat').read_text();end=stat.rindex(')');tail=stat[end+2:].split();return {'pid':pid,'ppid':int(tail[1]),'startTicks':int(tail[19]),'cmdline':pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().decode(errors='replace').replace('\x00',' ').strip()}
 except (OSError,ValueError):return None
def descendants(pid):
 records=[x for p in pathlib.Path('/proc').iterdir() if p.name.isdigit() and (x:=proc(int(p.name)))]
 owned={pid};changed=True
 while changed:
  children={r['pid'] for r in records if r['ppid'] in owned};changed=bool(children-owned);owned|=children
 return [r for r in records if r['pid'] in owned and r['pid']!=pid]
before=manifest()
for rel,digest in before.items():
 raw=(candidate/rel).read_bytes();assert hashlib.sha256(raw).hexdigest()==digest,rel;target=folder/'source-as-run'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
(folder/'inputs-before.json').write_text(json.dumps(before,indent=2)+'\n');started=datetime.datetime.now(datetime.timezone.utc).isoformat();ancestry=[];pid=os.getpid()
while (record:=proc(pid)):
 ancestry.append(record)
 if record['ppid']==pid or record['ppid']==0:break
 pid=record['ppid']
p=subprocess.Popen(command,cwd=candidate,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);identity=proc(p.pid);timed=False
try:output=p.communicate(timeout=limit)[0]
except subprocess.TimeoutExpired:
 timed=True;os.killpg(p.pid,signal.SIGTERM)
 try:output=p.communicate(timeout=5)[0]
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);output=p.communicate()[0]
(folder/'raw.log').write_bytes(output);after=manifest();(folder/'inputs-after.json').write_text(json.dumps(after,indent=2)+'\n');active=descendants(os.getpid());status='TIMED_OUT_PARTIAL' if timed else 'PASS' if p.returncode==0 else 'FAIL'
r={'scope':name,'status':status,'command':command,'cwd':str(candidate),'timeLimitSeconds':limit,'startedAt':started,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'rootAncestry':ancestry,'childIdentity':identity,'ownedActiveAtEnd':active,'inputsExact':before==after,'inputCount':len(before),'productionSourceCount':sum(k.startswith('src/') for k in before),'rawLogSHA256':hashlib.sha256(output).hexdigest()}
(folder/'receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({key:r[key] for key in ['scope','status','startedAt','endedAt','exitCode','ownedActiveAtEnd','inputsExact','inputCount','productionSourceCount','rawLogSHA256']}));print(output.decode(errors='replace')[-16000:]);sys.exit(0 if status=='PASS' and before==after and not active else 1)

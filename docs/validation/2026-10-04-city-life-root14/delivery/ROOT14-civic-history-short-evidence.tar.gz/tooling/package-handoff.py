import pathlib,json,hashlib,tarfile,io,os,datetime
os.nice(19)
b=pathlib.Path(__file__).resolve().parents[1];c=b/'candidate';out=b/'delivery';out.mkdir(exist_ok=True)
def digest(data):return hashlib.sha256(data).hexdigest()
def bytes_for(p):return p.read_bytes()
def json_bytes(data):return (json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode()
def add(t,name,data):
 i=tarfile.TarInfo(name);i.size=len(data);i.mtime=0;i.mode=0o644;t.addfile(i,io.BytesIO(data))
f=json.loads((b/'FINAL-INPUTS.json').read_text());inputs=f['inputs']
for rel,sha in inputs.items():assert digest(bytes_for(c/rel))==sha,rel
source=out/'ROOT14-civic-history-final-source.tar.gz'
with tarfile.open(source,'w:gz',compresslevel=1) as t:
 for rel,sha in inputs.items():add(t,'candidate/'+rel,bytes_for(c/rel))
 for name in ['FINAL-INPUTS.json','FROZEN-BASE.json','SOURCE-DELTA.json']:add(t,name,bytes_for(b/name))
evidence=out/'ROOT14-civic-history-short-evidence.tar.gz';entries={}
with tarfile.open(evidence,'w:gz',compresslevel=1) as t:
 def include(name,data):add(t,name,data);entries[name]={'bytes':len(data),'sha256':digest(data)}
 for name in ['REPORT.md','HANDOFF.md','PLAN-AND-OWNERS.md','MEMO-ENTRY.md','NATURAL-BUDGET-PILOT-PLAN.md','FINAL-INPUTS.json','FROZEN-BASE.json','SOURCE-DELTA.json','FINAL-VERIFICATION.json','ROOT13-READONLY-CHECK.json','tooling/run-scope.py','tooling/package-handoff.py']:include(name,bytes_for(b/name))
 for folder in sorted((b/'scopes').iterdir()):
  if not (folder/'receipt.json').is_file():continue
  m=json.loads((folder/'inputs-before.json').read_text());recipe={'base':'final source candidate, verified FINAL-INPUTS.json','inputCount':len(m),'removeFromFinal':sorted(set(inputs)-set(m)),'overlayFiles':[]}
  for rel,sha in m.items():
   p=folder/'source-as-run'/rel;data=bytes_for(p);assert digest(data)==sha,(folder.name,rel)
   if inputs.get(rel)!=sha:
    name=f'scopes/{folder.name}/source-overlay/{rel}';include(name,data);recipe['overlayFiles'].append(rel)
  include(f'scopes/{folder.name}/source-reconstruction.json',json_bytes(recipe))
  for name in ['receipt.json','raw.log','inputs-before.json','inputs-after.json']:include(f'scopes/{folder.name}/{name}',bytes_for(folder/name))
  for p in sorted((folder/'outputs').rglob('*')) if (folder/'outputs').exists() else []:
   if p.is_file():include(str(p.relative_to(b)),bytes_for(p))
 include('EVIDENCE-ENTRIES.json',json_bytes(entries))
# Verify every archived entry against the source/manifest; this is artifact
# consistency checking, not a Simulation/test/build/performance command.
with tarfile.open(source,'r:gz') as t:
 got={m.name[10:]:digest(t.extractfile(m).read()) for m in t.getmembers() if m.name.startswith('candidate/')}
 assert got==inputs
with tarfile.open(evidence,'r:gz') as t:
 for name,meta in entries.items():data=t.extractfile(name).read();assert digest(data)==meta['sha256'] and len(data)==meta['bytes'],name
 for folder in sorted((b/'scopes').iterdir()):
  if not (folder/'receipt.json').is_file():continue
  recipe=json.loads(t.extractfile(f'scopes/{folder.name}/source-reconstruction.json').read());m=json.loads((folder/'inputs-before.json').read_text());restored={k:v for k,v in inputs.items() if k not in recipe['removeFromFinal']}
  for rel in recipe['overlayFiles']:restored[rel]=digest(t.extractfile(f'scopes/{folder.name}/source-overlay/{rel}').read())
  assert restored==m,folder.name
artifacts={str(p.relative_to(b)):{'bytes':p.stat().st_size,'sha256':digest(bytes_for(p))} for p in [source,evidence]}
(b/'DELIVERY-MANIFEST.json').write_bytes(json_bytes({'status':'LOCAL_SAFE_HANDOFF_ONLY_NO_UPLOAD','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'finalGraphSHA256':f['graphSHA256'],'artifacts':artifacts,'sourcePackageVerified304Files':True,'evidencePackageVerifiedAllEntries':True,'eachDistinctSourceGraphReconstructsExactly':True,'originalCompleteSourcesRetainedLocally':'scopes/*/source-as-run/','scope01SnapshotException':'typecheck01 is hash-matched post-run recovery; see REPORT','uploadOwner':'parent only; no Git/Library/deploy action by this group'}))
print(json.dumps(artifacts,indent=2))

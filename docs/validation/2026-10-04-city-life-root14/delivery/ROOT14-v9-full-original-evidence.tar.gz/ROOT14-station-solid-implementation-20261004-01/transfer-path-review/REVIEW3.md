# REVIEW3 — exact rational finite-face corridor independent review

日期：2026-10-04。本次只读复核新 `exact-planar-union.ts`、重写的 `street-foot-corridor.ts`、未变的 path v9-2 调用及七条纯规则的测试文本。主审与独立子审查者分别核对了数学和源码。未执行任何代码、World、Simulation、测试、build 或 GPU；未改 source、CLOSED 或原 REPORT/REVIEW2。

结论：**本版精确接受逻辑未发现新的静态阻断问题。** 旧换 floor 集与小孔容差反例均已从此 projection proof 中排除。此结论限于有限、code-owned affine Float32 boxes 与精确线性 feet 段的完整投影/高度带证明；不是实际 factory、cursor、grounded contact、capsule 数值证明或 transport 验收 PASS。

## 1. IEEE 有理数、GCD 与规范形式

`exact-planar-union.ts:8–27`：零分母先拒绝；负分母转正；零值统一为 0/1；GCD 对两输入取绝对值并执行欧几里得算法。非零分子、正分母时 factor 不会为 0。加减乘除后均重新规范化，比较用交叉乘 BigInt，不受浮点舍入影响。规范化也使 cut 的 numerator/denominator 字符串去重正确。

15–21 行正确提取 Float64 sign、11-bit exponent 与 52-bit fraction。normal 添加隐含 2^52 并使用 exponent-1023-52；subnormal 使用原 fraction 与 2^-1074；负数正确翻转分子，正/负零均返回 0/1。Float32 matrix 中每个实际 number 本来就是可精确表示的 Float64 dyadic，所以转换保留原 material coefficient 的精确值。

`approximateExact` 29–32 行只产生报告标签；未发现其值进入 acceptance 分支。所有 proof 比较使用 BigInt 有理数。

## 2. 实际 face orientation 与高度裁剪

43–56 行直接以精确 matrix coefficients 重建 cube ±1/2 vertices，变换累加也都是有理数，未先计算 rounded-double vertices。face normal 用 exact cross；`outwardSign = sign(normal·(face0-center))`。54 行 `sign(normal.y)*outwardSign>0` 等价于真正外法向向上，适用于普通正 determinant 和反射/负 determinant affine box。向下或竖直面排除；零 volume/退化法向被保守排除。

58–65 行是保持 face 原顶点次序的精确半平面裁剪。仅在 ai!=bi 时计算交点，此时端点高度必不同，除数不为零，t 在 [0,1] 内。交点是原真实 face 上的 exact lerp，并显式置于 exact clipping height；不会扩张物理域。边界相等时可能产生重复顶点，但 zero-length edges 后续跳过，orientation/convex contains 不因此改变。

每个非退化 upward face 的 XZ 投影仍是凸域；clip 后亦凸。零面积投影被 exact union 函数排除，不会成为凭空面积。

## 3. 交点、共线与 exposed union boundary

67–73 行用精确 signed area 测试所有 convex half-planes。负值明确拒绝，不再有 area tolerance。point 在边上时，outward 向另一 polygon 外侧则拒绝；outward 向内或沿共同边时才允许其遮蔽当前 boundary。

87–89 行的非平行交点公式 `t=cross(offset,delta)/cross(edge,delta)`、`u=cross(offset,edge)/cross(edge,delta)` 符号正确；只纳入当前 edge 的内部 t，并允许另一 edge 的端点 u=0/1。真共线时把另一 segment 两端投影到当前 edge 并加入内部 cuts。所有边界交叉/共享区间变化都在 cuts 中分段，不以“接近共线”扩域。

91 行依据 polygon winding 选择右/左侧 outward，方向正确。94 行在每个开放 cut interval 的中点检查另一个 polygon 是否覆盖外侧；该 interval 内没有尚未切分的 boundary crossing，所以 exact half-plane 状态不变。共享真实 floor seam 的两侧面互相遮蔽内部边；重复同一 polygon 的外边在 outward 方向被正确拒绝遮蔽。不同高度的 face 只按已经证明可达的投影并集组合，未发明共面 floor。

95–97 行把中心到完整 edge 的正交投影参数钳制到当前 exposed 子段 [low,high]，其 exact squared distance 正确。中心不在 union 返回 null；非退化有限 union 的外边界仍保留。未发现 hole、coplanar seam、duplicate face 或方向符号导致的假 PASS。

## 4. 距离平方 margin 等价性

104–107 行使用：

```text
D = exact exposed-boundary distance squared
S = exact horizontal run squared
E = D - R^2 - S/4
accept iff E >= 0 and E^2 >= R^2*S
```

调用方 10 行保证 R>0；18 行把 S 构造成 dx²+dz²>=0；D 来自平方距离或 null。于是上述条件恰好等价：

```text
E >= R*sqrt(S)
D >= (R + sqrt(S)/2)^2
sqrt(D) >= R + sqrt(S)/2
```

E>=0 是避免平方后接受负 excess 的必要符号条件，代码已保留。run=0 时也退化为正确的 D>=R²。接受逻辑没有 sqrt、epsilon 或 rounded distance。

## 5. 固定 height-valid union 与递归

`street-foot-corridor.ts:16–19` 对整个 leaf 使用 `[maxY-.4,minY+R]` 的同一精确物理 face 裁剪域；任意 leaf 内 feetY 均满足每个保留面点落入其 `[Y-.4,Y+R]`。两端确实计算同一 U 的距离，上述 R+run/2 条件通过固定 U 的距离 Lipschitz 性质覆盖整个圆盘扫掠。

26 行 midpoint 使用 exact `(a+b)/2`，没有把报告标签喂回递归。各 leaf 的物理域/高度带可以不同，因为每个 leaf 已分别覆盖其整个段；leaf 相接端点也包含在各自闭域内。depth16 上限可产生保守 FAIL，未引入无证据提前通过。

## 6. 两个旧反例的静态复核

原 REPORT 的换 floor 两斜板例仍被 exact lower=-.4 裁到约 x<=-.174975 和 x>=+.174975；端点小平台不填满圆足投影。它不会通过新固定域证明。

REVIEW2 四矩形微孔例中，左孔边面对右矩形的 area 为 **严格负值** `-2*delta*gap=-2^-35`。71 行现在直接拒绝 contains，而非用 -1e-10 放宽；其余三孔边同理保留。端点到孔边约 .04m，小于 R=.35m，连初始圆盘都未覆盖，margin 为 false。constant feetY 的二分不改变该固定 union，也不能修复缺孔，所以最终应返回 null。

这是源码与数学推导，不是本审查运行的测试结果。只读的七条测试文本确实含同一 Float32 四矩形孔、宽有限平面、真实小缝/无关 floating face、倾斜面、不可达面、raise 的 ground false 语义、非法 motion 参数；父组的实际运行回执另行提供。

## 7. 报告标签及仍保留的范围限制

22 行已从每个 leaf 的 endpoint 距离最小值扣除 run/2，再全局取 min，修复 REVIEW2 的端点距离冒充连续下界问题。不过 `minimumBoundaryDistance`、`fixedFaceDomains` 坐标/高度等仍是 approximate report labels，不能用其浮点值重新决定接受或导入 authority。真正接受由 exact predicates 完成。faceCount 是投影前域数量，可能含后续排除的 zero-area 域；它不是完整的 face witness artifact。

`provesGroundedContact:false` 保留正确。新核只证明实际面高度带内的完整投影，不证明 horizontal flat-foot 全面接触，也不证明 raise/settle 中途或障碍中断时实际 grounded contact。未变 path v9-2 仍使用 axis raise/horizontal/settle；原 REPORT 的实际 ramp 中途悬空例仍属于 transport blocker。

完整 capsule clearance 仍依赖原 `streetCapsuleSeparation` 的浮点实现并以同一实体列表另行验证；本次 exact projection 改动没有让该 capsule 计算成为精确有理数，也没有补齐建筑/terrain/voxel/allocated bodies 或 road parcel、门叶动画、driver 路线、FIFO/hold、预算/导入权利合同。不得由本静态 projection 结论推导这些合同 PASS。

本审查证明对象是 code-owned affine material matrices 与其精确线性段；未来实际 cursor 的数值位置、矩阵生成、动态 obstacle recheck 和保存再生仍须按实际运行合同验证。非法矩阵长度/非有限数会抛错，未产生 certificate；调用方应维持生成的 finite affine 输入前提。

## 本次输入 SHA256

```text
f2d76cecb99b46d6ef2f4bb9707ae53d025bc63e9a1370846825ee427843c406  source/src/exact-planar-union.ts
7bb6590a91e71e2b0d86375d9bfc8225dbee45b64f3208a10a473c67c92b55ae  source/src/street-foot-corridor.ts
9bde99742401600195930fb7ede677ff02fe5502335f09754a2c5fd5156c11be  source/src/carrier-motion-path.ts
16b54824ee4eb4037df9741643168ae88785538d069b51b1a26aaa15b25da494  source/src/street-solid-authority.ts
9885276cbb1abea0c9b9ac55998d78183ec57594f86b50fc68930ab337273e45  source/src/carrier-solids.ts
ab7ec81f6cd985cb1175a58c9baea629258dbefdc970bade32d8fdb4d749dbba  source/src/station-parcel-solids.ts
1ff9d37ce182d146b398d7f41f3b653dfea8e85b349bdf5cb426021fcc07f624  source/tests/street-foot-corridor.test.ts
91c6e98af9eaa09d1dad0d944b13e619e28fc3a45f8fad45760e2c6c3d82245b  PLAN.md
```

`SOURCE-SHA256-REVIEW3.txt` 捕获完成时 source/src 全部文件 SHA。所有旧审查原件不改；本结论仅适用于以上 SHA，不评价后续其他 owner 修订。

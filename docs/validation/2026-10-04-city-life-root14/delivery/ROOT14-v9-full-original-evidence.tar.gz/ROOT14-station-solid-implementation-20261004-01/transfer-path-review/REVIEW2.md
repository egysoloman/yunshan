# REVIEW2 — fixed-face foot corridor independent read-only review

日期：2026-10-04。审查对象：新 `source/src/street-foot-corridor.ts` 与 path v9-2 的调用方式。原 `REPORT.md` 原件保持不变。本次未运行代码、World、Simulation、测试、build 或 GPU，未修改 source/CLOSED。独立子审查者复核，主审又逐边手算了下面的数值反例。

结论：**实数几何下修复了旧的可达楼板换集错误；当前数值实现仍可对非零真实孔洞错误 PASS。** `provesGroundedContact:false` 正确限定了证书语义；raise/settle 的实际接触支持仍未实现，不应提升为完整 supported-transfer 验收。

## 1. 固定物理 face 域的实数证明成立

`street-foot-corridor.ts:18–35` 从实际 Float32 matrix 重建 upward faces，以高度平面裁剪真实 face，没有新增 support rectangle。81 行为每个线性子段取：

```text
lower = max(a.y,b.y) - maximumSupportDistance
upper = min(a.y,b.y) + radius
```

对段内任何 feetY=Y，保留真实点高度 h 都满足 `Y-.4 <= h <= Y+R`。两端的 `circleCoverage` 在 82–84 行使用完全相同的裁剪投影并集 U，因而固定 U 的 exposed-boundary 距离 1-Lipschitz 推理合法：段内任一点离某端点至多 run/2，端点距离均至少 `R+run/2` 即可保证整段距离至少 R。每个递归 leaf 使用自己的固定 U，也不破坏证明；16 层上限可能拒绝可走路径，但不会在实数运算下放行未覆盖路径。

这条修复不再依赖 `streetSolidCapsuleSupport` 沿有限 face 的 plane-gradient Lipschitz 假设，因此原报告的 finite-edge 无界导数问题不进入新证明。

旧 `.08m` 两斜板反例被排除。旧顶面在新 lower=-.4 裁剪后分别只剩 `x <= -.174975...` 与 `x >= +.174975...`；两个 `.01×.01` 端点小平台不能补齐中间或完整圆盘，故精确几何下新函数拒绝旧反例。

## 2. 明确可精确表示为 Float32 的小孔假 PASS

问题位置：`street-foot-corridor.ts:38–44` 的 `contains`，尤其 42 行绝对面积容差 `1e-10`；64 行据此删除 exposed boundary。该容差将 polygon 向外放宽，随后却把放宽后的遮蔽结果当成真实实体并集。其单位是面积，短边会对应很大的实际距离容差。

四个普通轴对齐薄盒的顶面均 y=0，底面可取 y=-.125；水平矩形如下：

```text
delta = 2^-20 = .00000095367431640625
gap   = 2^-16 = .0000152587890625

L = [-1,0]   × [-delta,delta]
R = [gap,1]  × [-delta,delta]
T = [-1,1]   × [delta,1]
B = [-1,1]   × [-1,-delta]

a = (-.04,0,0)
b = (+.04,0,0)
radius = .35
```

各盒的中心与尺寸均能 Float32 精确表示。例如 R 的 x center 为 `.5+2^-17`、x size 为 `1-2^-16`；T 的 z center 为 `.5+2^-21`、z size 为 `1-2^-20`。y center=-.0625、thickness=.125 也精确可表示。该反例不依赖工厂、非法矩阵、特别大世界坐标或非 Float32 geometry。

真实实体并集留下孔洞 `(0,gap) × (-delta,delta)`，约 **15.26µm × 1.91µm**，两个圆足迹及整条 `.08m` 微段均包含该孔。高度裁剪带 [-.4,+.35] 保留四个真实顶面。

手算遮蔽过程：

- 左孔边是 L 的 x=0 短竖边，向外为 +x。针对 R 的左边，`value = -2*delta*gap = -2^-35 ≈ -2.91e-11`，不会触发 `value < -1e-10`。R 的该边与 outward 方向面积为正，故 direction 条件也不拒绝，64 行将左孔边隐藏。右孔边对称。
- 上孔边是 T 的 z=delta 边在 x∈(0,gap) 的切段。其 midpoint 对 L 的右短边，`value=-delta*gap=-2^-36` 落在容差内；outward 向下与该短竖边平行，direction 面积为 0。对 L 的顶边，point 正好在其延长线上且 outward 向 L 内，亦不拒绝。上孔边也被隐藏。下孔边对称。
- 孔的四条真实 exposed boundary 全被跳过，剩下的外方框距离两端约 .96m，超过 `.35+.08/2=.39m`，84 行立即通过，不触发递归。

完整 capsule 碰撞不能补救：平顶面在 feetY=0 仅与 capsule 底部相切，孔洞缺少物质并非碰撞障碍。两端也有真实小条顶面接触，但完整足投影确实有孔。

这是源码谓词的静态数学假阳性，不是已运行的测试结果，不声称默认城市含这种微孔。合同若是“完整圆盘”，非零孔必须保留；不能将其改称完整证书而静默容忍。

## 3. 最小保守修复要求

遮蔽边界只可在“另一个真实 polygon 确实覆盖该边外侧”得到证明时执行。若数值符号不确定，应保留该边作为 exposed boundary 或返回 FAIL；不能以 `abs(value)<=epsilon` 把真实 polygon 外点判为可遮蔽。

具体需要同时处理：

1. `contains` 的点/外侧覆盖谓词：使用精确或带可核验误差界的 orientation/half-plane 符号。边界共享与 outward 条件需要证明真实共线/共边，不能容差扩张。只删掉或缩小 `1e-10` 可消除本例，但尚不是完整数值证明。
2. 59 行的近平行/共线判断也含 `1e-10`，须一起改为保守判定；57–59 行 intersection cuts 在不确定时不能遗漏可能 exposed 的切段。
3. 16 行 orientation 使用绝对世界坐标 shoelace。用相对同一顶点的叉积降低消去误差，并保留精确或 interval fallback，避免小裁剪域的正负/零误判。
4. 29–35 行 clipping 交点必须确认为真实 face 中的点且满足高度带，或保守内缩；对已经近似的交点只做 exact-double orientation，并不能证明它仍位于原 Float32 face 的精确裁剪域。
5. 66、84 行的边界距离与 `R+run/2` 比较需要 conservative distance lower bound 和 run upper bound，或 exact comparison/fallback。当前没有 directed rounding 或误差余量，距离边界相等时不具严格数值保证。

这些保守修改可产生更多 FAIL；正常 shared seam 的接受率必须在保守安全之后另行证明，不应先消去 seam 边界来恢复 PASS。实际工厂 rail-curb/loop-guard 的宏观 FAIL 与本微孔修复独立，不能通过放宽投影证明绕过。

## 4. 支撑语义与 path v9-2 的组合界

新证书证明的是每个圆足投影点有实际 upward face 位于 `[feetY-.4, feetY+R]`。这个上界允许 face 高于水平 feet 面；只有与对同一 material solids 的完整 capsule clearance 一起使用，才能保证它不穿入下半球。它并不证明水平 flat-foot 全面接触、实际 grounded contact 或游标任意暂停点有接触。

72、90 行显式 `provesGroundedContact:false` 与实现一致。例如宽坡 `h(x)=.5x`、capsule feetY=`.35*(sqrt(1.25)-1)≈.041312`，圆盘表面高度在 [-.175,+.175] 内，满足新高度带且 capsule 可相切；上坡边仍高于水平 feet 面。应把它称为 rounded-body 的完整真实 floor **projection** 证书，而非完整平足接触证书。

`carrier-motion-path.ts:43–49` 用新函数证明 plateau，并在每个非零 vertical raise/settle 上单独投影证明；48 行仍对每个非零 segment 做 capsule sweep。这修复了“vertical projection 完全未查”这一范围缺失，且保留了 mandatory capsule 检查。但是 axis raise/settle 路线未改变，实际坡道上 `.003m` 预算停在 `.007m` raise 中途仍会悬空。证书的 false 标记准确表明该剩余限制；PLAN 的 newly blocked cursor stops on real support 仍未满足。

新函数本身不运行 capsule 检查，所以其证书不能脱离该 mandatory 组合；尤其上方平板也可能独自通过投影函数后被胶囊检查拒绝。未来导入仍必须再生 authority，而非信任 certificate label。

## 5. 证书报告值的精度

84 行把各 leaf 两端距离最小值保存为 `minimumBoundaryDistance`。它不是已证明的整段最小值。Lipschitz 可证明的下界是每个 leaf 的 `min(first.distance,last.distance)-run/2`，再在全部 leaf 上取 min；应用数值 conservative bound 后还须扣相应误差。可改为该下界，或把现字段改名为 `minimumMeasuredEndpointBoundaryDistance`，另加真正的 `certifiedMinimumBoundaryDistance`。

`fixedFaceDomains` 当前只保存 leaf 高度带和 faceCount，不能仅凭证书数据重建或审查所用的 face 域。若需要独立复核 artifact，应记录实际 solid/face witness identity 与 matrix bits/裁剪域，或明确证书只在 code-owned 当前输入上即时有效且需重新计算。

## 本次输入 SHA256

```text
e2744d747a5995fae5ab8d0c6c01275d81b3297f233429f9ccc218b8f84d73fd  source/src/street-foot-corridor.ts
9bde99742401600195930fb7ede677ff02fe5502335f09754a2c5fd5156c11be  source/src/carrier-motion-path.ts
16b54824ee4eb4037df9741643168ae88785538d069b51b1a26aaa15b25da494  source/src/street-solid-authority.ts
9885276cbb1abea0c9b9ac55998d78183ec57594f86b50fc68930ab337273e45  source/src/carrier-solids.ts
ab7ec81f6cd985cb1175a58c9baea629258dbefdc970bade32d8fdb4d749dbba  source/src/station-parcel-solids.ts
91c6e98af9eaa09d1dad0d944b13e619e28fc3a45f8fad45760e2c6c3d82245b  PLAN.md
```

新增 `SOURCE-SHA256-REVIEW2.txt` 捕获本次完成时 source/src 全部文件 SHA。原 REPORT SHA 为 `eaa4b011db33194d5c1098a9f9975be8a979dbfa444f1c104a230d9905c7d222`；原 SHA manifest 也未改。上述审查仅针对列明 SHA，不评价其他 owner 后续修订。

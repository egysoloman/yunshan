# ROOT14 transfer path independent read-only review

日期：2026-10-04。结论：**BLOCKED / 未证明完整支持路径**。本报告不是 factory、Simulation、测试、build、GPU 或默认城市验收结果；均未运行。未修改 source、共享输入、CLOSED、Git 或 Library。仅创建本 `transfer-path-review` 目录。审查依据为组 `PLAN.md` 的完整 `.35R / 1.72H` 连续胶囊、完整圆足、真实移动预算、实际支持位置停留与所有真实障碍合同。

主审输入是 `source/src/carrier-motion-path.ts`、`carrier-solids.ts`、`station-parcel-solids.ts`、`street-solid-authority.ts`；辅助只读了 station-throats、network-solid-recipe、controller、types 和现有 primitive 测试文本，并对 src 做了符号搜索。独立子审查者复核了足证明的数学反例，未运行代码或写文件。

## 1. 圆足 Lipschitz 证书可以错误 PASS

位置：`carrier-motion-path.ts:32–46`，尤其 36、39 行；`street-solid-authority.ts:244–267`，尤其 245 行。

对固定投影并集 U，内部点到 exposed boundary 的距离确实是 1-Lipschitz；两端距离至少 `r + run/2` 可覆盖段内整个圆盘。但当前每个端点按当前位置的 `streetSolidCapsuleSupport` 是否落在 `[feetY-.4, feetY]` 重新选楼板。两端测的是不同 U，段内资格还会变化。递归深度 16 不能补救 39 行直接通过的分支。

可兼容 `.08m` 微段、且不被连续胶囊碰撞拒绝的纯数学反例：

```text
r = .35; a = (-.04,0,0); b = (.04,0,0)
c = r*(sqrt(2)-1)
左宽斜板顶面 hL(x) = -.39 -(x+.04) -c
右宽斜板顶面 hR(x) = -.39 +(x-.04) -c
两顶面的投影均覆盖 [-2,2]^2；可由普通旋转薄盒表达。
另在 a、b 各放顶面 y=0、投影 .01×.01 的小平台。
```

宽斜面上的下半球支持公式给出 `sL(x)=-.39-(x+.04)`、`sR(x)=-.39+(x-.04)`。

| 位置 | 左斜板 support | 右斜板 support | 算法所选投影并集 |
| --- | ---: | ---: | --- |
| a | -.39，入选 | -.47，排除 | 左宽板加小平台，边距 >=1.96 |
| 中点 | -.43，排除 | -.43，排除 | 仅小平台，中心不在任一投影内 |
| b | -.47，排除 | -.39，入选 | 右宽板加小平台，边距 >=1.96 |

端点 `supportAt` 均取小平台 0。39 行阈值只有 `.35+.08/2=.39`，直接 PASS；中点调用 coverage 则 FAIL。全段两斜板 support <=-.39，小平台只有端点与 capsule 相切，中间在下半球之下，所以 `physicalStep` 的连续碰撞不能纠正该假证书。此反例证明通用内核的错误，不声称默认工厂已有该排列。

最小修复方向：先明确要证明的 support 语义，再把证书绑定到**整个段持续合格的固定真实 floor 子集**；给每个入选 primitive 沿段的 support 上下界/资格区间证明，资格变化处必须分段。只有固定子集资格已证实，才使用 exposed-boundary Lipschitz 提前通过。只补一个 midpoint 或改小 `.08` 不构成完整连续证明，也不能填入虚构 gap rectangle。

### 可审查 helper 的安全条件与 gradient 界

不能一般把 `streetSolidCapsuleSupport` 的 Lipschitz 常数取为上表面最大 `||gradient||`。有限 domain 的水平板 gradient=0，但中心在板外距边 `d∈(0,r)` 时其 support 为 `top + sqrt(r*r-d*d)-r`，导数绝对值 `d/sqrt(r*r-d*d)>0`，在 d 接近 r 时无界。

最小且保守的 affine helper 可以按**真实 face**保存 matrix bits、polygon、plane gradient g 和 contact witness，而非把整块 solid 的所有 upward face 因一个 support 值一起选入。对宽 planar face，无约束 lower-sphere contact 极值为 `q(p)=p+r*g/sqrt(1+||g||²)`，support 为 `s(p)=h(p)+r*(sqrt(1+||g||²)-1)`。只有证实整段 q(p) 始终位于该真实 face domain 内，才可使用 affine support 与 `L=||g||`。对于凸 face 和直线 p，这个 domain 条件可由 q 的两端在真实 polygon 内证明；整个 swept circular disk 在该 face 内是更强但简单的充分条件。有限 edge/corner 活跃时须另外推导 support 区间/导数界；不能复用 plane-gradient 界。

然后必须证明每个固定 face 的 `s(p)-Y(p)∈[-.4,+EPS]` 对整段成立。若 support 和 Y 均 affine，检查该**差值**的两个端点足够；若只用中心加 Lipschitz margin，margin 必须含 support 与 Y 的共同变化。只要求 support 落在宽包络 `[minY-.4,maxY+EPS]` 不足以证明每点都合格。最后只对这个持续合格固定 face 投影并集 U 做圆盘 exposed-boundary 证书。

这条 conservative affine 条件会拒绝部分真实多板接缝（单个 face 的接触点跨出 domain，虽然多个 face 合起来能支持），所以 helper 足以安全地产生部分 PASS 或更多 FAIL，不能保证所有正常接缝可走。要恢复这些正常接缝，必须明确 edge/corner 切换区间或合并真实共面的域并集后给共同证书。保持实际 FAIL 优于把资格边界忽略。

## 2. raise/horizontal/settle 可暂停在没有实际接触支持的位置

位置：`carrier-motion-path.ts:49–69, 85, 103–120`。

66 行对 raise、horizontal、settle 三种非零段都调用完整 capsule 连续扫掠。这一点成立于**已经传入的 solids**。但是 61 行仅给 plateau 的水平段做投影证书，raise/settle 没有接触支持证书；85 行只检查起点碰撞。`advanceCarrierPath` 可在任何垂直段中途耗尽预算。

真实固定坡道也是该问题的实例：station ramp 在横向 4m 下降 .35m，坡度 `.0875`。在同一宽平面内部上坡 `.08m`，capsule support 增加 `.007m`。目前先原地 raise `.007`、再横移；若本帧预算 `.003m`，返回的位置比原支持高度高 `.003m`，与坡道无接触。反向下坡也可暂停在 settle 中途；水平 plateau 多数位置也高于当前坡面。即使 coverage 仍因 `.4m` 容差为真，这不证明“实际支持”。新增障碍后停在当前 cursor 位置可能永久悬空。

另一个直接输入实例：起点在宽平板真实支持上方 `.2m`，无碰撞；投影仍在 `.4m` 范围内，因此 kernel 可接受并安排 settle，未首先证明实际起点接触。

最小修复方向：对同一 planar face 的 ramp 微段，沿其真实 capsule-support affine 高度直接走斜段，保留完整连续 capsule sweep，游标任意截断点都仍接触。接缝/curb 的接触高度可能是有限边的非线性曲线，应给该曲线及扫掠可核验证书；未实现的过渡应 FAIL。每个可暂停点和起点必须有实际支持证明；避免用原地 raise 后悬空平移作为“完整支持路径”。动态障碍的 recheck 应在 commit 游标之前完成，并保持已持有的权利。

## 3. capsule contact 与完整 flat-foot 支撑不能混称

位置：`street-solid-authority.ts:153–215, 217–267`；`carrier-solids.ts:93–97`。

`streetSolidCapsuleSupport` 209 行计算的是下半球接触，不是 `streetSolidFootTop` 的水平圆足最高面。宽平面 `h(x)=mx+b` 上：

```text
capsule feet Y = h(center) + r*(sqrt(1+m*m)-1)
圆足投影内最高面 = h(center) + r*abs(m)
```

非零 m 时二者不同。例如 m=1 且 capsule feet Y=0，中心地面约 -.145，上坡圆足边约 +.205，下坡圆足边约 -.495。圆胶囊可以相切且不重叠，但水平 flat-foot 面会穿入上坡一侧；下坡边也低于 `.4m` 可达带。245 行却因**整块 solid 的一个最高 capsule-support 值**合格而纳入其所有 upward face 投影，未逐足点验证高度。

因此当前函数精确计算的是“由中心资格筛选的 real solid 投影并集覆盖圆盘”。它没有证明完整水平足面接触、逐足点 `.4m` 可达带、或每一时刻实际支持接触。应在接口/证书中分别记录 capsule 接触、圆盘实际投影覆盖及必要的逐点高度约束；不得把 `covered=true` 提升成另一种语义。坡道的正常 capsule-contact 可以保留，但合同措辞和证书必须一致。

## 4. 实体障碍输入与前排驾驶员路线仍是 blocker

位置：`carrier-motion-path.ts:82–85`；`carrier-solids.ts:26–32`；`street-solid-authority.ts:129–141`；`network-solid-recipe.ts:86–133`。

kernel 固体列表是 network recipe、所选 carrier shell 和可选 `otherCarrierSolids=[]`。network recipe 遍历 edges/nodes 与 station parcel；没有建筑实体、terrain、placed voxels 或 allocated actor bodies。`WorldDefinition` 有 buildings、mountains，voxels/actors 在 SimState，但 kernel 未接收其权威数据。它的 PASS 仅相对于这个有限列表，不能满足 PLAN 的全部真实障碍合同。

两种 board/exit 都经中心 `(0,slot.z)` 再横移。road 前排 slot.z=1.75 的中心点距 driver `(0,1.95)` 仅 `.20m`；rail 最前排 slot.z=6.8 距 driver `(0,7.05)` 仅 `.25m`。两颗 `.35R` 身体需要水平中心距至少 `.70m`。当前没纳入驾驶员可掩盖问题；纳入后这些预设中心路线确实会堵。slot 本身与 driver 分离不代表通往 slot 的路线分离。

最小修复方向：建立必需的障碍输入 bundle，包含动态其他 carrier、实际已分配人身 capsule、建筑/terrain/placed voxels，并由 code-owned authority 构建。绕 driver/已占 slot 计算有限 cabin 路线且检查身体扫掠；例如在 driver 前提前转向的 diagonal 候选可检查，不应让驾驶员从 collision 列表消失。若 `.70m` clearance 无可行路径，保留 FAIL/降低可达容量。

静态 diagonal 候选的最小界：设 slot `(q,zS)`、driver `(0,zS+δ)`、中心转弯点 `(0,zS-t)`，driver 到 diagonal 线的距离为 `(δ+t)*q/sqrt(q*q+t*t)`（投影在段内时）。仅把中心提前 `.5m` 仍不够：road q=.75, δ=.20 给 `.582m`；rail q=.9, δ=.25 给 `.656m`，都小于 `.70m`。flat berth 下 road t=1.0 给 driver `.720m`；rail t=.7 给 driver约 `.750m`、前一同侧 row约 `.789m`，可以作为候选，仍须用实际 Float32 pose、其他 allocated bodies 和完整 capsule sweep验证，不是验收 PASS。

此外 path 83–84 行的静态 broadphase Y 固定为 parcel.center-.4 到 parcel.floor+.4，再由 nearby 扩高 1.72，未按实际 startingPosition 或后续 plateau 的最高值扩展。若路线吸附到另一个更高 walkable solid，后续身体可升出该查询窗，窗上方的 world solid 被永久遗漏。实际正常平泊 platform 是否触发未运行验证。修复可逐 segment 以真实扫掠范围重新查询，或先证明整条路径的高度 envelope 后一次收集完整 obstruction 集。

## 5. road 平台与门叶开合还没有路径证明

`station-throats.ts:15, 49–64` 只为 maglev/lightRail 生成 parcel。`carrier-motion-path.ts:77–78` 因无 parcel 对 road 直接 FAIL；当前可以说 road shell primitive 已定义，不能说 road 上下车已实现。最小修复是为真实 road endpoint lane/orientation/berth 设计 code-owned parcel 和实际有限支持过渡，再调用路径核；不要把 rail parcel 或逻辑 node 当 road 支持权威。

kernel 84 行总用 `carrierStreetSolids(..., true)`，只证明**全开**门叶的静态姿态；没有检查从 closed 到 opened 的有限叶片扫掠或 partial opening 时身体通行。正门全开时实际 1.2m 口宽大于 .70m body diameter；壳体 flat cabin 净高 1.85m，大于 1.72m height。这些静态尺寸不能证明开门运动。未来 cursor 必须等待真实足够门宽，并核验门叶 sweep 对人/其他实体的碰撞；已占门叶扫掠区应保持 finite WAIT/FAIL，而非穿过。

## 6. 预算游标：正常算术成立，暂停/导入前提未具备

位置：`carrier-motion-path.ts:67, 100, 105–120`。

对 code-owned path、整数有效 segmentIndex、`0<=segmentDistance<=segment.horizontalBudget`、有限非负 budget，循环每次消费 `min(remaining, length-distance)`；spent 不超过 budget，位置按该已认证 segment 插值，traversed 包含所走子段，没有直接设置远端终点。由于当前每个 segment 都是纯垂直或水平，67 行的 `horizontalBudget` 实际等于 segment 的空间长度；路径消费长度等于 spatialDistance，而非 horizontalDistance。坡道 staircase 每 .08m 水平还消费 .007m 垂直，使 4.8m/s 成为此轴折线的空间速度。应把字段改成真实含义并明确玩家/NPC预算单位，不能把 NPC business-minute 预算转换成玩家 real-second 预算。

函数未验证 cursor 或 budget。负数/NaN budget 在有非零 segmentDistance 时会跳过 while，返回 segment.from；越界 index/distance 可外插、卡死或抛错。未来 marker/body/layout/import 校验和 path 再生必须拒绝非法 cursor；kernel 入口也应验证有限非负预算及 segment 游标范围。在合法 partial cursor 上预算 0 应稳定返回现位置。

仅符号搜索显示这份审查输入中 `carrierTransferPath` / `advanceCarrierPath` 尚无 src 调用；只看到 renderer 的 transportMotion 门 fraction cast。故4.8 real-second调用、NPC原分钟预算和 deferred minutes、动态阻塞、FIFO/hold、fare/occupancy提交、import再生与未来继续行为仍未取得运行或集成证据。本报告不宣布这些合同通过。

## 7. 接缝与有限实体的已知边界

实际 shell/platform 是由 renderer 同源 Float32 matrix 生成的有限 boxes，而不是 query-only rectangle；streetCapsuleSeparation 对给定直线段计算完整 `.35R / 1.72H` capsule 的 Minkowski sweep。threshold 与 rail platform 在64位参数上有 .2m横向重叠；ramp 用 normal thickness 且以真 top 端点连接 platform。这些是可取的基础，不能消除上述 support/obstruction 问题。

未运行实际 v9 factory，未声称真实默认站点一定有或没有 Float32 微缝、站梁/柱/curb/rail碰撞。正常 ramp 上前述 mid-raise 暂停问题已由参数直接推导，不依赖工厂异常。生产验收仍应使用真正 material matrices，逐 actual berth/side/slot 保留 FAIL receipt，包括端点反向、接缝高度变化、坡道与实际 driver/occupancy、动态其他 carrier 和门叶动画。

## 源码 SHA 与只读边界

四个主审文件在初读和报告生成前复核 SHA 完全一致：

```text
9abf8eef206a7641d4bca0796561ee93099990d73f355654828b378a8f06e1a1  source/src/carrier-motion-path.ts
9885276cbb1abea0c9b9ac55998d78183ec57594f86b50fc68930ab337273e45  source/src/carrier-solids.ts
ab7ec81f6cd985cb1175a58c9baea629258dbefdc970bade32d8fdb4d749dbba  source/src/station-parcel-solids.ts
16b54824ee4eb4037df9741643168ae88785538d069b51b1a26aaa15b25da494  source/src/street-solid-authority.ts
b90f03a2d295d5aa2d47309dfcce6ede4e77637fbfe764493ca19d0e393ad982  source/src/station-throats.ts
7d7eee485d5b685648240a99d6527145c3ce5cf3bcf2be2cb911b9d6d5992f18  source/src/network-solid-recipe.ts
dd8c937107fa82d69fb7f12ff0eb0df5ff31732c261912469aa3e04d5b62a01b  source/src/types.ts
659ad9a34498af000d0b9df66deb682ec277d4d72cbceea739d8f293045ee902  source/tests/carrier-station-solids.test.ts
8c16bdfdfcabec95015b2026a0ee446d7fad8e9343c1cffa598ce3b8de98e2b4  source/tests/street-solid-authority.test.ts
b27e4f6a2bbebc16355bb60423e0639c3451971975d896b477a966956f33f1e0  PLAN.md
```

`SOURCE-SHA256.txt` 记录报告时 `source/src` 全75个文件的 SHA256（含 style.css），供父组冻结核对；该 manifest 不表示审查了全部75文件。controller 初次辅助读取 SHA 为 `506142691aa155f977c43950448b03e787cba54cf933b04b84a6bcd802b34b64`，manifest 生成时已被其他 owner 改为 `50aee0030f9e00280fef6659ac1fd3f2457f5559ca91ca901be985319c7725f4`。本审查未修改它，也不评价该并发变化；核心四输入未变。

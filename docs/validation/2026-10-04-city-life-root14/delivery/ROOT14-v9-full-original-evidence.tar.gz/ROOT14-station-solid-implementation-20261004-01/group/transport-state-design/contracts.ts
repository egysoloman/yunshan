/**
 * STATIC DESIGN ONLY — NOT INSTALLED, BUILT OR EXECUTED.
 * No imports from source, implementations, migrations or generated authority.
 * Proposed independent layout9 contract; save envelopes1/2/3 and old NPC
 * motion markers remain unchanged. REPORT.md supplies integration boundaries.
 */
export interface FeetV9 { x: number; y: number; z: number }
export type ActorKeyV9 = 'player' | `citizen:${string}`;
export type EngineeredCarrierModeV9 = 'road' | 'maglev' | 'lightRail';
export type TransferActionV9 = 'board' | 'drive' | 'exit';

/** Identities plus the ACTUAL incoming berth pose, retained until departure.
 * No nearest-node tolerance, outgoing-edge replacement or imported pose grants
 * authority: import must reproduce this from trusted world + vehicle progress.
 */
export interface StoppedBerthV9 {
  edgeId: string;
  nodeId: string;
  progress: 0 | 1;
  direction: -1 | 1;
  position: FeetV9;
}

/** All request serials <= batchTailSerial were accepted while opening.
 * Opening -> open seals admission; open/closing/blocked take no new requests.
 * FIFO is derived by sorting requests for this vehicle by serial, never by
 * map iteration, actor tier, imported array order or mutable priority labels.
 */
export interface CarrierHoldV9 {
  berth: StoppedBerthV9;
  phase: 'opening' | 'open' | 'closing' | 'blocked';
  batchTailSerial: number;
  blockedReason: null | 'door-sweep' | 'body' | 'support' | 'death' | 'authority';
}

/** Regenerate segments from request start + held berth + real named slot.
 * Normal form: 0 <= index < regenerated segments.length, and
 * 0 <= distance < regenerated segments[index].budgetCost.
 * The exact completed endpoint is never persisted as a pending cursor: its
 * geometric, fare and occupancy commit occurs in the same synchronous step.
 * Any save/blocked endpoint must itself have actual full-foot support, not
 * merely a projected footprint or a remembered earlier supported point.
 */
export interface TransferCursorV9 {
  segmentIndex: number;
  segmentDistance: number;
}

/** These are BUSINESS minutes from extension.lastUpdate, not wall/performance
 * seconds or mutable day/hour. The existing runtime.peopleElapsed is still
 * the sole deferred actor-minute bank. Blocked/queued time cannot accumulate
 * extra walk credits. Times are checked against the candidate business clock.
 */
export interface NpcTransferClockV9 {
  acceptedAtBusinessMinute: number;
  eligibleSinceBusinessMinute: number | null;
  lastObservedBusinessMinute: number;
}

interface TransferRequestBaseV9 {
  serial: number;
  vehicleId: string;
  action: TransferActionV9;
  slotId: string;
  side: -1 | 1;
  startFeet: FeetV9;
  cursor: TransferCursorV9;
  phase: 'queued' | 'moving' | 'blocked' | 'deadBlocked';
  blockedReason: null | 'body' | 'support' | 'wallet' | 'death' | 'authority';
  /** Frozen trusted quote: drive/exit=0, engineered passenger board=4.
   * Cash is NOT subtracted on acceptance. The live uncompleted quote is a
   * spendable-cash lien; all ordinary debit sites must honor it. Never trust
   * an imported fare as the tariff. Dead requests have no payable lien.
   */
  fare: 0 | 4;
}

export interface PlayerTransferRequestV9 extends TransferRequestBaseV9 {
  actor: { kind: 'player' };
  clock: { kind: 'real' };
}
export interface CitizenTransferRequestV9 extends TransferRequestBaseV9 {
  actor: { kind: 'citizen'; citizenId: string };
  clock: { kind: 'business'; observation: NpcTransferClockV9 };
  /** Original travel intent survives cabin transit/physical exit. This is an
   * existing building identity, not an imported physical arrival destination.
   */
  stopNodeId: string;
}
export type TransferRequestV9 = PlayerTransferRequestV9 | CitizenTransferRequestV9;

/** Committed physical bodies, including a dead body's still occupied slot.
 * boardSerial records the consumed request; imported history cannot replay a
 * completion. mode=driver only grants control while alive and duly licensed.
 * Runtime.riders and player.vehicleId/driving are checked mirrors, not a
 * second v9 movement authority. Exit keeps this row until actual completion.
 */
export interface CabinOccupancyV9 {
  vehicleId: string;
  slotId: string;
  boardSerial: number;
  mode: 'passenger' | 'driver';
  stopNodeId: string | null;
}

/** Add only as state.transportMotion for code-owned current-v9.
 * Limits: <= citizens+1 requests/occupancies, <= generatedFleet holds/doors;
 * every map is a plain non-array object; all fields strictly shape-checked.
 */
export interface TransportMotionStateV1 {
  version: 1;
  /** Positive safe integer; reject exhaustion, never wrap/recycle. */
  nextSerial: number;
  requests: Partial<Record<ActorKeyV9, TransferRequestV9>>;
  occupants: Partial<Record<ActorKeyV9, CabinOccupancyV9>>;
  holds: Record<string, CarrierHoldV9>;
  /** Actual finite leaf displacement fraction; renderer already reads this
   * name. Exactly the hold keys; finite [0,1]; absent hold means closed=0.
   * Rendering and obstruction queries consume the same fraction/descriptors.
   */
  doorFractions: Record<string, number>;
}

/** Add only to Runtime; body, marker AND persistedModules declaration pair.
 * Neither presence of this marker nor a save's layout label authorizes a path.
 */
export interface TransportMotionRuntimeMarkerV1 { transportMotionVersion?: 1 }

/** Never serialized: created solely by trusted world regeneration. */
declare const trustedPlanV9: unique symbol;
export interface CodeOwnedTransferPlanV9 {
  readonly [trustedPlanV9]: true;
  readonly points: readonly FeetV9[];
  readonly segments: readonly {
    from: FeetV9; to: FeetV9; budgetCost: number;
  }[];
  readonly fullySupportedAtEveryPersistableCursor: true;
  /** Derived diagnostics only; an imported matching signature is insufficient. */
  readonly diagnosticSignature: string;
}

/** Fresh runtime host clock: reset after import/hidden-tab/pose ownership
 * changes. Main supplies only actual post-acceptance visible seconds and caps
 * stalls consistently with existing walking. Never save performance.now(),
 * charge seconds before acceptance, multiply by state.speed, or bank blocked
 * real time. Player uses exactly 4.8 metres per supplied real second.
 */
export interface TransportRealIntervalV9 { secondsAfterAcceptance: number }

/** Nonserialized staged import cache; activated only after all old AND new
 * validators/load hooks succeed. Reject import atomically on invalid structure,
 * cursor, current body/support or static path. Future dynamic blockage may be
 * restored at the same supported cursor, without completion or cash changes.
 */
export interface RegeneratedTransportCacheV9 {
  plansBySerial: ReadonlyMap<number, CodeOwnedTransferPlanV9>;
}

/** Pure proposal: separate structural declarations from trusted-world checks.
 * Own-property checks reject nulls, partial pairing, unknown versions and
 * standalone manifest claims before codec reordering can erase declarations.
 */
export declare function validateTransportDeclarationV1(
  state: unknown,
  runtime: unknown,
  trustedLayout: string,
): void;

/** This capability is NOT the current carrierTransferPath implementation:
 * REPORT records its missing geometry/dynamic/support proofs and actual FAIL.
 */
export declare function regenerateTransportPlansV1(
  trustedWorld: unknown,
  candidateState: unknown,
  candidateRuntime: unknown,
): RegeneratedTransportCacheV9;

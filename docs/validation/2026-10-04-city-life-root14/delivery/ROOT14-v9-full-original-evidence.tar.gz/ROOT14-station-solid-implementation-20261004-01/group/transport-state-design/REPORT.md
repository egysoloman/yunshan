# v9 transport motion 持久合同：只读静态设计

本目录只提供供 root13 审查的提议。未接入 `source`，未修改 src/tests/build，未运行 World、Simulation、factory、测试、typecheck 或 build。`contracts.ts` 为独立静态类型草案，没有实现或源码导入。另一 native4 候选没有安装，本合同不定义 native4 envelope，也不覆盖其方案。原读入字节的 SHA256 见 `READ-SHAS.json`。

交付前复核59个读入文件：58个SHA不变；其他owner并行修改了 `source/src/carrier-motion-path.ts`，由本报告原读 `9abf8eef206a7641d4bca0796561ee93099990d73f355654828b378a8f06e1a1` 变为 `9bde99742401600195930fb7ede677ff02fe5502335f09754a2c5fd5156c11be`。`source-as-prepared-transfer01/src/carrier-motion-path.ts`仍与原读SHA完全一致。下文该文件行号/缺口针对原读版本；新版本没有被本报告重新验证。此并行变化不是本目录写入，不能将本报告视为对新工程的结论。

**结论：独立 transport marker/body 可以准备，现阶段不能安装后声称真实登离合同成立。** 实际 transfer01 为 FAIL；现有 kernel 还缺少所有必要障碍和任意阻停游标的真实支撑权威。v9 模式不得退回旧瞬移登离作为完成路径。old6/7/8 必须继续原分支、原 save 1/2/3 与原 NPC motion 版本；静态设计不是旧 savebytes/future24 的验证结果。

**已读事实和提交边界。** `PLAN.md` 声明 base 是 root exact295 snapshot。现源码 `types.ts:37–46` 只有普通 actor/vehicle 状态，没有 transport body；`simulation.ts:75–105` 有旧 `riders`/`driving` 与独立 `npcMotionVersion:2`。`renderer.ts:1030` 已用临时断言读取 `state.transportMotion.doorFractions`，但并无 schema/marker 校验。

| 现有位置 | 实際行为 | v9 需要截断的位置 |
| --- | --- | --- |
| `simulation.ts:2314–2318` ride/drive | 35m 邻近、非 moving 即接受；立即扣费、emit fare、vehicleId、passengers++、把 feet 写成 vehicle.position | 在任何修改前，转入纯检查及入队；最后一个物理段完成才提交 |
| `simulation.ts:2320–2322` leaveVehicle | 最近节点 45m 内即把 feet 写成 node.position，清控制/occupancy | 精确 endpoint berth 和真实 cabin→door→platform→ramp 路径；完成前保留原 rights |
| `simulation.ts:936–946` traffic arrival | 到端点即标 NPC arrived 并 passengers-- | 只记录到站观察/请求真实出口；不能提前清占位 |
| `simulation.ts:977–984` traffic departure | 同一个到站 tick 选择新 edge，改 direction/progress 或原地反向 | 保留 incoming edge/pose，hold 全程禁止此修改；离站还需要真实连续 orientation/route authority |
| `simulation.ts:988–989` player follow | 每 traffic phase 覆盖成载具中心 | v9 occupancy 的实际 slot feet；pending exit 由 cursor 独占 |
| `simulation.ts:1652–1665` NPC ride/arrival | 随车中心；到站直接落 logical node，删 rider，重建 route | 随真实 floor slot；实际 exit 完成后才删 mirror，并以出口真实 feet 重建步行 |
| `simulation.ts:1693–1699` NPC board | 40m 内可瞬间扣4/加occupancy/移到中心 | 同一纯接受与队列，消费这个 actor 已有 business-minute 预算 |
| `simulation.ts:1613` death | 直接清 rider，扣 passenger，不证明尸体已离开 | v9 必须另行保留真实 body/slot/support；不可执行这段旧清理 |
| `main.ts:195–202,216` frame | vehicleId 空就继续走及回写 feet；只有已乘车才 syncPassenger | board pending 尚无 vehicleId，因此必须同时阻止 walking/feet/focus 覆写并 sync 真 cursor |

**最小新增持久状态。** 选择 `SimState.transportMotion?: TransportMotionStateV1` 与 `Runtime.transportMotionVersion?:1`，沿已有 body-in-state/marker-in-runtime 结构。body 含 `version:1`、`nextSerial`、`requests`、`occupants`、`holds`、`doorFractions`；精确形状见 `contracts.ts`。不新增 Vehicle/Citizen 上的 path、geometry、seatCapacity 或 arrival 标签，不序列化路径点、证书、签名权威、空间索引、性能计数或 DOM clock。

请求按 actor 唯一；actor key 为 `player` 或 `citizen:<真实id>`。`nextSerial` 正安全整数且大于所有活跃 request/occupant 序号，不可回绕。请求保存原 startFeet、action、actual slotId、side、cursor、状态和 NPC 观察时钟；hold 保存原 incoming berth 的 edge/node/progress/direction/position 和当前开闭状态。队列按 serial 排序派生，不依赖对象 key 顺序。`doorFractions` 是唯一门开度事实，直接接现 renderer，键恰为 holds 键，非 hold 车辆门关闭。

occupants 是 v9 物理占位权威；`runtime.riders`、`player.vehicleId`、`inventory.driving`、`runtime.driving` 仍是既有系统读取的严格镜像。exit 请求与自身 occupant 可同时存在；board/drive 请求不得已有 occupant。pending board 的命名槽位是 reservation，不计 `Vehicle.passengers`；完成后变 committed occupant 并计数。活 passenger/driver 加尚未真实移出的 dead body 都占真实槽位；不能以逻辑死亡腾出它。`Vehicle.passengers` 在 v9 等于 committed 物理 occupant 数，包括 reserved driver anchor 上的 body；pending board 不在其内。此变化仅限 v9。

`carrier-solids.ts:26–33` 给 road4、rail24 passenger slots 及另一个 driver anchor，旧 road10/loaded2/flight80/edgeCapacity 的容量保持旧分支。v9 同一车的 committed occupants + uncompleted board reservations 必须 slot 唯一；exit 持有自己的旧 slot，不另占第二格。导入必须从代码 `carrierSlots`/`carrierDriverSlot` 重建槽位，不能只验 imported slot 字符串。当前没有工程 cargo bay/装载占体描述，不能用 cargo>0 时旧“2座”数字代替空间证明。

**配对与历史兼容。** trusted layout 来自 `Simulation.world` 或 `selectSavedWorld` 代码重新生成并匹配的候选；导入 `layoutVersion` 字段无授权效力。

| 可信布局 | 允许的 transport 声明 |
| --- | --- |
| current-v9 | body 非 null/数组且 version 数值1；runtime marker 数值1；persistedModules 中恰一次 transportMotion；三处均必须存在 |
| old6/7/8、其他旧布局、未标可信布局 | body、marker、manifest 三处均不存在 |
| 任意布局 | 未知版本、部分存在、null、孤立 manifest、重复 manifest 均拒绝 |

先用 `Object.hasOwn` 识别 body/marker，manifest 独立声称也触发校验。必须在 importer 删除 manifest (`simulation.ts:2386`) 前检查。`PERSISTED_MODULES:38` 仅末尾追加 `transportMotion`；旧过滤结果和 key 插入次序不变。constructor 只在可信 current-v9 安装空 body/marker，load hook 不得给旧 saves 补值。saveVersion getter 和 export 的 envelope1/2/3、v3 `motionVersion`、NPC `npcMotionVersion:2`/stair cursors 不改。已有“无 transport 的 v9”准备档不能默认迁移：要么拒绝，要么另经 root 批准明确标识一个历史运动合同；不得静默补建新 authority。

**接受过程应先全证后单次入队。** 先只读判断 actor 活着、当前无其他运输拥有权、许可与价格来自 code、槽位未占/未保留、berth 为精确 endpoint、车未移动且 manual speed 为0、station parcel 存在、车位姿与 trusted edge arc/road lane recipe 一致。然后完整证明 supported start→platform/ramp→真实 opening/threshold→命名 cabin slot；出口反向同理。门开启/关闭的有限实体 sweep 也必须避开所有 body。两个 side 只能来自真正工程的平台，不搜索免费方形 support，不改 node/feet 把失败变成功。

接受时允许修改 request/hold/door actuator 的 v9 控制状态与成功通知，但不能修改 wallet、fare ledger、vehicleId、rider、driving、passengers 或把 feet 写成终点。**任何拒绝**必须连 request serial、notice/eventId、door state、fare、occupancy、runtime/savebytes 都不变：所有检查在 nextSerial++ 与 success/notice 前完成。队列容量/密封窗口/重复 actor 拒绝也遵守这一点。

**FIFO 与正常有限完成。** 第一请求建立 actual stopped hold，opening 阶段接受同批有限请求，按当前空 slots/已占 exit slots 限制总数。opening→open 即密封，hold 的 `batchTailSerial` 固定；open/closing/blocked 阶段的新请求一律纯拒绝，避免连续新客使车永远不离站。最小实现同车只允许一个 head cursor 移动，后续 FIFO；不同车的 shared platform/door body 仍互相避让。队尾退出后安全闭门到0，删除 hold/door key，才允许 departure。不能每 tick 重置 departure/dwell。旧 nextDeparture 可继续存在；hold gate 优先于任何 manual throttle、closed-road reroute、noPower/redLight、随机新 edge 或方向反转。

正常 liveness 条件必须写明：可信静态路径可通、动态障碍没有永久占住它、资格/票款未被强制撤销、NPC business time 在走、host real intervals 持续供给。此时有限批、有限路径 cost、正门机速度、player4.8和NPC3.1/4.2，加现频率最大16tick，应有有限完成界。未知门机速度不是已有事实，需另定工程常数并验证；不允许只留 `doorOpen=true` 永久hold。动态重阻、尸体、错误权威是明确异常 blocked，可以安全保持；不能宣称无条件有限恢复或用超时清rights。

同批还需排除自己制造的normal deadlock：锁定queued actor的真实start body不能占任何较早请求的剩余sweep/门机体积；新path必须包含已reserved最终slot的未来body体积，不能只含当前已committed客体。所有queue actor都有实际supported staging feet，等待时不得freely走进head路径。可由再生计划cache保守推导这些reservation，无需保存外来corridor geometry；无真实staging空间时纯拒绝入队。仅有serial FIFO不足以保证物理FIFO liveness。

**真实完成后的唯一提交。** 最后一个段的 proposed feet 和 body/foot sweep、最终 slot/exit 支撑、wallet/permit、held berth 和同车占位均复验成功后，同一个同步事务内消费 request。board：扣可信价4一次，emit既有 transit-fare一次，创建 occupant及 rider/player mirrors、passengers++、feet置为刚走到的slot；NPC commute在此 emit。drive：可信价0，创建driver occupant及control mirrors，hold仍阻止发车。exit：feet保留刚走到的实际平台/坡道端点，删除自身occupant和rider/player mirrors、passengers--、驾驶控制归零；不把它替换成 logical node。旧 fare listener `simulation.ts:786` 收 treasury/GDP；不得另加第二收款路径。

pending cursor 不允许 `index===segments.length` 的“已经完成但未结算”存档；终点推进和结算是同一事务，不制造待重放终态。request 消失/occupant 的 consumed `boardSerial` 是重复 completion guard。若 EventBus handler 可抛异常，事务必须涵盖受影响 wallet/treasury/GDP/extension receipt 与 mirror，或保证这条已知 event 路径不抛；只回滚 player.money 不够。导入 occupancy 是合法持久事实，不是再次扣费指令。

**票款 reservation 不等于预扣。** request 的可信报价是钱包的 spendable-cash lien，cash不变；ordinary debit须以 `money - liveUncompletedBoardFares` 判断。这样能同时满足“路径完成后才扣”和正常完成票款仍在。当前源码没有中心 wallet debit，所以只挡 player command 不足；例如独立 finance/people 仍扣 NPC 钱，legacy investment还可亏损扣player钱。必须新增 v9-only spendable helper并接所有可能消费 reservation 的 debit，旧无transport时helper返回原money、原顺序。司法强制追缴等明确更高优先级事务若合法压低余额，先把请求变 wallet-blocked并保留实际 cursor/rights；不透支、不到终点再退款、不补贴票款。未接这些 debit 时只能证明完工前再检查余额，不可声称accepted有票款liveness保证。

| 现有直接 debit 见证 | 必要接入 |
| --- | --- |
| `simulation.ts:725,1793,1923,2193,2213–2217,2226,2306` | public fee/NPC food/investment loss/player spending尊重 lien；initial constructor contribution699在无request时不变 |
| `simulation/culture.ts:89,124`、`civic-staffing.ts:352` | player fee/NPC service登记费不能消耗登车 reservation |
| `simulation/banking.ts:45,56` | actor deposit/repayment 含自动调用使用 spendable；withdraw/payroll等credit保持原规则 |
| `simulation/family.ts:158,212,220,239,538,546` | 双 actor transfer/reserve/fee都核对各自 lien |
| `clinical.ts:301`、`family-education.ts:103`、`education.ts:283` | 原payer escrow扣款前尊重 lien |
| `hygiene.ts:153`、`hygiene-transfer.ts:143`、`power.ts:201`、`roadworks.ts:311` | player escrow/搬运资金扣款前尊重 lien |
| `simulation/extensions.ts:338,347,373,424,450,469,479,496,511,524,557,595,598,602` | NPC创业/科研、司法追缴、player商业/科研/组织资金等；373必须明确强制事务处理 |
| `simulation/shop_lifecycle.ts:234,470`、`aviation.ts:81` | buyer/funder不消耗 lien；pending运输还应先拒绝aircraft并发拥有权 |

这张表为静态见证，最终实现需复搜全部 actor.money 赋值和 helper 调用；不能靠一张名单宣称封闭性已经验证。外部直接改公开state也不能产生几何/事务权威；下一次推进应复验并blocked。

**玩家与 NPC 时钟分开。** player cursor使用原4.8m/real-second，与state.speed无关。原 controller walking甚至 paused 时仍可走 (`_paused`未参与步行阻止)；因此v9 player/门机real推进也不能被现 `Simulation.step:808` paused早退无意冻结。将real推进与business fixed tick明确拆开；main在正常frame仅给真正接受后可见区间，stall上限沿原walking规则，load/tab visibility重置非持久host epoch，不消费接受前、后台、save离线秒，也不把blocked秒积攒以后追赶。若API仍以step(realSeconds)承载，需在有效值检查后、paused早退前运行v9 real分支，并给main可裁剪post-acceptance预算的入口；别对old step分支插额外调用。只把delta放进traffic业务分钟是不正确实现。

NPC 保留 `peopleElapsed` 与现frequency/tier/spend处理 (`simulation.ts:1605–1625`)，雨3.1/正常4.2m **per business minute**，不能给其4.8实时时钟、强迫全员frequency1、清deferred minutes或复用player dt。每request保存acceptedAt、eligibleSince、lastObservedAt，使用单调 `extension.lastUpdate`，不是setTime可改变的hour。门真正open且轮到head后开始eligible；本people phase可用运动分钟为 `min(existingElapsed, max(0, businessNow - max(eligibleSince,lastObservedAt)))`，观察后lastObservedAt前推，blocked/queue分钟不bank。needs仍按原elapsed衰减。

NPC到站到实际exit之间不能复用ride分钟。exit实际完成后，只有本phase eligible预算中扣掉物理exit消费后剩余的分钟可用于真实出口起步、到达和劳动；原到站节点与延迟分钟不能补算到现场。board完成后的剩余分钟属于等待/乘车，不用于现场工资/疗养。`stopNodeId`仍是意图，到站event只触发exit请求；不是物理下车证明。actor transport分支必须在 `setDestination`、dispatch、private opportunity和普通moveCitizen重写route之前独占feet和movement，但needs频率/账务观察不失真。

**导入重建和 fail-closed。** 先parse/safeTree/旧validators，再structure+layout pairing、所有counts/references/mirrors和cursor形状，最后在候选对象上重建真正权威。从trusted World9、实际carrier incoming berth和slot、request.startFeet/side/action再生固定路径；与保存cursor插值和候选actor.position核对。外来points、signature、geometryVersion、capacity、support label不能授权，即使和当前字符串相同。当前 importer只验vehicle.position有限、不验与edge/progress相符 (`2408–2410`)，v9必须增加 trusted pose一致性；不允许伪造车位开门。

重建应把不变结构路径与动态阻碍检查分开：静态路径/当前feet支撑与capsule无效就原子拒绝整个import；future动态障碍只是block后续推进，应能在同一真实supported cursor恢复而不charge/relocate/释放rights。不能因为新voxel阻住余路就重生到node，也不能重新从当前位置生成另一条路径再“对齐”游标。静态计划cache只在全部loadHooks也成功后替换，异常回滚不能遗留指向失败candidate的authority。现onLoad只回滚state/runtime，新增cache须延后发布或同时回滚。import不推进、不结算、不改blocked时间/phase来美化savebytes。

**codec风险。** transport小body和marker可自然保留global document，无需改citizen route pool或chunk分配名单。`partition.ts:36` inspect后只在声明出现时做结构校验；selector/importer仍负责trusted布局。`assembleSave:155–163`的layout.order重排可删除整个body/marker，或删除内部字段，因此重排前锁定declared并验证，重排后按原declared复验并要求transport子树无丢字段/字节差异，不能只在重排后“检测是否存在”。legacy/fallback完整JSON读取 (`persistence.ts:195`) 可绕过codec，故selector和直接import双入口都必须检查。partial chunk读取无世界参数不应推断v9授权。

**死亡、中断、动态重阻。** queued尚未移动且真实body完全在车外、door可安全闭时，死亡可无fare地取消reservation；不能把此前deferred needs分钟转成新的运动预算。moving时死亡/资格撤销/route authority变动，留在实际cursor，记deadBlocked/authority-blocked；若body已跨threshold，不得删hold让车开走。已在车内死亡保留dead body slot和实地floor attachment，撤驾驶权/业务劳动而不退已赚票款；清物理body需另有实际搬离authority，本源码没有，此为异常liveness blocker。alive:false不能自动把occupant变“空格”。

blur/tab/save/load只暂停或重置host秒，不清request。cancelJourney只改导航意图；不能销毁物理motion。setMode/aircraft/syncPlayerView需遵守pending拥有权。重复ride/drive/exit与冲突生活动作在任何handler前纯拒绝；setTime现会清全actor route和重排全车辆nextDeparture，v9有active transport时应拒绝，或专门保留transport actor/held vehicle，不能照搬破坏已接受合同。需要取消已走请求时，须以同样真实预算走经过重新证实的逆路；“清状态/退款/写origin”不是安全取消。

**必须保留的工程阻碍。** transfer01 receipt：2026-10-04T16:11:26.804681Z–16:11:45.824067Z，exit1、未超时、315 stable inputs，raw SHA `fce61879833c51de0a161e4e9e8c5a0d3ebe8c4f9bb1d1757743febe54e97c57`，active descendants空。原W6.349231772539076秒有167真实rejections；network body分析为FAIL并有1181 endpointFootFailures。market两侧完整exit均FAIL：side-1保留 `renderer.ts:770:1` 旧network guard接触，side+1保留 `renderer.ts:761:1/2` 实rail实体接触。这些证据未因静态合同而改善。

1. `carrier-motion-path.ts:74–100` 目前只消费nearby street/network、当前carrier、可选otherCarrierSolids；未消费terrain、buildings、placed voxels、allocated actor bodies。optional默认[]不可用于真实命令或import。原artifact的remaining也明确这些缺失。
2. `street-solid-authority.ts:245` 允许support.y位于feetY以下.4m，只证明投影覆盖。`physicalStep:48–69`构造raise/move/settle，`advanceCarrierPath:105–122`按任意预算停在其中任何插值点；抬升中途的feet可能不接实际floor。因此当前kernel不能证明任意save/重阻时“停在真实支撑”。保存lastSupportedFeet后直接回写会是另一次瞬移；必须先完成连续支撑/停点工程，或有真实、预算受限且连续碰撞有效的落足/恢复路径。
3. `station-throats.ts:63–85` 只给maglev/lightRail建parcel。road虽有5.5m shell和4个slots，但没有actual road berth/platform/ramp authority；`traffic:931–933`固定1.3m车道偏移，`977`新edge/orientation立即切换，端点调向和lane过渡仍未工程。drive road不能依靠rail parcel或nearest35/45m继续通行。
4. `carrierShape`仅road/maglev/lightRail。网络flight、cable、lift、ferry没有工程舱底/开口/slot/path；flight不是工程完成的v9乘车。`aviation.ts:119–135`的自由aircraft也在board时sync进机舱、exit写pad侧offset，没有真正舱门floor/capsule路径。本合同不伪装解决它们；v9这些access命令明确拒绝/保持blocker，不可绕到legacy teleports。old布局继续原行为。
5. moving occupied-carrier的真实inclinedFloat32 floor slot/head clearance及周围实体sweep仍需交通运动验证；当前carrierSlotFeet仅求本floor support，不足以证明整段旅途身体连续清净。rail/road端点反向carrierPose变化可能旋转所有slot，同样需真实转向authority；hold只延迟不解决旋转穿墙。

**精确必要integration hunks（仅建议，未应用）。**

| 文件/原行 | 必需变化及旧分支保护 |
| --- | --- |
| `types.ts:46` | 可选transportMotion类型；其余Player/Citizen/Vehicle字段不改 |
| `simulation.ts:38,94,159` | 末尾模块名、独立runtime marker；fresh可信9才初始化body；不要借npc marker/envelope升级 |
| 新pure declaration validator + 新transport engine模块 | schema/marker/布局结构、tariff/slots/berth/path再生、FIFO/doors/clock/transaction；不得返回imported-authorityPASS |
| `simulation.ts:807–822` | real推进与paused/fixed business分开；setFocus只读focus更新，pending时不再覆盖feet |
| `simulation.ts:734` | 仅transport1分支capacity来自真正slots/cargo证据；旧表达式原封不动 |
| `simulation.ts:888–990` | 每车先hold gate；v9 arrival不减occupancy；保留incoming pose；slot attachment代替中心；无连续departure authority则blocked |
| `simulation.ts:1601–1665,1693–1699` | v9 transport actor在普通route/decision前处理；延迟needs/minutes保留；board/arrival/exit用cursor，移除旧instant分支只针对9 |
| `simulation.ts:1613` + `extensions.ts:274–280` death | v9 cleanup原子保持实体/slot及撤driver control；注意core people先执行，extensions同phase后才可能die；只次tick cleanup会允许一帧/一次export悬挂，需phase末reconcile或v9 death hook |
| `simulation.ts:2160–2180,2314–2322` | before commandHandlers的pending拥有权检查；ride/drive/leave首先v9纯入口；防setTime毁约；old命令body不改变 |
| `simulation.ts:2346–2349,2371–2386,2408–2416,2595–2612` | export原envelope；paired declaration在manifest删除前；全语义/pose/mirror校验在state/runtime换入前；authoritycache在loadHooks成功后发布 |
| `main.ts:195–216,270–276,290–326` | pending/occupied共享位置拥有权guard；board尚未vehicleId仍禁止walking与feet写回；按实际postaccept秒推进，syncPlayerView/interact/setMode不能替换cursor |
| `controller.ts:155–163` | sync真实cursor/slot并丢旧walking输入；已有v9 eye=feet+1.72分支保持（旧仍+额外.5） |
| `renderer.ts:1030` | 正式类型取doorFractions；render/body collision必须使用同一fraction，无隐藏或代理门 |
| `persistence/world-layout.ts:10–50,72` | 必要时只新增9 fingerprint描述绑定code-ownedshell/slots/station/实体recipe输入；旧identity文本不动。候选fingerprint匹配后验证该layout pairing再return |
| `persistence/partition.ts:36,155–163` | declaration-triggered纯结构检查；before/after reorder抗删声明/子字段。routes/pages/chunk名单不用搬动 |
| actor wallet debit见证表 | v9 spendable-lien gate及强制追缴异常处理；不安装则票款正常liveness未成立 |
| `simulation/journeys.ts:32–49` | arrival仍记录真实车到站；pendingboard/exit不能被navigation当作真实步行终点；hold保留incoming方向保障nextStop观察。journey不授予物理登离authority |

**后续验收建议，均未执行。** 根CPU/GPU调度下，先保留首个真实contact FAIL并完成每个可保存cursor的完整圆足支撑/全capsule连续证书；补全部dynamic实体、road lane/endpoint、cargo/flight阻碍。随后测拒绝savebytes不变、partialboard不扣费/不增occupancy、不同FPS/speed/paused的player4.8、NPC rain3.1/4.2和exactdeferred、FIFO sealed batch正常完成、动态堵塞不丢rights、death/blur/reload稳定、marker/body/manifest/layout拆对与伪cursor原子拒绝、codec恶意order不能降级、import/export不中途结算。最后按root冻结oracle实际运行old1/2/3及layout6/7/8立即bytes和future24 continuation。不得以本静态报告替代这些证据。

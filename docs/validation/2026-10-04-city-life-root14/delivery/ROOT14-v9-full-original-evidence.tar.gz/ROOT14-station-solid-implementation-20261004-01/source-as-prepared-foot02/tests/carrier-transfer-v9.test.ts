import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import path from 'node:path';
import { PerspectiveCamera } from 'three';
import { PlayerController } from '../src/controller';
import { createWorld } from '../src/world';
import { carrierSlotFeet, carrierSlots, carrierStreetSolids } from '../src/carrier-solids';
import { advanceCarrierPath, carrierTransferPath } from '../src/carrier-motion-path';
import { getNearbyStreetSolids, streetCapsuleSeparation, streetFootCoverageFromSolids } from '../src/street-solid-authority';
import type { Vec3, Vehicle } from '../src/types';

const output = path.resolve('artifacts/v9-transfer01');
fs.mkdirSync(output, { recursive: true });
const save = (name: string, value: unknown) => fs.writeFileSync(path.join(output, name), JSON.stringify(value, null, 2) + '\n');
let instance: ReturnType<typeof createWorld> | undefined;
const world = () => { if (!instance) { instance = createWorld(20261001, 'current-v9'); save('actual-world-v9.json', instance); } return instance; };

test('actual v9 unchanged birth/original W uses original camera and speed with strict continuous NETWORK capsule checks', () => {
  const city = world(), keyboard = Object.assign(new EventTarget(), { closest: () => null }), documentTarget = Object.assign(new EventTarget(), { pointerLockElement: null });
  const oldWindow = Object.getOwnPropertyDescriptor(globalThis, 'window'), oldDocument = Object.getOwnPropertyDescriptor(globalThis, 'document');
  Object.defineProperty(globalThis, 'window', { value: keyboard, configurable: true }); Object.defineProperty(globalThis, 'document', { value: documentTarget, configurable: true });
  const camera = new PerspectiveCamera(48, 1, .12, 18000); camera.quaternion.set(-.024191989150678845, -.25171716574181724, -.006294240498289998, .9674779577170685);
  const controller = new PlayerController(camera, new EventTarget() as HTMLCanvasElement, city, () => {}), start = controller.position, positions = [start], segments: { from: Vec3; to: Vec3 }[] = [], rejected: unknown[] = [];
  const walkTo = Reflect.get(controller, 'walkTo') as (x: number, z: number) => void;
  Reflect.set(controller, 'walkTo', function (x: number, z: number) { const from = controller.position; walkTo.call(controller, x, z); const to = controller.position; if ((x !== from.x || z !== from.z) && to.x === from.x && to.z === from.z) rejected.push({ from, requested: { x, z } }); if (JSON.stringify(from) !== JSON.stringify(to)) segments.push(...controller.lastStreetMovementSegments.map(segment => ({ from: { ...segment.from }, to: { ...segment.to } }))); positions.push(to); });
  const key = (type: string) => { const event = new Event(type); Object.assign(event, { code: 'KeyW', repeat: false }); keyboard.dispatchEvent(event); };
  const seconds = 30.47631250818756 / 4.8;
  try { key('keydown'); let remaining = seconds; while (remaining > 1e-12) { const dt = Math.min(.01, remaining); controller.step(dt, false, true); remaining -= dt; } key('keyup'); }
  finally { controller.dispose(); if (oldWindow) Object.defineProperty(globalThis, 'window', oldWindow); else Reflect.deleteProperty(globalThis, 'window'); if (oldDocument) Object.defineProperty(globalThis, 'document', oldDocument); else Reflect.deleteProperty(globalThis, 'document'); }
  save('original-W-controller.json', { scope: 'Actual production controller, DOM EventTarget, original constructor/camera/W/.01sec/4.8 horizontal. No Simulation/RAF/GPU/browser. Network capsule proof only; building/voxels/carriers not included.', start, end: controller.position, seconds, positions, rejected, segments });
  const contacts: unknown[] = [], endpointFootFailures: unknown[] = [], nearby = new Map<string, unknown>(); let exactPairs = 0, minimumSeparation = Infinity;
  for (const [index, segment] of segments.entries()) {
    const solids = getNearbyStreetSolids(city, segment.from, segment.to);
    for (const solid of solids) { const separation = streetCapsuleSeparation(solid, segment.from, segment.to); exactPairs++; minimumSeparation = Math.min(minimumSeparation, separation); const descriptor = solid.descriptor; nearby.set(JSON.stringify([descriptor.owner, descriptor.sourceCall, descriptor.matrixUint32]), descriptor); if (separation < 0) contacts.push({ index, segment, owner: descriptor.owner, sourceCall: descriptor.sourceCall, matrixUint32: descriptor.matrixUint32, separation }); }
    for (const point of [segment.from, segment.to]) { const coverage = streetFootCoverageFromSolids(solids, point.x, point.z, point.y); if (!coverage.covered) endpointFootFailures.push({ index, point, coverage }); }
  }
  const distance = Math.hypot(controller.position.x - start.x, controller.position.z - start.z);
  save('original-W-network-body-analysis.json', { status: contacts.length || endpointFootFailures.length || rejected.length || Math.abs(distance - 30.47631250818756) >= 1e-6 ? 'FAIL' : 'NETWORK_CAPSULE_PASS_FOOT_ENDPOINTS_ONLY', bodyRadius: .35, bodyHeight: 1.72, distance, rejected, exactPairs, minimumSeparation, contacts, endpointFootFailures, remaining: 'The old endpoint-selected floor union is not accepted as a complete continuous-foot certificate until independent fixed-set proof is implemented.', actualNearbyDescriptors: [...nearby.values()] });
  assert.equal(rejected.length, 0); assert.ok(Math.abs(distance - 30.47631250818756) < 1e-6, 'original actual W horizontal target'); assert.deepEqual(contacts, []); assert.deepEqual(endpointFootFailures, []);
});

test('actual market-carriage passenger exits through its real door/platform/ramp and returns with conserved real movement budget', () => {
  const city = world(), line = city.edges.find(edge => edge.id === 'maglev-market-station-core-station')!, node = city.nodes.find(node => node.id === 'market-station')!;
  const car: Vehicle = { id: 'explicit-market-transfer-fixture', kind: 'maglev', edgeId: line.id, position: { ...node.position }, progress: 0, direction: 1, speed: 40, state: 'waiting', passengers: 0, cargo: 0, nextDeparture: 480 };
  const slot = carrierSlots(car.kind).find(slot => slot.z === 1.8 && slot.x > 0)!; assert.ok(slot); const feet = carrierSlotFeet(car, line, slot)!; assert.ok(feet);
  save('market-carriage-fixture.json', { scope: 'Explicit actual World9 stopped carrier geometry; not natural arrival, accepted command, fare/occupancy or Simulation.', car, edge: line, slot, feet, cabinOpenDescriptors: carrierStreetSolids(car, line, true).map(solid => solid.descriptor) });
  const results = [-1, 1].map(side => {
    const exit = carrierTransferPath(city, car, line, slot, 'exit', feet, side);
    if (exit.status === 'FAIL') return { side, exit };
    let cursor = { segmentIndex: 0, segmentDistance: 0 }, position = feet, steps = 0, spent = 0;
    while (cursor.segmentIndex < exit.segments.length && steps < 10000) { const advanced = advanceCarrierPath(exit, cursor.segmentIndex, cursor.segmentDistance, .01 * 4.8); assert.ok(advanced.spent <= .01 * 4.8); cursor = advanced; position = advanced.position; spent += advanced.spent; steps++; }
    assert.equal(cursor.segmentIndex, exit.segments.length); assert.ok(Math.abs(spent - exit.segments.reduce((sum, segment) => sum + segment.horizontalBudget, 0)) < 1e-9);
    const board = carrierTransferPath(city, car, line, slot, 'board', position, side);
    return { side, exit, board, spent, realSeconds: steps * .01, end: position };
  });
  save('market-full-transfer-analysis.json', { status: results.every(result => result.exit.status === 'PASS' && 'board' in result && result.board.status === 'PASS') ? 'PROVISIONAL_GEOMETRY_PATH_PASS_FOOT_PROOF_REVIEW_PENDING' : 'FAIL', results, remaining: ['Complete continuous-foot certificate independently under review; this scope may preserve its failure.', 'Buildings/voxels/other carriers/allocated passengers and legal Simulation fare/occupancy are not consumed.'] });
  for (const result of results) { assert.equal(result.exit.status, 'PASS', `actual side ${result.side} exit: ${result.exit.status === 'FAIL' ? result.exit.reason : ''}`); assert.ok('board' in result && result.board.status === 'PASS'); }
});

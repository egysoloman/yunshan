/** v9-only complete circular-foot projection proof. Actual upward faces are
 * clipped to a height band valid for the whole segment before union testing.
 * No geometry is invented; this proves support beneath the foot, not grounded
 * contact during a raise/settle animation or an arbitrary pause. */
import type { Vec3 } from './types';
import type { StreetSolid } from './street-solid-authority';
export const STREET_FOOT_CORRIDOR_VERSION = 'yunshan-fixed-face-foot-corridor-v9-1';
type Point = readonly [number, number, number];
type Flat = readonly [number, number];
const sub = (a: Point, b: Point): Point => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const cross = (a: Point, b: Point): Point => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const dot = (a: Point, b: Point) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const transform = (m: readonly number[], p: Point): Point => [m[0] * p[0] + m[4] * p[1] + m[8] * p[2] + m[12], m[1] * p[0] + m[5] * p[1] + m[9] * p[2] + m[13], m[2] * p[0] + m[6] * p[1] + m[10] * p[2] + m[14]];
const difference = (a: Flat, b: Flat): Flat => [a[0] - b[0], a[1] - b[1]];
const area = (a: Flat, b: Flat) => a[0] * b[1] - a[1] * b[0];
const orientation = (p: readonly Flat[]) => Math.sign(p.reduce((sum, a, i) => sum + area(a, p[(i + 1) % p.length]), 0));
const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
function upwardFaces(solid: StreetSolid): Point[][] {
  const m = solid.descriptor.matrixFloat32, center = transform(m, [0, 0, 0]), faces: Point[][] = [];
  for (let fixed = 0; fixed < 3; fixed++) for (const side of [-.5, .5]) {
    const axes = [0, 1, 2].filter(axis => axis !== fixed);
    const face = [[-.5, -.5], [.5, -.5], [.5, .5], [-.5, .5]].map(([a, b]) => { const local: [number, number, number] = [0, 0, 0]; local[fixed] = side; local[axes[0]] = a; local[axes[1]] = b; return transform(m, local); });
    let normal = cross(sub(face[1], face[0]), sub(face[2], face[0]));
    if (dot(normal, sub(face[0], center)) < 0) normal = [-normal[0], -normal[1], -normal[2]];
    if (normal[1] > 0) faces.push(face);
  }
  return faces;
}
function clipHeight(face: Point[], height: number, lower: boolean): Point[] {
  const result: Point[] = [], inside = (point: Point) => lower ? point[1] >= height : point[1] <= height;
  for (let i = 0; i < face.length; i++) {
    const a = face[i], b = face[(i + 1) % face.length], ai = inside(a), bi = inside(b);
    if (ai) result.push(a);
    if (ai !== bi) { const t = (height - a[1]) / (b[1] - a[1]); result.push([a[0] + (b[0] - a[0]) * t, height, a[2] + (b[2] - a[2]) * t]); }
  }
  return result;
}
function contains(point: Flat, polygon: readonly Flat[], outward?: Flat): boolean {
  const sign = orientation(polygon); if (!sign) return false;
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], edge = difference(polygon[(i + 1) % polygon.length], a), value = sign * area(edge, difference(point, a));
    if (value < -1e-10 || outward && Math.abs(value) <= 1e-10 && sign * area(edge, outward) < 0) return false;
  }
  return true;
}
/** Same fixed, physically clipped union is used for both endpoints. */
function circleCoverage(polygons: readonly Flat[][], x: number, z: number, radius: number): { covered: boolean; distance: number } {
  const center: Flat = [x, z]; if (!polygons.some(polygon => contains(center, polygon))) return { covered: false, distance: 0 };
  let closest = Infinity;
  for (let pi = 0; pi < polygons.length; pi++) {
    const polygon = polygons[pi], sign = orientation(polygon);
    for (let i = 0; i < polygon.length; i++) {
      const a = polygon[i], edge = difference(polygon[(i + 1) % polygon.length], a), length2 = edge[0] ** 2 + edge[1] ** 2;
      if (!length2) continue;
      const cuts = new Set([0, 1]);
      for (let oi = 0; oi < polygons.length; oi++) if (oi !== pi) for (let j = 0; j < polygons[oi].length; j++) {
        const c = polygons[oi][j], d = polygons[oi][(j + 1) % polygons[oi].length], delta = difference(d, c), offset = difference(c, a), denominator = area(edge, delta);
        if (Math.abs(denominator) > 1e-20) { const t = area(offset, delta) / denominator, u = area(offset, edge) / denominator; if (t > 0 && t < 1 && u >= 0 && u <= 1) cuts.add(t); }
        else if (Math.abs(area(edge, offset)) < 1e-10) for (const point of [c, d]) { const t = ((point[0] - a[0]) * edge[0] + (point[1] - a[1]) * edge[1]) / length2; if (t > 0 && t < 1) cuts.add(t); }
      }
      const values = [...cuts].sort((a, b) => a - b), outward: Flat = [sign * edge[1], -sign * edge[0]];
      for (let j = 1; j < values.length; j++) {
        const low = values[j - 1], high = values[j], middle: Flat = [a[0] + (low + high) / 2 * edge[0], a[1] + (low + high) / 2 * edge[1]];
        if (polygons.some((other, oi) => oi !== pi && contains(middle, other, outward))) continue;
        const t = clamp(((x - a[0]) * edge[0] + (z - a[1]) * edge[1]) / length2, low, high);
        closest = Math.min(closest, Math.hypot(a[0] + t * edge[0] - x, a[1] + t * edge[1] - z));
      }
    }
  }
  return { covered: closest >= radius, distance: closest };
}
export interface StreetFootCorridorCertificate { version: typeof STREET_FOOT_CORRIDOR_VERSION; from: Vec3; to: Vec3; bodyRadius: number; maximumSupportDistance: number; minimumBoundaryDistance: number; horizontalLength: number; subdivisions: number; fixedFaceDomains: { from: Vec3; to: Vec3; lower: number; upper: number; faceCount: number }[]; provesGroundedContact: false }
export function certifyStreetFootProjection(solids: readonly StreetSolid[], from: Vec3, to: Vec3, radius = .35, maximumSupportDistance = .4): StreetFootCorridorCertificate | null {
  if (![from.x, from.y, from.z, to.x, to.y, to.z, radius, maximumSupportDistance].every(Number.isFinite) || radius <= 0 || maximumSupportDistance < 0) return null;
  const faces = solids.filter(solid => solid.walkable).flatMap(upwardFaces), domains: StreetFootCorridorCertificate['fixedFaceDomains'] = [];
  let minimumBoundaryDistance = Infinity, subdivisions = 0;
  const prove = (a: Vec3, b: Vec3, depth: number): boolean => {
    // Every retained point is within this same band's support reach for every
    // interpolated feetY. The upper bound is the rounded foot's radius, while
    // exact full-capsule collision is a separate mandatory certificate.
    const lower = Math.max(a.y, b.y) - maximumSupportDistance, upper = Math.min(a.y, b.y) + radius;
    const polygons = faces.map(face => clipHeight(clipHeight(face, lower, true), upper, false)).filter(face => face.length >= 3).map(face => face.map(point => [point[0], point[2]] as Flat)).filter(polygon => orientation(polygon) !== 0);
    const first = circleCoverage(polygons, a.x, a.z, radius), last = circleCoverage(polygons, b.x, b.z, radius), run = Math.hypot(a.x - b.x, a.z - b.z);
    if (first.covered && last.covered && Math.min(first.distance, last.distance) >= radius + run / 2) { minimumBoundaryDistance = Math.min(minimumBoundaryDistance, first.distance, last.distance); domains.push({ from: { ...a }, to: { ...b }, lower, upper, faceCount: polygons.length }); return true; }
    if (depth >= 16 || a.x === b.x && a.y === b.y && a.z === b.z) return false;
    subdivisions++; const mid = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, z: (a.z + b.z) / 2 };
    return prove(a, mid, depth + 1) && prove(mid, b, depth + 1);
  };
  if (!prove(from, to, 0)) return null;
  return { version: STREET_FOOT_CORRIDOR_VERSION, from: { ...from }, to: { ...to }, bodyRadius: radius, maximumSupportDistance, minimumBoundaryDistance, horizontalLength: Math.hypot(from.x - to.x, from.z - to.z), subdivisions, fixedFaceDomains: domains, provesGroundedContact: false };
}

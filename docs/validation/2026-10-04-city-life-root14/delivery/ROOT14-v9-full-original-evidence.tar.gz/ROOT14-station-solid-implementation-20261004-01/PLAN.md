# ROOT14 station-solid implementation — v9 isolated candidate

Final bounded stage:319 inputs/77 source frozen in `source-as-run-final`; see REPORT.md/HANDOFF.md. Descriptors6 and actual factory5 PASS, original W and door2 FAIL, exact projection7+strict types PASS. This does not complete v9 transport, grounded interruption, payment/occupancy or browser acceptance. The concrete66m berth/214m corridor remains uninstalled/unchecked. Root requested local delivery and CLOSED, then NEW engineering on its next accepted native4 baseline; no further factory/Sim/GPU is active here.

The base is the root's exact final 295-input / 68-source snapshot, copied from `ROOT13-integrated-civic-shop-light-20261004-01/source-as-prepared` after every file matched its frozen SHA. `V8-DELTA-IMPORT.json` records guarded application of five closed-v8 production files and five closed-v8 test/script inputs; preexisting world/controller inputs were byte-equal to the closed v7 before replacement. The apron stays byte-identical. No shared/root input or CLOSED group is modified.

## Owners and preparation

This child exclusively owns the isolated candidate's World, new station/carrier/transport modules, controller, v9-only renderer carrier and shared network branch, v9 main guards, v9 persistence branch, and necessary additive types. Root granted these internal owners. Existing v6/v7/v8 geometry/fingerprint/command paths must retain their outputs. Product default remains v6.

The separate read-only `vehicle-door-audit` child owns only that subdirectory and is finished. Its source sections prove the observed road/rail model consists of solid body/head/trim boxes, without a cavity, door or passenger floor; selected-vehicle hiding near 25m masks that fact. Capacity180 also exceeds the full carriage's physical standing area for .35-radius occupants. These are implementation causes rather than missing art alone. All audit proposals were static.

Prepared production code:

- `carrier-solids.ts`: physical thin shell, floor top .35, roof underside2.2/top2.5, bilateral 1.2m side opening, finite door leaves sliding .6m, retained thresholds; shared Float32 material/matrix descriptors, true 3D arc segment pose, and physically separated passenger floor slots (road4/rail24) with a reserved driver anchor. Existing body lengths/widths remain. This geometry-derived capacity applies only to a future v9 motion branch; old capacities are unchanged.
- `station-throats.ts`: distinct v9 parameters,10m level rail endpoint throat, actual changed-point recovery grade <=.20, preserved old nodes/doors/spawn and old XZ samples, atomic proposals and physical platform parcels. The rail .20 rule is a new explicit v9 engineering rule; old recipes contain no rail-grade bound. Impossible recovery must FAIL. The first candidate keeps route XZ; if true clearance fails, retain the FAIL before proposing a necessary new track corridor.
- `station-parcel-solids.ts`: finite floor/ramp parcels, rear track buffer supporting a stopped16m carriage, actual normal rails/curbs and outer platform guards. A floor-backed boarding portal replaces only the corresponding old inner guard span; both collision and rendering consume the same engineered geometry. This is not a renderer hide operation.
- Network/world/renderer v9 branches: source-derived Float32 solids are drawn directly; supported v9 carriers use their actual shell, including the player's carrier at close range. Old renderer/light branches remain. Old v8 World geometry stays distinct and unmodified.
- Six primitive descriptor/door/slot/throat rules passed in the original bounded descriptor scope. A separate five-rule actual factory scope also passed. These establish the stated geometry fixtures; they do not establish natural boarding, alighting, Simulation state or browser acceptance.

## Actual scopes completed

`carrier-descriptor-rules01`: cap120,6/6 PASS,307 stable inputs/74 source,2026-10-04T15:42:25.150Z–15:42:26.586Z,raw SHA256 `ab08cf11c0cab99f87c749a0f66124b86a51d07e7933af3bab447ad1bce8d891`,active descendants empty. These are primitive carrier/throat fixtures, not a World or Simulation journey.

`carrier-types01`: original FAIL,307 stable inputs,raw `cc8854432da65075263aaec4d120a6dfd6312b692ef3a6930f743cf468f32c74`. Four inherited v8/v7 script/helper/fixture dependencies were absent from the five-input checkpoint intake. Their exact absent-only imports are recorded in `V8-INHERITED-DEPENDENCY-CORRECTION.json`; no tests or assertions were weakened. `carrier-types02`: cap120 PASS,311 stable inputs/74 source,15:44:40.764Z–15:45:00.687Z,empty raw SHA `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`,active descendants empty.

`v9-factory01`: cap120,5/5 PASS,313 stable inputs/74 source,15:50:02.975Z–15:50:21.468Z,raw SHA `3d32d573e822769398d0b78decd5f89ac78394f23114e59b577d853e436e4ee7`,active descendants empty. Actual complete v6/v7/v8 factory literals match frozen archives exactly. Actual v9 retains birth/buildings/nodes/doors, all old XZ samples and all nonrail edges;18 rail endpoint profiles/parcels satisfy the new .20 rule. Unchanged birth has exact Float32 NETWORK capsule clearance and full circular-foot support. An explicit stopped market carriage interior fixture also clears the network and has actual floor support. It does not claim a natural train arrival, physical door traversal, accepted command or moving passenger.

Source snapshots for each scope are retained unchanged. The later pure `carrier-motion-path.ts` and controller9 branch were actually checked in transfer01 and failed the original W/door assertions. The flawed endpoint/different-union and tolerance footprint proof was replaced with exact rational fixed-face projection,7 rules+types PASS; grounded interruption remains explicitly false and full original W/door was not rerun. No fare/occupancy actor mutation is implemented or claimed.

## Pending transport motion contract

Install an independent `transportMotionVersion:1` marker and code-owned `transportMotion.version:1` cursor state only for layout9. Save envelopes1/2/3 and old NPC motion versions stay distinct. Validate marker/body/layout pairing and regenerate geometry/path authority on import; no imported path or geometry label creates authority. Exact old saves and their future continuations remain regression requirements.

Board/exit requests first prove a complete actual supported and full-capsule-clear platform/door/cabin path. Accepted requests open finite leaves and advance a physical cursor at the original player's4.8m/s **real** movement budget. NPCs retain their existing3.1/4.2m per business-minute budgets and their exact deferred minutes; do not substitute the player's clock. Complete before committing fare/vehicleId/passenger changes. Actual stopped-carrier holds and FIFO requests must have a finite normal completion path; rejected requests cannot mutate fare, occupancy or save bytes. A newly blocked cursor stops on its real support and retains existing rights rather than silently clearing, refunding or relocating.

Moving passengers are attached to an actual carrier floor slot and use its exact inclined Float32 support. The v9 cab eye is feet+1.72, without the old extra.5m offset into the roof. A real transfer pose must sync through the existing frame; main/focus guards prevent walking/focus writeback from replacing a pending cursor. Old modes/commands still use their original branches.

Dynamic other carriers, allocated bodies, station beams, track/guard/curb entities, buildings, terrain and placed voxels are real obstruction inputs. A point-only search is insufficient. Road endpoint lane/orientation transitions and NPC boarding/arrival currently have further old instantaneous behaviors identified by the audit; they must be physically integrated or explicitly remain blockers, never claimed solved by this primitive scope.

## Validation and acceptance gates

All10 actual owned scopes ended naturally with stable inputs and no active descendants. Next work belongs to a NEW engineering group on the parent's accepted baseline: install/prove real66m berth/corridor/soil/pier/curvature assets, solve grounded cursor/dynamic inputs, then implement motion/time/cost/occupancy/queue/import contracts. True full .35/1.72 continuous body and full-foot proof, old1/2/3/native4/layout6/7/8 future24 and ordinary parent GPU/browser birth/W/board/ride/exit remain required. ART remains FAIL and macOS/different-city semantics are unfinished.

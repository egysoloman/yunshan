# Static source excerpts

This file copies source text with original line numbers. No product code was executed.

## oldV8: src/renderer.ts — makePool-and-put (906–921)

```typescript
  906:   private makePool(capacity: number, bodyMat: THREE.Material, headMat: THREE.Material, trimMat: THREE.Material): MovingPool {
  907:     const body = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), bodyMat, capacity), head = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), headMat, capacity), trim = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), trimMat, capacity);
  908:     for (const mesh of [body, head, trim]) {
  909:       if (mesh.material === this.materials.roof) mesh.geometry.setAttribute('instanceRoofSurface', new THREE.InstancedBufferAttribute(new Float32Array(capacity), 1));
  910:       if (mesh.material === this.materials.glass) mesh.geometry.setAttribute('instanceWindowSurface', new THREE.InstancedBufferAttribute(new Float32Array(capacity), 1));
  911:       mesh.count = 0; mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); mesh.frustumCulled = false; this.scene.add(mesh);
  912:     }
  913:     return { body, head, trim, capacity };
  914:   }
  915: 
  916:   private put(mesh: THREE.InstancedMesh, index: number, x: number, y: number, z: number, sx: number, sy: number, sz: number, angle: number, color?: string) {
  917:     this.position.set(x, y, z); this.scale.set(sx, sy, sz); this.rotation.setFromAxisAngle(this.axis, angle); this.matrix.compose(this.position, this.rotation, this.scale); mesh.setMatrixAt(index, this.matrix);
  918:     if (color) { let c = this.colors.get(color); if (!c) { c = new THREE.Color(color); this.colors.set(color, c); } mesh.setColorAt(index, c); }
  919:   }
  920: 
  921:   update(
```

## base295: src/renderer.ts — makePool-and-put (907–922)

```typescript
  907:   private makePool(capacity: number, bodyMat: THREE.Material, headMat: THREE.Material, trimMat: THREE.Material): MovingPool {
  908:     const body = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), bodyMat, capacity), head = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), headMat, capacity), trim = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), trimMat, capacity);
  909:     for (const mesh of [body, head, trim]) {
  910:       if (mesh.material === this.materials.roof) mesh.geometry.setAttribute('instanceRoofSurface', new THREE.InstancedBufferAttribute(new Float32Array(capacity), 1));
  911:       if (mesh.material === this.materials.glass) mesh.geometry.setAttribute('instanceWindowSurface', new THREE.InstancedBufferAttribute(new Float32Array(capacity), 1));
  912:       mesh.count = 0; mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); mesh.frustumCulled = false; this.scene.add(mesh);
  913:     }
  914:     return { body, head, trim, capacity };
  915:   }
  916: 
  917:   private put(mesh: THREE.InstancedMesh, index: number, x: number, y: number, z: number, sx: number, sy: number, sz: number, angle: number, color?: string) {
  918:     this.position.set(x, y, z); this.scale.set(sx, sy, sz); this.rotation.setFromAxisAngle(this.axis, angle); this.matrix.compose(this.position, this.rotation, this.scale); mesh.setMatrixAt(index, this.matrix);
  919:     if (color) { let c = this.colors.get(color); if (!c) { c = new THREE.Color(color); this.colors.set(color, c); } mesh.setColorAt(index, c); }
  920:   }
  921: 
  922:   update(
```

## oldV8: src/renderer.ts — vehicleUpdate (994–1008)

```typescript
  994:     const counts = new Map<string, number>();
  995:     for (const vehicle of state.vehicles) {
  996:       const pool = this.vehiclePools.get(vehicle.kind); if (!pool) continue; const n = counts.get(vehicle.kind) ?? 0; if (n >= pool.capacity) continue;
  997:       if (vehicle.id === state.player.vehicleId && Math.hypot(vehicle.position.x - this.camera.position.x, vehicle.position.y - this.camera.position.y, vehicle.position.z - this.camera.position.z) < 25) continue;
  998:       if (Math.hypot(vehicle.position.x - this.camera.position.x, vehicle.position.z - this.camera.position.z) > this.distance + 600) continue;
  999:       const edge = this.edges.get(vehicle.edgeId); let direction = 0;
 1000:       if (edge && edge.points.length > 1) { const t = Math.max(0, Math.min(.99999, vehicle.progress)), i = Math.min(edge.points.length - 2, Math.floor(t * (edge.points.length - 1))), a = edge.points[i], b = edge.points[i + 1]; direction = Math.atan2(b.x - a.x, b.z - a.z) + (vehicle.direction < 0 ? Math.PI : 0); }
 1001:       const p = vehicle.position, flight = vehicle.kind === 'flight', train = vehicle.kind === 'maglev' || vehicle.kind === 'lightRail', boat = vehicle.kind === 'ferry', length = flight ? 17 : train ? 16 : boat ? 11 : vehicle.kind === 'cable' ? 3.5 : 5.5, width = flight ? 14 : train ? 3.3 : boat ? 4.5 : 2.5, lift = vehicle.kind === 'cable' ? 2.5 : 0;
 1002:       this.put(pool.body, n, p.x, p.y + 1.1 + lift, p.z, width, flight ? .8 : 1.5, length, direction, flight ? '#d5c7aa' : train ? '#d0b985' : '#a77851');
 1003:       this.put(pool.head, n, p.x, p.y + 2.1 + lift, p.z, flight ? 3 : width * .85, flight ? 1.8 : .8, length * .68, direction, '#517f82');
 1004:       this.put(pool.trim, n, p.x, p.y + .6 + lift, p.z, width + .25, .2, length * .85, direction); counts.set(vehicle.kind, n + 1);
 1005:     }
 1006:     for (const [kind, pool] of this.vehiclePools) for (const mesh of [pool.body, pool.head, pool.trim]) { mesh.count = counts.get(kind) ?? 0; mesh.instanceMatrix.needsUpdate = true; if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true; }
 1007:   }
```

## base295: src/renderer.ts — vehicleUpdate (991–1005)

```typescript
  991:     const counts = new Map<string, number>();
  992:     for (const vehicle of state.vehicles) {
  993:       const pool = this.vehiclePools.get(vehicle.kind); if (!pool) continue; const n = counts.get(vehicle.kind) ?? 0; if (n >= pool.capacity) continue;
  994:       if (vehicle.id === state.player.vehicleId && Math.hypot(vehicle.position.x - this.camera.position.x, vehicle.position.y - this.camera.position.y, vehicle.position.z - this.camera.position.z) < 25) continue;
  995:       if (Math.hypot(vehicle.position.x - this.camera.position.x, vehicle.position.z - this.camera.position.z) > this.distance + 600) continue;
  996:       const edge = this.edges.get(vehicle.edgeId); let direction = 0;
  997:       if (edge && edge.points.length > 1) { const t = Math.max(0, Math.min(.99999, vehicle.progress)), i = Math.min(edge.points.length - 2, Math.floor(t * (edge.points.length - 1))), a = edge.points[i], b = edge.points[i + 1]; direction = Math.atan2(b.x - a.x, b.z - a.z) + (vehicle.direction < 0 ? Math.PI : 0); }
  998:       const p = vehicle.position, flight = vehicle.kind === 'flight', train = vehicle.kind === 'maglev' || vehicle.kind === 'lightRail', boat = vehicle.kind === 'ferry', length = flight ? 17 : train ? 16 : boat ? 11 : vehicle.kind === 'cable' ? 3.5 : 5.5, width = flight ? 14 : train ? 3.3 : boat ? 4.5 : 2.5, lift = vehicle.kind === 'cable' ? 2.5 : 0;
  999:       this.put(pool.body, n, p.x, p.y + 1.1 + lift, p.z, width, flight ? .8 : 1.5, length, direction, flight ? '#d5c7aa' : train ? '#d0b985' : '#a77851');
 1000:       this.put(pool.head, n, p.x, p.y + 2.1 + lift, p.z, flight ? 3 : width * .85, flight ? 1.8 : .8, length * .68, direction, '#517f82');
 1001:       this.put(pool.trim, n, p.x, p.y + .6 + lift, p.z, width + .25, .2, length * .85, direction); counts.set(vehicle.kind, n + 1);
 1002:     }
 1003:     for (const [kind, pool] of this.vehiclePools) for (const mesh of [pool.body, pool.head, pool.trim]) { mesh.count = counts.get(kind) ?? 0; mesh.instanceMatrix.needsUpdate = true; if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true; }
 1004:   }
```

## oldV8: src/types.ts — Vehicle (36–36)

```typescript
   36: export interface Vehicle { id: string; kind: TransportMode; position: Vec3; edgeId: string; progress: number; direction: number; speed: number; state: string; passengers: number; cargo: number; nextDeparture: number }
```

## base295: src/types.ts — Vehicle (38–38)

```typescript
   38: export interface Vehicle { id: string; kind: TransportMode; position: Vec3; edgeId: string; progress: number; direction: number; speed: number; state: string; passengers: number; cargo: number; nextDeparture: number }
```

## oldV8: src/simulation.ts — pointOn-and-traffic (863–968)

```typescript
  863:   private pointOn(edge: NetworkEdge, progress: number): Vec3 {
  864:     const points = edge.points.length >= 2 ? edge.points : [this.world.nodes.find(n => n.id === edge.from)!.position, this.world.nodes.find(n => n.id === edge.to)!.position];
  865:     let total = 0; for (let i = 1; i < points.length; i++) total += distance(points[i - 1], points[i]);
  866:     let remaining = clamp(progress, 0, 1) * total;
  867:     for (let i = 1; i < points.length; i++) { const length = distance(points[i - 1], points[i]); if (remaining <= length || i === points.length - 1) { const t = length ? clamp(remaining / length, 0, 1) : 0; return { x: points[i - 1].x + (points[i].x - points[i - 1].x) * t, y: points[i - 1].y + (points[i].y - points[i - 1].y) * t, z: points[i - 1].z + (points[i].z - points[i - 1].z) * t }; } remaining -= length; }
  868:     return copy(points[0]);
  869:   }
  870:   private updateSignals() { this.state.signals = Object.fromEntries(this.world.nodes.filter(n => (this.neighbors.get(n.id) ?? []).some(e => e.edge.mode === 'road')).map(n => [n.id, (this.runtime.signalOverrides[n.id] ?? ((Math.floor((this.now + 1e-7) / 6) + hash(n.id) % 4) % 2)) as 0 | 1])); }
  871:   private traffic() {
  872:     // Keep an imported legacy save byte-identical until real time advances.
  873:     // Materialize its observation clock before a deferred actor can save again,
  874:     // so post-load time survives another import without backfilling old rides.
  875:     for (const rider of Object.values(this.runtime.riders)) if (rider.arrived === true && rider.arrivedAt === undefined) {
  876:       rider.arrivedAt = this.legacyRiderArrivalAt.get(rider) ?? (this.state.extension?.lastUpdate ?? this.now);
  877:       this.legacyRiderArrivalAt.delete(rider);
  878:     }
  879:     this.updateSignals();
  880:     const lanes = new Map<string, Vehicle[]>();
  881:     for (const vehicle of this.state.vehicles) { const key = `${vehicle.edgeId}:${vehicle.direction}`; const list = lanes.get(key) ?? []; list.push(vehicle); lanes.set(key, list); }
  882:     for (const vehicle of this.state.vehicles) {
  883:       const edge = this.edges.get(vehicle.edgeId)!;
  884:       const roadActor = `vehicle:${vehicle.id}`;
  885:       // Endpoint waiting is not occupancy permission. Only a captured mid-edge
  886:       // vehicle can leave a newly closed deck; an endpoint may select an open leg.
  887:       if (!isRoadOpen(this.state, edge.id) && (vehicle.progress === 0 || vehicle.progress === 1)) {
  888:         const nodeId = vehicle.progress === 0 ? edge.from : edge.to;
  889:         releaseRoadExitPermit(this.world, this.state, roadActor, vehicle.position);
  890:         const exits = (this.neighbors.get(nodeId) ?? []).filter(n => n.edge.mode === vehicle.kind && n.edge.id !== edge.id && isRoadOpen(this.state, n.edge.id));
  891:         if (!exits.length) { vehicle.state = 'roadClosed'; if (this.isDriving(vehicle.id)) this.runtime.driving.speed = 0; continue; }
  892:         const outgoing = this.isDriving(vehicle.id) ? this.chooseTurn(edge, vehicle.progress === 0 ? -1 : 1, nodeId, exits) : exits[Math.floor(this.random() * exits.length)];
  893:         vehicle.edgeId = outgoing.edge.id; vehicle.direction = outgoing.edge.from === nodeId ? 1 : -1; vehicle.progress = vehicle.direction > 0 ? 0 : 1;
  894:         vehicle.state = 'boarding'; vehicle.nextDeparture = Math.max(vehicle.nextDeparture, this.now + (this.isDriving(vehicle.id) ? 2 : 8));
  895:         continue;
  896:       }
  897:       const energy = this.state.energy / 100;
  898:       if (energy < .18 && vehicle.kind !== 'bridge') { vehicle.state = 'noPower'; continue; }
  899:       if (vehicle.kind === 'flight' && (vehicle.progress === 0 || vehicle.progress === 1) && (this.state.hour < 6 || this.state.hour >= 23 || this.state.visibility < .6)) { vehicle.state = 'grounded'; continue; }
  900:       const manual = this.isDriving(vehicle.id);
  901:       if (!manual && this.now + 1e-7 < vehicle.nextDeparture) { vehicle.state = vehicle.state === 'redLight' ? 'redLight' : 'waiting'; continue; }
  902:       if (manual) { const control = this.runtime.driving; const acceleration = control.brake ? -14 : control.throttle >= 0 ? control.throttle * 6 - .65 : control.throttle * 9 - .65; control.speed = clamp(control.speed + acceleration * TICK_SECONDS * this.state.speed, 0, vehicle.kind === 'flight' ? 180 : 38); if (control.speed < .01) { control.speed = 0; vehicle.state = 'parked'; continue; } }
  903:       vehicle.state = 'moving';
  904:       const congestion = vehicle.kind === 'road' ? .8 + (this.state.hour >= 7 && this.state.hour < 9 || this.state.hour >= 17 && this.state.hour < 19 ? -.22 : .1) : 1;
  905:       const delta = (manual ? this.runtime.driving.speed : vehicle.speed) * TICK_SECONDS * this.state.speed * Math.max(.3, energy) * congestion / Math.max(1, edge.length);
  906:       const oldProgress = vehicle.progress;
  907:       let nextProgress = clamp(oldProgress + delta * vehicle.direction, 0, 1);
  908:       if (vehicle.kind === 'road') {
  909:         for (const ahead of lanes.get(`${edge.id}:${vehicle.direction}`) ?? []) {
  910:           if (ahead === vehicle || ahead.edgeId !== edge.id || (ahead.progress - oldProgress) * vehicle.direction <= 1e-7) continue;
  911:           const safeProgress = ahead.progress - vehicle.direction * 6 / Math.max(1, edge.length);
  912:           nextProgress = vehicle.direction > 0 ? Math.min(nextProgress, Math.max(oldProgress, safeProgress)) : Math.max(nextProgress, Math.min(oldProgress, safeProgress));
  913:         }
  914:         if (Math.abs(nextProgress - oldProgress) < 1e-9) { vehicle.state = 'congested'; if (manual) this.runtime.driving.speed = 0; }
  915:       }
  916:       if (!roadMovementAllowed(this.world, this.state, roadActor, vehicle.position, this.pointOn(edge, nextProgress))) { vehicle.state = 'roadClosed'; if (manual) this.runtime.driving.speed = 0; continue; }
  917:       vehicle.progress = nextProgress;
  918:       vehicle.position = this.pointOn(edge, vehicle.progress);
  919:       if (vehicle.kind === 'road') { const front = this.pointOn(edge, Math.min(1, vehicle.progress + .001)), back = this.pointOn(edge, Math.max(0, vehicle.progress - .001)); const dx = front.x - back.x, dz = front.z - back.z, length = Math.hypot(dx, dz); if (length > .001) { vehicle.position.x -= dz / length * vehicle.direction * 1.3; vehicle.position.z += dx / length * vehicle.direction * 1.3; } }
  920:       if (vehicle.progress === 0 && vehicle.direction < 0 || vehicle.progress === 1 && vehicle.direction > 0) {
  921:         const nodeId = vehicle.direction > 0 ? edge.to : edge.from;
  922:         const node = this.world.nodes.find(n => n.id === nodeId)!;
  923:         if (oldProgress > 0 && oldProgress < 1) this.bus.emit({ type: 'vehicle-arrived', vehicleId: vehicle.id, nodeId, fromEdgeId: edge.id, arrivedAt: this.state.extension?.lastUpdate ?? this.now });
  924:         for (const rider of Object.values(this.runtime.riders)) if (rider.vehicleId === vehicle.id && rider.stopNodeId === nodeId && !rider.arrived) { rider.arrived = true; rider.arrivedAt = this.state.extension?.lastUpdate ?? this.now; vehicle.passengers = Math.max(0, vehicle.passengers - 1); }
  925:         releaseRoadExitPermit(this.world, this.state, roadActor, vehicle.position);
  926:         let candidates = (this.neighbors.get(nodeId) ?? []).filter(n => n.edge.mode === vehicle.kind && n.edge.id !== edge.id && isRoadOpen(this.state, n.edge.id));
  927:         if (!isRoadOpen(this.state, edge.id) && !candidates.length) { vehicle.state = 'roadClosed'; if (manual) this.runtime.driving.speed = 0; continue; }
  928:         if (vehicle.kind === 'road') {
  929:           const offset = hash(nodeId) % 4;
  930:           const green = this.state.signals?.[nodeId] ?? ((Math.floor((this.now + 1e-7) / 48) + offset) % 2);
  931:           if (green !== (vehicle.direction > 0 ? 1 : 0)) { vehicle.state = 'redLight'; vehicle.nextDeparture = this.now + 2; if (manual) this.runtime.driving.speed = 0; continue; }
  932:         }
  933:         if (vehicle.cargo > 0) { this.bus.emit({ type: 'cargo-arrived', districtId: node.districtId, amount: vehicle.cargo, shopId: this.runtime.cargoSources?.[vehicle.id] }); vehicle.cargo = 0; if (this.runtime.cargoSources) delete this.runtime.cargoSources[vehicle.id]; }
  934:         const freightCarrier = this.freightCarriers.get(vehicle.id);
  935:         const activePassengers = Object.values(this.runtime.riders).filter(rider => rider.vehicleId === vehicle.id && !rider.arrived).length + (this.state.player.vehicleId === vehicle.id ? 1 : 0);
  936:         // Empty road carriers retain their existing ten-seat passenger use.
  937:         // Cargo cannot replace people who boarded legitimately while empty.
  938:         const loadedPassengerCapacity = vehicle.kind === 'road' ? 2 : this.passengerCapacity(vehicle);
  939:         if (freightCarrier?.kind === vehicle.kind && vehicle.cargo === 0 && Math.max(vehicle.passengers, activePassengers) <= loadedPassengerCapacity) {
  940:           const producer = this.state.shops.find(shop => {
  941:             const site = this.buildings.get(shop.buildingId)!;
  942:             return ['farm', 'dock'].includes(site.kind) && this.shopCommodity(shop) === 'food' && shop.inventory >= 1
  943:               && this.isNearBuilding(site, node.position, 2) && this.isNearBuilding(site, vehicle.position, 2);
  944:           });
  945:           if (producer) {
  946:             vehicle.cargo = Math.min(producer.inventory, freightCarrier.cargoCapacity); producer.inventory -= vehicle.cargo;
  947:             (this.runtime.cargoSources ??= {})[vehicle.id] = producer.id;
  948:             this.bus.emit({ type: 'cargo-loaded', vehicleId: vehicle.id, nodeId, shopId: producer.id, districtId: producer.districtId, amount: vehicle.cargo, quantity: vehicle.cargo });
  949:           }
  950:         }
  951:         if (vehicle.kind === 'flight') this.bus.emit({ type: 'flight' });
  952:         vehicle.passengers = Object.values(this.runtime.riders).filter(r => r.vehicleId === vehicle.id && !r.arrived).length + (this.state.player.vehicleId === vehicle.id ? 1 : 0);
  953:         // The departure graph excludes every closed leg, including a reverse.
  954:         candidates = candidates.filter(n => isRoadOpen(this.state, n.edge.id));
  955:         if (vehicle.kind === 'road' && !manual) { const mainRoads = candidates.filter(c => this.world.nodes.find(n => n.id === c.edge.from)?.station && this.world.nodes.find(n => n.id === c.edge.to)?.station); if (mainRoads.length && this.random() < .85) candidates = mainRoads; }
  956:         if (candidates.length && ['road', 'lightRail', 'maglev', 'ferry'].includes(vehicle.kind)) { const chosen = manual ? this.chooseTurn(edge, vehicle.direction, nodeId, candidates) : candidates[Math.floor(this.random() * candidates.length)]; vehicle.edgeId = chosen.edge.id; vehicle.direction = chosen.edge.from === nodeId ? 1 : -1; vehicle.progress = vehicle.direction > 0 ? 0 : 1; }
  957:         else if (isRoadOpen(this.state, edge.id)) vehicle.direction *= -1;
  958:         else { vehicle.state = 'roadClosed'; if (manual) this.runtime.driving.speed = 0; continue; }
  959:         vehicle.state = 'boarding';
  960:         const maintenance = Object.entries(this.state.culture?.transportMaintenance ?? {}).some(([siteId, item]) => item.maintainedUntil > (this.state.extension?.lastUpdate ?? this.now) && item.units >= 4 && this.state.culture?.orders.some(order => order.id === item.orderId && order.state === 'fulfilled') && this.buildings.get(siteId)?.kind === 'station' && distance(this.buildings.get(siteId)!.door, node.position) <= 40);
  961:         const dwell = manual ? 2 : vehicle.kind === 'flight' ? 75 : vehicle.kind === 'road' ? 8 : this.state.hour >= 22 || this.state.hour < 6 ? 48 : 16;
  962:         vehicle.nextDeparture = this.now + dwell - (!manual && vehicle.kind !== 'flight' && maintenance ? .5 : 0);
  963:       }
  964:     }
  965:     const boarded = this.state.vehicles.find(v => v.id === this.state.player.vehicleId);
  966:     if (boarded) this.state.player.position = copy(boarded.position);
  967:   }
  968:   private chooseTurn(
```

## base295: src/simulation.ts — pointOn-and-traffic (880–985)

```typescript
  880:   private pointOn(edge: NetworkEdge, progress: number): Vec3 {
  881:     const points = edge.points.length >= 2 ? edge.points : [this.world.nodes.find(n => n.id === edge.from)!.position, this.world.nodes.find(n => n.id === edge.to)!.position];
  882:     let total = 0; for (let i = 1; i < points.length; i++) total += distance(points[i - 1], points[i]);
  883:     let remaining = clamp(progress, 0, 1) * total;
  884:     for (let i = 1; i < points.length; i++) { const length = distance(points[i - 1], points[i]); if (remaining <= length || i === points.length - 1) { const t = length ? clamp(remaining / length, 0, 1) : 0; return { x: points[i - 1].x + (points[i].x - points[i - 1].x) * t, y: points[i - 1].y + (points[i].y - points[i - 1].y) * t, z: points[i - 1].z + (points[i].z - points[i - 1].z) * t }; } remaining -= length; }
  885:     return copy(points[0]);
  886:   }
  887:   private updateSignals() { this.state.signals = Object.fromEntries(this.world.nodes.filter(n => (this.neighbors.get(n.id) ?? []).some(e => e.edge.mode === 'road')).map(n => [n.id, (this.runtime.signalOverrides[n.id] ?? ((Math.floor((this.now + 1e-7) / 6) + hash(n.id) % 4) % 2)) as 0 | 1])); }
  888:   private traffic() {
  889:     // Keep an imported legacy save byte-identical until real time advances.
  890:     // Materialize its observation clock before a deferred actor can save again,
  891:     // so post-load time survives another import without backfilling old rides.
  892:     for (const rider of Object.values(this.runtime.riders)) if (rider.arrived === true && rider.arrivedAt === undefined) {
  893:       rider.arrivedAt = this.legacyRiderArrivalAt.get(rider) ?? (this.state.extension?.lastUpdate ?? this.now);
  894:       this.legacyRiderArrivalAt.delete(rider);
  895:     }
  896:     this.updateSignals();
  897:     const lanes = new Map<string, Vehicle[]>();
  898:     for (const vehicle of this.state.vehicles) { const key = `${vehicle.edgeId}:${vehicle.direction}`; const list = lanes.get(key) ?? []; list.push(vehicle); lanes.set(key, list); }
  899:     for (const vehicle of this.state.vehicles) {
  900:       const edge = this.edges.get(vehicle.edgeId)!;
  901:       const roadActor = `vehicle:${vehicle.id}`;
  902:       // Endpoint waiting is not occupancy permission. Only a captured mid-edge
  903:       // vehicle can leave a newly closed deck; an endpoint may select an open leg.
  904:       if (!isRoadOpen(this.state, edge.id) && (vehicle.progress === 0 || vehicle.progress === 1)) {
  905:         const nodeId = vehicle.progress === 0 ? edge.from : edge.to;
  906:         releaseRoadExitPermit(this.world, this.state, roadActor, vehicle.position);
  907:         const exits = (this.neighbors.get(nodeId) ?? []).filter(n => n.edge.mode === vehicle.kind && n.edge.id !== edge.id && isRoadOpen(this.state, n.edge.id));
  908:         if (!exits.length) { vehicle.state = 'roadClosed'; if (this.isDriving(vehicle.id)) this.runtime.driving.speed = 0; continue; }
  909:         const outgoing = this.isDriving(vehicle.id) ? this.chooseTurn(edge, vehicle.progress === 0 ? -1 : 1, nodeId, exits) : exits[Math.floor(this.random() * exits.length)];
  910:         vehicle.edgeId = outgoing.edge.id; vehicle.direction = outgoing.edge.from === nodeId ? 1 : -1; vehicle.progress = vehicle.direction > 0 ? 0 : 1;
  911:         vehicle.state = 'boarding'; vehicle.nextDeparture = Math.max(vehicle.nextDeparture, this.now + (this.isDriving(vehicle.id) ? 2 : 8));
  912:         continue;
  913:       }
  914:       const energy = this.state.energy / 100;
  915:       if (energy < .18 && vehicle.kind !== 'bridge') { vehicle.state = 'noPower'; continue; }
  916:       if (vehicle.kind === 'flight' && (vehicle.progress === 0 || vehicle.progress === 1) && (this.state.hour < 6 || this.state.hour >= 23 || this.state.visibility < .6)) { vehicle.state = 'grounded'; continue; }
  917:       const manual = this.isDriving(vehicle.id);
  918:       if (!manual && this.now + 1e-7 < vehicle.nextDeparture) { vehicle.state = vehicle.state === 'redLight' ? 'redLight' : 'waiting'; continue; }
  919:       if (manual) { const control = this.runtime.driving; const acceleration = control.brake ? -14 : control.throttle >= 0 ? control.throttle * 6 - .65 : control.throttle * 9 - .65; control.speed = clamp(control.speed + acceleration * TICK_SECONDS * this.state.speed, 0, vehicle.kind === 'flight' ? 180 : 38); if (control.speed < .01) { control.speed = 0; vehicle.state = 'parked'; continue; } }
  920:       vehicle.state = 'moving';
  921:       const congestion = vehicle.kind === 'road' ? .8 + (this.state.hour >= 7 && this.state.hour < 9 || this.state.hour >= 17 && this.state.hour < 19 ? -.22 : .1) : 1;
  922:       const delta = (manual ? this.runtime.driving.speed : vehicle.speed) * TICK_SECONDS * this.state.speed * Math.max(.3, energy) * congestion / Math.max(1, edge.length);
  923:       const oldProgress = vehicle.progress;
  924:       let nextProgress = clamp(oldProgress + delta * vehicle.direction, 0, 1);
  925:       if (vehicle.kind === 'road') {
  926:         for (const ahead of lanes.get(`${edge.id}:${vehicle.direction}`) ?? []) {
  927:           if (ahead === vehicle || ahead.edgeId !== edge.id || (ahead.progress - oldProgress) * vehicle.direction <= 1e-7) continue;
  928:           const safeProgress = ahead.progress - vehicle.direction * 6 / Math.max(1, edge.length);
  929:           nextProgress = vehicle.direction > 0 ? Math.min(nextProgress, Math.max(oldProgress, safeProgress)) : Math.max(nextProgress, Math.min(oldProgress, safeProgress));
  930:         }
  931:         if (Math.abs(nextProgress - oldProgress) < 1e-9) { vehicle.state = 'congested'; if (manual) this.runtime.driving.speed = 0; }
  932:       }
  933:       if (!roadMovementAllowed(this.world, this.state, roadActor, vehicle.position, this.pointOn(edge, nextProgress))) { vehicle.state = 'roadClosed'; if (manual) this.runtime.driving.speed = 0; continue; }
  934:       vehicle.progress = nextProgress;
  935:       vehicle.position = this.pointOn(edge, vehicle.progress);
  936:       if (vehicle.kind === 'road') { const front = this.pointOn(edge, Math.min(1, vehicle.progress + .001)), back = this.pointOn(edge, Math.max(0, vehicle.progress - .001)); const dx = front.x - back.x, dz = front.z - back.z, length = Math.hypot(dx, dz); if (length > .001) { vehicle.position.x -= dz / length * vehicle.direction * 1.3; vehicle.position.z += dx / length * vehicle.direction * 1.3; } }
  937:       if (vehicle.progress === 0 && vehicle.direction < 0 || vehicle.progress === 1 && vehicle.direction > 0) {
  938:         const nodeId = vehicle.direction > 0 ? edge.to : edge.from;
  939:         const node = this.world.nodes.find(n => n.id === nodeId)!;
  940:         if (oldProgress > 0 && oldProgress < 1) this.bus.emit({ type: 'vehicle-arrived', vehicleId: vehicle.id, nodeId, fromEdgeId: edge.id, arrivedAt: this.state.extension?.lastUpdate ?? this.now });
  941:         for (const rider of Object.values(this.runtime.riders)) if (rider.vehicleId === vehicle.id && rider.stopNodeId === nodeId && !rider.arrived) { rider.arrived = true; rider.arrivedAt = this.state.extension?.lastUpdate ?? this.now; vehicle.passengers = Math.max(0, vehicle.passengers - 1); }
  942:         releaseRoadExitPermit(this.world, this.state, roadActor, vehicle.position);
  943:         let candidates = (this.neighbors.get(nodeId) ?? []).filter(n => n.edge.mode === vehicle.kind && n.edge.id !== edge.id && isRoadOpen(this.state, n.edge.id));
  944:         if (!isRoadOpen(this.state, edge.id) && !candidates.length) { vehicle.state = 'roadClosed'; if (manual) this.runtime.driving.speed = 0; continue; }
  945:         if (vehicle.kind === 'road') {
  946:           const offset = hash(nodeId) % 4;
  947:           const green = this.state.signals?.[nodeId] ?? ((Math.floor((this.now + 1e-7) / 48) + offset) % 2);
  948:           if (green !== (vehicle.direction > 0 ? 1 : 0)) { vehicle.state = 'redLight'; vehicle.nextDeparture = this.now + 2; if (manual) this.runtime.driving.speed = 0; continue; }
  949:         }
  950:         if (vehicle.cargo > 0) { this.bus.emit({ type: 'cargo-arrived', districtId: node.districtId, amount: vehicle.cargo, shopId: this.runtime.cargoSources?.[vehicle.id] }); vehicle.cargo = 0; if (this.runtime.cargoSources) delete this.runtime.cargoSources[vehicle.id]; }
  951:         const freightCarrier = this.freightCarriers.get(vehicle.id);
  952:         const activePassengers = Object.values(this.runtime.riders).filter(rider => rider.vehicleId === vehicle.id && !rider.arrived).length + (this.state.player.vehicleId === vehicle.id ? 1 : 0);
  953:         // Empty road carriers retain their existing ten-seat passenger use.
  954:         // Cargo cannot replace people who boarded legitimately while empty.
  955:         const loadedPassengerCapacity = vehicle.kind === 'road' ? 2 : this.passengerCapacity(vehicle);
  956:         if (freightCarrier?.kind === vehicle.kind && vehicle.cargo === 0 && Math.max(vehicle.passengers, activePassengers) <= loadedPassengerCapacity) {
  957:           const producer = this.state.shops.find(shop => {
  958:             const site = this.buildings.get(shop.buildingId)!;
  959:             return ['farm', 'dock'].includes(site.kind) && this.shopCommodity(shop) === 'food' && shop.inventory >= 1
  960:               && this.isNearBuilding(site, node.position, 2) && this.isNearBuilding(site, vehicle.position, 2);
  961:           });
  962:           if (producer) {
  963:             vehicle.cargo = Math.min(producer.inventory, freightCarrier.cargoCapacity); producer.inventory -= vehicle.cargo;
  964:             (this.runtime.cargoSources ??= {})[vehicle.id] = producer.id;
  965:             this.bus.emit({ type: 'cargo-loaded', vehicleId: vehicle.id, nodeId, shopId: producer.id, districtId: producer.districtId, amount: vehicle.cargo, quantity: vehicle.cargo });
  966:           }
  967:         }
  968:         if (vehicle.kind === 'flight') this.bus.emit({ type: 'flight' });
  969:         vehicle.passengers = Object.values(this.runtime.riders).filter(r => r.vehicleId === vehicle.id && !r.arrived).length + (this.state.player.vehicleId === vehicle.id ? 1 : 0);
  970:         // The departure graph excludes every closed leg, including a reverse.
  971:         candidates = candidates.filter(n => isRoadOpen(this.state, n.edge.id));
  972:         if (vehicle.kind === 'road' && !manual) { const mainRoads = candidates.filter(c => this.world.nodes.find(n => n.id === c.edge.from)?.station && this.world.nodes.find(n => n.id === c.edge.to)?.station); if (mainRoads.length && this.random() < .85) candidates = mainRoads; }
  973:         if (candidates.length && ['road', 'lightRail', 'maglev', 'ferry'].includes(vehicle.kind)) { const chosen = manual ? this.chooseTurn(edge, vehicle.direction, nodeId, candidates) : candidates[Math.floor(this.random() * candidates.length)]; vehicle.edgeId = chosen.edge.id; vehicle.direction = chosen.edge.from === nodeId ? 1 : -1; vehicle.progress = vehicle.direction > 0 ? 0 : 1; }
  974:         else if (isRoadOpen(this.state, edge.id)) vehicle.direction *= -1;
  975:         else { vehicle.state = 'roadClosed'; if (manual) this.runtime.driving.speed = 0; continue; }
  976:         vehicle.state = 'boarding';
  977:         const maintenance = Object.entries(this.state.culture?.transportMaintenance ?? {}).some(([siteId, item]) => item.maintainedUntil > (this.state.extension?.lastUpdate ?? this.now) && item.units >= 4 && this.state.culture?.orders.some(order => order.id === item.orderId && order.state === 'fulfilled') && this.buildings.get(siteId)?.kind === 'station' && distance(this.buildings.get(siteId)!.door, node.position) <= 40);
  978:         const dwell = manual ? 2 : vehicle.kind === 'flight' ? 75 : vehicle.kind === 'road' ? 8 : this.state.hour >= 22 || this.state.hour < 6 ? 48 : 16;
  979:         vehicle.nextDeparture = this.now + dwell - (!manual && vehicle.kind !== 'flight' && maintenance ? .5 : 0);
  980:       }
  981:     }
  982:     const boarded = this.state.vehicles.find(v => v.id === this.state.player.vehicleId);
  983:     if (boarded) this.state.player.position = copy(boarded.position);
  984:   }
  985:   private chooseTurn(
```

## oldV8: src/simulation.ts — passengerCapacity (717–717)

```typescript
  717:   private passengerCapacity(vehicle: Vehicle): number { return vehicle.kind === 'road' ? vehicle.cargo > 0 ? 2 : 10 : vehicle.kind === 'flight' ? 80 : Math.max(4, this.edges.get(vehicle.edgeId)?.capacity ?? 24); }
```

## base295: src/simulation.ts — passengerCapacity (734–734)

```typescript
  734:   private passengerCapacity(vehicle: Vehicle): number { return vehicle.kind === 'road' ? vehicle.cargo > 0 ? 2 : 10 : vehicle.kind === 'flight' ? 80 : Math.max(4, this.edges.get(vehicle.edgeId)?.capacity ?? 24); }
```

## oldV8: src/simulation.ts — ride-and-leaveCommands (2288–2298)

```typescript
 2288:     if (command.type === 'ride' || command.type === 'drive') {
 2289:       const vehicle = this.state.vehicles.find(v => v.id === command.targetId); if (!vehicle || distance(p.position, vehicle.position) > 35) return fail('请到车辆或站点附近上车。'); if (p.vehicleId) return fail('请先离开当前载具。'); if (!isRoadOpen(this.state, vehicle.edgeId) || vehicle.state === 'roadClosed') return fail('此路段已关闭，请等候真实改道或修复后上车。'); if (vehicle.state === 'moving') return fail('请等车辆进站停稳后上车。');
 2290:       if (vehicle.passengers >= this.passengerCapacity(vehicle)) return fail('载具已满员，请等下一班。');
 2291:       if (command.type === 'drive' && (!['driver', 'police', 'soldier'].some(role => this.hasIdentity(role as Role)) || vehicle.kind !== 'road' && !(this.hasIdentity('driver') && vehicle.kind === 'flight'))) return fail('需驾驶员或执勤人员资格，且载具须符合许可。');
 2292:       const cost = command.type === 'drive' ? 0 : vehicle.kind === 'flight' ? 45 : 4; if (p.money < cost) return fail('票款不足。'); p.money -= cost; if (cost) this.bus.emit({ type: 'transit-fare', amount: cost, citizenId: 'player', vehicleId: vehicle.id }); p.vehicleId = vehicle.id; vehicle.passengers++; p.position = copy(vehicle.position); p.inventory.driving = command.type === 'drive' ? 1 : 0; this.runtime.driving = { vehicleId: command.type === 'drive' ? vehicle.id : null, throttle: 0, turn: 0, brake: true, speed: 0 }; if (command.type === 'drive') vehicle.nextDeparture = this.now; return success(command.type === 'drive' ? '取得载具操作权：W加速、S减速、空格刹车、A/D选择路口方向，须遵守信号。' : '已登车，角色位置将随真实载具移动。');
 2293:     }
 2294:     if (command.type === 'leaveVehicle') {
 2295:       const vehicle = this.state.vehicles.find(v => v.id === p.vehicleId); if (!vehicle) return fail('当前未乘坐载具。');
 2296:       const node = this.nearestNode(vehicle.position); if (vehicle.state === 'moving' || distance(vehicle.position, node.position) > 45) return fail('请等候车辆抵达合法停靠点后下车。'); p.position = copy(node.position); p.vehicleId = null; p.inventory.driving = 0; this.runtime.driving = { vehicleId: null, throttle: 0, turn: 0, brake: true, speed: 0 }; vehicle.passengers = Math.max(0, vehicle.passengers - 1); return success(`已在${node.name}下车。`);
 2297:     }
 2298:     if (command.type === 'signal'
```

## base295: src/simulation.ts — ride-and-leaveCommands (2314–2324)

```typescript
 2314:     if (command.type === 'ride' || command.type === 'drive') {
 2315:       const vehicle = this.state.vehicles.find(v => v.id === command.targetId); if (!vehicle || distance(p.position, vehicle.position) > 35) return fail('请到车辆或站点附近上车。'); if (p.vehicleId) return fail('请先离开当前载具。'); if (!isRoadOpen(this.state, vehicle.edgeId) || vehicle.state === 'roadClosed') return fail('此路段已关闭，请等候真实改道或修复后上车。'); if (vehicle.state === 'moving') return fail('请等车辆进站停稳后上车。');
 2316:       if (vehicle.passengers >= this.passengerCapacity(vehicle)) return fail('载具已满员，请等下一班。');
 2317:       if (command.type === 'drive' && (!['driver', 'police', 'soldier'].some(role => this.hasIdentity(role as Role)) || vehicle.kind !== 'road' && !(this.hasIdentity('driver') && vehicle.kind === 'flight'))) return fail('需驾驶员或执勤人员资格，且载具须符合许可。');
 2318:       const cost = command.type === 'drive' ? 0 : vehicle.kind === 'flight' ? 45 : 4; if (p.money < cost) return fail('票款不足。'); p.money -= cost; if (cost) this.bus.emit({ type: 'transit-fare', amount: cost, citizenId: 'player', vehicleId: vehicle.id }); p.vehicleId = vehicle.id; vehicle.passengers++; p.position = copy(vehicle.position); p.inventory.driving = command.type === 'drive' ? 1 : 0; this.runtime.driving = { vehicleId: command.type === 'drive' ? vehicle.id : null, throttle: 0, turn: 0, brake: true, speed: 0 }; if (command.type === 'drive') vehicle.nextDeparture = this.now; return success(command.type === 'drive' ? '取得载具操作权：W加速、S减速、空格刹车、A/D选择路口方向，须遵守信号。' : '已登车，角色位置将随真实载具移动。');
 2319:     }
 2320:     if (command.type === 'leaveVehicle') {
 2321:       const vehicle = this.state.vehicles.find(v => v.id === p.vehicleId); if (!vehicle) return fail('当前未乘坐载具。');
 2322:       const node = this.nearestNode(vehicle.position); if (vehicle.state === 'moving' || distance(vehicle.position, node.position) > 45) return fail('请等候车辆抵达合法停靠点后下车。'); p.position = copy(node.position); p.vehicleId = null; p.inventory.driving = 0; this.runtime.driving = { vehicleId: null, throttle: 0, turn: 0, brake: true, speed: 0 }; vehicle.passengers = Math.max(0, vehicle.passengers - 1); return success(`已在${node.name}下车。`);
 2323:     }
 2324:     if (command.type === 'signal'
```

## oldV8: src/controller.ts — syncPassenger (155–161)

```typescript
  155:   syncPassenger(position: Vec3): void {
  156:     this.feet = { ...position };
  157:     this.discardWalkingInput();
  158:     if (this.mode === 'walk') this.camera.position.set(position.x, position.y + EYE_HEIGHT + 0.5, position.z);
  159:     this.inside = null;
  160:     this.supportingSite = null;
  161:   }
```

## base295: src/controller.ts — syncPassenger (151–157)

```typescript
  151:   syncPassenger(position: Vec3): void {
  152:     this.feet = { ...position };
  153:     this.discardWalkingInput();
  154:     if (this.mode === 'walk') this.camera.position.set(position.x, position.y + EYE_HEIGHT + 0.5, position.z);
  155:     this.inside = null;
  156:     this.supportingSite = null;
  157:   }
```


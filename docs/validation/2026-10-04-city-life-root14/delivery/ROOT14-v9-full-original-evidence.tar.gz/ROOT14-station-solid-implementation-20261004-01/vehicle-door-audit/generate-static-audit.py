"""Read-only source audit and parameter arithmetic; imports no product code."""
from pathlib import Path
import hashlib
import json
import math
import re
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
OLD = Path('/workspace/yunshan-work/ROOT13-street-solid-authority-20261004-01/source-as-run-final')
BASE = Path('/workspace/yunshan-work/ROOT13-integrated-civic-shop-light-20261004-01/source-as-prepared')
FROZEN = BASE.parent / 'FROZEN-INPUTS.json'
sha = lambda value: hashlib.sha256(value).hexdigest()
freeze = json.loads(FROZEN.read_text())
files = ['src/renderer.ts', 'src/types.ts', 'src/simulation.ts', 'src/controller.ts',
         'src/world.ts', 'src/transport-geometry.ts', 'src/rendering/citizen-appearance.ts']
input_rows = []
for path in files:
    a, b = (OLD / path).read_bytes(), (BASE / path).read_bytes()
    actual = sha(b)
    input_rows.append({'path': path, 'oldBytes': len(a), 'base295Bytes': len(b),
                       'oldSha256': sha(a), 'base295Sha256': actual,
                       'wholeFileByteEqual': a == b, 'frozen295Sha256': freeze['inputs'][path],
                       'base295MatchesFrozen': actual == freeze['inputs'][path]})
assert all(row['base295MatchesFrozen'] for row in input_rows)

sections = [
 ('src/renderer.ts', 'makePool-and-put', r'  private makePool\([\s\S]*?\n  update\('),
 ('src/renderer.ts', 'vehicleUpdate', r'    const counts = new Map<string, number>\(\);[\s\S]*?\n  }\n'),
 ('src/types.ts', 'Vehicle', r'export interface Vehicle [^\n]*'),
 ('src/simulation.ts', 'pointOn-and-traffic', r'  private pointOn\([\s\S]*?\n  private chooseTurn\('),
 ('src/simulation.ts', 'passengerCapacity', r'  private passengerCapacity[^\n]*'),
 ('src/simulation.ts', 'ride-and-leaveCommands', r"    if \(command.type === 'ride'[\s\S]*?    if \(command.type === 'signal'"),
 ('src/controller.ts', 'syncPassenger', r'  syncPassenger\([\s\S]*?\n  }'),
]
section_rows = []
excerpts = ['# Static source excerpts', '', 'This file copies source text with original line numbers. No product code was executed.', '']
for path, name, pattern in sections:
    texts = [(OLD / path).read_text(), (BASE / path).read_text()]
    matches = [re.search(pattern, text) for text in texts]
    values = [match.group() for match in matches]
    row = {'path': path, 'section': name, 'oldSha256': sha(values[0].encode()),
           'base295Sha256': sha(values[1].encode()), 'byteEqual': values[0] == values[1]}
    for label, text, match in zip(['oldV8', 'base295'], texts, matches):
        first = text[:match.start()].count('\n') + 1
        last = first + match.group().count('\n')
        row[label + 'Lines'] = [first, last]
        excerpts += [f'## {label}: {path} — {name} ({first}–{last})', '', '```typescript']
        excerpts += [f'{first+i:5d}: {line}' for i, line in enumerate(match.group().splitlines())]
        excerpts += ['```', '']
    section_rows.append(row)
assert all(row['byteEqual'] for row in section_rows)

comparison = {
 'status': 'STATIC_READ_ONLY', 'generatedAtUtc': datetime.now(timezone.utc).isoformat(),
 'oldV8Source': str(OLD), 'base295Source': str(BASE), 'frozenManifest': str(FROZEN),
 'frozenManifestSha256': sha(FROZEN.read_bytes()), 'frozenInputCount': freeze['inputCount'],
 'frozenProductionSourceCount': freeze['productionSourceCount'], 'checkedFiles': input_rows,
 'checkedSections': section_rows,
 'validation': {'sourceSubsetFrozenMatch': 'PASS_STATIC_HASH', 'vehicleSectionsEqual': 'PASS_STATIC_BYTES',
                'factory': 'NOT_RUN', 'simulation': 'NOT_RUN', 'tests': 'NOT_RUN',
                'build': 'NOT_RUN', 'browserGpu': 'NOT_RUN', 'sharedSourceWrites': 0,
                'closedArchiveWrites': 0, 'libraryGitNetworkOperations': 0},
}

def box(name, center, size, material, purpose, **extra):
    # Local unrotated unit box parameters, not a witnessed world Float32 matrix.
    minimum = [round(c-s/2, 12) for c, s in zip(center, size)]
    maximum = [round(c+s/2, 12) for c, s in zip(center, size)]
    return {'id': name, 'primitive': 'box', 'localCenter': center, 'localSize': size,
            'localBounds': {'minimum': minimum, 'maximum': maximum},
            'material': material, 'purpose': purpose, **extra}

before = {}
after = {}
for kind, width, length, color in [('road', 2.5, 5.5, '#a77851'),
                                   ('lightRail', 3.3, 16, '#d0b985'),
                                   ('maglev', 3.3, 16, '#d0b985')]:
    before[kind] = {
        'status': 'OBSERVED_SOURCE_PARAMETERS', 'outerWidth': width, 'outerLength': length,
        'parts': [box('body', [0, 1.1, 0], [width, 1.5, length], 'roof', 'filledBody', color=color),
                  box('head', [0, 2.1, 0], [width*.85, .8, length*.68], 'glass', 'filledHead', color='#517f82'),
                  box('trim', [0, .6, 0], [width+.25, .2, length*.85], 'cyan', 'filledTrim')],
        'floorDescriptor': None, 'doorDescriptors': [], 'roofSlabDescriptor': None,
        'doorAnimation': None, 'interiorCavity': False,
        'capsulePassage': 'BLOCKED_BY_FILLED_BODY_IF_ACTUAL_MESH_IS_SOLID',
        'liveControllerVehicleCollision': 'NO_VEHICLE_BODY_RECIPE_IN_REVIEWED_CONTROLLER_PATH',
    }
    parts = [box('floor', [0, .1, 0], [width, .2, length], 'metal', 'floor', walkableTop=True),
             box('roof', [0, 2.4, 0], [width, .2, length], 'roof', 'roof', walkableTop=False)]
    # Side walls retain opaque lower panels and real thin glass upper panels.
    # Both sides have the same aperture; a berth must authorize the actual side.
    for side in [-1, 1]:
        x = side * (width/2-.1)
        for end in [-1, 1]:
            z = end * (length/4+.3)
            span = length/2-.6
            parts += [box(f'side-{side}-{end}-lower', [x, .9, z], [.2, 1.4, span], 'roof', 'wall', color=color),
                      box(f'side-{side}-{end}-upper', [x, 1.95, z], [.2, .7, span], 'glass', 'window', color='#517f82'),
                      box(f'side-{side}-{end}-trim', [side*(width/2-.01), .6, z], [.02, .2, span], 'cyan', 'wallSkin')]
        z = side*(length/2-.1)
        parts += [box(f'end-{side}-lower', [0, .9, z], [width, 1.4, .2], 'roof', 'wall', color=color),
                  box(f'end-{side}-upper', [0, 1.95, z], [width, .7, .2], 'glass', 'window', color='#517f82'),
                  box(f'end-{side}-trim', [0, .6, side*(length/2-.01)], [width, .2, .02], 'cyan', 'wallSkin')]
    doors = []
    for side in [-1, 1]:
        leaves = []
        for leaf in [-1, 1]:
            leaves.append({
                **box(f'door-{side}-{leaf}', [side*(width/2+.05), 1.25, leaf*.3], [.1, 2.1, .6], 'glass', 'doorLeaf'),
                'localTranslationAtFraction': {'axis': 'z', 'signedTravel': leaf*.6, 'fractionInput': 'doorOpenFraction'},
                'localCenterWhenFullyOpen': [side*(width/2+.05), 1.25, leaf*.9],
            })
        doors.append({'id': f'side-door-{side}', 'side': side,
                      'wallThicknessRangeX': sorted([side*(width/2-.2), side*(width/2)]),
                      'opening': {'zRange': [-.6, .6], 'yRange': [.2, 2.3], 'width': 1.2, 'height': 2.1},
                      'leaves': leaves, 'freeWidthByFraction': '1.2 * doorOpenFraction',
                      'capsuleRequiresFullyOpen': True})
    after[kind] = {
        'status': 'PROPOSED_ONLY_NOT_IMPLEMENTED_NOT_VALIDATED',
        'preservedOuterMainShellWidth': width, 'preservedOuterLength': length,
        'preservedHighestPoint': 2.5, 'externalDoorMaxWidth': width+.2,
        'floorTop': .2, 'roofUnderside': 2.3, 'wallThickness': .2,
        'interiorClearWidth': width-.4, 'interiorClearLength': length-.4, 'interiorHeadroom': 2.1,
        'capsuleStandingCenterDomainNominal': {'xRange': [-round(width/2-.55, 12), round(width/2-.55, 12)],
                                             'zRange': [-round(length/2-.55, 12), round(length/2-.55, 12)],
                                             'feetY': .2,
                                             'meaning': 'Derived nominal erosion of the real proposed floor and side/end walls; not an accepted safe point'},
        'staticParts': parts, 'doors': doors,
        'headFilledBoxRetained': False,
        'replacementMeaning': 'Replace filled visual volumes with explicitly listed floor, roof, side/end opaque panels, thin glass panels, and retained door leaves; never hide/delete all vehicle body to create passage',
        'activation': 'New explicitly selected layout only; old archived layouts retain the witnessed recipe',
        'supportRule': 'Only top faces of actually rendered descriptor floor solids, with complete circular foot coverage and full capsule sweep; no unattached support point',
        'stateRequirement': 'A new authoritative validated berth/door phase contract is required; current Vehicle has no doorOpenFraction',
        'animationProposal': {'openDurationGameMinutes': .5, 'closeDurationGameMinutes': .5,
                              'leafSlideDistance': .6, 'fullOpenNominalGap': 1.2,
                              'boardingAllowedFraction': 1,
                              'mustInterlockDepartureWhilePortalOccupied': True,
                              'clockSource': 'validated core game minutes, not render elapsed time'},
    }

descriptor = {
 'schema': 'yunshan-vehicle-door-static-proposal-1', 'status': 'STATIC_PROPOSAL_ONLY',
 'sourceComparison': 'SOURCE-COMPARISON.json',
 'capsule': {'radius': .35, 'height': 1.72, 'minimumNominalDoorWidth': .7,
             'maximumStep': .4, 'source': 'old v8 street-solid-authority.ts:6-8; controller.ts:11-12'},
 'observedWorldTransform': {
   'origin': 'vehicle.position exactly', 'axis': [0, 1, 0], 'pitch': 0, 'roll': 0,
   'yaw': 'atan2(edge.points[i+1].x-edge.points[i].x, edge.points[i+1].z-edge.points[i].z) + (vehicle.direction < 0 ? pi : 0)',
   'segmentIndex': 'min(points.length-2, floor(clamp(progress,0,.99999)*(points.length-1)))',
   'missingEdgeOrFewerThanTwoPointsYaw': 0,
   'worldFromLocal': {'x': 'p.x + cos(yaw)*local.x + sin(yaw)*local.z',
                      'y': 'p.y + local.y', 'z': 'p.z - sin(yaw)*local.x + cos(yaw)*local.z'},
   'unitBoxMatrix': 'compose(worldCenter, quaternion about +Y, localSize); setMatrixAt stores Float32 instanceMatrix',
   'actualMatrixNotMaterializedInThisAudit': True,
 },
 'observedSimulationPose': {
   'position': '3D arc-length interpolation on edge.points; fallback to endpoint node positions if fewer than 2 points',
   'roadLaneOffsetOnMovement': {'x': '-dz/hypot(dx,dz)*vehicle.direction*1.3', 'z': '+dx/hypot(dx,dz)*vehicle.direction*1.3'},
   'roadLaneOffsetOnInitialization': False,
   'rendererYawCanUseDifferentSegmentThanPosition': True,
   'endpointTransition': 'edgeId/direction/progress change before another position update; visual yaw may change while the last position remains',
 },
 'observedGeometry': before, 'proposedGeometry': after,
 'analyticalOnly': {
   'proposedDoorWidthMarginPerSide': .25, 'proposedDoorHeightMargin': .38,
   'proposedStationPlatformStepIfExactSameNodePose': .3,
   'stationPlatformReference': 'old renderer.ts:782 and network-solid-recipe.ts:118 station slab top=node.y-.1',
   'railExistingPassengerCapacity': 180, 'railOuterFootprintArea': 52.8,
   'railProposedInteriorArea': 45.24,
   'minimumAreaFor180DistinctStandingCapsuleFootDiscs': 180*math.pi*.35**2,
   'capacityConclusion': '180 simultaneous non-overlapping full standing capsules cannot fit even in the retained entire outer footprint; current capacity is an abstract edge capacity, not a physical cabin capacity',
 },
 'unresolvedImplementationRequirements': [
   'actual renderer and collision/support must consume the same immutable local solids and actual Float32 world matrices',
   'berth docking must be proven from actual platform/door/floor geometry; waiting/boarding state or 35/40/45m radius alone is insufficient',
   'continuous platform-to-door-to-floor capsule movement must consume real distance/time and never assign the actor directly to vehicle origin or nearest node',
   'current origin-following riders need actual vehicle-local supported positions, occupancy and capacity derived from a physical cabin plan',
   'actual yaw/position consistency and endpoint instant turn require a separate pose contract decision before accepting moving interior support',
   'door phase must preserve physical leaves when closed, slide them into measured free exterior pockets, and interlock motion while a body occupies the aperture',
   'floor .2 height is only a nominal candidate: actual station/platform/road/curb/rail Float32 contact and overhead/body sweep have not been checked',
   'renderer must retain the occupied vehicle hull instead of skipping the player vehicle within 25m',
 ],
 'acceptance': {'arithmeticAndSourceComparison': 'STATIC_ONLY', 'factory': 'NOT_RUN',
                'simulation': 'NOT_RUN', 'tests': 'NOT_RUN', 'build': 'NOT_RUN',
                'browserGpu': 'NOT_RUN', 'naturalDoorPassage': 'NOT_RUN',
                'sharedSourceModified': False},
}
for name, value in [('SOURCE-COMPARISON.json', comparison), ('DESCRIPTOR-CANDIDATE.json', descriptor)]:
    (OUT/name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')
(OUT/'SOURCE-EXCERPTS.md').write_text('\n'.join(excerpts)+'\n')
print(json.dumps({'status': 'STATIC_ARTIFACTS_WRITTEN', 'checked295Files': len(input_rows),
                  'matchedVehicleSections': len(section_rows), 'productCodeExecuted': False}, ensure_ascii=False))

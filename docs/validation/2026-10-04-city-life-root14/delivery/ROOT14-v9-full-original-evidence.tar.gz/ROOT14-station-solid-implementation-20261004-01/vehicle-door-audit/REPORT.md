# 载具实体门与内部支撑静态审计

结论：闭组 v8 与 295 精确基线中的 `road`、`lightRail`、`maglev` 都是完整的 `body/head/trim` 三盒体。没有车门网格、门洞、门动画或真实车厢地板支撑。把这些实际网格作为实体后，完整半径 0.35 m、身高 1.72 m 的身体不能从外部走入车内；当前成功的上车命令是位置赋值，不是穿门证明。

本子任务只读代码并在本目录生成报告/参数 JSON；没有调用产品 factory、Simulation、测试、构建、浏览器或 GPU，没有更改共享源码、isolated source、world/controller/Simulation 或旧 CLOSED，没有 Library、Git、网络操作。生成器只使用 Python 标准库读取字节、计算 SHA、提取文本及做尺寸算术。所有尺寸候选都是 **PLAN / NOT_IMPLEMENTED / NOT_RUN**。

## 输入与证据范围

- 闭组 v8：`/workspace/yunshan-work/ROOT13-street-solid-authority-20261004-01/source-as-run-final`。
- 295 基线：`/workspace/yunshan-work/ROOT13-integrated-civic-shop-light-20261004-01/source-as-prepared`。
- 295 冻结清单：其上层 `FROZEN-INPUTS.json`，声明 295 inputs / 68 production sources。
- 读取的工作要求：`/workspace/yunshan/AGENTS.md` 与闭组 `source/AGENTS.md`、`提示词.md`、`开发备忘录.md`；最近委派要求优先，明确禁止运行和改共享源。本目录的 `开发备忘录.md` 只记录这次审计。

[`SOURCE-COMPARISON.json`](SOURCE-COMPARISON.json) 保存 7 个被读基线文件的 SHA，全部逐 SHA 匹配 295 冻结清单；没有把这个子集检查称为重新审核全部 295 文件。全文件 renderer/types/simulation/controller 有其它差异，但以下七段载具相关代码逐字一致：`makePool+put`、车辆 update、`Vehicle` 接口、`pointOn+traffic`、`passengerCapacity`、`ride/leaveVehicle` 命令、`syncPassenger`。每段都有两侧 SHA 和准确行号。[`SOURCE-EXCERPTS.md`](SOURCE-EXCERPTS.md) 保存带行号的两侧原代码。

本报告其余源码行号以 **295** 为准，括号中给旧 v8 对应位置。295 本身尚未包含旧闭组的 street-solid-authority/network-solid-recipe 文件，因此引用这两个文件时明确属于旧 v8 实体权威，不能冒称它们已经在 295 内。

## 实际几何参数

`renderer.ts:907–913`（旧 906–913）每类只有三个 `BoxGeometry(1,1,1)` 实例；`renderer.ts:999–1001`（旧 1002–1004）给它们赋以下中心和尺度。坐标是以 `vehicle.position` 为原点的局部坐标，Y 向上，Z 为车长，X 为车宽。

| 类型/部件 | 局部中心 XYZ | 尺度 XYZ | 局部范围 XYZ |
| --- | --- | --- | --- |
| road body | `(0,1.1,0)` | `(2.5,1.5,5.5)` | X ±1.25，Y 0.35–1.85，Z ±2.75 |
| road head | `(0,2.1,0)` | `(2.125,0.8,3.74)` | X ±1.0625，Y 1.7–2.5，Z ±1.87 |
| road trim | `(0,0.6,0)` | `(2.75,0.2,4.675)` | X ±1.375，Y 0.5–0.7，Z ±2.3375 |
| lightRail/maglev body | `(0,1.1,0)` | `(3.3,1.5,16)` | X ±1.65，Y 0.35–1.85，Z ±8 |
| lightRail/maglev head | `(0,2.1,0)` | `(2.805,0.8,10.88)` | X ±1.4025，Y 1.7–2.5，Z ±5.44 |
| lightRail/maglev trim | `(0,0.6,0)` | `(3.55,0.2,13.6)` | X ±1.775，Y 0.5–0.7，Z ±6.8 |

body 材质是 `roof`，head 材质是 `glass`，trim 材质是 `cyan`（395，旧 394）。材质名称不把完整盒体变成薄壳；玻璃透明也不产生可穿越开口。body/head 在 Y 1.7–1.85 还重叠；trim 位于 body 内部的高度范围，不是独立可用的车厢地板。没有独立 roof slab，也没有可站立空腔。body 顶面 1.85 只能解释成车体外表面，不能被当作车厢内部支撑；head 下界 1.7 与它相交。

`types.ts:38`（旧 36）的 `Vehicle` 只有 position/edgeId/progress/direction/speed/state/passengers/cargo/nextDeparture 等字段，没有门位置、开门分数、车厢局部乘员位置、占用槽或支撑字段。renderer 的车辆分支不读 `state` 或 `nextDeparture` 来变换几何，所以 `boarding/waiting` 不会开门。

## 实际世界变换与姿态差异

`renderer.ts:916–919`（旧 916–918）按单独部件中心、绕 +Y 的 quaternion、部件尺寸 compose 矩阵，`setMatrixAt` 写 Float32 instanceMatrix；无 pitch/roll。

`renderer.ts:997`（旧 1000）取 `i=min(N−2,floor(clamp(progress,0,.99999)×(N−1)))`，然后 `yaw=atan2(b.x−a.x,b.z−a.z)+(direction<0?π:0)`。缺边或点不足时 yaw=0。对于局部点 `l`：

```
world.x = p.x + cos(yaw)*l.x + sin(yaw)*l.z
world.y = p.y + l.y
world.z = p.z - sin(yaw)*l.x + cos(yaw)*l.z
```

`simulation.ts:880–886`（旧 863–869）却用三维分段长度之和做弧长插值。长度不同的折线可能使 renderer 的等点数段号与真实位置所在段不同，故不能自行拿位置切线替换实际 renderer yaw，再称门洞与网格一致。本审计未生成世界实例矩阵，也未测此差异在哪辆自然车上实际发生。

道路车每次移动后在 `936`（旧 919）施加 ±1.3 m 横向偏移，切线由 progress±.001 的三维点采样后取 XZ 部分；初始车辆 `182`（旧 174）直接 `pointOn`，没有该横移。到端点时 `973–974`（旧 956–957）先换 edgeId/direction/progress，再在下一次移动前仍保留上次 position，renderer 因新 edge/direction 可以立刻换朝向。没有持续刚体转弯/车门在站口保持固定的契约。是否应修姿态属于后续工程决策，不能在只读审计中静默替换。

## 乘客、时间及当前实际阻碍

1. `simulation.ts:2315–2318`（旧 2289–2292）只需距载具中心 35 m 内、路段开放、state 不为 moving、未满员等条件，就扣票并把玩家 position 直接设为 vehicle.position。没有端点/站台门洞/支撑/穿门路线要求；`waiting/noPower/congested/redLight/parked` 等状态也不能自动等同合法站位。起始第二辆道路车 progress=.5 且 waiting，进一步说明 waiting 不是停站证明。
2. `simulation.ts:2322`（旧 2296）仅以非 moving 与距最近 node≤45 m 判断下车，再直接赋最近 node.position；node 不要求 station，也没有从车厢地板通过真实门洞的步行。
3. NPC 在 `1693–1699`（旧 1674–1680）寻找 40 m 内非 moving 车辆，按票价/容量/预计行程比较后直接赋载具位置。`1656–1663`（旧 1638–1645）乘车跟随中心，到站赋 stop.position。所有乘员可以共享同一个 XYZ。人物 renderer 的 `riding` 只是 seated pose（citizen-appearance.ts:128），没有车厢支撑或不同座位。
4. `simulation.ts:982–983`（旧 965–966）每轮 traffic 再将玩家位置赋载具中心。`controller.ts:151–157`（旧 155–161）把 feet 设为这个点，步行相机设置为 p.y+1.72+0.5，并清空 building support；乘客步行在 301（旧 305）提前返回。因此不存在车内走动或检查足底支撑的现有路径。相机的 +0.5 不是地板。
5. `renderer.ts:994`（旧 997）当玩家所乘车离相机<25 m 时跳过 **整车**。当前第一人称乘车看不到实体不是门已打开；真实新车厢必须保留在渲染与碰撞中。
6. 旧 v8 `street-solid-authority.ts:128–143` 只索引 `NetworkSolidRecipeBuilder.buildNetwork()` 生成的网络实体；车辆实例不在此集合。旧 v8 controller 的街道碰撞/支撑路径没有载具 floor/body descriptor，295 controller 也没有载具实体碰撞接口。故“现有玩家可穿过可见车体”若发生，也不能叫实体门通行通过。本次未执行这个行为。
7. 单车容量不等于物理容纳：`simulation.ts:734`（旧 717）对 road 有货给 2、空车给 10；列车用 edge.capacity。`world.ts:648`（旧 658）为 elevated maglev/lightRail 生成 capacity=180。180 个半径 .35 m 的互不重叠站立身体投影面积下界为 **69.2721 m²**，大于整个 3.3×16=52.8 m² 外轮廓，更大于建议内部 2.9×15.6=45.24 m²。此静态面积下界已经排除 180 个完整站立 capsule 同时在这辆单层车内；未据此修改任何人数、经济或容量规则。

时间是游戏分钟：`simulation.ts:39`（旧 36）tick=0.25 real seconds，`807–815`（旧 790–798）每 tick `.25*state.speed` 游戏分钟；now=`day*1440+hour*60`（225，旧 210）。自动速度 road18 / lightRail25 / maglev50（260，旧 245）。交通位移用速度×.25×speed×energy/congestion÷edge.length（922，旧 905）；道路高峰 congestion=.58，其它时段 .9，轨道1。停车 dwell 在 978–979（旧 961–962）：手控2、自动道路8、自动轨道日间16/22时–6时48，真实维护可减 .5。下一 tick 还会把 boarding 置为 waiting（918，旧 901），所以仅动画绑定 boarding 字符串甚至不能覆盖停车窗口。

## exact before/after 工程候选（没有实施）

[`DESCRIPTOR-CANDIDATE.json`](DESCRIPTOR-CANDIDATE.json) 提供三个模式各自完整的局部正尺寸盒体参数、门板位移参数、当前 pose 规则、闭组与295的关联及未解决条件。它不是已经生成的世界矩阵或验收记录，不含 safe point、teleport 目标或假支撑点。

建议保持主壳体外宽 road2.5 / train3.3、车长 road5.5 / train16、最高点2.5，把原填满车厢的 body/head/trim 几何替换为明确实体地板、侧/端壁、窗板、屋顶和保留的门板。必须由新明确 layout 分支共同供 renderer 和碰撞/支撑消费，旧 layout 不改。车身仍存在，只是实际壳体结构改变。

| 项目 | before 真实源码 | after 候选参数 |
| --- | --- | --- |
| floor | 无独立内部 floor；body Y .35–1.85 填满 | 完整 W×L 的 slab，Y 0–.2，顶面 .2 |
| roof | 无独立 slab；head Y1.7–2.5 填满 | 完整 W×L 的 slab，Y2.3–2.5，底面2.3 |
| side/end wall | 完整 body+head 体积 | 厚.2，opaque Y.2–1.6 / glass Y1.6–2.3；侧墙按门洞 Z[-.6,.6]真实分段 |
| cabin | 无空腔 | 高2.1；road净宽2.1/净长5.1，train净宽2.9/净长15.6 |
| side door opening | 不存在 | 两侧各一候选门洞，宽1.2（沿局部Z）、高2.1（Y.2–2.3）；实际站位仅授权有合法平台的侧 |
| door leaves | 不存在 | 每洞双板 size(.1,2.1,.6)，Y中心1.25；X中心=side×(W/2+.05)；闭合Z中心±.3，完全打开±.9，保留门板实际滑移±.6 |
| trim | 宽W+.25的完整扁盒，Y.5–.7，穿车厢 | 侧/端壁皮层厚.02，仍Y.5–.7；侧条分段止于Z±.6，不穿门洞或车厢中部 |
| rendering occupied vehicle | 相机<25 m整车消失 | 保留地板/屋顶/墙/门与同一碰撞矩阵；不得隐藏车身来容许穿门 |

门板放在墙外表面，完全打开停在门洞旁外部滑动范围，避免直接与侧墙体积重叠。新门板总外宽 road2.7/train3.5，仍小于旧 trim 全局宽2.75/3.55。需要对真实平台家具、路栏、轨道、其它载具检查门板完整扫掠；参数没有宣布该外部范围必然安全。

尺寸算术上，完全开门时1.2−.7=.5，居中身体每侧名义余量.25 m；净高2.1−1.72=.38 m。新真实车厢 floor 与壁内界决定的静态站立身体中心域为 road X±.7 / Z±2.2、train X±1.1 / Z±7.45，feetY=.2。这是名义几何侵蚀范围，**不是任选点可直接移入的许可**，更不是座位/容量已安排。位于同一精确 node pose 的原 station slab 顶面为 node.y−.1（旧 renderer.ts:782 / network-solid-recipe.ts:118），名义上到 floor+.2 的高差 .3≤.4；该算术不能证明实际连接。

特别是旧 rail 光条是全局 X±1.8 的 .28×.24 段，lift=.16，水平段顶为轨迹Y+.28（旧 renderer.ts:761 / recipe:97），高于候选 floor+.2；rail guardrail 顶部在轨迹Y1.0–1.2、横向约±2.75（旧770/recipe106）。真实跨门路径仍可能被这些实体、站柱、其它车或斜坡矩阵阻碍。须消费实际 Float32 网格与完整身体扫掠，不能只靠本表高度或最近 node。295 与闭组站台 recipe 的相关拓扑没有在本子任务实例化。

门动画可采用**候选**开/关各 .5 游戏分钟、每片 .6 m 滑移，fraction输入必须来自新增可信 berth/door phase，不能由 render elapsed 或 `boarding` 标签虚构。部分开启的净宽是1.2×fraction，即使算术上约fraction≥.5833可容直径.7，建议只在 fraction=1 且平台/地板连续支撑和扫掠通过时允许进入。关闭和发车须对门洞身体占用互锁；现有 Vehicle 未包含这个 fraction/占用状态，现有2/8/16/48分钟规则也没有互锁，尚需父任务单独落实合同。

## 仍需完成的工程与验收

- 明确新布局版本和共同 descriptor 来源，使实际 renderer、完整身体碰撞、floor 支撑、门片动画使用同一实例矩阵；检查实际 Float32 误差。
- 解决 core arc-length position 与 renderer index-yaw、换边瞬转和 road 初始/移动偏置的姿态契约，车内位置要保存在真实 vehicle-local 支撑上。
- 从真实当前身体连续走到合法平台、经过已开门洞、进入实际 floor；按原速度和真实距离扣时，退出也走门；不能中心/最近 node 赋值。
- 建立真实车厢占用与可达空间，重新判断既有2/10/180名义容量，保留原票款与经济规则的审查边界。
- 保留车身和门板，门关闭时真实阻挡、开启时完整 capsule 通过；停站/门洞占用须阻止发车。支持保存/恢复的可信门状态与局部乘员位置。
- 独立实际检查横向站位、阶差、轨道/路栏/柱/屋顶/其它车、完整门板扫掠、每步足底圆覆盖与头部净空，再检查自然上下车和持续车内支撑。

这次仅完成源码/哈希与纯参数算术审计。以上工程和 factory/Sim/test/build/browser/GPU/自然上下车验收均 **NOT_RUN**，不能称载具已经真实可进入或本阶段全部完成。

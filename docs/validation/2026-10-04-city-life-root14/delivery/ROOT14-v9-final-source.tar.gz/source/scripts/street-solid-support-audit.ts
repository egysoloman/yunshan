import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { streetFootCoverage, getStreetSolidDescriptors, streetSolidFromDescriptor, streetCapsuleSeparation, STREET_BODY_RADIUS } from '../src/street-solid-authority';
import type { Vec3, WorldDefinition } from '../src/types';
const input = process.argv[2], output = process.argv[3]; if (!input || !output) throw new Error('Specify trusted factory/trajectory input and a new output directory');
fs.mkdirSync(output, { recursive: false });
const world = JSON.parse(fs.readFileSync(path.join(input, 'world-v8.json'), 'utf8')) as WorldDefinition;
const route = JSON.parse(fs.readFileSync(path.join(input, 'controlled-native-W-route.json'), 'utf8')) as { bodySegments: { from: Vec3; to: Vec3 }[]; start: Vec3; end: Vec3 };
const certificates: unknown[] = []; let subdivisions = 0, minimumDistance = Infinity;
function audit(a: Vec3, b: Vec3, segmentIndex: number, depth = 0): void {
  const first = streetFootCoverage(world, a.x, a.z, a.y), last = streetFootCoverage(world, b.x, b.z, b.y), run = Math.hypot(a.x - b.x, a.z - b.z);
  assert(first.covered && last.covered, 'Full circular foot projection must remain supported by actual reachable source faces');
  const minimum = Math.min(first.exposedBoundaryDistance, last.exposedBoundaryDistance); minimumDistance = Math.min(minimumDistance, minimum);
  if (minimum >= STREET_BODY_RADIUS + run / 2) { certificates.push({ segmentIndex, depth, from: a, to: b, first, last, horizontalRun: run, requiredBoundaryDistance: STREET_BODY_RADIUS + run / 2, continuousProjectionCertified: true }); return; }
  assert(depth < 16, 'A gap or unresolved support boundary cannot be assumed covered');
  subdivisions++; const middle = { x: (a.x + b.x) / 2, y: a.y, z: (a.z + b.z) / 2 }; audit(a, middle, segmentIndex, depth + 1); audit(middle, b, segmentIndex, depth + 1);
}
route.bodySegments.forEach((segment, index) => { if (segment.from.x !== segment.to.x || segment.from.z !== segment.to.z) { assert.equal(segment.from.y, segment.to.y); audit(segment.from, segment.to, index); } });
const plaza = JSON.parse(fs.readFileSync(path.join(input, 'plaza-all-height-actual-formula-boxes.json'), 'utf8')) as { parts: ReturnType<typeof getStreetSolidDescriptors> };
const railClasses = plaza.parts.filter(part => ['maglev', 'lightRail'].includes(String(part.owner.mode))).map(part => { const solid = streetSolidFromDescriptor(part); assert.equal(solid.walkable, false); return { owner: part.owner, sourceCall: part.sourceCall, matrixUint32: part.matrixUint32, physicalSolid: true, pedestrianSupport: false, boundedStepEligible: false }; });
// A track remains solid through the full body test. This witness stays in the
// original station region; it is not asserted to be an accepted player pose.
const rail = plaza.parts.find(part => part.owner.edgeId === 'maglev-market-station-core-station' && part.owner.segmentIndex === 1 && part.sourceCall === 'renderer.ts:760:1'); assert(rail);
const railSolid = streetSolidFromDescriptor(rail), witness = { x: world.nodes.find(node => node.id === 'market-station')!.position.x, y: 52.6, z: world.nodes.find(node => node.id === 'market-station')!.position.z };
const witnessSeparation = streetCapsuleSeparation(railSolid, witness, witness); assert(witnessSeparation < 0); assert.equal(railSolid.walkable, false);
const result = { status: 'PASS_CONTINUOUS_FULL_FOOT_PROJECTION_AND_RAIL_CLASSIFICATION', bodyRadius: STREET_BODY_RADIUS, bodySegments: route.bodySegments.length, horizontalCertificateCount: certificates.length, adaptiveSubdivisions: subdivisions, minimumExposedBoundaryDistance: minimumDistance, scope: 'Trusted literal v8 factory output and actual production controller physical segments. Every complete circular foot projection is certified against actual reachable solid-face union boundaries throughout horizontal motion via a Lipschitz distance bound. Rail classification keeps all original source boxes collidable and ineligible for pedestrian support or .4m steps; this does not claim the whole plaza unoccupied or a live GPU journey.', certificates, railClasses, railStationWitness: { feet: witness, signedCapsuleSeparation: witnessSeparation, owner: rail.owner, wouldBeRejectedAsSolid: true } };
fs.writeFileSync(path.join(output, 'FOOT-PROJECTION-AND-RAIL-AUTHORITY.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ status: result.status, certificates: certificates.length, subdivisions, minimumDistance, railBoxes: railClasses.length, railStationWitnessSeparation: witnessSeparation }));

/** One read-only query of the frozen actual v8 literal. Proposed assets are not
 * installed into World. Terrain/footprint samples are not body acceptance. */
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { terrainHeight } from '../src/world';
import type { Vec3, WorldDefinition } from '../src/types';
const output = process.argv[2]; if (!output) throw new Error('A proposal output directory is required'); fs.mkdirSync(output, { recursive: true });
const file = new URL('../tests/fixtures/street-authority/archived-world-v8.json', import.meta.url), bytes = fs.readFileSync(file);
if (createHash('sha256').update(bytes).digest('hex') !== '42566fc1c64af7b930cd980e2ad7b0436889941ad5ce8717a2a1e676d9667baf') throw new Error('Frozen v8 actual literal changed');
const world = JSON.parse(bytes.toString()) as WorldDefinition, before = JSON.stringify(world), hub = world.nodes.find(node => node.id === 'market-station')!;
const configs = [
  { edgeId: 'maglev-river-station-market-station', x: -376, escape: [[-416, 426], [-416, 540]], suitable: (point: Vec3) => point.z >= 540 },
  { edgeId: 'lightRail-workshop-station-market-station', x: -352, escape: [[-388, 426], [-388, 400]], suitable: (point: Vec3) => point.x <= -400 },
  { edgeId: 'maglev-market-station-core-station', x: -328, escape: [[-312, 426], [-312, 400]], suitable: (point: Vec3) => point.z <= 400 },
  { edgeId: 'lightRail-market-station-academy-station', x: -304, escape: [[-312, 426], [-312, 400]], suitable: (point: Vec3) => point.z <= 400 },
];
const run = (a: Vec3, b: Vec3) => Math.hypot(b.x - a.x, b.z - a.z), copy = (point: Vec3) => ({ ...point });
const sampledTerrain: unknown[] = [], proposals = configs.map((config, index) => {
  const edge = world.edges.find(edge => edge.id === config.edgeId)!, atStart = edge.from === hub.id, old = (atStart ? edge.points : edge.points.slice().reverse()).map(copy), nodeId = `market-rail-berth-${index + 1}`;
  const anchor = { x: config.x, y: hub.position.y, z: 436 }, flatEnd = { x: config.x, y: hub.position.y, z: 426 }, escape = config.escape.map(([x, z]) => ({ x, y: hub.position.y, z })), prefix = [anchor, flatEnd, ...escape];
  let recover = -1, maximumProposedGrade = Infinity, points: Vec3[] | null = null, oldArc = 0;
  const prefixRuns = [0]; for (let i = 1; i < prefix.length; i++) prefixRuns.push(prefixRuns[i - 1] + run(prefix[i - 1], prefix[i]));
  for (let i = 1; i < old.length - 1; i++) {
    oldArc += run(old[i - 1], old[i]); if (oldArc < 80 || !config.suitable(old[i])) continue;
    const total = prefixRuns.at(-1)! + run(prefix.at(-1)!, old[i]), rampRun = total - 10;
    if (rampRun <= 0 || Math.abs(old[i].y - anchor.y) / rampRun > .20) continue;
    maximumProposedGrade = Math.abs(old[i].y - anchor.y) / rampRun; recover = i;
    const graded = prefix.map((point, pi) => ({ ...point, y: anchor.y + (old[i].y - anchor.y) * Math.max(0, prefixRuns[pi] - 10) / rampRun }));
    points = [...graded, ...old.slice(i).map(copy)]; break;
  }
  const floorY = hub.position.y + .35, landingY = hub.position.y + .22;
  const corridors = [-1, 1].map(side => [{ x: hub.position.x, y: landingY, z: hub.position.z }, { x: hub.position.x, y: landingY, z: 452 }, { x: anchor.x + side * 8.8, y: landingY, z: 452 }, { x: anchor.x + side * 8.8, y: landingY, z: anchor.z }]);
  for (const corridor of corridors) for (let i = 1; i < corridor.length; i++) {
    const a = corridor[i - 1], b = corridor[i], count = Math.max(1, Math.ceil(run(a, b))), nx = -(b.z - a.z) / Math.max(run(a, b), 1), nz = (b.x - a.x) / Math.max(run(a, b), 1);
    for (let j = 0; j <= count; j++) for (const side of [-1, 0, 1]) { const x = a.x + (b.x - a.x) * j / count + nx * .8 * side, z = a.z + (b.z - a.z) * j / count + nz * .8 * side, actualTerrain = terrainHeight(world, x, z); sampledTerrain.push({ nodeId, source: 'proposed-corridor', x, z, actualTerrain, proposedFloorY: landingY, requiredGroundCut: Math.max(0, actualTerrain - (landingY - .15)) }); }
  }
  for (const side of [-1, 1]) for (let x = 1.8; x <= 8.8; x += .5) for (let z = -1; z <= 1; z += .5) { const px = anchor.x + side * x, pz = anchor.z + z, actualTerrain = terrainHeight(world, px, pz); sampledTerrain.push({ nodeId, source: 'proposed-platform-ramp', x: px, z: pz, actualTerrain, proposedFloorY: x <= 4.8 ? floorY : floorY + (landingY - floorY) * (x - 4.8) / 4, requiredGroundCut: Math.max(0, actualTerrain - (landingY - .15)) }); }
  const length = corridors.reduce((sum, corridor) => sum + corridor.slice(1).reduce((sum, b, i) => sum + run(corridor[i], b), 0), 0);
  const broadphaseBuildings = world.buildings.filter(site => { const cosine = Math.abs(Math.cos(site.rotation)), sine = Math.abs(Math.sin(site.rotation)), hw = (site.width * cosine + site.depth * sine) / 2, hd = (site.width * sine + site.depth * cosine) / 2; return site.position.x + hw >= anchor.x - 12 && site.position.x - hw <= anchor.x + 12 && site.position.z + hd >= 412 && site.position.z - hd <= 453; }).map(site => ({ id: site.id, position: site.position, door: site.door, width: site.width, depth: site.depth, rotation: site.rotation }));
  return { status: points ? 'PROPOSED_GRADE_PASS_BODY_NOT_CHECKED' : 'FAIL_NO_ENDPOINT_RECOVERY_AT_POINT20', edgeId: edge.id, oldEndpointNodeId: hub.id, proposedNode: { id: nodeId, districtId: hub.districtId, station: true, name: `${hub.name}轨道${index + 1}泊位`, position: anchor }, atStart, changedReference: atStart ? 'from' : 'to', proposedForward: { x: 0, y: 0, z: -1 }, preservedOldHub: hub, originalEdge: edge, replacedOriginalVertexCount: recover < 0 ? null : recover, recoveryOriginalIndex: recover, recoveryOriginalVertex: recover < 0 ? null : old[recover], maximumProposedGrade, proposedEdgePoints: points ? atStart ? points : points.slice().reverse() : null, floorY, landingY, corridors, width: 1.6, thickness: .15, materialBillUpperBound: { corridorLengthWithOverlaps: length, corridorSlabCubicMetersWithOverlaps: length * 1.6 * .15, twoPlatformSlabCubicMeters: 2 * 3 * 2 * .15 }, broadphaseBuildings, remaining: ['Actual finite floor/ramp/soil excavation assets are not installed.', 'Route corner radius/moving carriage body clearance are not proven.', 'Building/terrain/other-carrier/capsule proofs are not replaced by these footprint or height samples.', 'Canonical hub and door prefix is preserved; only a future explicit recipe may append these nodes and change rail endpoint references.'] };
});
if (JSON.stringify(world) !== before) throw new Error('Read-only proposal query mutated the actual v8 literal');
const summary = { status: 'PROPOSAL_ONLY_NOT_PRODUCT_NOT_FULL_BODY_PROOF', scope: 'One literal World query using trusted terrainHeight, no createWorld/Simulation/GPU. New nodes/routes are not installed.', originalWorldSHA256: createHash('sha256').update(bytes).digest('hex'), originalNodeCount: world.nodes.length, originalEdgeCount: world.edges.length, proposals, terrainSampling: { samples: sampledTerrain.length, maximumRequiredGroundCut: Math.max(...sampledTerrain.map(value => (value as { requiredGroundCut: number }).requiredGroundCut)), warning: 'Finite diagnostic samples/bill upper bounds are not an excavation-volume proof or completed funded construction.' } };
fs.writeFileSync(path.join(output, 'MARKET-BERTH-PROPOSAL.json'), JSON.stringify(summary, null, 2) + '\n'); fs.writeFileSync(path.join(output, 'TERRAIN-SAMPLES.json'), JSON.stringify(sampledTerrain, null, 2) + '\n');
console.log(JSON.stringify({ status: summary.status, proposalStatuses: proposals.map(proposal => ({ edgeId: proposal.edgeId, status: proposal.status, anchor: proposal.proposedNode.position, recovery: proposal.recoveryOriginalVertex, grade: proposal.maximumProposedGrade })), samples: sampledTerrain.length, maximumRequiredGroundCut: summary.terrainSampling.maximumRequiredGroundCut, unchangedWorld: JSON.stringify(world) === before }));

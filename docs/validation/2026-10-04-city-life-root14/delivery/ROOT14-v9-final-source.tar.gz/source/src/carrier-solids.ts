/** Actual enterable v9 carriers. Rendering and motion read these same Float32 solids. */
import * as THREE from 'three';
import type { NetworkEdge, TransportMode, Vec3, Vehicle } from './types';
import type { NetworkSolidDescriptor } from './network-solid-recipe';
import { streetSolidFromDescriptor, streetSolidCapsuleSupport, type StreetSolid } from './street-solid-authority';

export const CARRIER_SOLID_VERSION = 'yunshan-carrier-shell-door-floor-v9-1';
export const CARRIER_FLOOR_TOP = .35;
export const CARRIER_FLOOR_THICKNESS = .15;
export const CARRIER_ROOF_BOTTOM = 2.2;
export const CARRIER_ROOF_TOP = 2.5;
export const CARRIER_WALL_THICKNESS = .1;
export const CARRIER_DOOR_WIDTH = 1.2;
export const CARRIER_DOOR_LEAF_THICKNESS = .08;
export const CARRIER_BODY_RADIUS = .35;
export const CARRIER_BODY_HEIGHT = 1.72;
export interface CarrierShape { width: number; length: number; kind: 'road' | 'rail' }
export interface CarrierSlot { id: string; x: number; z: number; purpose: 'passenger' | 'driver' }
export interface CarrierPose { position: Vec3; forward: Vec3; across: Vec3; up: Vec3; matrixFloat64: number[]; arc: number; segmentIndex: number }
export interface CarrierSolidDescriptor extends NetworkSolidDescriptor { carrierPart: 'floor' | 'roof' | 'wall' | 'window' | 'door' | 'threshold'; walkable: boolean; vehicleId: string }
const colors = { stone: '#89958f', wood: '#a77851', glass: '#517f82', metal: '#a3b1bb', amber: '#d0b985' };
const bits = (values: number[]) => Array.from(new Uint32Array(new Float32Array(values).buffer));
export const carrierShape = (kind: TransportMode): CarrierShape | null => kind === 'road' ? { width: 2.5, length: 5.5, kind: 'road' } : kind === 'maglev' || kind === 'lightRail' ? { width: 3.3, length: 16, kind: 'rail' } : null;

/** Each slot has a complete .35m footprint; the central and door corridors stay empty. */
export function carrierSlots(kind: TransportMode): CarrierSlot[] {
  const shape = carrierShape(kind); if (!shape) return [];
  const rows = shape.kind === 'road' ? [-1.75, 1.75] : [-6.8, -5.8, -4.8, -3.8, -2.8, -1.8, 1.8, 2.8, 3.8, 4.8, 5.8, 6.8];
  const side = shape.kind === 'road' ? .75 : .9;
  return rows.flatMap((z, row) => [-1, 1].map(sign => ({ id: `passenger-${row}-${sign}`, x: sign * side, z, purpose: 'passenger' as const })));
}
export const carrierDriverSlot = (kind: TransportMode): CarrierSlot | null => carrierShape(kind) ? { id: 'driver', x: 0, z: kind === 'road' ? 1.95 : 7.05, purpose: 'driver' } : null;
export const carrierPassengerCapacity = (kind: TransportMode): number => carrierSlots(kind).length;

/** Locate the same 3D arc-length segment used by Simulation.pointOn, rather than equal-index progress. */
export function carrierPose(vehicle: Vehicle, edge: NetworkEdge): CarrierPose {
  const lengths = edge.points.slice(1).map((b, i) => Math.hypot(b.x - edge.points[i].x, b.y - edge.points[i].y, b.z - edge.points[i].z));
  const total = lengths.reduce((sum, length) => sum + length, 0), arc = Math.max(0, Math.min(1, vehicle.progress)) * total;
  let preceding = 0, segmentIndex = 1;
  while (segmentIndex < edge.points.length - 1 && preceding + lengths[segmentIndex - 1] < arc) { preceding += lengths[segmentIndex - 1]; segmentIndex++; }
  const a = edge.points[segmentIndex - 1], b = edge.points[segmentIndex];
  const forward = new THREE.Vector3(b.x - a.x, b.y - a.y, b.z - a.z).normalize();
  // Symmetric bidirectional rail bodies keep their physical track axis. A road
  // cab follows travel direction; both models have real bilateral side doors.
  if (vehicle.kind === 'road' && vehicle.direction < 0) forward.multiplyScalar(-1);
  const across = new THREE.Vector3(forward.z, 0, -forward.x).normalize(), up = forward.clone().cross(across).normalize();
  const matrix = new THREE.Matrix4().makeBasis(across, up, forward).setPosition(vehicle.position.x, vehicle.position.y, vehicle.position.z);
  return { position: { ...vehicle.position }, forward: { x: forward.x, y: forward.y, z: forward.z }, across: { x: across.x, y: across.y, z: across.z }, up: { x: up.x, y: up.y, z: up.z }, matrixFloat64: [...matrix.elements], arc, segmentIndex };
}

export function carrierWorldPoint(pose: CarrierPose, local: Vec3): Vec3 {
  const point = new THREE.Vector3(local.x, local.y, local.z).applyMatrix4(new THREE.Matrix4().fromArray(pose.matrixFloat64));
  return { x: point.x, y: point.y, z: point.z };
}

/** Door leaves slide along the actual wall; their finite material remains drawn and solid. */
export function carrierSolidDescriptors(vehicle: Vehicle, edge: NetworkEdge, doorOpen: boolean | number): CarrierSolidDescriptor[] {
  const shape = carrierShape(vehicle.kind); if (!shape) return [];
  const opening = typeof doorOpen === 'boolean' ? Number(doorOpen) : Math.max(0, Math.min(1, doorOpen));
  const pose = carrierPose(vehicle, edge), parent = new THREE.Matrix4().fromArray(pose.matrixFloat64), result: CarrierSolidDescriptor[] = [];
  const box = (part: CarrierSolidDescriptor['carrierPart'], key: keyof typeof colors, x: number, y: number, z: number, sx: number, sy: number, sz: number, walkable = false) => {
    const matrix = parent.clone().multiply(new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion(), new THREE.Vector3(sx, sy, sz)));
    const m64 = [...matrix.elements], m32 = Array.from(new Float32Array(m64)), color = new THREE.Color(colors[key]), c32 = Array.from(new Float32Array([color.r, color.g, color.b]));
    result.push({ owner: { scope: 'carrier', vehicleId: vehicle.id, mode: vehicle.kind, carrierPart: part }, sourceCall: `carrier-solids-v9:${part}`, matrixFloat64: m64, matrixFloat32: m32, matrixUint32: bits(m64), colorFloat32: c32, colorUint32: bits(c32), key, distanceDetail: false, arguments: [x, y, z, sx, sy, sz, doorOpen], operation: 'box', carrierPart: part, walkable, vehicleId: vehicle.id });
  };
  const halfWidth = shape.width / 2, halfLength = shape.length / 2, wallHeight = CARRIER_ROOF_BOTTOM - CARRIER_FLOOR_TOP;
  box('floor', 'stone', 0, CARRIER_FLOOR_TOP - CARRIER_FLOOR_THICKNESS / 2, 0, shape.width, CARRIER_FLOOR_THICKNESS, shape.length, true);
  box('roof', 'metal', 0, (CARRIER_ROOF_BOTTOM + CARRIER_ROOF_TOP) / 2, 0, shape.width, CARRIER_ROOF_TOP - CARRIER_ROOF_BOTTOM, shape.length);
  for (const end of [-1, 1]) box('window', 'glass', 0, CARRIER_FLOOR_TOP + wallHeight / 2, end * (halfLength - CARRIER_WALL_THICKNESS / 2), shape.width, wallHeight, CARRIER_WALL_THICKNESS);
  for (const side of [-1, 1]) {
    const x = side * (halfWidth - CARRIER_WALL_THICKNESS / 2), panelLength = (shape.length - CARRIER_DOOR_WIDTH) / 2;
    for (const end of [-1, 1]) {
      const z = end * (CARRIER_DOOR_WIDTH / 2 + panelLength / 2);
      box('wall', shape.kind === 'rail' ? 'amber' : 'wood', x, CARRIER_FLOOR_TOP + wallHeight / 2, z, CARRIER_WALL_THICKNESS, wallHeight, panelLength);
    }
    const leafWidth = CARRIER_DOOR_WIDTH / 2;
    // Open leaves rest outside the wall skin, so they do not invade the cabin.
    const leafX = side * (halfWidth + CARRIER_DOOR_LEAF_THICKNESS / 2);
    for (const sign of [-1, 1]) box('door', 'glass', leafX, CARRIER_FLOOR_TOP + wallHeight / 2, sign * (leafWidth / 2 + opening * leafWidth), CARRIER_DOOR_LEAF_THICKNESS, wallHeight, leafWidth);
    // The real threshold projects to the platform interface. It is part of the
    // carrier floor rather than a fictional support square supplied by a query.
    box('threshold', 'metal', side * (halfWidth + .15), CARRIER_FLOOR_TOP - CARRIER_FLOOR_THICKNESS / 2, 0, .4, CARRIER_FLOOR_THICKNESS, CARRIER_DOOR_WIDTH, true);
  }
  return result;
}

export function carrierStreetSolids(vehicle: Vehicle, edge: NetworkEdge, doorOpen: boolean | number): StreetSolid[] {
  return carrierSolidDescriptors(vehicle, edge, doorOpen).map(descriptor => {
    const solid = streetSolidFromDescriptor(descriptor); return { ...solid, surfaceKind: descriptor.walkable ? 'station' : 'solid', walkable: descriptor.walkable };
  });
}

export function carrierSlotFeet(vehicle: Vehicle, edge: NetworkEdge, slot: CarrierSlot): Vec3 | null {
  const point = carrierWorldPoint(carrierPose(vehicle, edge), { x: slot.x, y: CARRIER_FLOOR_TOP, z: slot.z });
  const floor = carrierStreetSolids(vehicle, edge, false).find(solid => solid.descriptor.owner.carrierPart === 'floor');
  const support = floor && streetSolidCapsuleSupport(floor, point.x, point.z); if (!support) return null;
  return { x: point.x, y: support.y + 8 * Number.EPSILON * Math.max(1, Math.abs(support.y)), z: point.z };
}

/** Pure physical transfer path kernel. No fare, occupancy or actor mutation. */
import type { NetworkEdge, Vec3, Vehicle, WorldDefinition } from './types';
import { carrierPose, carrierShape, carrierSlotFeet, carrierStreetSolids, carrierWorldPoint, type CarrierSlot } from './carrier-solids';
import { stationPlatform } from './station-throats';
import { getNearbyStreetSolids, streetCapsuleSeparation, streetSolidCapsuleSupport, STREET_BODY_HEIGHT, STREET_BODY_RADIUS, STREET_MAXIMUM_STEP, type StreetSolid } from './street-solid-authority';
import { certifyStreetFootProjection, type StreetFootCorridorCertificate } from './street-foot-corridor';

export const CARRIER_TRANSFER_PATH_VERSION = 'yunshan-supported-carrier-transfer-path-v9-2';
export const PLAYER_CARRIER_WALK_METERS_PER_REAL_SECOND = 4.8;
export const CARRIER_TRANSFER_SPATIAL_STEP = .08;
export interface CarrierBodySegment { from: Vec3; to: Vec3; horizontalBudget: number }
export type CarrierFootCertificate = StreetFootCorridorCertificate;
export interface CarrierPathFailure { status: 'FAIL'; reason: string; from?: Vec3; to?: Vec3; contacts?: { owner: Record<string, unknown>; sourceCall: string; matrixUint32: number[]; signedSeparation: number }[] }
export interface CarrierTransferPath { status: 'PASS'; version: typeof CARRIER_TRANSFER_PATH_VERSION; vehicleId: string; edgeId: string; nodeId: string; side: number; kind: 'board' | 'exit'; points: Vec3[]; segments: CarrierBodySegment[]; footCertificates: CarrierFootCertificate[]; horizontalDistance: number; spatialDistance: number; authoritySignature: string; startingPosition: Vec3; carrierPosition: Vec3; carrierProgress: number }
const copy = (point: Vec3): Vec3 => ({ ...point });
const roundUp = (value: number) => value + 8 * Number.EPSILON * Math.max(1, Math.abs(value));
const near = (solid: StreetSolid, a: Vec3, b: Vec3, step = 0) => solid.bounds.minimum.every((value, axis) => value <= Math.max(axis === 0 ? a.x : axis === 1 ? a.y : a.z, axis === 0 ? b.x : axis === 1 ? b.y : b.z) + (axis === 1 ? STREET_BODY_HEIGHT : STREET_BODY_RADIUS)) && solid.bounds.maximum.every((value, axis) => value >= Math.min(axis === 0 ? a.x : axis === 1 ? a.y : a.z, axis === 0 ? b.x : axis === 1 ? b.y : b.z) - (axis === 1 ? step : STREET_BODY_RADIUS));
const contacts = (solids: readonly StreetSolid[], from: Vec3, to: Vec3) => solids.filter(solid => near(solid, from, to)).map(solid => ({ solid, separation: streetCapsuleSeparation(solid, from, to) })).filter(contact => contact.separation < 0);
const rawContacts = (items: ReturnType<typeof contacts>) => items.map(({ solid, separation }) => ({ owner: solid.descriptor.owner, sourceCall: solid.descriptor.sourceCall, matrixUint32: solid.descriptor.matrixUint32, signedSeparation: separation }));

function supportAt(solids: readonly StreetSolid[], x: number, z: number, reference: number): number | null {
  let y: number | null = null;
  for (const solid of solids) {
    if (!solid.walkable || solid.bounds.minimum[0] > x + STREET_BODY_RADIUS || solid.bounds.maximum[0] < x - STREET_BODY_RADIUS || solid.bounds.minimum[2] > z + STREET_BODY_RADIUS || solid.bounds.maximum[2] < z - STREET_BODY_RADIUS) continue;
    const support = streetSolidCapsuleSupport(solid, x, z);
    if (support && support.y <= reference + STREET_MAXIMUM_STEP && support.y >= reference - STREET_MAXIMUM_STEP && (y === null || support.y > y)) y = support.y;
  }
  return y === null ? null : roundUp(y);
}

function physicalStep(solids: readonly StreetSolid[], from: Vec3, to: Vec3): { segments: CarrierBodySegment[]; certificates: CarrierFootCertificate[] } | CarrierPathFailure {
  let plateau = Math.max(from.y, to.y);
  const start = (y: number) => ({ x: from.x, y, z: from.z }), end = (y: number) => ({ x: to.x, y, z: to.z });
  const initial = contacts(solids, start(plateau), end(plateau));
  if (initial.length) {
    if (initial.some(contact => !contact.solid.walkable)) return { status: 'FAIL', reason: 'real nonwalkable solid blocks transfer', from, to, contacts: rawContacts(initial) };
    let low = plateau, high = from.y + STREET_MAXIMUM_STEP;
    const ceiling = contacts(solids, start(high), end(high));
    if (high < low || ceiling.length) return { status: 'FAIL', reason: 'real step has no full-body head clearance within .4m', from, to, contacts: rawContacts(ceiling.length ? ceiling : initial) };
    for (let i = 0; i < 36; i++) { const middle = (low + high) / 2; if (contacts(solids, start(middle), end(middle)).length) low = middle; else high = middle; }
    plateau = high;
  }
  const certificate = certifyStreetFootProjection(solids, start(plateau), end(plateau));
  if (!certificate) return { status: 'FAIL', reason: 'complete foot projection loses actual connected support', from, to };
  const points = [from, start(plateau), end(plateau), to], segments: CarrierBodySegment[] = [], certificates: CarrierFootCertificate[] = [certificate];
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1], b = points[i]; if (a.x === b.x && a.y === b.y && a.z === b.z) continue;
    const hit = contacts(solids, a, b); if (hit.length) return { status: 'FAIL', reason: 'continuous full capsule overlaps a real solid', from: a, to: b, contacts: rawContacts(hit) };
    if (a.x === b.x && a.z === b.z) { const verticalProjection = certifyStreetFootProjection(solids, a, b); if (!verticalProjection) return { status: 'FAIL', reason: 'raise or settle loses complete actual support projection', from: a, to: b }; certificates.push(verticalProjection); }
    segments.push({ from: copy(a), to: copy(b), horizontalBudget: Math.hypot(a.x - b.x, a.z - b.z) || Math.abs(a.y - b.y) });
  }
  return { segments, certificates };
}

/** The candidates are the two actual built platform doors. No free-space point
 * search, logical-node relocation or imported support rectangle is allowed. */
export function carrierTransferPath(world: WorldDefinition, vehicle: Vehicle, edge: NetworkEdge, slot: CarrierSlot, kind: 'board' | 'exit', startingPosition: Vec3, side: number, otherCarrierSolids: readonly StreetSolid[] = []): CarrierTransferPath | CarrierPathFailure {
  const shape = carrierShape(vehicle.kind); if (!shape) return { status: 'FAIL', reason: 'this carrier has no engineered v9 cabin and door' };
  if (vehicle.progress !== 0 && vehicle.progress !== 1 || vehicle.state === 'moving') return { status: 'FAIL', reason: 'carrier is not stopped at its actual endpoint berth' };
  const nodeId = vehicle.progress === 0 ? edge.from : edge.to, parcel = stationPlatform(world, edge.id, nodeId);
  if (!parcel) return { status: 'FAIL', reason: 'this endpoint has no physical v9 platform/door parcel' };
  const pose = carrierPose(vehicle, edge), slotFeet = carrierSlotFeet(vehicle, edge, slot); if (!slotFeet) return { status: 'FAIL', reason: 'actual cabin slot lacks finite floor support' };
  const point = (x: number, z: number) => carrierWorldPoint(pose, { x, y: .35, z });
  const outside = side * (parcel.rampOuterOffset - .25), turn = side * (parcel.outerOffset - .1), threshold = side * (shape.width / 2 + .25);
  const localRoute = kind === 'exit' ? [point(0, slot.z), point(0, 0), point(threshold, 0), point(turn, 0), point(outside, 0)] : [point(outside, 0), point(turn, 0), point(threshold, 0), point(0, 0), point(0, slot.z), slotFeet];
  const waypoints = [copy(startingPosition), ...localRoute], minimum = { x: Math.min(...waypoints.map(point => point.x)), y: parcel.center.y - STREET_MAXIMUM_STEP, z: Math.min(...waypoints.map(point => point.z)) }, maximum = { x: Math.max(...waypoints.map(point => point.x)), y: parcel.floorY + STREET_MAXIMUM_STEP, z: Math.max(...waypoints.map(point => point.z)) };
  const solids = [...getNearbyStreetSolids(world, minimum, maximum), ...carrierStreetSolids(vehicle, edge, true), ...otherCarrierSolids];
  const openingContacts = contacts(solids, startingPosition, startingPosition); if (openingContacts.length) return { status: 'FAIL', reason: 'starting pose already overlaps actual geometry', from: startingPosition, contacts: rawContacts(openingContacts) };
  const segments: CarrierBodySegment[] = [], footCertificates: CarrierFootCertificate[] = [];
  let current = copy(startingPosition);
  for (let wi = 1; wi < waypoints.length; wi++) {
    const target = waypoints[wi], beginning = copy(current), run = Math.hypot(target.x - beginning.x, target.z - beginning.z), count = Math.max(1, Math.ceil(run / CARRIER_TRANSFER_SPATIAL_STEP));
    for (let i = 1; i <= count; i++) {
      const x = beginning.x + (target.x - beginning.x) * i / count, z = beginning.z + (target.z - beginning.z) * i / count, y = supportAt(solids, x, z, current.y);
      if (y === null) return { status: 'FAIL', reason: 'route leaves actual reachable floor/threshold/platform/ramp', from: current, to: { x, y: current.y, z } };
      const proposed = { x, y, z }, step = physicalStep(solids, current, proposed); if ('status' in step) return step;
      segments.push(...step.segments); footCertificates.push(...step.certificates); current = proposed;
    }
  }
  const points = [copy(startingPosition), ...segments.map(segment => copy(segment.to))];
  let hash = 2166136261; const authority = JSON.stringify([CARRIER_TRANSFER_PATH_VERSION, vehicle.id, edge.id, nodeId, side, kind, points, solids.map(solid => [solid.descriptor.owner, solid.descriptor.sourceCall, solid.descriptor.matrixUint32])]);
  for (let i = 0; i < authority.length; i++) hash = Math.imul(hash ^ authority.charCodeAt(i), 16777619);
  return { status: 'PASS', version: CARRIER_TRANSFER_PATH_VERSION, vehicleId: vehicle.id, edgeId: edge.id, nodeId, side, kind, points, segments, footCertificates, horizontalDistance: segments.reduce((sum, segment) => sum + Math.hypot(segment.to.x - segment.from.x, segment.to.z - segment.from.z), 0), spatialDistance: segments.reduce((sum, segment) => sum + Math.hypot(segment.to.x - segment.from.x, segment.to.y - segment.from.y, segment.to.z - segment.from.z), 0), authoritySignature: (hash >>> 0).toString(16), startingPosition: copy(startingPosition), carrierPosition: copy(vehicle.position), carrierProgress: vehicle.progress };
}

/** A cursor spends the original player's real horizontal movement budget on
 * the already certified physical segments. It never sets a distant endpoint. */
export function advanceCarrierPath(path: CarrierTransferPath, segmentIndex: number, segmentDistance: number, budget: number): { segmentIndex: number; segmentDistance: number; position: Vec3; completed: boolean; spent: number; traversed: CarrierBodySegment[] } {
  let index = segmentIndex, distance = segmentDistance, remaining = budget, spent = 0;
  const traversed: CarrierBodySegment[] = [];
  let position = index < path.segments.length ? copy(path.segments[index].from) : copy(path.points.at(-1)!);
  while (index < path.segments.length && remaining >= 0) {
    const segment = path.segments[index], length = segment.horizontalBudget, offset = length ? distance / length : 1;
    const from = { x: segment.from.x + (segment.to.x - segment.from.x) * offset, y: segment.from.y + (segment.to.y - segment.from.y) * offset, z: segment.from.z + (segment.to.z - segment.from.z) * offset };
    const amount = Math.min(remaining, Math.max(0, length - distance)), t = length ? (distance + amount) / length : 1;
    position = { x: segment.from.x + (segment.to.x - segment.from.x) * t, y: segment.from.y + (segment.to.y - segment.from.y) * t, z: segment.from.z + (segment.to.z - segment.from.z) * t };
    if (from.x !== position.x || from.y !== position.y || from.z !== position.z) traversed.push({ from, to: copy(position), horizontalBudget: amount });
    remaining -= amount; spent += amount; distance += amount;
    if (distance < length) break;
    index++; distance = 0;
    if (remaining === 0) break;
  }
  return { segmentIndex: index, segmentDistance: distance, position, completed: index === path.segments.length, spent, traversed };
}

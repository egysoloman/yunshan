import * as THREE from 'three';
import type { NetworkSolidDescriptor } from './network-solid-recipe';
import type { Vec3, WorldDefinition } from './types';
import { CARRIER_FLOOR_THICKNESS } from './carrier-solids';
import type { StationPlatformParcel, StationWorld } from './station-throats';

export const STATION_PARCEL_SOLID_VERSION = 'yunshan-physical-platform-portal-ramp-v9-1';
export interface StationParcelSolid extends NetworkSolidDescriptor { stationPart: 'floor' | 'ramp' | 'guard' | 'track-deck' | 'track-rail' | 'track-curb'; walkable: boolean }
const bits = (values: number[]) => Array.from(new Uint32Array(new Float32Array(values).buffer));

/** These are actual finite slabs, ramps and rails, not query-only safe regions. */
export function stationParcelDescriptors(world: WorldDefinition): StationParcelSolid[] {
  const parcels = (world as StationWorld).stationEngineering?.platforms ?? [], result: StationParcelSolid[] = [];
  for (const parcel of parcels) {
    const forward = new THREE.Vector3(parcel.forward.x, 0, parcel.forward.z), across = new THREE.Vector3(parcel.across.x, 0, parcel.across.z);
    const parent = new THREE.Matrix4().makeBasis(across, new THREE.Vector3(0, 1, 0), forward).setPosition(parcel.center.x, parcel.center.y, parcel.center.z);
    const add = (part: StationParcelSolid['stationPart'], key: NetworkSolidDescriptor['key'], matrix: THREE.Matrix4, walkable: boolean, args: unknown[]) => {
      const color = new THREE.Color(key === 'wood' ? '#6b7771' : key === 'cyan' ? '#82d9d0' : '#a0ab9f'), m64 = [...matrix.elements], m32 = Array.from(new Float32Array(m64)), c32 = Array.from(new Float32Array([color.r, color.g, color.b]));
      result.push({ owner: { scope: 'station-parcel', parcelId: parcel.id, nodeId: parcel.nodeId, edgeId: parcel.edgeId, mode: parcel.mode, stationPart: part }, sourceCall: `station-parcel-v9:${part}`, matrixFloat64: m64, matrixFloat32: m32, matrixUint32: bits(m64), colorFloat32: c32, colorUint32: bits(c32), key, distanceDetail: false, arguments: args, operation: 'box', stationPart: part, walkable });
    };
    const box = (part: StationParcelSolid['stationPart'], key: NetworkSolidDescriptor['key'], x: number, y: number, z: number, sx: number, sy: number, sz: number, walkable = false) => add(part, key, parent.clone().multiply(new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion(), new THREE.Vector3(sx, sy, sz))), walkable, [x, y, z, sx, sy, sz]);
    const top = parcel.floorY - parcel.center.y, landing = parcel.landingY - parcel.center.y;
    for (const side of [-1, 1]) {
      const width = parcel.outerOffset - parcel.innerOffset;
      box('floor', 'stone', side * (parcel.innerOffset + width / 2), top - CARRIER_FLOOR_THICKNESS / 2, 0, width, CARRIER_FLOOR_THICKNESS, parcel.doorHalfWidth * 2, true);
      // Ramp thickness is normal to its actual inclined support plane. The top
      // connects to the real platform; authority computes exact Float32 support.
      const a = new THREE.Vector3(side * parcel.outerOffset, top, 0), b = new THREE.Vector3(side * parcel.rampOuterOffset, landing, 0), axis = b.clone().sub(a).normalize();
      const rampAcross = new THREE.Vector3(0, 0, side), normal = axis.clone().cross(rampAcross).normalize();
      if (normal.y < 0) { rampAcross.multiplyScalar(-1); normal.multiplyScalar(-1); }
      const center = a.clone().add(b).multiplyScalar(.5).addScaledVector(normal, -CARRIER_FLOOR_THICKNESS / 2), ramp = new THREE.Matrix4().makeBasis(rampAcross, normal, axis).setPosition(center).scale(new THREE.Vector3(parcel.doorHalfWidth * 2, CARRIER_FLOOR_THICKNESS, a.distanceTo(b)));
      add('ramp', 'stone', parent.clone().multiply(ramp), true, [a.toArray(), b.toArray(), CARRIER_FLOOR_THICKNESS, parcel.doorHalfWidth * 2]);
      // The old track-side bar is replaced only at a code-owned physical
      // platform portal. New outer rails protect both actual ramp edges.
      for (const zSide of [-1, 1]) box('guard', 'wood', side * (parcel.innerOffset + parcel.rampOuterOffset) / 2, top + 1.1, zSide * (parcel.doorHalfWidth + .3), parcel.rampOuterOffset - parcel.innerOffset, .2, .2);
    }
    // A physical buffer throat supports the rear of a stopped 16m carriage.
    // It is a station parcel, not an extra route that vehicles select at random.
    const length = parcel.flatLength;
    box('track-deck', 'stone', 0, -.9, -length / 2, 6, 1.4, length);
    for (const side of [-1, 1]) {
      box('track-rail', 'cyan', side * 1.8, .16, -length / 2, .28, .24, length);
      box('track-curb', 'stone', side * 2.75, -.1, -length / 2, .35, .5, length);
      const guarded = length - parcel.gateHalfLength;
      box('guard', 'wood', side * 2.75, 1.1, -(length + parcel.gateHalfLength) / 2, .2, .2, guarded);
    }
  }
  return result;
}

export function stationParcelPoint(parcel: StationPlatformParcel, across: number, along: number, y: number): Vec3 {
  return { x: parcel.center.x + parcel.across.x * across + parcel.forward.x * along, y, z: parcel.center.z + parcel.across.z * across + parcel.forward.z * along };
}

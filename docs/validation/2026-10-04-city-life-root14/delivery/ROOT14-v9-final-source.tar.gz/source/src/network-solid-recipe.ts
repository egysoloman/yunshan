/** Code-owned network solid descriptors. Old recipe preserves the witnessed renderer compose/Float32 transforms. No WebGL objects or Simulation. */
import * as THREE from 'three';
import { terrainHeight, samplePolyline } from './world';
import { deckWidth, guardrailOffset, guardrailSpans, hasGuardrailAt, GUARDRAIL_THICKNESS } from './transport-geometry';
import { marketApproachField, marketApproachGradient, marketApproachHeight, type MarketApproachField } from './market-station-approach';
import { stationRailGuardSpans } from './station-throats';
import { stationParcelDescriptors } from './station-parcel-solids';
import type { NetworkEdge, Vec3, WorldDefinition } from './types';
type LocalBox = ((key: MaterialKey, x: number, y: number, z: number, sx: number, sy: number, sz: number, floor?: number, roof?: boolean, color?: string) => void) & { profile?: (profile: unknown) => void }; 
const PALETTE = { wall: '#d2c9b6', stone: '#a0ab9f', wood: '#73533b', roof: '#456760', glass: '#6c938c', amber: '#ffd39a', cyan: '#82d9d0', red: '#954c40', metal: '#a3b1bb', fabric: '#cfc7ad' };
type MaterialKey = keyof typeof PALETTE;
const bits = (numbers: number[]) => Array.from(new Uint32Array(new Float32Array(numbers).buffer));
export interface NetworkSolidDescriptor { owner: Record<string, unknown>; sourceCall: string; matrixFloat64: number[]; matrixFloat32: number[]; matrixUint32: number[]; colorFloat32: number[]; colorUint32: number[]; key: MaterialKey; distanceDetail: boolean; arguments: unknown[]; operation: 'box' | 'segment'; meshName?: string; instanceId?: number; tags?: { roof?: boolean; building?: string; floor?: number; ceiling?: boolean } }
class MatrixCollector {
  private field: MarketApproachField | null;
  private engineeredEdges: Map<string, NetworkEdge>;
  constructor(private world: WorldDefinition) {
    this.field = ['current-v8', 'current-v9'].includes((world as WorldDefinition & { layoutVersion?: string }).layoutVersion ?? '') ? marketApproachField(world) : null;
    this.engineeredEdges = new Map(world.edges.filter(edge => ['road', 'bridge'].includes(edge.mode) && (edge.from === 'market-station' || edge.to === 'market-station')).map(edge => [edge.id, edge]));
  }
  owner: Record<string, unknown> = {};
  site = '';
  parts = new Map<MaterialKey, NetworkSolidDescriptor[]>();
  at(site: string) { this.site = site; return this; }
  add(key: MaterialKey, matrix: THREE.Matrix4, color: string | undefined, distanceDetail: boolean, args: unknown[], operation: 'box' | 'segment', tags?: NetworkSolidDescriptor['tags']) {
    const c = new THREE.Color(color ?? PALETTE[key]);
    const m64 = [...matrix.elements], m32 = Array.from(new Float32Array(m64));
    const c32 = Array.from(new Float32Array([c.r, c.g, c.b]));
    const list = this.parts.get(key) ?? [];
    list.push({ owner: { ...this.owner }, sourceCall: this.site, matrixFloat64: m64, matrixFloat32: m32, matrixUint32: bits(m64), colorFloat32: c32, colorUint32: bits(c32), key, distanceDetail, arguments: args, operation, ...(tags ? { tags } : {}) });
    this.parts.set(key, list);
  }
  box(key: MaterialKey, x: number, y: number, z: number, sx: number, sy: number, sz: number, color?: string, rotation = 0, tag?: unknown) {
    if (sx <= 0 || sy <= 0 || sz <= 0) return;
    const matrix = new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), rotation), new THREE.Vector3(sx, sy, sz));
    this.add(key, matrix, color, false, [x, y, z, sx, sy, sz, color ?? null, rotation, tag ?? null], 'box', tag as NetworkSolidDescriptor['tags']);
  }
  segment(key: MaterialKey, a: Vec3, b: Vec3, width: number, height: number, lift = 0, color?: string) {
    const va = new THREE.Vector3(a.x, a.y + lift, a.z), vb = new THREE.Vector3(b.x, b.y + lift, b.z);
    const edge = this.engineeredEdges.get(String(this.owner.edgeId)), field = this.field;
    const crossfall = field && edge && ['renderer.ts:760:1', 'renderer.ts:768:1', 'renderer.ts:762:1', 'renderer.ts:770:1', 'renderer.ts:772:1'].includes(this.site) ? marketApproachGradient(field, (a.x + b.x) / 2, (a.z + b.z) / 2) : null;
    if (field && edge && crossfall !== null && typeof this.owner.segmentIndex === 'number') {
      const start = edge.points[this.owner.segmentIndex - 1], end = edge.points[this.owner.segmentIndex];
      const dx = end.x - start.x, dz = end.z - start.z, run2 = dx * dx + dz * dz;
      const fieldOffset = (point: Vec3) => {
        const t = run2 ? Math.max(0, Math.min(1, ((point.x - start.x) * dx + (point.z - start.z) * dz) / run2)) : 0;
        const centerZ = start.z + dz * t;
        return marketApproachHeight(field, point.z) - marketApproachHeight(field, centerZ);
      };
      va.y += fieldOffset(a); vb.y += fieldOffset(b);
    }
    const direction = vb.clone().sub(va), length = direction.length();
    if (length < .01) return;
    let matrix: THREE.Matrix4;
    if (crossfall !== null) {
      // Actual v8 crossfall is geometry authority, including curb/guard offsets.
      // The shared matrix replaces the old implicit shortest-arc roll only here.
      const axis = direction.clone().normalize(), normal = new THREE.Vector3(0, 1, -crossfall);
      normal.addScaledVector(axis, -normal.dot(axis)).normalize();
      const across = normal.clone().cross(axis).normalize(), up = axis.clone().cross(across).normalize();
      matrix = new THREE.Matrix4().makeBasis(across, up, axis).setPosition(va.clone().add(vb).multiplyScalar(.5)).scale(new THREE.Vector3(width, height, length));
    } else if ((this.world as WorldDefinition & { layoutVersion?: string }).layoutVersion === 'current-v9' && ['maglev', 'lightRail'].includes(String(this.owner.mode))) {
      const axis = direction.clone().normalize(), across = new THREE.Vector3(axis.z, 0, -axis.x).normalize(), up = axis.clone().cross(across).normalize();
      matrix = new THREE.Matrix4().makeBasis(across, up, axis).setPosition(va.clone().add(vb).multiplyScalar(.5)).scale(new THREE.Vector3(width, height, length));
    } else matrix = new THREE.Matrix4().compose(va.add(vb).multiplyScalar(.5), new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), direction.normalize()), new THREE.Vector3(width, height, length));
    this.add(key, matrix, color, width <= .4 && height <= .24, [{...a}, {...b}, width, height, lift, color ?? null], 'segment');
  }
  append(descriptors: readonly NetworkSolidDescriptor[]) {
    for (const descriptor of descriptors) { const list = this.parts.get(descriptor.key) ?? []; list.push(descriptor); this.parts.set(descriptor.key, list); }
  }
  finish(cellSize: number) {
    const result: NetworkSolidDescriptor[] = [];
    for (const [key, parts] of this.parts) {
      const cells = new Map<string, NetworkSolidDescriptor[]>();
      for (const part of parts) {
        const cell = `${Math.floor(part.matrixFloat64[12] / cellSize)}:${Math.floor(part.matrixFloat64[14] / cellSize)}` + (part.distanceDetail ? ':detail' : '') + ':box';
        const list = cells.get(cell) ?? []; list.push(part); cells.set(cell, list);
      }
      for (const [cell, instances] of cells) instances.forEach((part, index) => { result.push({ ...part, meshName: `batch-${key}-${cell}`, instanceId: index }); });
    }
    return result;
  }
}
export class NetworkSolidRecipeBuilder {
  constructor(private world: WorldDefinition) {}
  buildNetwork() {
    const batch = new MatrixCollector(this.world);
    for (const edge of this.world.edges) {
      batch.owner = { scope: 'network-edge', edgeId: edge.id, mode: edge.mode }; if (edge.mode === 'flight') continue;
      let supportRemainder = 0;
      for (let i = 1; i < edge.points.length; i++) {
        const a = edge.points[i - 1], b = edge.points[i]; batch.owner.segmentIndex = i;
        if (edge.mode === 'ferry') continue;
        if (edge.mode === 'cable') { batch.at("renderer.ts:750:1").segment('wood', a, b, .45, .45, 9); batch.at("renderer.ts:750:2").segment('cyan', a, b, .15, .15, 8.5); continue; }
        if (edge.mode === 'lift') {
          // An open four-post lift cage preserves the real central travel axis
          // while allowing the adjacent waterfall to remain visible through it.
          for (const x of [-2.5, 2.5]) for (const z of [-2.5, 2.5]) batch.at("renderer.ts:754:1").segment('stone', { ...a, x: a.x + x, z: a.z + z }, { ...b, x: b.x + x, z: b.z + z }, .6, .6, 0, '#a4b0a2');
          for (let y = Math.min(a.y, b.y); y <= Math.max(a.y, b.y); y += 12) { for (const x of [-2.5, 2.5]) batch.at("renderer.ts:755:1").box('wood', a.x + x, y, a.z, .6, .6, 5.6, '#698780'); for (const z of [-2.5, 2.5]) batch.at("renderer.ts:755:2").box('wood', a.x, y, a.z + z, 5.6, .6, .6, '#698780'); }
          batch.at("renderer.ts:756:1").segment('cyan', { ...a, x: a.x + 3.2 }, { ...b, x: b.x + 3.2 }, .3, .3); continue;
        }
        const rail = edge.mode === 'maglev' || edge.mode === 'lightRail';
        const width = deckWidth(edge);
        batch.at("renderer.ts:760:1").segment('stone', a, b, width, rail ? 1.4 : .5, rail ? -.9 : -.25, rail ? '#84948e' : edge.mode === 'bridge' ? '#b8b3a0' : '#969987');
        if (rail) {
          const realFrame = (this.world as WorldDefinition & { layoutVersion?: string }).layoutVersion === 'current-v9', horizontal = Math.hypot(b.x - a.x, b.z - a.z), rx = realFrame ? -(b.z - a.z) / horizontal * 1.8 : 1.8, rz = realFrame ? (b.x - a.x) / horizontal * 1.8 : 0;
          batch.at("renderer.ts:761:1").segment('cyan', { ...a, x: a.x - rx, z: a.z - rz }, { ...b, x: b.x - rx, z: b.z - rz }, .28, .24, .16); batch.at("renderer.ts:761:2").segment('cyan', { ...a, x: a.x + rx, z: a.z + rz }, { ...b, x: b.x + rx, z: b.z + rz }, .28, .24, .16);
        }
        else if (edge.mode !== 'bridge') batch.at("renderer.ts:762:1").segment('stone', a, b, .16, .08, .07, '#d1c6a1');
        // Curbs, paving seams and separate shoulders make the travelled deck
        // legible at body height without widening the shared collision surface.
        const dx = b.x - a.x, dz = b.z - a.z, horizontal = Math.hypot(dx, dz) || 1, nx = -dz / horizontal, nz = dx / horizontal;
        for (const side of [-1, 1]) {
          const offset = guardrailOffset(edge), aa = { x: a.x + nx * offset * side, y: a.y, z: a.z + nz * offset * side }, bb = { x: b.x + nx * offset * side, y: b.y, z: b.z + nz * offset * side };
          batch.at("renderer.ts:768:1").segment('stone', aa, bb, rail ? .35 : .4, rail ? .5 : .2, rail ? -.1 : .12, '#c0c2ac');
          const elevated = (a.y + b.y) / 2 - terrainHeight(this.world, (a.x + b.x) / 2, (a.z + b.z) / 2) > 4;
          if (edge.mode === 'bridge' || rail || elevated && edge.mode === 'road') for (const span of rail && (this.world as WorldDefinition & { layoutVersion?: string }).layoutVersion === 'current-v9' ? stationRailGuardSpans(this.world, edge, i) : guardrailSpans(this.world, edge, i)) batch.at("renderer.ts:770:1").segment('wood', { x: span.a.x + nx * offset * side, y: span.a.y, z: span.a.z + nz * offset * side }, { x: span.b.x + nx * offset * side, y: span.b.y, z: span.b.z + nz * offset * side }, GUARDRAIL_THICKNESS, .2, 1.1, '#6b7771');
        }
        if (edge.mode === 'road' && !edge.id.includes('runway')) { const middle = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 + .04, z: (a.z + b.z) / 2 }; batch.at("renderer.ts:772:1").segment('stone', { ...middle, x: middle.x - nx * 3.5, z: middle.z - nz * 3.5 }, { ...middle, x: middle.x + nx * 3.5, z: middle.z + nz * 3.5 }, .08, .04, 0, '#757e73'); }
        const length = Math.hypot(b.x - a.x, b.z - a.z), interval = rail ? 80 : 70;
        // Spacing spans all samples of the same edge, including the world's 4m rails.
        for (let along = interval - supportRemainder; along <= length; along += interval) { const t = along / Math.max(.01, length), x = a.x + (b.x - a.x) * t, z = a.z + (b.z - a.z) * t, y = a.y + (b.y - a.y) * t, ground = terrainHeight(this.world, x, z); if (y - ground > 5 && edge.mode !== 'bridge') { const tall = y - ground; batch.at("renderer.ts:775:1").box('stone', x, ground + 1, z, rail ? 7 : 8, 2, rail ? 7 : 8, '#939e91'); batch.at("renderer.ts:775:2").box('stone', x, ground + tall / 2, z, rail ? 3 : 4, tall, rail ? 3 : 4, '#a0aaa0'); batch.at("renderer.ts:775:3").box('stone', x, y - 1.3, z, width + 1, 1.8, 4, '#929d92'); if (tall > 25) for (let tie = ground + 12; tie < y - 5; tie += 16) batch.at("renderer.ts:775:4").box('wood', x, tie, z, rail ? 4 : 5, .6, rail ? 4 : 5); } }
        supportRemainder = (supportRemainder + length) % interval;
      }
      if (edge.mode === 'bridge') { batch.owner = { scope: 'bridge', edgeId: edge.id, mode: edge.mode }; this.buildBridge(edge, batch); }
    }
    for (const node of this.world.nodes) {
      const p = node.position; batch.owner = { scope: 'network-node', nodeId: node.id, station: node.station };
      if (node.station) { batch.at("renderer.ts:782:1").box('stone', p.x, p.y - .6, p.z, 22, 1, 18); batch.at("renderer.ts:782:2").box('cyan', p.x, p.y + .1, p.z + 8, 20, .2, .35); for (const x of [-8, 8]) { batch.at("renderer.ts:782:3").box('wood', p.x + x, p.y + 3, p.z, .8, 6, .8); batch.at("renderer.ts:782:4").box('amber', p.x + x, p.y + 5.7, p.z, 1.5, .35, 1.5); } batch.at("renderer.ts:782:5").box('roof', p.x, p.y + 6.4, p.z, 23, .65, 11, undefined, 0, { roof: true }); batch.at("renderer.ts:782:6").box('wood', p.x + 12, p.y + 1.8, p.z + 11, .35, 3.6, .35); batch.at("renderer.ts:782:7").box('wood', p.x + 12, p.y + 3.5, p.z + 11, 1, 1.6, .65); }
      else if (node.id.includes('junction') || node.id.includes('road')) { batch.at("renderer.ts:783:1").box('wood', p.x + 4, p.y + 2.2, p.z + 4, .4, 4.4, .4); }
    }
    if ((this.world as WorldDefinition & { layoutVersion?: string }).layoutVersion === 'current-v9') batch.append(stationParcelDescriptors(this.world));
    return batch.finish(384);
  }
  private buildBridge(edge: NetworkEdge, batch: MatrixCollector) {
    if (edge.points.length < 2) return;
    const length = edge.points.slice(1).reduce((sum, p, i) => sum + Math.hypot(p.x - edge.points[i].x, p.z - edge.points[i].z), 0);
    const arcLength = edge.points.slice(1).reduce((sum, p, i) => sum + Math.hypot(p.x - edge.points[i].x, p.y - edge.points[i].y, p.z - edge.points[i].z), 0);
    const samples = Math.max(8, Math.ceil(length / 8));
    const point = (t: number, side: number, lift: number) => { const p = samplePolyline(edge.points, t), a = samplePolyline(edge.points, Math.max(0, t - .01)), b = samplePolyline(edge.points, Math.min(1, t + .01)), dx = b.x - a.x, dz = b.z - a.z, l = Math.hypot(dx, dz) || 1; return { x: p.x - dz / l * side * 4.1, y: p.y + lift, z: p.z + dx / l * side * 4.1 }; };
    const suspension = length > 140;
    for (const side of [-1, 1]) {
      for (let i = 0; i <= samples; i++) {
        const t = i / samples, deck = point(t, side, 0);
        const guarded = hasGuardrailAt(this.world, edge, t * arcLength);
        if (guarded) batch.at("renderer.ts:801:1").box('wood', deck.x, deck.y + .55, deck.z, .4, 1.1, .4, '#6c7871');
        if (suspension) {
          const lift = t < .16 ? 3 + t / .16 * 27 : t > .84 ? 3 + (1 - t) / .16 * 27 : 30 - 21 * Math.sin((t - .16) / .68 * Math.PI);
          const cable = point(t, side, lift);
          if (i) { const previousT = (i - 1) / samples, previousLift = previousT < .16 ? 3 + previousT / .16 * 27 : previousT > .84 ? 3 + (1 - previousT) / .16 * 27 : 30 - 21 * Math.sin((previousT - .16) / .68 * Math.PI); batch.at("renderer.ts:805:1").segment('wood', point(previousT, side, previousLift), cable, .5, .5, 0, '#627d7c'); }
          if (guarded) batch.at("renderer.ts:806:1").segment('stone', { ...deck, y: deck.y + 1.1 }, cable, .2, .2, 0, '#9eb1a7');
        }
      }
      for (const t of suspension ? [.16, .84] : [0, 1]) {
        if (suspension && !hasGuardrailAt(this.world, edge, t * arcLength)) continue;
        const offset = suspension ? 6 : 6.5, deck = point(t, side * offset / 4.1, 0), ground = Math.min(terrainHeight(this.world, deck.x, deck.z), deck.y - 2.6), height = deck.y - ground + (suspension ? 32 : 2.4);
        batch.at("renderer.ts:812:1").box('stone', deck.x, ground + .8, deck.z, 9, 1.6, 9, '#a4aa9b');
        batch.at("renderer.ts:813:1").box('stone', deck.x, ground + height / 2, deck.z, 2, height, 2, '#8c9b95');
        if (suspension) { const across = point(t, -side * offset / 4.1, 28); batch.at("renderer.ts:814:1").segment('stone', { ...deck, y: deck.y + 28 }, across, 1.6, 1.6, 0, '#8b9b95'); this.roof((key, x, y, z, sx, sy, sz) => batch.at("renderer.ts:814:2").box(key, deck.x + x, deck.y + y, deck.z + z, sx, sy, sz), 5, 5, 32, 0, .35, true); }
      }
    }
    for (const t of [0, 1]) { const p = samplePolyline(edge.points, t), ground = terrainHeight(this.world, p.x, p.z); batch.at("renderer.ts:817:1").box('stone', p.x, (p.y + ground) / 2, p.z, 12, Math.max(1, p.y - ground), 10, '#a2a88f'); }
  }
  private roof(box: LocalBox, w: number, d: number, y: number, floor: number, magnitude: number, simple = false) {
    const overhang = Math.max(2, Math.min(12, w * .14)), rise = Math.max(2.8, Math.min(14, w * .18)) * magnitude;
    box('wood', 0, y + .12, 0, w + overhang * 1.3, .2, d + overhang * 1.3, floor, true, '#947450');
    const levels = simple ? 3 : Math.max(6, Math.ceil(rise / .4));
    if (box.profile) box.profile({ form: 'hip', x: 0, y, z: 0, width: w, depth: d, rise, overhang, floor, simple, color: '#41605b' });
    else for (let step = 0; step < levels; step++) { const fraction = step / levels; box('roof', 0, y + .4 + fraction * rise, 0, (w + overhang * 2) * (1 - fraction * .78), rise / levels + .2, (d + overhang * 2) * (1 - fraction * .76), floor, true, step % 3 ? '#395f5b' : '#416a61'); }
    box('roof', 0, y + rise + .8, 0, Math.max(1.2, w * .48), .4, Math.max(.6, d * .035), floor, true);
    box('amber', 0, y + .2, d / 2 + overhang * .8, w + overhang, .12, .16, floor, true);
    // Stepped rising corners create a readable flying-eave silhouette.
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) for (let i = simple ? 2 : 0; i < 3; i++) box('roof', sx * (w / 2 + overhang * (.45 + i * .2)), y + .7 + i * .43, sz * (d / 2 + overhang * (.45 + i * .2)), overhang * .55, .58, overhang * .55, floor, true);
    if (!simple) {
      for (const x of [-.4, -.2, 0, .2, .4]) for (const side of [-1, 1]) box('wood', x * w, y - .08, side * (d / 2 + overhang * .3), .25, .2, overhang * .9, floor, true, '#b19365');
      // Individual tiled ribs and paired bracket arms read at walking distance.
      for (let x = -w / 2; x <= w / 2; x += Math.max(2, w / 18)) box('roof', x, y + .7, d / 2 + overhang * .7, .2, .2, overhang * .8, floor, true, '#769080');
      for (const x of [-w * .4, -w * .2, 0, w * .2, w * .4]) for (const z of [-d / 2, d / 2]) { box('wood', x, y - .45, z, 1.2, .4, 1.8, floor, true); box('wood', x, y - .15, z, 2, .2, 2.4, floor, true); }
    }
  }
}

export const NETWORK_SOLID_RECIPE_VERSION = 'yunshan-network-solid-float32-v8-1';

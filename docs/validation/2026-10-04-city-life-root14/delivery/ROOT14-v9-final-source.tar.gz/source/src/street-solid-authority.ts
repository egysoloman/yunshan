import * as THREE from 'three';
import { NetworkSolidRecipeBuilder, type NetworkSolidDescriptor } from './network-solid-recipe';
import type { Vec3, WorldDefinition } from './types';

export const STREET_SOLID_AUTHORITY_VERSION = 'yunshan-street-solid-support-v8-1';
export const STREET_BODY_RADIUS = .35;
export const STREET_BODY_HEIGHT = 1.72;
export const STREET_MAXIMUM_STEP = .4;
type Point = readonly [number, number, number];
type Triangle = readonly [Point, Point, Point];
type Edge = readonly [Point, Point];
export interface StreetSolid {
  descriptor: NetworkSolidDescriptor;
  vertices: readonly Point[];
  triangles: readonly Triangle[];
  edges: readonly Edge[];
  inverse: readonly number[];
  bounds: { minimum: Point; maximum: Point };
  surfaceKind: 'deck' | 'curb' | 'marking' | 'paving' | 'station' | 'solid';
  walkable: boolean;
}
export interface StreetSupport { y: number; solid: StreetSolid; point: Vec3; maximumStep: number }
export interface StreetContact { solid: StreetSolid; spineDistance: number; signedSeparation: number }
const add = (a: Point, b: Point): Point => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const sub = (a: Point, b: Point): Point => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const scale = (a: Point, k: number): Point => [a[0] * k, a[1] * k, a[2] * k];
const dot = (a: Point, b: Point) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a: Point, b: Point): Point => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = (a: Point) => Math.hypot(...a);
const clamp = (value: number, low: number, high: number) => Math.max(low, Math.min(high, value));
const xyz = (point: Vec3): Point => [point.x, point.y, point.z];
const transform = (matrix: readonly number[], point: Point): Point => [0, 1, 2].map(axis => matrix[axis] * point[0] + matrix[axis + 4] * point[1] + matrix[axis + 8] * point[2] + matrix[axis + 12]) as unknown as Point;
const surfaceKinds: Record<string, StreetSolid['surfaceKind']> = { 'renderer.ts:760:1': 'deck', 'renderer.ts:768:1': 'curb', 'renderer.ts:762:1': 'marking', 'renderer.ts:772:1': 'paving', 'renderer.ts:782:1': 'station' };

/** Uses the actual Float32 instance, including small nonorthogonal roundoff. */
export function streetSolidFromDescriptor(descriptor: NetworkSolidDescriptor): StreetSolid {
  const matrix = descriptor.matrixFloat32;
  const vertices: Point[] = [];
  for (const x of [-.5, .5]) for (const y of [-.5, .5]) for (const z of [-.5, .5]) vertices.push(transform(matrix, [x, y, z]));
  const triangles: Triangle[] = [];
  for (let fixed = 0; fixed < 3; fixed++) {
    const axes = [0, 1, 2].filter(axis => axis !== fixed);
    for (const side of [-.5, .5]) {
      const face = [[-.5, -.5], [.5, -.5], [.5, .5], [-.5, .5]].map(([u, v]) => {
        const point: [number, number, number] = [0, 0, 0]; point[fixed] = side; point[axes[0]] = u; point[axes[1]] = v;
        return transform(matrix, point);
      });
      triangles.push([face[0], face[1], face[2]], [face[0], face[2], face[3]]);
    }
  }
  const edges: Edge[] = [];
  for (let a = 0; a < 8; a++) for (let b = a + 1; b < 8; b++) if ([1, 2, 4].includes(a ^ b)) edges.push([vertices[a], vertices[b]]);
  const surfaceKind = surfaceKinds[descriptor.sourceCall] ?? 'solid';
  const stationParcelFloor = descriptor.owner.scope === 'station-parcel' && ['floor', 'ramp'].includes(String(descriptor.owner.stationPart));
  const walkable = stationParcelFloor || surfaceKind === 'station' || ['road', 'bridge'].includes(String(descriptor.owner.mode)) && surfaceKind !== 'solid';
  const inverse = new THREE.Matrix4().fromArray(matrix).invert().elements.slice();
  return { descriptor, vertices, triangles, edges, inverse, surfaceKind, walkable, bounds: { minimum: [0, 1, 2].map(axis => Math.min(...vertices.map(point => point[axis]))) as unknown as Point, maximum: [0, 1, 2].map(axis => Math.max(...vertices.map(point => point[axis]))) as unknown as Point } };
}

function segmentIntersectsSolid(a: Point, b: Point, solid: StreetSolid): boolean {
  const p = transform(solid.inverse, a), direction = sub(transform(solid.inverse, b), p);
  let low = 0, high = 1;
  for (let axis = 0; axis < 3; axis++) {
    if (Math.abs(direction[axis]) < 1e-30) { if (Math.abs(p[axis]) > .5) return false; continue; }
    const first = (-.5 - p[axis]) / direction[axis], second = (.5 - p[axis]) / direction[axis];
    low = Math.max(low, Math.min(first, second)); high = Math.min(high, Math.max(first, second));
    if (low > high) return false;
  }
  return true;
}
function segmentDistance(p: Point, q: Point, a: Point, b: Point): number {
  const d1 = sub(q, p), d2 = sub(b, a), r = sub(p, a), aa = dot(d1, d1), ee = dot(d2, d2), f = dot(d2, r);
  let s = 0, t = 0;
  if (aa <= 1e-30 && ee <= 1e-30) return norm(r);
  if (aa <= 1e-30) t = clamp(f / ee, 0, 1);
  else {
    const c = dot(d1, r);
    if (ee <= 1e-30) s = clamp(-c / aa, 0, 1);
    else {
      const bb = dot(d1, d2), denominator = aa * ee - bb * bb;
      s = denominator ? clamp((bb * f - c * ee) / denominator, 0, 1) : 0; t = (bb * s + f) / ee;
      if (t < 0) { t = 0; s = clamp(-c / aa, 0, 1); }
      else if (t > 1) { t = 1; s = clamp((bb - c) / aa, 0, 1); }
    }
  }
  return norm(sub(add(p, scale(d1, s)), add(a, scale(d2, t))));
}
function pointTriangleDistance(point: Point, [a, b, c]: Triangle): number {
  const ab = sub(b, a), ac = sub(c, a), ap = sub(point, a), d1 = dot(ab, ap), d2 = dot(ac, ap);
  if (d1 <= 0 && d2 <= 0) return norm(ap);
  const bp = sub(point, b), d3 = dot(ab, bp), d4 = dot(ac, bp);
  if (d3 >= 0 && d4 <= d3) return norm(bp);
  const vc = d1 * d4 - d3 * d2;
  if (vc <= 0 && d1 >= 0 && d3 <= 0) return norm(sub(point, add(a, scale(ab, d1 / (d1 - d3)))));
  const cp = sub(point, c), d5 = dot(ab, cp), d6 = dot(ac, cp);
  if (d6 >= 0 && d5 <= d6) return norm(cp);
  const vb = d5 * d2 - d1 * d6;
  if (vb <= 0 && d2 >= 0 && d6 <= 0) return norm(sub(point, add(a, scale(ac, d2 / (d2 - d6)))));
  const va = d3 * d6 - d5 * d4;
  if (va <= 0 && d4 - d3 >= 0 && d5 - d6 >= 0) return norm(sub(point, add(b, scale(sub(c, b), (d4 - d3) / ((d4 - d3) + (d5 - d6))))));
  const denominator = 1 / (va + vb + vc);
  return norm(sub(point, add(a, add(scale(ab, vb * denominator), scale(ac, vc * denominator)))));
}
function segmentTriangleDistance(p: Point, q: Point, triangle: Triangle): number {
  const [a, b, c] = triangle, normal = cross(sub(b, a), sub(c, a)), direction = sub(q, p), denominator = dot(normal, direction);
  if (Math.abs(denominator) > 1e-30) {
    const t = dot(normal, sub(a, p)) / denominator;
    if (t >= 0 && t <= 1 && pointTriangleDistance(add(p, scale(direction, t)), triangle) < 1e-10) return 0;
  }
  return Math.min(pointTriangleDistance(p, triangle), pointTriangleDistance(q, triangle), segmentDistance(p, q, a, b), segmentDistance(p, q, b, c), segmentDistance(p, q, c, a));
}

/** Continuous Minkowski sweep of the full capsule, not only sampled endpoints. */
export function streetCapsuleSeparation(solid: StreetSolid, from: Vec3, to: Vec3, radius = STREET_BODY_RADIUS, height = STREET_BODY_HEIGHT): number {
  const a = xyz(from), b = xyz(to), p: Point = [a[0], a[1] + radius, a[2]], q: Point = [a[0], a[1] + height - radius, a[2]], u: Point = [b[0], b[1] + radius, b[2]], v: Point = [b[0], b[1] + height - radius, b[2]];
  if (Math.hypot(a[0] - b[0], a[2] - b[2]) < 1e-12) {
    const low: Point = [p[0], Math.min(p[1], u[1]), p[2]], high: Point = [p[0], Math.max(q[1], v[1]), p[2]];
    return segmentIntersectsSolid(low, high, solid) ? -radius : Math.min(...solid.triangles.map(triangle => segmentTriangleDistance(low, high, triangle))) - radius;
  }
  const quad = [p, q, v, u], edges: Edge[] = quad.map((point, index) => [point, quad[(index + 1) % 4]]), triangles: Triangle[] = [[p, q, v], [p, v, u]];
  if (edges.some(([start, end]) => segmentIntersectsSolid(start, end, solid))) return -radius;
  const distance = Math.min(...edges.flatMap(([start, end]) => solid.triangles.map(triangle => segmentTriangleDistance(start, end, triangle))), ...solid.edges.flatMap(([start, end]) => triangles.map(triangle => segmentTriangleDistance(start, end, triangle))));
  return distance - radius;
}

interface SolidIndex { descriptors: NetworkSolidDescriptor[]; solids: StreetSolid[]; cells: Map<string, number[]> }
const indices = new WeakMap<WorldDefinition, SolidIndex>();
const CELL = 24, key = (x: number, z: number) => `${x}:${z}`;
function indexFor(world: WorldDefinition): SolidIndex {
  let index = indices.get(world); if (index) return index;
  const descriptors = new NetworkSolidRecipeBuilder(world).buildNetwork(), solids = descriptors.map(streetSolidFromDescriptor), cells = new Map<string, number[]>();
  solids.forEach((solid, id) => { for (let x = Math.floor(solid.bounds.minimum[0] / CELL); x <= Math.floor(solid.bounds.maximum[0] / CELL); x++) for (let z = Math.floor(solid.bounds.minimum[2] / CELL); z <= Math.floor(solid.bounds.maximum[2] / CELL); z++) { const list = cells.get(key(x, z)) ?? []; list.push(id); cells.set(key(x, z), list); } });
  index = { descriptors, solids, cells }; indices.set(world, index); return index;
}
export function invalidateStreetSolids(world: WorldDefinition): void { indices.delete(world); }
/** The renderer can consume these exact descriptors; no second transform recipe. */
export function getStreetSolidDescriptors(world: WorldDefinition): readonly NetworkSolidDescriptor[] { return indexFor(world).descriptors; }
export function getNearbyStreetSolids(world: WorldDefinition, from: Vec3, to: Vec3, radius = STREET_BODY_RADIUS, height = STREET_BODY_HEIGHT): StreetSolid[] {
  const index = indexFor(world), ids = new Set<number>(), minimum = [Math.min(from.x, to.x) - radius, Math.min(from.y, to.y), Math.min(from.z, to.z) - radius], maximum = [Math.max(from.x, to.x) + radius, Math.max(from.y, to.y) + height, Math.max(from.z, to.z) + radius];
  for (let x = Math.floor(minimum[0] / CELL); x <= Math.floor(maximum[0] / CELL); x++) for (let z = Math.floor(minimum[2] / CELL); z <= Math.floor(maximum[2] / CELL); z++) for (const id of index.cells.get(key(x, z)) ?? []) ids.add(id);
  return [...ids].map(id => index.solids[id]).filter(solid => minimum.every((value, axis) => value <= solid.bounds.maximum[axis] && maximum[axis] >= solid.bounds.minimum[axis]));
}
export function streetMovementContacts(world: WorldDefinition, from: Vec3, to: Vec3, radius = STREET_BODY_RADIUS, height = STREET_BODY_HEIGHT): StreetContact[] {
  return getNearbyStreetSolids(world, from, to, radius, height).map(solid => { const signedSeparation = streetCapsuleSeparation(solid, from, to, radius, height); return { solid, spineDistance: signedSeparation + radius, signedSeparation }; }).filter(contact => contact.signedSeparation < 0);
}

type FlatPoint = readonly [number, number];
function insidePolygon(point: FlatPoint, polygon: readonly FlatPoint[]): boolean {
  let positive = false, negative = false;
  for (let index = 0; index < polygon.length; index++) { const a = polygon[index], b = polygon[(index + 1) % polygon.length], area = (b[0] - a[0]) * (point[1] - a[1]) - (b[1] - a[1]) * (point[0] - a[0]); positive ||= area > 1e-10; negative ||= area < -1e-10; }
  return !(positive && negative);
}
/** Maximum true face top under a finite circular foot, including curb edges. */
export function streetSolidFootTop(solid: StreetSolid, x: number, z: number, radius = STREET_BODY_RADIUS): { y: number; point: Vec3 } | null {
  let best: { y: number; point: Vec3 } | null = null;
  const matrix = solid.descriptor.matrixFloat32;
  for (let fixed = 0; fixed < 3; fixed++) {
    const axes = [0, 1, 2].filter(axis => axis !== fixed);
    for (const side of [-.5, .5]) {
      const face = [[-.5, -.5], [.5, -.5], [.5, .5], [-.5, .5]].map(([u, v]) => { const local: [number, number, number] = [0, 0, 0]; local[fixed] = side; local[axes[0]] = u; local[axes[1]] = v; return transform(matrix, local); });
      let normal = cross(sub(face[1], face[0]), sub(face[2], face[0]));
      if (dot(normal, sub(face[0], transform(matrix, [0, 0, 0]))) < 0) normal = scale(normal, -1);
      if (normal[1] <= 1e-10) continue;
      const polygon: FlatPoint[] = face.map(point => [point[0], point[2]]), candidates: FlatPoint[] = polygon.filter(point => Math.hypot(point[0] - x, point[1] - z) <= radius);
      const gradient: FlatPoint = [-normal[0] / normal[1], -normal[2] / normal[1]], magnitude = Math.hypot(...gradient), extreme: FlatPoint = magnitude ? [x + radius * gradient[0] / magnitude, z + radius * gradient[1] / magnitude] : [x, z];
      if (insidePolygon(extreme, polygon)) candidates.push(extreme);
      if (insidePolygon([x, z], polygon)) candidates.push([x, z]);
      for (let index = 0; index < polygon.length; index++) {
        const a = polygon[index], b = polygon[(index + 1) % polygon.length], dx = b[0] - a[0], dz = b[1] - a[1], length2 = dx * dx + dz * dz;
        if (!length2) continue;
        const projection = clamp(((x - a[0]) * dx + (z - a[1]) * dz) / length2, 0, 1), closest: FlatPoint = [a[0] + projection * dx, a[1] + projection * dz];
        if (Math.hypot(closest[0] - x, closest[1] - z) <= radius) candidates.push(closest);
        const aa = a[0] - x, az = a[1] - z, quadraticB = 2 * (aa * dx + az * dz), quadraticC = aa * aa + az * az - radius * radius, discriminant = quadraticB * quadraticB - 4 * length2 * quadraticC;
        if (discriminant >= 0) for (const t of [(-quadraticB - Math.sqrt(discriminant)) / (2 * length2), (-quadraticB + Math.sqrt(discriminant)) / (2 * length2)]) if (t >= 0 && t <= 1) candidates.push([a[0] + t * dx, a[1] + t * dz]);
      }
      const constant = dot(normal, face[0]);
      for (const point of candidates) { const y = (constant - normal[0] * point[0] - normal[2] * point[1]) / normal[1]; if (!best || y > best.y) best = { y, point: { x: point[0], y, z: point[1] } }; }
    }
  }
  return best;
}

/** Contact of the actual lower capsule sphere, rather than hovering a rounded
 * body above a flat-foot maximum at a narrow curb's far edge. */
export function streetSolidCapsuleSupport(solid: StreetSolid, x: number, z: number, radius = STREET_BODY_RADIUS): { y: number; point: Vec3 } | null {
  let best: { y: number; point: Vec3 } | null = null;
  const matrix = solid.descriptor.matrixFloat32;
  for (let fixed = 0; fixed < 3; fixed++) {
    const axes = [0, 1, 2].filter(axis => axis !== fixed);
    for (const side of [-.5, .5]) {
      const face = [[-.5, -.5], [.5, -.5], [.5, .5], [-.5, .5]].map(([u, v]) => { const local: [number, number, number] = [0, 0, 0]; local[fixed] = side; local[axes[0]] = u; local[axes[1]] = v; return transform(matrix, local); });
      let normal = cross(sub(face[1], face[0]), sub(face[2], face[0]));
      if (dot(normal, sub(face[0], transform(matrix, [0, 0, 0]))) < 0) normal = scale(normal, -1);
      if (normal[1] <= 1e-10) continue;
      const polygon: FlatPoint[] = face.map(point => [point[0], point[2]]), gradient: FlatPoint = [-normal[0] / normal[1], -normal[2] / normal[1]], factor = radius / Math.sqrt(1 + gradient[0] ** 2 + gradient[1] ** 2), candidates: FlatPoint[] = [];
      const extreme: FlatPoint = [x + factor * gradient[0], z + factor * gradient[1]];
      if (insidePolygon(extreme, polygon)) candidates.push(extreme);
      for (let index = 0; index < polygon.length; index++) {
        const a = polygon[index], b = polygon[(index + 1) % polygon.length], dx = b[0] - a[0], dz = b[1] - a[1], length = Math.hypot(dx, dz);
        if (!length) continue;
        const t0 = ((x - a[0]) * dx + (z - a[1]) * dz) / (length * length), closest: FlatPoint = [a[0] + t0 * dx, a[1] + t0 * dz], distance2 = (closest[0] - x) ** 2 + (closest[1] - z) ** 2;
        if (distance2 > radius * radius) continue;
        const slope = (gradient[0] * dx + gradient[1] * dz) / length, halfChord = Math.sqrt(Math.max(0, radius * radius - distance2)), t = clamp(t0 + slope * halfChord / Math.sqrt(1 + slope * slope) / length, 0, 1);
        candidates.push([a[0] + t * dx, a[1] + t * dz]);
      }
      const constant = dot(normal, face[0]);
      for (const point of candidates) {
        const distance2 = (point[0] - x) ** 2 + (point[1] - z) ** 2; if (distance2 > radius * radius) continue;
        const surfaceY = (constant - normal[0] * point[0] - normal[2] * point[1]) / normal[1], y = surfaceY + Math.sqrt(Math.max(0, radius * radius - distance2)) - radius;
        if (!best || y > best.y) best = { y, point: { x: point[0], y: surfaceY, z: point[1] } };
      }
    }
  }
  return best;
}

function facePolygons(solid: StreetSolid): FlatPoint[][] {
  const matrix = solid.descriptor.matrixFloat32, result: FlatPoint[][] = [];
  for (let fixed = 0; fixed < 3; fixed++) {
    const axes = [0, 1, 2].filter(axis => axis !== fixed);
    for (const side of [-.5, .5]) {
      const face = [[-.5, -.5], [.5, -.5], [.5, .5], [-.5, .5]].map(([u, v]) => { const p: [number, number, number] = [0, 0, 0]; p[fixed] = side; p[axes[0]] = u; p[axes[1]] = v; return transform(matrix, p); });
      let normal = cross(sub(face[1], face[0]), sub(face[2], face[0])); if (dot(normal, sub(face[0], transform(matrix, [0, 0, 0]))) < 0) normal = scale(normal, -1);
      if (normal[1] > 1e-10) result.push(face.map(point => [point[0], point[2]]));
    }
  }
  return result;
}
const area2 = (a: FlatPoint, b: FlatPoint) => a[0] * b[1] - a[1] * b[0];
const difference2 = (a: FlatPoint, b: FlatPoint): FlatPoint => [a[0] - b[0], a[1] - b[1]];
const winding = (polygon: FlatPoint[]) => Math.sign(polygon.reduce((sum, point, index) => sum + area2(point, polygon[(index + 1) % polygon.length]), 0));
function coversExterior(point: FlatPoint, outward: FlatPoint, polygon: FlatPoint[]): boolean {
  const orientation = winding(polygon); if (!orientation) return false;
  for (let index = 0; index < polygon.length; index++) {
    const a = polygon[index], edge = difference2(polygon[(index + 1) % polygon.length], a), value = orientation * area2(edge, difference2(point, a));
    if (value < -1e-10) return false;
    if (Math.abs(value) <= 1e-10 && orientation * area2(edge, outward) < 0) return false;
  }
  return true;
}
export interface StreetFootCoverage { covered: boolean; centerContained: boolean; exposedBoundaryDistance: number; projectedSolidCount: number }
/** Exact exposed-boundary audit of the complete circular foot projection. The
 * union includes real reachable decks/steps, never an invented gap rectangle. */
export function streetFootCoverageFromSolids(input: readonly StreetSolid[], x: number, z: number, feetY: number, radius = STREET_BODY_RADIUS): StreetFootCoverage {
  const solids = input.filter(solid => { if (!solid.walkable) return false; const support = streetSolidCapsuleSupport(solid, x, z, radius); return support !== null && support.y <= feetY + 1e-10 && support.y >= feetY - STREET_MAXIMUM_STEP; }), polygons = solids.flatMap(facePolygons), center: FlatPoint = [x, z];
  const centerContained = polygons.some(polygon => insidePolygon(center, polygon)); let closest2 = Infinity;
  for (let pi = 0; pi < polygons.length; pi++) {
    const polygon = polygons[pi], orientation = winding(polygon);
    for (let index = 0; index < polygon.length; index++) {
      const a = polygon[index], b = polygon[(index + 1) % polygon.length], edge = difference2(b, a), length2 = edge[0] ** 2 + edge[1] ** 2;
      if (!length2) continue;
      const cuts = new Set([0, 1]);
      for (let other = 0; other < polygons.length; other++) if (other !== pi) for (let j = 0; j < polygons[other].length; j++) {
        const c = polygons[other][j], d = polygons[other][(j + 1) % polygons[other].length], delta = difference2(d, c), offset = difference2(c, a), denominator = area2(edge, delta);
        if (Math.abs(denominator) > 1e-20) { const t = area2(offset, delta) / denominator, u = area2(offset, edge) / denominator; if (t > 0 && t < 1 && u >= 0 && u <= 1) cuts.add(t); }
        else if (Math.abs(area2(edge, offset)) < 1e-10) for (const point of [c, d]) { const t = ((point[0] - a[0]) * edge[0] + (point[1] - a[1]) * edge[1]) / length2; if (t > 0 && t < 1) cuts.add(t); }
      }
      const sorted = [...cuts].sort((a, b) => a - b), outward: FlatPoint = [orientation * edge[1], -orientation * edge[0]];
      for (let cut = 1; cut < sorted.length; cut++) {
        const low = sorted[cut - 1], high = sorted[cut], middle: FlatPoint = [a[0] + (low + high) / 2 * edge[0], a[1] + (low + high) / 2 * edge[1]];
        if (polygons.some((other, oi) => oi !== pi && coversExterior(middle, outward, other))) continue;
        const t = clamp(((x - a[0]) * edge[0] + (z - a[1]) * edge[1]) / length2, low, high), distance2 = (a[0] + t * edge[0] - x) ** 2 + (a[1] + t * edge[1] - z) ** 2;
        closest2 = Math.min(closest2, distance2);
      }
    }
  }
  return { covered: centerContained && closest2 >= radius * radius, centerContained, exposedBoundaryDistance: Math.sqrt(closest2), projectedSolidCount: solids.length };
}

export function streetFootCoverage(world: WorldDefinition, x: number, z: number, feetY: number, radius = STREET_BODY_RADIUS): StreetFootCoverage {
  return streetFootCoverageFromSolids(getNearbyStreetSolids(world, { x, y: feetY - STREET_MAXIMUM_STEP, z }, { x, y: feetY, z }, radius), x, z, feetY, radius);
}

/** Only a real reachable road/station face provides support. Rail/guard/roof solids never attract the body from below. */
export function findStreetSupport(world: WorldDefinition, x: number, z: number, referenceHeight: number, radius = STREET_BODY_RADIUS, maximumStep = STREET_MAXIMUM_STEP): StreetSupport | null {
  let best: StreetSupport | null = null;
  const from = { x, y: referenceHeight - 2.6, z }, to = { x, y: referenceHeight + maximumStep, z };
  for (const solid of getNearbyStreetSolids(world, from, to, radius)) {
    if (!solid.walkable) continue;
    const top = streetSolidCapsuleSupport(solid, x, z, radius);
    if (!top || top.y > referenceHeight + maximumStep || top.y < referenceHeight - 2.6) continue;
    if (!best || top.y > best.y) best = { ...top, solid, maximumStep };
  }
  if (best) best.y += 8 * Number.EPSILON * Math.max(1, Math.abs(best.y));
  return best;
}

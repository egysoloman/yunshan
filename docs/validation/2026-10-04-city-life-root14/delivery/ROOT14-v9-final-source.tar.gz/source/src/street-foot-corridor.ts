/** v9 complete circular-foot projection proof over actual upward Float32 faces.
 * Rational clipping/predicates preserve every nonzero physical gap. Projection
 * beneath a raised foot is explicitly distinct from grounded contact. */
import type { Vec3 } from './types';
import type { StreetSolid } from './street-solid-authority';
import { addExact, approximateExact, clipExactFaceHeight, compareExact, exactCircularSweepMargin, exactNumber, exactUnionBoundaryDistanceSquared, exactUpwardFaces, multiplyExact, rational, subtractExact, type ExactFlatPoint, type ExactPoint } from './exact-planar-union';
export const STREET_FOOT_CORRIDOR_VERSION = 'yunshan-rational-fixed-face-foot-corridor-v9-2';
export interface StreetFootCorridorCertificate { version: typeof STREET_FOOT_CORRIDOR_VERSION; from: Vec3; to: Vec3; bodyRadius: number; maximumSupportDistance: number; minimumBoundaryDistance: number; horizontalLength: number; subdivisions: number; fixedFaceDomains: { from: Vec3; to: Vec3; lower: number; upper: number; faceCount: number }[]; provesGroundedContact: false }
export function certifyStreetFootProjection(solids: readonly StreetSolid[], from: Vec3, to: Vec3, radius = .35, maximumSupportDistance = .4): StreetFootCorridorCertificate | null {
  if (![from.x, from.y, from.z, to.x, to.y, to.z, radius, maximumSupportDistance].every(Number.isFinite) || radius <= 0 || maximumSupportDistance < 0) return null;
  const faces = solids.filter(solid => solid.walkable).flatMap(solid => exactUpwardFaces(solid.descriptor.matrixFloat32)), domains: StreetFootCorridorCertificate['fixedFaceDomains'] = [], r = exactNumber(radius), reach = exactNumber(maximumSupportDistance), half = rational(1n, 2n);
  const point = (value: Vec3): ExactPoint => [exactNumber(value.x), exactNumber(value.y), exactNumber(value.z)];
  const label = (value: ExactPoint): Vec3 => ({ x: approximateExact(value[0]), y: approximateExact(value[1]), z: approximateExact(value[2]) });
  let minimumBoundaryDistance = Infinity, subdivisions = 0;
  const prove = (a: ExactPoint, b: ExactPoint, depth: number): boolean => {
    const lower = subtractExact(compareExact(a[1], b[1]) >= 0 ? a[1] : b[1], reach), upper = addExact(compareExact(a[1], b[1]) <= 0 ? a[1] : b[1], r);
    const polygons = faces.map(face => clipExactFaceHeight(clipExactFaceHeight(face, lower, true), upper, false)).filter(face => face.length >= 3).map(face => face.map(point => [point[0], point[2]] as ExactFlatPoint));
    const first = exactUnionBoundaryDistanceSquared(polygons, [a[0], a[2]]), last = exactUnionBoundaryDistanceSquared(polygons, [b[0], b[2]]), dx = subtractExact(a[0], b[0]), dz = subtractExact(a[2], b[2]), run2 = addExact(multiplyExact(dx, dx), multiplyExact(dz, dz));
    if (exactCircularSweepMargin(first, r, run2) && exactCircularSweepMargin(last, r, run2)) {
      // Approximate numbers below are report labels. Acceptance above performs
      // no floating sqrt, area tolerance or rounded distance comparison.
      minimumBoundaryDistance = Math.min(minimumBoundaryDistance, Math.min(Math.sqrt(approximateExact(first!)), Math.sqrt(approximateExact(last!))) - Math.sqrt(approximateExact(run2)) / 2);
      domains.push({ from: label(a), to: label(b), lower: approximateExact(lower), upper: approximateExact(upper), faceCount: polygons.length }); return true;
    }
    if (depth >= 16 || [0, 1, 2].every(axis => compareExact(a[axis], b[axis]) === 0)) return false;
    subdivisions++; const middle = [0, 1, 2].map(axis => multiplyExact(addExact(a[axis], b[axis]), half)) as unknown as ExactPoint;
    return prove(a, middle, depth + 1) && prove(middle, b, depth + 1);
  };
  if (!prove(point(from), point(to), 0)) return null;
  return { version: STREET_FOOT_CORRIDOR_VERSION, from: { ...from }, to: { ...to }, bodyRadius: radius, maximumSupportDistance, minimumBoundaryDistance, horizontalLength: Math.hypot(from.x - to.x, from.z - to.z), subdivisions, fixedFaceDomains: domains, provesGroundedContact: false };
}

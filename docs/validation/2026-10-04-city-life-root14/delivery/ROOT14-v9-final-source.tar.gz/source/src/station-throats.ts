/** New v9 engineering. Old recipes are never reinterpreted by this module. */
import type { NetworkEdge, Vec3, WorldDefinition } from './types';
import { invalidateTransportGeometry } from './transport-geometry';

export const STATION_THROAT_VERSION = 'yunshan-station-throat-platform-v9-1';
export const STATION_RAIL_MAXIMUM_GRADE = .20;
export const STATION_RAIL_FLAT_LENGTH = 10;
export const STATION_PLATFORM_FLOOR_LIFT = .35;
export const STATION_PLATFORM_DOOR_HALF_WIDTH = 1;
export const STATION_PLATFORM_INNER_OFFSET = 1.8;
export const STATION_PLATFORM_OUTER_OFFSET = 4.8;
export const STATION_PLATFORM_RAMP_OUTER_OFFSET = 8.8;
export const STATION_PLATFORM_GATE_HALF_LENGTH = 1.2;
export interface StationProfileChange { edgeId: string; atStart: boolean; flatLength: number; recoveryOriginalVertex: number; recoveryRun: number; grade: number; before: Vec3[]; after: Vec3[] }
export interface StationPlatformParcel { id: string; nodeId: string; edgeId: string; mode: 'maglev' | 'lightRail'; center: Vec3; forward: Vec3; across: Vec3; floorY: number; landingY: number; innerOffset: number; outerOffset: number; rampOuterOffset: number; doorHalfWidth: number; gateHalfLength: number; flatLength: number }
export interface StationEngineering { version: typeof STATION_THROAT_VERSION; maximumRailGrade: number; flatLength: number; changes: StationProfileChange[]; platforms: StationPlatformParcel[] }
export type StationWorld = WorldDefinition & { layoutVersion?: string; stationEngineering?: StationEngineering };
const copy = (point: Vec3): Vec3 => ({ ...point });
const cumulative = (points: readonly Vec3[]) => { const runs = [0]; for (let i = 1; i < points.length; i++) runs.push(runs[i - 1] + Math.hypot(points[i].x - points[i - 1].x, points[i].z - points[i - 1].z)); return runs; };
const grade = (a: Vec3, b: Vec3) => Math.abs(b.y - a.y) / Math.hypot(b.x - a.x, b.z - a.z);

function fromEndpoint(original: readonly Vec3[], edgeId: string, atStart: boolean): StationProfileChange {
  const points = atStart ? original.map(copy) : original.slice().reverse().map(copy), runs = cumulative(points), start = points[0];
  let recovery = -1;
  for (let i = 1; i < points.length - 1; i++) {
    const rampRun = runs[i] - STATION_RAIL_FLAT_LENGTH;
    if (rampRun > 0 && Math.abs(points[i].y - start.y) / rampRun <= STATION_RAIL_MAXIMUM_GRADE) { recovery = i; break; }
  }
  if (recovery < 0) throw new Error(`v9 station engineering FAIL: ${edgeId} ${atStart ? 'from' : 'to'} has no endpoint-preserving <=${STATION_RAIL_MAXIMUM_GRADE} recovery after ${STATION_RAIL_FLAT_LENGTH}m flat throat`);
  const endpoint = points[recovery], rampRun = runs[recovery] - STATION_RAIL_FLAT_LENGTH;
  const after: Vec3[] = [];
  for (let i = 0; i < points.length; i++) {
    if (i && runs[i - 1] < STATION_RAIL_FLAT_LENGTH && runs[i] > STATION_RAIL_FLAT_LENGTH) {
      const a = points[i - 1], b = points[i], t = (STATION_RAIL_FLAT_LENGTH - runs[i - 1]) / (runs[i] - runs[i - 1]);
      after.push({ x: a.x + (b.x - a.x) * t, y: start.y, z: a.z + (b.z - a.z) * t });
    }
    after.push(i === recovery ? copy(points[i]) : i < recovery ? { ...points[i], y: start.y + (endpoint.y - start.y) * Math.max(0, runs[i] - STATION_RAIL_FLAT_LENGTH) / rampRun } : copy(points[i]));
  }
  const recoveryPoint = after.findIndex(point => point.x === endpoint.x && point.z === endpoint.z && point.y === endpoint.y);
  if (recoveryPoint < 0) throw new Error(`v9 station engineering FAIL: ${edgeId} recovery vertex lost`);
  for (let i = 1; i <= recoveryPoint; i++) if (grade(after[i - 1], after[i]) > STATION_RAIL_MAXIMUM_GRADE + 1e-12) throw new Error(`v9 station engineering FAIL: ${edgeId} changed segment exceeds actual grade rule`);
  return { edgeId, atStart, flatLength: STATION_RAIL_FLAT_LENGTH, recoveryOriginalVertex: atStart ? recovery : original.length - 1 - recovery, recoveryRun: rampRun, grade: Math.abs(endpoint.y - start.y) / rampRun, before: original.map(copy), after: atStart ? after : after.reverse() };
}

/** Proposals are computed before applying any edit. Endpoint identities and all
 * original XZ samples remain. New splits express the real grade boundary. */
export function applyStationThroats(world: StationWorld): StationEngineering {
  const changes: StationProfileChange[] = [], proposed = new Map<NetworkEdge, Vec3[]>();
  for (const edge of world.edges) {
    if (edge.mode !== 'maglev' && edge.mode !== 'lightRail') continue;
    const first = fromEndpoint(edge.points, edge.id, true), last = fromEndpoint(first.after, edge.id, false);
    // The second endpoint must not silently rewrite the first certified throat.
    const oldRuns = cumulative(first.after), newRuns = cumulative(last.after), total = newRuns[newRuns.length - 1];
    for (let i = 0; i < last.after.length; i++) if (newRuns[i] <= STATION_RAIL_FLAT_LENGTH && last.after[i].y !== last.after[0].y) throw new Error(`v9 station engineering FAIL: ${edge.id} endpoint throat proposals overlap`);
    if (Math.abs(oldRuns[oldRuns.length - 1] - total) > 8 * Number.EPSILON * Math.max(1, total)) throw new Error(`v9 station engineering FAIL: ${edge.id} changed XZ arc beyond split-sum arithmetic roundoff`);
    changes.push(first, last); proposed.set(edge, last.after);
  }
  for (const [edge, points] of proposed) { edge.points = points; edge.length = points.slice(1).reduce((sum, b, i) => sum + Math.hypot(b.x - points[i].x, b.y - points[i].y, b.z - points[i].z), 0); }
  const platforms: StationPlatformParcel[] = [];
  for (const edge of proposed.keys()) for (const atStart of [true, false]) {
    const index = atStart ? 0 : edge.points.length - 1, next = atStart ? 1 : edge.points.length - 2, center = edge.points[index], other = edge.points[next], dx = other.x - center.x, dz = other.z - center.z, run = Math.hypot(dx, dz);
    if (!run) throw new Error(`v9 station engineering FAIL: ${edge.id} zero-length berth tangent`);
    const forward = { x: dx / run, y: 0, z: dz / run }, across = { x: forward.z, y: 0, z: -forward.x }, nodeId = atStart ? edge.from : edge.to;
    platforms.push({ id: `platform-${edge.id}-${nodeId}`, nodeId, edgeId: edge.id, mode: edge.mode as 'maglev' | 'lightRail', center: copy(center), forward, across, floorY: center.y + STATION_PLATFORM_FLOOR_LIFT, landingY: center.y, innerOffset: STATION_PLATFORM_INNER_OFFSET, outerOffset: STATION_PLATFORM_OUTER_OFFSET, rampOuterOffset: STATION_PLATFORM_RAMP_OUTER_OFFSET, doorHalfWidth: STATION_PLATFORM_DOOR_HALF_WIDTH, gateHalfLength: STATION_PLATFORM_GATE_HALF_LENGTH, flatLength: STATION_RAIL_FLAT_LENGTH });
  }
  const engineering: StationEngineering = { version: STATION_THROAT_VERSION, maximumRailGrade: STATION_RAIL_MAXIMUM_GRADE, flatLength: STATION_RAIL_FLAT_LENGTH, changes, platforms };
  world.stationEngineering = engineering; invalidateTransportGeometry(world); return engineering;
}

export function stationPlatform(world: WorldDefinition, edgeId: string, nodeId: string): StationPlatformParcel | null {
  return (world as StationWorld).stationEngineering?.platforms.find(parcel => parcel.edgeId === edgeId && parcel.nodeId === nodeId) ?? null;
}

/** Full physical guard segments outside the engineered, floor-backed boarding
 * portal remain. The portal is a World parcel bound into the v9 fingerprint. */
export function stationRailGuardSpans(world: WorldDefinition, edge: NetworkEdge, segmentIndex: number): { a: Vec3; b: Vec3 }[] {
  const a = edge.points[segmentIndex - 1], b = edge.points[segmentIndex]; if (!a || !b) return [];
  const runs = cumulative(edge.points), total = runs[runs.length - 1], start = runs[segmentIndex - 1], end = runs[segmentIndex], portals = [stationPlatform(world, edge.id, edge.from), stationPlatform(world, edge.id, edge.to)];
  let intervals = [{ low: start, high: end }];
  if (portals[0]) intervals = intervals.flatMap(span => span.high <= STATION_PLATFORM_GATE_HALF_LENGTH ? [] : [{ low: Math.max(span.low, STATION_PLATFORM_GATE_HALF_LENGTH), high: span.high }]);
  if (portals[1]) intervals = intervals.flatMap(span => span.low >= total - STATION_PLATFORM_GATE_HALF_LENGTH ? [] : [{ low: span.low, high: Math.min(span.high, total - STATION_PLATFORM_GATE_HALF_LENGTH) }]);
  const point = (along: number): Vec3 => { const t = (along - start) / (end - start); return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t, z: a.z + (b.z - a.z) * t }; };
  return intervals.filter(span => span.high > span.low).map(span => ({ a: point(span.low), b: point(span.high) }));
}

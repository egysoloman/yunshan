/** Exact rational predicates for finite Float32 boxes. No area or distance
 * tolerance expands a support domain. IEEE inputs are their exact dyadics. */
export interface Rational { numerator: bigint; denominator: bigint }
export type ExactPoint = readonly [Rational, Rational, Rational];
export type ExactFlatPoint = readonly [Rational, Rational];
const gcd = (a: bigint, b: bigint): bigint => { a = a < 0n ? -a : a; b = b < 0n ? -b : b; while (b) { const remainder = a % b; a = b; b = remainder; } return a; };
export const ZERO: Rational = { numerator: 0n, denominator: 1n }, ONE: Rational = { numerator: 1n, denominator: 1n };
export function rational(numerator: bigint, denominator = 1n): Rational {
  if (!denominator) throw new Error('Exact geometry has a zero denominator');
  if (denominator < 0n) { numerator = -numerator; denominator = -denominator; }
  if (!numerator) return ZERO;
  const factor = gcd(numerator, denominator); return { numerator: numerator / factor, denominator: denominator / factor };
}
const binary = new DataView(new ArrayBuffer(8));
export function exactNumber(value: number): Rational {
  if (!Number.isFinite(value)) throw new Error('Exact geometry requires finite numbers');
  if (value === 0) return ZERO;
  binary.setFloat64(0, value, false); const bits = binary.getBigUint64(0, false), exponent = Number(bits >> 52n & 2047n), fraction = bits & ((1n << 52n) - 1n);
  let numerator = exponent ? fraction | (1n << 52n) : fraction; if (bits >> 63n) numerator = -numerator;
  const power = exponent ? exponent - 1023 - 52 : -1074;
  return power >= 0 ? rational(numerator << BigInt(power)) : rational(numerator, 1n << BigInt(-power));
}
export const addExact = (a: Rational, b: Rational) => rational(a.numerator * b.denominator + b.numerator * a.denominator, a.denominator * b.denominator);
export const subtractExact = (a: Rational, b: Rational) => rational(a.numerator * b.denominator - b.numerator * a.denominator, a.denominator * b.denominator);
export const multiplyExact = (a: Rational, b: Rational) => rational(a.numerator * b.numerator, a.denominator * b.denominator);
export const divideExact = (a: Rational, b: Rational) => rational(a.numerator * b.denominator, a.denominator * b.numerator);
export const compareExact = (a: Rational, b: Rational) => { const difference = a.numerator * b.denominator - b.numerator * a.denominator; return difference < 0n ? -1 : difference > 0n ? 1 : 0; };
/** Report labels only; geometric acceptance does not consume this rounding. */
export function approximateExact(a: Rational): number {
  if (a.numerator === 0n) return 0;
  const n = a.numerator < 0n ? -a.numerator : a.numerator, nb = n.toString(2).length, db = a.denominator.toString(2).length, ns = Math.max(0, nb - 54), ds = Math.max(0, db - 54);
  return (a.numerator < 0n ? -1 : 1) * Number(n >> BigInt(ns)) / Number(a.denominator >> BigInt(ds)) * 2 ** (ns - ds);
}
const square = (a: Rational) => multiplyExact(a, a);
const neg = (a: Rational) => ({ numerator: -a.numerator, denominator: a.denominator });
const difference = (a: ExactFlatPoint, b: ExactFlatPoint): ExactFlatPoint => [subtractExact(a[0], b[0]), subtractExact(a[1], b[1])];
const area = (a: ExactFlatPoint, b: ExactFlatPoint) => subtractExact(multiplyExact(a[0], b[1]), multiplyExact(a[1], b[0]));
const dot2 = (a: ExactFlatPoint, b: ExactFlatPoint) => addExact(multiplyExact(a[0], b[0]), multiplyExact(a[1], b[1]));
const lerp = (a: Rational, b: Rational, t: Rational) => addExact(a, multiplyExact(subtractExact(b, a), t));
const half = rational(1n, 2n), minusHalf = rational(-1n, 2n);
const orientation = (polygon: readonly ExactFlatPoint[]) => compareExact(polygon.reduce((sum, point, index) => addExact(sum, area(point, polygon[(index + 1) % polygon.length])), ZERO), ZERO);

export function exactUpwardFaces(matrix: readonly number[]): ExactPoint[][] {
  if (matrix.length !== 16) throw new Error('Exact geometry requires a16-element transform');
  const m = matrix.map(exactNumber), transform = (p: ExactPoint): ExactPoint => [0, 1, 2].map(axis => addExact(addExact(addExact(multiplyExact(m[axis], p[0]), multiplyExact(m[axis + 4], p[1])), multiplyExact(m[axis + 8], p[2])), m[axis + 12])) as unknown as ExactPoint;
  const subtract = (a: ExactPoint, b: ExactPoint): ExactPoint => [0, 1, 2].map(axis => subtractExact(a[axis], b[axis])) as unknown as ExactPoint;
  const cross = (a: ExactPoint, b: ExactPoint): ExactPoint => [subtractExact(multiplyExact(a[1], b[2]), multiplyExact(a[2], b[1])), subtractExact(multiplyExact(a[2], b[0]), multiplyExact(a[0], b[2])), subtractExact(multiplyExact(a[0], b[1]), multiplyExact(a[1], b[0]))];
  const dot = (a: ExactPoint, b: ExactPoint) => addExact(addExact(multiplyExact(a[0], b[0]), multiplyExact(a[1], b[1])), multiplyExact(a[2], b[2]));
  const center = transform([ZERO, ZERO, ZERO]), faces: ExactPoint[][] = [];
  for (let fixed = 0; fixed < 3; fixed++) for (const side of [minusHalf, half]) {
    const axes = [0, 1, 2].filter(axis => axis !== fixed);
    const face = [[minusHalf, minusHalf], [half, minusHalf], [half, half], [minusHalf, half]].map(([a, b]) => { const local: [Rational, Rational, Rational] = [ZERO, ZERO, ZERO]; local[fixed] = side; local[axes[0]] = a; local[axes[1]] = b; return transform(local); });
    const normal = cross(subtract(face[1], face[0]), subtract(face[2], face[0])), outward = compareExact(dot(normal, subtract(face[0], center)), ZERO);
    if (compareExact(normal[1], ZERO) * outward > 0) faces.push(face);
  }
  return faces;
}
export function clipExactFaceHeight(face: readonly ExactPoint[], height: Rational, lower: boolean): ExactPoint[] {
  const result: ExactPoint[] = [], inside = (point: ExactPoint) => lower ? compareExact(point[1], height) >= 0 : compareExact(point[1], height) <= 0;
  for (let i = 0; i < face.length; i++) {
    const a = face[i], b = face[(i + 1) % face.length], ai = inside(a), bi = inside(b);
    if (ai) result.push(a);
    if (ai !== bi) { const t = divideExact(subtractExact(height, a[1]), subtractExact(b[1], a[1])); result.push([lerp(a[0], b[0], t), height, lerp(a[2], b[2], t)]); }
  }
  return result;
}
function contains(point: ExactFlatPoint, polygon: readonly ExactFlatPoint[], outward?: ExactFlatPoint): boolean {
  const sign = orientation(polygon); if (!sign) return false;
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], edge = difference(polygon[(i + 1) % polygon.length], a), value = compareExact(area(edge, difference(point, a)), ZERO) * sign;
    if (value < 0 || value === 0 && outward && compareExact(area(edge, outward), ZERO) * sign < 0) return false;
  }
  return true;
}
/** Squared distance to the union's actual exposed boundary, including every
 * arbitrarily small hole. Intersections, collinearity and distances are exact. */
export function exactUnionBoundaryDistanceSquared(polygons: readonly ExactFlatPoint[][], center: ExactFlatPoint): Rational | null {
  const nondegenerate = polygons.filter(polygon => orientation(polygon) !== 0);
  if (!nondegenerate.some(polygon => contains(center, polygon))) return null;
  let closest: Rational | null = null;
  for (let pi = 0; pi < nondegenerate.length; pi++) {
    const polygon = nondegenerate[pi], sign = orientation(polygon);
    for (let i = 0; i < polygon.length; i++) {
      const a = polygon[i], edge = difference(polygon[(i + 1) % polygon.length], a), length2 = dot2(edge, edge); if (length2.numerator === 0n) continue;
      const cuts = new Map<string, Rational>(), cut = (t: Rational) => { cuts.set(`${t.numerator}/${t.denominator}`, t); }; cut(ZERO); cut(ONE);
      for (let oi = 0; oi < nondegenerate.length; oi++) if (oi !== pi) for (let j = 0; j < nondegenerate[oi].length; j++) {
        const c = nondegenerate[oi][j], delta = difference(nondegenerate[oi][(j + 1) % nondegenerate[oi].length], c), offset = difference(c, a), denominator = area(edge, delta);
        if (denominator.numerator !== 0n) { const t = divideExact(area(offset, delta), denominator), u = divideExact(area(offset, edge), denominator); if (compareExact(t, ZERO) > 0 && compareExact(t, ONE) < 0 && compareExact(u, ZERO) >= 0 && compareExact(u, ONE) <= 0) cut(t); }
        else if (area(edge, offset).numerator === 0n) for (const point of [c, nondegenerate[oi][(j + 1) % nondegenerate[oi].length]]) { const t = divideExact(dot2(difference(point, a), edge), length2); if (compareExact(t, ZERO) > 0 && compareExact(t, ONE) < 0) cut(t); }
      }
      const values = [...cuts.values()].sort(compareExact), outward: ExactFlatPoint = sign > 0 ? [edge[1], neg(edge[0])] : [neg(edge[1]), edge[0]];
      for (let j = 1; j < values.length; j++) {
        const low = values[j - 1], high = values[j], middleParameter = multiplyExact(addExact(low, high), half), middle: ExactFlatPoint = [lerp(a[0], addExact(a[0], edge[0]), middleParameter), lerp(a[1], addExact(a[1], edge[1]), middleParameter)];
        if (nondegenerate.some((other, oi) => oi !== pi && contains(middle, other, outward))) continue;
        let t = divideExact(dot2(difference(center, a), edge), length2); if (compareExact(t, low) < 0) t = low; if (compareExact(t, high) > 0) t = high;
        const delta: ExactFlatPoint = [subtractExact(addExact(a[0], multiplyExact(t, edge[0])), center[0]), subtractExact(addExact(a[1], multiplyExact(t, edge[1])), center[1])], squared = dot2(delta, delta);
        if (closest === null || compareExact(squared, closest) < 0) closest = squared;
      }
    }
  }
  return closest;
}
/** d >= radius + run/2 without a rounded sqrt or comparison tolerance. */
export function exactCircularSweepMargin(distanceSquared: Rational | null, radius: Rational, runSquared: Rational): boolean {
  if (distanceSquared === null) return false;
  const excess = subtractExact(subtractExact(distanceSquared, square(radius)), multiplyExact(runSquared, rational(1n, 4n)));
  return compareExact(excess, ZERO) >= 0 && compareExact(square(excess), multiplyExact(square(radius), runSquared)) >= 0;
}

import { invalidateStreetSolids } from './street-solid-authority';
import { invalidateTransportGeometry } from './transport-geometry';
import { MARKET_STATION_APRON_OFFSETS, MARKET_STATION_APRON_MAX_GRADE } from './market-station-apron';
import type { NetworkEdge, Vec3, WorldDefinition } from './types';

export const MARKET_STATION_APPROACH_VERSION = 'yunshan-market-station-connected-approach-v8-1';
export const MARKET_STATION_BIRTH_LANDING_RADIUS = .6;
export const MARKET_STATION_LANDING_PAVING_CENTER_LIFT = .04;
export const MARKET_STATION_LANDING_PAVING_THICKNESS = .04;
function pavingLandingGrade(feetY: number): number {
  const target = feetY - Math.fround(MARKET_STATION_LANDING_PAVING_THICKNESS) / 2;
  const buffer = new Float32Array([target]), bits = new Uint32Array(buffer.buffer);
  // The real paving center is constructed outward below the retained feet.
  // One Float32 cell bounds placement roundoff; body assertions stay strict.
  if (buffer[0] >= target) bits[0] += buffer[0] >= 0 ? -1 : 1;
  return buffer[0] - MARKET_STATION_LANDING_PAVING_CENTER_LIFT;
}
const distance = (a: Vec3, b: Vec3) => Math.hypot(a.x - b.x, a.z - b.z);
export interface MarketApproachField {
  x0: number; x1: number; z0: number; apronSouth: number; landingNorth: number; landingSouth: number;
  stationY: number; landingY: number;
}
export function marketApproachField(world: WorldDefinition): MarketApproachField {
  const station = world.nodes.find(node => node.id === 'market-station');
  if (!station) throw new Error('The connected approach requires market-station');
  const field = { x0: station.position.x + MARKET_STATION_APRON_OFFSETS.x0, x1: station.position.x + MARKET_STATION_APRON_OFFSETS.x1, z0: station.position.z + MARKET_STATION_APRON_OFFSETS.z0, apronSouth: station.position.z + MARKET_STATION_APRON_OFFSETS.z1, landingNorth: world.spawn.z - MARKET_STATION_BIRTH_LANDING_RADIUS, landingSouth: world.spawn.z + MARKET_STATION_BIRTH_LANDING_RADIUS, stationY: station.position.y, landingY: pavingLandingGrade(world.spawn.y) };
  if (field.landingNorth <= field.apronSouth || world.spawn.x < field.x0 || world.spawn.x > field.x1) throw new Error('The birth landing must have a real connected south approach');
  if (Math.abs(field.stationY - field.landingY) / (field.landingNorth - field.apronSouth) > MARKET_STATION_APRON_MAX_GRADE) throw new Error('The connected approach cannot retain its birth height at the allowed grade');
  return field;
}
export function marketApproachHeight(field: MarketApproachField, z: number): number {
  if (z <= field.apronSouth) return field.stationY;
  if (z >= field.landingNorth) return field.landingY;
  return field.stationY + (field.landingY - field.stationY) * (z - field.apronSouth) / (field.landingNorth - field.apronSouth);
}
export function marketApproachGradient(field: MarketApproachField, x: number, z: number): number | null {
  if (x < field.x0 || x > field.x1 || z < field.z0 || z > field.landingSouth) return null;
  return z > field.apronSouth && z < field.landingNorth ? (field.landingY - field.stationY) / (field.landingNorth - field.apronSouth) : 0;
}
export interface MarketApproachChange { edgeId: string; oldPoints: Vec3[]; newPoints: Vec3[]; oldLength: number; newLength: number; boundary: Vec3; restoredOriginalVertex: Vec3; maximumChangedGrade: number }
function proposal(edge: NetworkEdge, field: MarketApproachField): MarketApproachChange {
  const fromStation = edge.from === 'market-station', original = (fromStation ? edge.points : [...edge.points].reverse()).map(point => ({ ...point }));
  const inside = (point: Vec3) => point.x >= field.x0 && point.x <= field.x1 && point.z >= field.z0 && point.z <= field.landingSouth;
  const points: Vec3[] = [];
  for (let index = 0; index < original.length; index++) {
    const a = original[index]; if (index === 0) { points.push({ ...a }); continue; }
    const previous = original[index - 1], fractions = new Set<number>();
    const dx = a.x - previous.x, dz = a.z - previous.z;
    if (dx) for (const x of [field.x0, field.x1]) { const t = (x - previous.x) / dx; if (t > 0 && t < 1) fractions.add(t); }
    if (dz) for (const z of [field.z0, field.apronSouth, field.landingNorth, field.landingSouth]) { const t = (z - previous.z) / dz; if (t > 0 && t < 1) fractions.add(t); }
    for (const t of [...fractions].sort((a, b) => a - b)) { const point = { x: previous.x + dx * t, y: previous.y + (a.y - previous.y) * t, z: previous.z + dz * t }; if (inside(point)) points.push(point); }
    points.push({ ...a });
  }
  const firstOutside = points.findIndex(point => !inside(point));
  if (firstOutside <= 0 || points.slice(firstOutside).some(inside)) throw new Error(`Approach route must enter once with a preserved outside endpoint: ${edge.id}`);
  const boundaryIndex = firstOutside - 1;
  for (let index = 0; index <= boundaryIndex; index++) points[index].y = marketApproachHeight(field, points[index].z);
  const cumulative = [0]; for (let index = 1; index < points.length; index++) cumulative.push(cumulative[index - 1] + distance(points[index - 1], points[index]));
  const originalVertex = (point: Vec3) => original.some(vertex => vertex.x === point.x && vertex.z === point.z);
  let result: Vec3[] | null = null, maximumChangedGrade = Infinity, anchorIndex = -1;
  for (let anchor = boundaryIndex + 1; anchor < points.length; anchor++) {
    if (!originalVertex(points[anchor])) continue;
    const span = cumulative[anchor] - cumulative[boundaryIndex]; if (!span) continue;
    const candidate = points.map(point => ({ ...point }));
    for (let index = boundaryIndex + 1; index < anchor; index++) candidate[index].y = points[boundaryIndex].y + (points[anchor].y - points[boundaryIndex].y) * (cumulative[index] - cumulative[boundaryIndex]) / span;
    let grade = 0;
    for (let index = 1; index <= anchor; index++) { const run = distance(candidate[index - 1], candidate[index]), rise = Math.abs(candidate[index].y - candidate[index - 1].y); grade = Math.max(grade, run ? rise / run : rise ? Infinity : 0); }
    if (grade <= MARKET_STATION_APRON_MAX_GRADE + 1e-12) { result = candidate; maximumChangedGrade = grade; anchorIndex = anchor; break; }
  }
  if (!result) throw new Error(`Approach cannot recover its real endpoint at grade <= .20: ${edge.id}`);
  const ordered = fromStation ? result : [...result].reverse();
  for (const index of [0, ordered.length - 1]) { const old = edge.points[index === 0 ? 0 : edge.points.length - 1]; if (ordered[index].x !== old.x || ordered[index].y !== old.y || ordered[index].z !== old.z) throw new Error(`Approach changed a network endpoint: ${edge.id}`); }
  return { edgeId: edge.id, oldPoints: edge.points.map(point => ({ ...point })), newPoints: ordered, oldLength: edge.length, newLength: ordered.slice(1).reduce((sum, point, index) => sum + Math.hypot(point.x - ordered[index].x, point.y - ordered[index].y, point.z - ordered[index].z), 0), boundary: { ...result[boundaryIndex] }, restoredOriginalVertex: { ...result[anchorIndex] }, maximumChangedGrade };
}
/** New v8 recipe. v7 archived points remain an independently reproducible map. */
export function applyMarketStationApproach(world: WorldDefinition): MarketApproachChange[] {
  const field = marketApproachField(world), proposals = world.edges.filter(edge => ['road', 'bridge'].includes(edge.mode) && (edge.from === 'market-station' || edge.to === 'market-station')).map(edge => proposal(edge, field));
  for (const change of proposals) { const edge = world.edges.find(edge => edge.id === change.edgeId)!; edge.points = change.newPoints; edge.length = change.newLength; }
  invalidateTransportGeometry(world); invalidateStreetSolids(world); return proposals;
}

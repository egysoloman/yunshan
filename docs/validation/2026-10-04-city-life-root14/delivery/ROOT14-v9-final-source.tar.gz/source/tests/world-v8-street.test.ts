import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { createWorld, CURRENT_CITY_LAYOUT, getWalkHeight, terrainHeight } from '../src/world';
import { applyMarketStationApproach, marketApproachField, marketApproachHeight } from '../src/market-station-approach';
import { getStreetSolidDescriptors, streetCapsuleSeparation, streetSolidFromDescriptor } from '../src/street-solid-authority';
let before: ReturnType<typeof createWorld> | undefined, after: ReturnType<typeof createWorld> | undefined;
const v7 = () => before ??= createWorld(20261001, 'current-v7');
const v8 = () => after ??= createWorld(20261001, 'current-v8');
test('v8 preserves the archived v7 factory, all endpoints/sites/rails/birth and keeps product-compatible noarg v6', () => {
  const archivedBytes = fs.readFileSync(new URL('./fixtures/street-authority/archived-world-v7.json', import.meta.url));
  assert.equal(createHash('sha256').update(archivedBytes).digest('hex'), '135a9adba5d920ead70f93133d9efd4eac55085fc2d34dc8ca8132506b21cf72');
  const archived = JSON.parse(archivedBytes.toString()), world = v8();
  assert.equal(JSON.stringify(v7()), JSON.stringify(archived));
  assert.equal(CURRENT_CITY_LAYOUT, 'current-v6');
  assert.deepEqual(v7(), archived);
  for (const field of ['nodes', 'buildings', 'spawn'] as const) assert.deepEqual(world[field], archived[field]);
  for (let index = 0; index < world.edges.length; index++) {
    const a = archived.edges[index], b = world.edges[index];
    assert.deepEqual([b.id, b.mode, b.from, b.to, b.capacity], [a.id, a.mode, a.from, a.to, a.capacity]);
    assert.deepEqual(b.points[0], a.points[0]); assert.deepEqual(b.points.at(-1), a.points.at(-1));
    if (!['road', 'bridge'].includes(a.mode)) assert.deepEqual(a, b);
    let cursor = 0;
    for (const old of a.points) { while (cursor < b.points.length && (b.points[cursor].x !== old.x || b.points[cursor].z !== old.z)) cursor++; assert(cursor < b.points.length); cursor++; }
  }
});
test('real connected south approach recovers all original endpoints at <=.20; landing retains exact original birth height', () => {
  const world = structuredClone(v7()), changes = applyMarketStationApproach(world), field = marketApproachField(world);
  assert.equal(changes.length, 17);
  for (const change of changes) assert(change.maximumChangedGrade <= .20 + 1e-12, change.edgeId);
  assert.equal(marketApproachHeight(field, world.spawn.z - .35), field.landingY);
  assert.equal(marketApproachHeight(field, world.spawn.z + .35), field.landingY);
  assert(field.landingY < world.spawn.y && world.spawn.y - field.landingY < .06001);
  assert.equal(marketApproachHeight(field, field.apronSouth), field.stationY);
  const markedV7 = { ...v8(), layoutVersion: 'current-v7' as const };
  for (const [x, z] of [[-330, 487], [-330, 460], [-1500, 1400]]) assert.equal(terrainHeight(v8(), x, z), terrainHeight(markedV7, x, z));
});
test('unchanged birth capsule is clear of engineered road solids; v8 foot support includes actual curbs', () => {
  const world = v8(), solids = getStreetSolidDescriptors(world).filter(part => ['road', 'bridge'].includes(String(part.owner.mode)));
  const contacts = solids.map(part => ({ part, separation: streetCapsuleSeparation(streetSolidFromDescriptor(part), world.spawn, world.spawn) })).filter(item => item.separation < 0);
  assert.deepEqual(contacts.map(item => [item.part.owner, item.part.sourceCall, item.separation]), []);
  const curbY = getWalkHeight(world, -319.9, 469, 52.6);
  assert(curbY > 52.6 && curbY < 53);
});

import assert from 'node:assert/strict';
import fs from 'node:fs';
import test from 'node:test';
import { createHash } from 'node:crypto';
import { createWorld, CURRENT_CITY_LAYOUT, terrainHeight, getWalkHeight } from '../src/world';
import { applyMarketStationApron, MARKET_STATION_APRON_MAX_GRADE } from '../src/market-station-apron';
import { guardrailSpans } from '../src/transport-geometry';

const literalBytes = fs.readFileSync(new URL('./fixtures/street-authority/actual-world-v6.json', import.meta.url));
assert.equal(createHash('sha256').update(literalBytes).digest('hex'), '2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512');
const literal = JSON.parse(literalBytes.toString());
let before: ReturnType<typeof createWorld> | undefined, after: ReturnType<typeof createWorld> | undefined;
const v6 = () => before ??= createWorld(20261001, 'current-v6');
const v7 = () => after ??= createWorld(20261001, 'current-v7');
const expectedIds = ['road-river-station-market-station', 'road-market-station-workshop-station', 'road-market-station-academy-station',
  ...[0,1,2,3].map(index => `road-market-quarter-${index}-market-station`),
  ...[22,24,31,35,37,41,62,66,69].map(index => `road-market-b${index}-door-market-station`), 'bridge-market-dock-market-station'];
const inside = (point: { x: number; z: number }) => point.x >= -340 && point.x <= -304 && point.z >= 448 && point.z <= 472;

test('old current-v6 and the noarg layout retain the literal actual browser World', () => {
  assert.equal(CURRENT_CITY_LAYOUT, 'current-v6');
  assert.equal(JSON.stringify(v6()), JSON.stringify(literal));
  assert.equal(JSON.stringify(createWorld()), JSON.stringify(v6()));
});

test('v7 changes the approved real street surfaces while preserving sites, nodes, spawn, rails, endpoints and original XZ', () => {
  const old = v6(), world = v7();
  assert.equal(world.layoutVersion, 'current-v7');
  assert.deepEqual(world.nodes, old.nodes); assert.deepEqual(world.buildings, old.buildings); assert.deepEqual(world.spawn, old.spawn);
  assert.deepEqual([world.buildings.length,world.nodes.length,world.edges.length],[612,674,691]);
  const actualIds: string[] = [];
  for (let index = 0; index < old.edges.length; index++) {
    const a = old.edges[index], b = world.edges[index];
    assert.deepEqual([b.id,b.from,b.to,b.mode,b.capacity],[a.id,a.from,a.to,a.mode,a.capacity]);
    if (JSON.stringify(a) === JSON.stringify(b)) continue;
    actualIds.push(b.id);
    assert.equal(b.points[0].x,a.points[0].x); assert.deepEqual(b.points[0],a.points[0]); assert.deepEqual(b.points.at(-1),a.points.at(-1));
    let cursor = 0;
    for (const point of a.points) {
      while (cursor < b.points.length && (b.points[cursor].x !== point.x || b.points[cursor].z !== point.z)) cursor++;
      assert(cursor < b.points.length, b.id + ': original horizontal route vertices remain in order'); cursor++;
    }
    assert.equal(b.length,b.points.slice(1).reduce((sum,p,i)=>sum+Math.hypot(p.x-b.points[i].x,p.y-b.points[i].y,p.z-b.points[i].z),0));
  }
  assert.deepEqual(actualIds,expectedIds);
});

test('every real apron vertex shares station grade; recovery slopes remain <= .20 and actual old body footprint is supported above the former bridge contact', () => {
  const planWorld = createWorld(20261001,'current-v6'), changes = applyMarketStationApron(planWorld);
  for (const change of changes) {
    assert(change.maximumChangedGrade <= MARKET_STATION_APRON_MAX_GRADE + 1e-12, change.edgeId + ': arithmetic roundoff only');
    assert.equal(change.boundary.y,52.6);
    for (const point of change.newPoints.filter(inside)) assert.equal(point.y,52.6,change.edgeId + ': actual shared grade');
    assert(change.oldPoints.some(point=>point.x===change.restoredOriginalVertex.x&&point.y===change.restoredOriginalVertex.y&&point.z===change.restoredOriginalVertex.z));
  }
  assert.equal(getWalkHeight(v7(),-315.0281115874095,460.4547898587516,52.10331245069323),52.6);
  assert.equal(getWalkHeight(v7(),v7().spawn.x,v7().spawn.z,v7().spawn.y),v7().spawn.y);
});

test('v7 retains the v6 ground and geological recipe outside street changes and at equal-parameter markers', () => {
  const old = v6(), world = v7(), sameParametersV6Marker = { ...world, layoutVersion:'current-v6' as const };
  for (const [x,z] of [[-1600,-1000],[1000,-800],[1300,600],[-500,-1300],[300,850],[1800,1500],[-1700,1100]]) assert.equal(terrainHeight(world,x,z),terrainHeight(old,x,z));
  for (const [x,z] of [[-330,487],[-330,460],[-312,448],[-320,472],[-370,350],[-430,420],[-560,250]]) assert.equal(terrainHeight(world,x,z),terrainHeight(sameParametersV6Marker,x,z));
});

test('same-count street edits invalidate old guard layouts and impossible grades reject atomically', () => {
  const world = createWorld(20261001,'current-v6');
  const spans = (input: typeof world) => input.edges.filter(edge=>expectedIds.includes(edge.id)).map(edge=>[edge.id,edge.points.slice(1).map((_,index)=>guardrailSpans(input,edge,index+1))]);
  const oldSpans = JSON.stringify(spans(world)); applyMarketStationApron(world);
  const refreshed = JSON.stringify(spans(world)); assert.notEqual(refreshed,oldSpans); assert.equal(refreshed,JSON.stringify(spans(v7())));
  const invalid = createWorld(20261001,'current-v6'), edge = invalid.edges.find(edge=>edge.id==='road-market-b69-door-market-station')!, station=invalid.nodes.find(node=>node.id==='market-station')!;
  edge.points=[{x:-304,y:200,z:474},{x:-304,y:200,z:472},{...station.position}];
  const unchanged=JSON.stringify(invalid);
  assert.throws(()=>applyMarketStationApron(invalid),/cannot preserve its endpoint at grade/);
  assert.equal(JSON.stringify(invalid),unchanged,'one impossible route cannot install a partial city grade');
});

import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import { createWorld, CURRENT_CITY_LAYOUT, terrainHeight } from '../src/world';
import { getNearbyStreetSolids, streetCapsuleSeparation, streetFootCoverage, streetFootCoverageFromSolids } from '../src/street-solid-authority';
import { carrierSlotFeet, carrierStreetSolids } from '../src/carrier-solids';
import type { StationWorld } from '../src/station-throats';
import type { Vehicle } from '../src/types';
const archive = (name: string) => JSON.parse(fs.readFileSync(new URL(`./fixtures/street-authority/${name}`, import.meta.url), 'utf8'));
const old8 = archive('archived-world-v8.json');
let current: ReturnType<typeof createWorld> | undefined;
const v9 = () => current ??= createWorld(20261001, 'current-v9');

test('old v6/v7/v8 complete factory literals remain exact and product default remains v6', () => {
  for (const [layout, file] of [['current-v6', 'actual-world-v6.json'], ['current-v7', 'archived-world-v7.json'], ['current-v8', 'archived-world-v8.json']] as const) assert.equal(JSON.stringify(createWorld(20261001, layout)), JSON.stringify(archive(file)), layout);
  assert.equal(CURRENT_CITY_LAYOUT, 'current-v6');
});

test('actual v9 World retains birth/sites/nodes/endpoints and exposes all18 engineered rail ends as real parcels', () => {
  const world = v9(), engineering = (world as StationWorld).stationEngineering!;
  assert.ok(engineering); assert.equal(engineering.maximumRailGrade, .20); assert.equal(engineering.flatLength, 10);
  assert.equal(engineering.changes.length, 18); assert.equal(engineering.platforms.length, 18);
  for (const field of ['buildings', 'nodes', 'spawn', 'districts', 'mountains', 'waterfall', 'river'] as const) assert.deepEqual(world[field], old8[field], field);
  for (let index = 0; index < world.edges.length; index++) {
    const before = old8.edges[index], after = world.edges[index];
    assert.deepEqual([after.id, after.from, after.to, after.mode, after.capacity], [before.id, before.from, before.to, before.mode, before.capacity]);
    assert.deepEqual(after.points[0], before.points[0]); assert.deepEqual(after.points.at(-1), before.points.at(-1));
    if (!['maglev', 'lightRail'].includes(before.mode)) assert.deepEqual(after, before);
    let cursor = 0;
    for (const original of before.points) { while (cursor < after.points.length && (after.points[cursor].x !== original.x || after.points[cursor].z !== original.z)) cursor++; assert.ok(cursor < after.points.length, `${after.id}: original XZ vertex lost`); cursor++; }
  }
  const archivedGeometry = { ...world, layoutVersion: 'current-v8' as const };
  assert.equal(terrainHeight(world, world.spawn.x, world.spawn.z), terrainHeight(archivedGeometry, world.spawn.x, world.spawn.z));
});

test('every actual changed rail approach recovers an original vertex within the new .20 grade rule', () => {
  const world = v9(), engineering = (world as StationWorld).stationEngineering!;
  for (const change of engineering.changes) {
    assert.ok(change.grade <= .20, `${change.edgeId}/${change.atStart}`);
    assert.deepEqual(change.after[0], change.before[0]); assert.deepEqual(change.after.at(-1), change.before.at(-1));
    assert.ok(change.recoveryRun > 0);
  }
  for (const line of world.edges.filter(line => ['maglev', 'lightRail'].includes(line.mode))) {
    const measured = line.points.slice(1).reduce((sum, b, i) => sum + Math.hypot(b.x - line.points[i].x, b.y - line.points[i].y, b.z - line.points[i].z), 0);
    assert.equal(line.length, measured);
  }
});

test('unchanged actual birth has strict Float32 network capsule clearance and complete circular-foot support', () => {
  const world = v9(), nearby = getNearbyStreetSolids(world, world.spawn, world.spawn), contacts = nearby.map(solid => ({ owner: solid.descriptor.owner, sourceCall: solid.descriptor.sourceCall, separation: streetCapsuleSeparation(solid, world.spawn, world.spawn) })).filter(contact => contact.separation < 0);
  assert.deepEqual(contacts, []);
  const coverage = streetFootCoverage(world, world.spawn.x, world.spawn.z, world.spawn.y);
  assert.equal(coverage.covered, true); assert.ok(coverage.exposedBoundaryDistance >= .35);
});

test('actual market-station carriage interior has supported full-body space above the preserved rail and buttress', () => {
  const world = v9(), line = world.edges.find(edge => edge.id === 'maglev-market-station-core-station')!, node = world.nodes.find(node => node.id === 'market-station')!;
  const car: Vehicle = { id: 'explicit-market-stopped-carriage-fixture', kind: 'maglev', edgeId: line.id, position: { ...node.position }, progress: 0, direction: 1, speed: 40, state: 'waiting', passengers: 0, cargo: 0, nextDeparture: 480 };
  const feet = carrierSlotFeet(car, line, { id: 'interior-center', x: 0, z: 0, purpose: 'passenger' }); assert.ok(feet);
  const cabin = carrierStreetSolids(car, line, true), solids = [...cabin, ...getNearbyStreetSolids(world, feet, feet)];
  assert.equal(streetFootCoverageFromSolids(solids, feet.x, feet.z, feet.y).covered, true);
  const contacts = solids.map(solid => ({ owner: solid.descriptor.owner, sourceCall: solid.descriptor.sourceCall, separation: streetCapsuleSeparation(solid, feet, feet) })).filter(contact => contact.separation < 0);
  assert.deepEqual(contacts, []);
  // Explicit geometry fixture, not a natural train arrival, accepted boarding or a Simulation run.
});

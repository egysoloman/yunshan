import assert from 'node:assert/strict';
import test from 'node:test';
import fs from 'node:fs';
import * as THREE from 'three';
import { NetworkSolidRecipeBuilder, type NetworkSolidDescriptor } from '../src/network-solid-recipe';
import { streetSolidFromDescriptor, streetCapsuleSeparation, streetSolidFootTop, streetSolidCapsuleSupport, streetFootCoverageFromSolids, findStreetSupport } from '../src/street-solid-authority';
import { LiteralWorldNetworkProducer } from './helpers/network-box-provenance';
import type { WorldDefinition } from '../src/types';

function solid(x0: number, x1: number, y0: number, y1: number, z0: number, z1: number, rotation?: THREE.Quaternion) {
  const matrix = new THREE.Matrix4().compose(new THREE.Vector3((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2), rotation ?? new THREE.Quaternion(), new THREE.Vector3(x1 - x0, y1 - y0, z1 - z0));
  const m64 = matrix.elements.slice(), m32 = Array.from(new Float32Array(m64));
  const descriptor: NetworkSolidDescriptor = { owner: { mode: 'road', edgeId: 'known-distance-road' }, sourceCall: 'renderer.ts:760:1', matrixFloat64: m64, matrixFloat32: m32, matrixUint32: Array.from(new Uint32Array(new Float32Array(m64).buffer)), colorFloat32: [0, 0, 0], colorUint32: [0, 0, 0], key: 'stone', distanceDetail: false, arguments: [], operation: 'box' };
  return streetSolidFromDescriptor(descriptor);
}
test('continuous complete body catches an obstacle between clear endpoints and exact support distances', () => {
  const box = solid(-.1, .1, .8, 1.2, -.1, .1);
  assert(streetCapsuleSeparation(box, { x: -1, y: 0, z: 0 }, { x: -1, y: 0, z: 0 }) > 0);
  assert.equal(streetCapsuleSeparation(box, { x: -1, y: 0, z: 0 }, { x: 1, y: 0, z: 0 }), -.35);
  const platform = solid(-5, 5, -.5, 0, -5, 5);
  assert(Math.abs(streetCapsuleSeparation(platform, { x: 0, y: 0, z: 0 }, { x: 1, y: 0, z: 0 })) < 1e-12);
  assert.equal(streetCapsuleSeparation(box, { x: 0, y: 0, z: 0 }, { x: 0, y: 0, z: 0 }), -.35);
});
test('support uses the real circular footprint, including tilted width and a narrow curb edge', () => {
  const rotation = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 0, 1), .12), deck = solid(-5, 5, -.25, .25, -5, 5, rotation);
  const top = streetSolidFootTop(deck, 0, 0, .35)!;
  assert(Math.abs(top.y - (.25 / Math.cos(.12) + .35 * Math.tan(.12))) < 1e-7);
  const curb = solid(.2, .4, 0, .22, -2, 2);
  assert(Math.abs(streetSolidFootTop(curb, 0, 0, .35)!.y - .22) < 1e-7);
  assert.equal(streetSolidFootTop(curb, -.16, 0, .35), null);
  const contact = streetSolidCapsuleSupport(curb, 0, 0, .35)!;
  assert(Math.abs(contact.y - (.22 + Math.sqrt(.35 ** 2 - .2 ** 2) - .35)) < 1e-7);
  assert(Math.abs(streetCapsuleSeparation(curb, { x: 0, y: contact.y, z: 0 }, { x: 0, y: contact.y, z: 0 })) < 1e-12);
});
test('complete foot projection rejects an interior gap and overhead shadow; joined and duplicate floor boundaries remain exact', () => {
  const a = solid(-2, 0, -.5, 0, -2, 2), b = solid(0, 2, -.5, 0, -2, 2);
  const joint = streetFootCoverageFromSolids([a, b, a], 0, 0, 0);
  assert.equal(joint.covered, true);
  assert.equal(joint.exposedBoundaryDistance, 2);
  const first = solid(-2, .1, -.5, 0, -2, 2), second = solid(.15, 2, -.5, 0, -2, 2);
  assert.equal(streetFootCoverageFromSolids([first, second], 0, 0, 0).covered, false);
  const overhead = solid(.1, .15, .8, 1.2, -2, 2);
  assert.equal(streetFootCoverageFromSolids([first, second, overhead], 0, 0, 0).covered, false);
  assert.equal(streetFootCoverageFromSolids([a], -.1, 0, 0).covered, false);
});
test('production descriptor source exactly retains every old v6 matrix/color/order; roofs retain their physical tag', () => {
  const world = JSON.parse(fs.readFileSync(new URL('./fixtures/street-authority/actual-world-v6.json', import.meta.url), 'utf8')) as WorldDefinition;
  const before = new LiteralWorldNetworkProducer(world).buildNetwork(), after = new NetworkSolidRecipeBuilder(world).buildNetwork();
  assert.equal(after.length, 73340);
  const key = (part: NetworkSolidDescriptor) => [part.owner, part.sourceCall, part.matrixUint32, part.colorUint32, part.meshName, part.instanceId];
  assert.deepEqual(after.map(key), before.map(key));
  assert(after.some(part => part.sourceCall === 'renderer.ts:782:5' && part.tags?.roof));
});
test('a distant elevated rail never supplies pedestrian support even when its solid remains collidable', () => {
  const world = JSON.parse(fs.readFileSync(new URL('./fixtures/street-authority/actual-world-v6.json', import.meta.url), 'utf8')) as WorldDefinition;
  const support = findStreetSupport(world, -330, 460, 52.6);
  assert(support);
  assert.equal(support.solid.walkable, true);
  assert(!['lightRail', 'maglev'].includes(String(support.solid.descriptor.owner.mode)));
  assert(support.y <= 53);
});

import assert from 'node:assert/strict';
import test from 'node:test';
import { carrierPassengerCapacity, carrierSlots, carrierSlotFeet, carrierSolidDescriptors, carrierStreetSolids, CARRIER_BODY_HEIGHT, CARRIER_BODY_RADIUS } from '../src/carrier-solids';
import { streetCapsuleSeparation, streetFootCoverageFromSolids, streetSolidFromDescriptor } from '../src/street-solid-authority';
import { applyStationThroats } from '../src/station-throats';
import type { NetworkEdge, Vehicle, WorldDefinition } from '../src/types';

const edge = (kind: Vehicle['kind']): NetworkEdge => ({ id: `${kind}-fixture`, mode: kind, from: 'a', to: 'b', points: [{ x: 0, y: 0, z: 0 }, { x: 0, y: 0, z: 100 }], length: 100, capacity: 180 });
const vehicle = (kind: Vehicle['kind']): Vehicle => ({ id: `${kind}-fixture-car`, kind, edgeId: `${kind}-fixture`, position: { x: 0, y: 0, z: 0 }, progress: 0, direction: 1, speed: 40, state: 'waiting', passengers: 0, cargo: 0, nextDeparture: 480 });

test('actual road and rail shells support every physical slot and contain the full standing capsule', () => {
  for (const kind of ['road', 'lightRail', 'maglev'] as const) {
    const car = vehicle(kind), line = edge(kind), solids = carrierStreetSolids(car, line, false);
    for (const slot of carrierSlots(kind)) {
      const feet = carrierSlotFeet(car, line, slot); assert.ok(feet);
      assert.equal(streetFootCoverageFromSolids(solids, feet.x, feet.z, feet.y).covered, true);
      for (const solid of solids) assert.ok(streetCapsuleSeparation(solid, feet, feet) >= 0, `${kind}/${slot.id}/${solid.descriptor.owner.carrierPart} contacts the body`);
    }
  }
});

test('a real closed leaf blocks the side doorway; fully opened leaves retain material and permit the same body sweep', () => {
  const car = vehicle('maglev'), line = edge('maglev'), start = carrierSlotFeet(car, line, { id: 'center', x: 0, z: 0, purpose: 'passenger' })!;
  const end = { ...start, x: 2.2 }, closed = carrierStreetSolids(car, line, false), opened = carrierStreetSolids(car, line, true);
  assert.ok(closed.some(solid => solid.descriptor.owner.carrierPart === 'door' && streetCapsuleSeparation(solid, start, end) < 0));
  assert.ok(opened.every(solid => streetCapsuleSeparation(solid, start, end) >= 0));
  const oldLeaves = carrierSolidDescriptors(car, line, false).filter(part => part.carrierPart === 'door'), newLeaves = carrierSolidDescriptors(car, line, true).filter(part => part.carrierPart === 'door');
  assert.equal(newLeaves.length, 4);
  newLeaves.forEach((part, i) => { assert.notDeepEqual(part.matrixUint32, oldLeaves[i].matrixUint32); assert.equal(part.arguments[3], oldLeaves[i].arguments[3]); assert.equal(part.arguments[4], oldLeaves[i].arguments[4]); assert.equal(part.arguments[5], oldLeaves[i].arguments[5]); });
  // This is a door-clearance test; a full alighting path also needs real platform support.
});

test('v9 capacity is constrained by nonoverlapping physical slots and an empty central corridor', () => {
  assert.equal(carrierPassengerCapacity('road'), 4); assert.equal(carrierPassengerCapacity('maglev'), 24);
  for (const kind of ['road', 'lightRail', 'maglev'] as const) {
    const slots = carrierSlots(kind);
    for (let i = 0; i < slots.length; i++) {
      assert.ok(Math.abs(slots[i].x) > CARRIER_BODY_RADIUS * 2);
      for (let j = i + 1; j < slots.length; j++) assert.ok(Math.hypot(slots[i].x - slots[j].x, slots[i].z - slots[j].z) >= CARRIER_BODY_RADIUS * 2);
    }
  }
  assert.equal(CARRIER_BODY_HEIGHT, 1.72); assert.equal(CARRIER_BODY_RADIUS, .35);
});

test('endpoint-preserving rail engineering has a real 10m flat boundary and bounded recovery grade', () => {
  const line = { ...edge('maglev'), points: [{ x: 0, y: 0, z: 0 }, { x: 0, y: 7.4, z: 2 }, { x: 0, y: 7.4, z: 60 }, { x: 0, y: 7.4, z: 100 }] };
  const world = { edges: [line], nodes: [{ id: 'a', position: line.points[0] }, { id: 'b', position: line.points[3] }] } as unknown as WorldDefinition;
  const first = { ...line.points[0] }, last = { ...line.points[3] }, engineering = applyStationThroats(world);
  assert.deepEqual(line.points[0], first); assert.deepEqual(line.points.at(-1), last);
  assert.ok(line.points.some(point => point.z === 10 && point.y === 0));
  assert.ok(engineering.changes.every(change => change.grade <= .20));
  assert.equal(engineering.platforms.length, 2);
});

test('an impossible rail throat reports failure before changing the World', () => {
  const line = { ...edge('maglev'), points: [{ x: 0, y: 0, z: 0 }, { x: 0, y: 7.4, z: 2 }, { x: 0, y: 8, z: 4 }] };
  const world = { edges: [line], nodes: [] } as unknown as WorldDefinition, before = JSON.stringify(world);
  assert.throws(() => applyStationThroats(world), /station engineering FAIL/);
  assert.equal(JSON.stringify(world), before);
});

test('every body descriptor uses the same Float32 matrix bits that rendering will write', () => {
  for (const part of carrierSolidDescriptors(vehicle('road'), edge('road'), .5)) {
    assert.deepEqual(Array.from(new Uint32Array(new Float32Array(part.matrixFloat32).buffer)), part.matrixUint32);
    const solid = streetSolidFromDescriptor(part); assert.equal(solid.vertices.length, 8); assert.equal(solid.triangles.length, 12);
  }
});

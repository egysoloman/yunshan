import assert from 'node:assert/strict';
import test from 'node:test';
import { Matrix4, Quaternion, Vector3 } from 'three';
import { certifyStreetFootProjection } from '../src/street-foot-corridor';
import { streetSolidFromDescriptor, streetSolidCapsuleSupport } from '../src/street-solid-authority';
const solid = (matrix: Matrix4, id: string) => {
  const matrixFloat64 = [...matrix.elements], matrixFloat32 = Array.from(new Float32Array(matrixFloat64));
  return streetSolidFromDescriptor({ owner: { scope: 'station-parcel', stationPart: 'floor', fixtureId: id }, sourceCall: 'test-actual-finite-Float32-box', operation: 'box', key: 'stone', distanceDetail: false, arguments: [], matrixFloat64, matrixFloat32, matrixUint32: Array.from(new Uint32Array(new Float32Array(matrixFloat64).buffer)), colorFloat32: [1, 1, 1], colorUint32: [1065353216, 1065353216, 1065353216] });
};
const box = (x: number, top: number, width: number, id: string) => solid(new Matrix4().compose(new Vector3(x, top - .1, 0), new Quaternion(), new Vector3(width, .2, 2)), id);
test('exact Float32 small rectangular hole is preserved by the continuous full-foot projection proof', () => {
  const delta = 2 ** -20, gap = 2 ** -16;
  const rectangle = (x: number, z: number, width: number, depth: number, id: string) => solid(new Matrix4().compose(new Vector3(x, -.1, z), new Quaternion(), new Vector3(width, .2, depth)), id);
  const floors = [rectangle(-.5, 0, 1, 2 * delta, 'left'), rectangle((1 + gap) / 2, 0, 1 - gap, 2 * delta, 'right'), rectangle(0, (1 + delta) / 2, 2, 1 - delta, 'top'), rectangle(0, -(1 + delta) / 2, 2, 1 - delta, 'bottom')];
  // Every box bound is exactly representable after real Float32 placement.
  assert.equal(floors[0].bounds.maximum[0], 0); assert.equal(floors[1].bounds.minimum[0], gap);
  assert.equal(floors[2].bounds.minimum[2], delta); assert.equal(floors[3].bounds.maximum[2], -delta);
  assert.equal(certifyStreetFootProjection(floors, { x: -.04, y: 0, z: 0 }, { x: .04, y: 0, z: 0 }), null, 'a 15.26µm by1.91µm real hole must not become a filled support square through area tolerance');
});

test('one fixed actual finite face certifies the whole circular foot during a horizontal segment', () => {
  const certificate = certifyStreetFootProjection([box(0, 0, 2, 'floor')], { x: -.2, y: 0, z: 0 }, { x: .2, y: 0, z: 0 });
  assert.ok(certificate); assert.ok(certificate.minimumBoundaryDistance >= .35); assert.ok(certificate.fixedFaceDomains.every(domain => domain.lower === -.4 && domain.upper === .35));
});
test('a true small floor gap cannot be hidden by endpoint support or a union containing unrelated floating faces', () => {
  const floors = [box(-.500005, 0, 1, 'left'), box(.500005, 0, 1, 'right'), box(0, 1, 2, 'floating')];
  assert.equal(certifyStreetFootProjection(floors, { x: -.04, y: 0, z: 0 }, { x: .04, y: 0, z: 0 }), null);
});
test('an actual inclined support face certifies a full foot without assuming finite-edge capsule support is globally affine', () => {
  const axis = new Vector3(1, .1, 0).normalize(), across = new Vector3(0, 0, -1), normal = axis.clone().cross(across).normalize();
  const ramp = solid(new Matrix4().makeBasis(across, normal, axis).setPosition(normal.clone().multiplyScalar(-.1)).scale(new Vector3(2, .2, 2)), 'ramp');
  const feet = (x: number) => { const support = streetSolidCapsuleSupport(ramp, x, 0); assert.ok(support); return { x, y: support.y + 8 * Number.EPSILON, z: 0 }; };
  const certificate = certifyStreetFootProjection([ramp], feet(-.1), feet(.1)); assert.ok(certificate); assert.ok(certificate.fixedFaceDomains.length > 0);
});
test('a floating or unreachable face does not provide support projection authority', () => {
  assert.equal(certifyStreetFootProjection([box(0, 1, 2, 'floating')], { x: 0, y: 0, z: 0 }, { x: .02, y: 0, z: 0 }), null);
  assert.equal(certifyStreetFootProjection([box(0, 0, 2, 'too-low')], { x: 0, y: .5, z: 0 }, { x: .02, y: .5, z: 0 }), null);
});
test('a supported raise projection is explicitly not a grounded-contact or interruption certificate', () => {
  const certificate = certifyStreetFootProjection([box(0, 0, 2, 'floor')], { x: 0, y: 0, z: 0 }, { x: 0, y: .2, z: 0 });
  assert.ok(certificate); assert.equal(certificate.provesGroundedContact, false); assert.ok(certificate.fixedFaceDomains.every(domain => domain.lower === -.2));
});
test('invalid motion parameters do not produce a certificate', () => {
  assert.equal(certifyStreetFootProjection([box(0, 0, 2, 'floor')], { x: NaN, y: 0, z: 0 }, { x: 0, y: 0, z: 0 }), null);
  assert.equal(certifyStreetFootProjection([box(0, 0, 2, 'floor')], { x: 0, y: 0, z: 0 }, { x: 0, y: 0, z: 0 }, -.35), null);
});

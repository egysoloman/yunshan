import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { gzipSync } from 'node:zlib';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Root owns the sole heavy gate. This script is a production-browser driver,
// never a synthetic camera viewer or a replacement game/controller loop.
const self = fileURLToPath(import.meta.url), home = path.dirname(self);
const [planArg, outputArg] = process.argv.slice(2);
assert(planArg && outputArg, 'Usage: node native-reference-browser.mjs BOUND_PLAN_JSON NEW_OUTPUT_DIRECTORY');
const planBytes = await readFile(path.resolve(planArg)), plan = JSON.parse(planBytes);
assert.equal(plan.schema, 'ROOT25-native-reference-browser-plan-v1');
assert.equal(plan.expectedLayout, 'current-v8');
assert.equal(plan.pagePath, '/?debug=1');
const output = path.resolve(outputArg);
assert(path.isAbsolute(plan.outputParent) && output.startsWith(path.resolve(plan.outputParent) + path.sep), 'New output must be below the plan-bound original-evidence parent');
assert(!output.startsWith(path.resolve(plan.source) + path.sep), 'Evidence may not overwrite product source or old originals');
await mkdir(path.dirname(output), { recursive: true });
await mkdir(output, { recursive: false });
const hash = value => createHash('sha256').update(value).digest('hex');
const startedAt = new Date().toISOString(), startedMs = Date.now();
const receipt = { status: 'STARTED', startedAt, planSHA256: hash(planBytes), driverSHA256: hash(await readFile(self)),
  platform: 'Linux Chromium, ANGLE SwiftShader software GPU', macHardwareEvidence: false,
  artResult: 'NOT_REVIEWED', naturalPlayerTravel: false, isolatedNonpersistentContext: true,
  actualFirstPersonOnly: true, injectedGameState: false, actions: [], captures: [], files: [],
  referenceViewport: { width: 1672, height: 941 }, ordinaryTickObserved: false };
let writtenBytes = 0, actionId = 0, screenshotId = 0, totalWMs = 0, totalObservedWMs = 0, wPulses = 0;
let browser, context, page, server, serverIdentity, deadlineTimer, serverOutput = '', observerReady = false;
const consoleMessages = [], pageErrors = [], requests = [], responseTasks = [];
function deadline() { assert(Date.now() - startedMs < plan.runDeadlineMs, 'Bound wall deadline reached'); }
async function put(name, value) {
  assert(!name.includes('..') && !path.isAbsolute(name));
  const bytes = Buffer.isBuffer(value) ? value : Buffer.from(typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n');
  assert(writtenBytes + bytes.length <= plan.maximumEvidenceBytes, 'Evidence cap reached; preserve current originals and stop');
  await writeFile(path.join(output, name), bytes, { flag: 'wx' });
  writtenBytes += bytes.length;
  const item = { path: name, bytes: bytes.length, SHA256: hash(bytes) };
  receipt.files.push(item);
  return item;
}
async function putSave(name, json) {
  const bytes = Buffer.from(json, 'utf8'), file = await put(name + '.save.json.gz', gzipSync(bytes));
  return { ...file, encoding: 'gzip', decodedBytes: bytes.length, decodedSHA256: hash(bytes), completeExportSave: true };
}
async function inventory(base, relative = '') {
  const result = {};
  for (const entry of (await readdir(path.join(base, relative), { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const name = relative ? relative + '/' + entry.name : entry.name;
    if (entry.isDirectory()) Object.assign(result, await inventory(base, name));
    else if (entry.isFile()) result[name] = hash(await readFile(path.join(base, name)));
    else throw Error('Unexpected symlink/special functional input: ' + name);
  }
  return result;
}
async function verifyFrozen(label) {
  assert.equal(hash(await readFile(self)), plan.driverSHA256, 'Driver drift');
  assert.equal(hash(await readFile(path.resolve(planArg))), receipt.planSHA256, 'Plan drift');
  const inputs = {};
  for (const directory of ['src', 'tests', 'scripts', 'adapters', 'public']) {
    try { Object.assign(inputs, await inventory(plan.source, directory)); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  for (const name of ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'index.html']) inputs[name] = hash(await readFile(path.join(plan.source, name)));
  const sorted = Object.fromEntries(Object.entries(inputs).sort(([a], [b]) => a.localeCompare(b)));
  assert.deepEqual(sorted, plan.inputs, 'Complete functional input graph drift');
  assert.equal(Object.keys(sorted).length, plan.inputCount);
  assert.equal(hash(JSON.stringify(sorted)), plan.inputGraphSHA256);
  assert.deepEqual(await inventory(path.join(plan.source, 'dist')), plan.buildFiles, 'Complete production build drift');
  const buildReceiptBytes = await readFile(plan.buildReceiptPath);
  assert.equal(hash(buildReceiptBytes), plan.buildReceiptSHA256, 'Actual PASS build receipt drift');
  const buildReceipt = JSON.parse(buildReceiptBytes);
  assert(['PASS', 'PASSED'].includes(buildReceipt.status)); assert.equal(buildReceipt.exitCode, 0);
  assert.equal(buildReceipt.timedOut, false); assert.equal(buildReceipt.inputsStable, true); assert.deepEqual(buildReceipt.activeDescendants, []);
  for (const [boundPath, expected] of Object.entries(plan.buildGateFiles)) {
    const bytes = await readFile(boundPath); assert.equal(hash(bytes), expected, 'Actual build gate artifact drift: ' + boundPath);
    if (boundPath.endsWith('inputs-before.json') || boundPath.endsWith('inputs-after.json')) assert.deepEqual(JSON.parse(bytes), sorted, 'Actual build source graph mismatch');
  }
  assert.equal(hash(await readFile(plan.root20OriginalArchive)), plan.root20OriginalArchiveSHA256);
  for (const [name, expected] of Object.entries(plan.references)) assert.equal(hash(await readFile(path.join(plan.source, name))), expected);
  return put(label + '-frozen-inputs.json', { inputCount: plan.inputCount, inputGraphSHA256: plan.inputGraphSHA256, inputs: sorted, buildFiles: plan.buildFiles, buildReceiptSHA256: plan.buildReceiptSHA256 });
}
async function processIdentity(pid) {
  try { const text = await readFile('/proc/' + pid + '/stat', 'utf8'), fields = text.slice(text.lastIndexOf(')') + 2).split(' ');
    return { pid, parent: Number(fields[1]), state: fields[0], startTicks: Number(fields[19]) };
  } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}
async function stopOwnedPreview() {
  if (!serverIdentity) return;
  const current = await processIdentity(serverIdentity.pid);
  if (current?.parent === process.pid && current.startTicks === serverIdentity.startTicks && current.state !== 'Z') server.kill('SIGTERM');
}
function snapshotInPage() {
  const d = window.__YUNSHAN__, s = d.simulation.state, c = d.controller, o = window.__ROOT25_OBSERVER__;
  return { save: d.simulation.exportSave(), tick: s.tick, day: s.day, hour: s.hour, paused: s.paused, speed: s.speed,
    mode: c.mode, body: c.position, playerPosition: { ...s.player.position }, insideId: c.inside?.id ?? null,
    floor: c.floor, yaw: c.yaw, pitch: c.pitch, vehicleId: s.player.vehicleId, activeAircraftId: s.aviation?.activeAircraftId ?? null,
    camera: { position: d.city.camera.position.toArray(), quaternion: d.city.camera.quaternion.toArray(), fov: d.city.camera.fov },
    input: { keys: [...c.keys], walkingKeys: [...c.walkingKeys], queued: c.walkingInputs.map(row => ({ at: row.at, keys: [...row.keys] })),
      frameKeys: [...c.walkingFrameKeys], frameEnd: Number.isFinite(c.walkingFrameEnd) ? c.walkingFrameEnd : null, resetAt: c.walkingResetAt, inputAt: c.walkingInputAt },
    focus: JSON.parse(d.simulation.exportSave()).runtime.focus, notice: d.getView().notice,
    nearbyBuildingId: d.getView().nearbyBuilding?.id ?? null, observerFrame: o?.frames.length ?? 0, observerEvent: o?.events.length ?? 0,
    documentHidden: document.hidden, drawCalls: d.city.renderer.info.render.calls, triangles: d.city.renderer.info.render.triangles,
  };
}
async function snapshot() { deadline(); const result = await page.evaluate(snapshotInPage); assert.equal(result.mode, 'walk'); assert.equal(result.vehicleId, null); assert.equal(result.activeAircraftId, null); return result; }
function withoutSave(snapshot) { const { save, ...rest } = snapshot; return rest; }
async function action(label, requestedInput, run) {
  deadline();
  const id = String(++actionId).padStart(5, '0'), stem = id + '-' + label;
  await page.evaluate(action => { window.__ROOT25_OBSERVER__.action = action; }, stem);
  const before = await snapshot(), beforeFile = await putSave(stem + '.before', before.save);
  let result, failure;
  try { result = await run(before); } catch (error) { failure = error; }
  const after = await snapshot(), afterFile = await putSave(stem + '.after', after.save);
  const observations = await page.evaluate(range => ({
    events: window.__ROOT25_OBSERVER__.events.slice(range.event), frames: window.__ROOT25_OBSERVER__.frames.slice(range.frame),
  }), { event: before.observerEvent, frame: before.observerFrame });
  const record = { id: stem, label, requestedInput, startedBefore: withoutSave(before), completedAfter: withoutSave(after), beforeFile, afterFile,
    tickDelta: after.tick - before.tick, bodyMetres: Math.hypot(after.body.x - before.body.x, after.body.y - before.body.y, after.body.z - before.body.z),
    realFrameCount: after.observerFrame - before.observerFrame, observations, result: result ?? null,
    status: failure ? 'FAIL' : 'PASS', failure: failure ? String(failure.stack ?? failure) : null };
  if (record.tickDelta > 0) receipt.ordinaryTickObserved = true;
  await put(stem + '.action.json', record); receipt.actions.push({ id: stem, status: record.status, label, beforeSave: beforeFile, afterSave: afterFile });
  if (failure) throw failure;
  return { before, after, result, record };
}
async function framePairs(count = 2) { await page.evaluate(n => new Promise(resolve => { let left = n * 2; const read = () => --left ? requestAnimationFrame(read) : resolve(); requestAnimationFrame(read); }), count); }
async function settle() {
  assert.equal(await page.evaluate(() => window.__YUNSHAN__.simulation.state.paused), true);
  for (let pairs = 1; pairs <= 12; pairs++) {
    const before = await snapshot(); await framePairs(1); const after = await snapshot();
    if (before.save === after.save && JSON.stringify(before.camera) === JSON.stringify(after.camera)
      && after.input.queued.length === 0 && after.input.keys.length === 0)
      return { observedRealFramePairs: pairs, stableSaveSHA256: hash(after.save) };
  }
  throw Error('Paused production loop failed to stabilize complete exportSave and camera');
}
async function setPaused(value) {
  const actual = await page.evaluate(() => window.__YUNSHAN__.simulation.state.paused);
  if (actual === value) return;
  await action(value ? 'native-ui-pause' : 'native-ui-resume', { kind: 'DOM click', selector: '[data-testid="pause-toggle"]', requestedPaused: value }, async () => {
    await page.getByTestId('pause-toggle').click();
    await page.waitForFunction(expected => window.__YUNSHAN__.simulation.state.paused === expected, value, { timeout: plan.actionTimeoutMs });
    await framePairs(1);
  });
}
async function graphics() {
  return page.evaluate(() => {
    const d = window.__YUNSHAN__, r = d.city.renderer, gl = r.getContext(), debug = gl.getExtension('WEBGL_debug_renderer_info');
    const errors = []; for (let i = 0; i < 64; i++) { const value = gl.getError(); if (value === gl.NO_ERROR) break; errors.push(value); }
    return { errors, contextLost: gl.isContextLost(), vendor: gl.getParameter(gl.VENDOR), renderer: gl.getParameter(gl.RENDERER), version: gl.getParameter(gl.VERSION),
      unmaskedVendor: debug ? gl.getParameter(debug.UNMASKED_VENDOR_WEBGL) : null, unmaskedRenderer: debug ? gl.getParameter(debug.UNMASKED_RENDERER_WEBGL) : null,
      shadingLanguageVersion: gl.getParameter(gl.SHADING_LANGUAGE_VERSION), supportedExtensions: gl.getSupportedExtensions(),
      canvas: { width: r.domElement.width, height: r.domElement.height, rect: r.domElement.getBoundingClientRect().toJSON(), viewport: { width: innerWidth, height: innerHeight }, devicePixelRatio },
      render: { ...r.info.render }, memory: { ...r.info.memory }, shadowMap: { enabled: r.shadowMap.enabled, type: r.shadowMap.type },
      residency: structuredClone(d.city.scene.userData.buildingResidency ?? null),
      architecture: structuredClone(d.city.architectureDetail?.group.userData ?? null),
      programs: (r.info.programs ?? []).map(program => ({ name: program.name, linked: gl.getProgramParameter(program.program, gl.LINK_STATUS), log: gl.getProgramInfoLog(program.program),
        shaders: (gl.getAttachedShaders(program.program) ?? []).map(shader => ({ stage: gl.getShaderParameter(shader, gl.SHADER_TYPE), compiled: gl.getShaderParameter(shader, gl.COMPILE_STATUS), log: gl.getShaderInfoLog(shader), source: gl.getShaderSource(shader) })) })),
    };
  });
}
async function capture(label) {
  await setPaused(true); const settled = await settle(), id = String(++screenshotId).padStart(2, '0'), stem = 'capture-' + id + '-' + label;
  const before = await snapshot(), beforeFile = await putSave(stem + '.before', before.save);
  const png = await page.screenshot({ type: 'png', fullPage: false, animations: 'allow', caret: 'initial' });
  const imageFile = await put(stem + '.ORIGINAL.png', png), after = await snapshot(), afterFile = await putSave(stem + '.after', after.save);
  const gl = await graphics(); await put(stem + '.webgl.json', gl);
  const record = { label, classification: 'Actual native first-person body; production camera; no reposition, crop, retouch or auxiliary view', settled,
    before: withoutSave(before), after: withoutSave(after), beforeFile, afterFile, imageFile, completeSaveUnchanged: before.save === after.save,
    cameraUnchanged: JSON.stringify(before.camera) === JSON.stringify(after.camera), humanArtReviewRequired: true };
  await put(stem + '.capture.json', record); receipt.captures.push(record);
  assert(record.completeSaveUnchanged && record.cameraUnchanged, 'Screenshot authority/camera drift; originals preserved');
  assert(gl.render.calls > 0 && gl.render.triangles > 1000 && !gl.contextLost, 'No actual functioning city render');
  assert.deepEqual(gl.errors, [], 'Actual WebGL errors'); assert(gl.programs.length > 0 && gl.programs.every(p => p.linked && p.shaders.every(s => s.compiled)), 'Actual shader/link failure');
  return record;
}
async function canvasPoint() {
  return page.evaluate(() => {
    const canvas = window.__YUNSHAN__.city.renderer.domElement, rect = canvas.getBoundingClientRect();
    for (const [fx, fy] of [[.5, .5], [.4, .55], [.55, .6], [.2, .5]]) {
      const x = rect.left + rect.width * fx, y = rect.top + rect.height * fy;
      if (document.elementFromPoint(x, y) === canvas) return { x, y };
    }
    throw Error('No unobscured native canvas drag starting point');
  });
}
const angle = value => Math.atan2(Math.sin(value), Math.cos(value));
async function facePoint(target, label) {
  const before = await snapshot(), dx = target.x - before.body.x, dz = target.z - before.body.z;
  if (Math.hypot(dx, dz) < .05) return;
  const yaw = Math.atan2(-dx, -dz), difference = angle(yaw - before.yaw);
  if (Math.abs(difference) < .01) return;
  await action('mouse-turn-' + label, { kind: 'native mouse drag', targetUsedForAimOnly: target, targetYaw: yaw, expectedYawDelta: difference }, async () => {
    let remaining = -difference / .003;
    while (Math.abs(remaining) > .01) {
      deadline(); const origin = await canvasPoint(), pixels = Math.max(-225, Math.min(225, remaining));
      await page.mouse.move(origin.x, origin.y); await page.mouse.down({ button: 'left' });
      try { await page.mouse.move(origin.x + pixels, origin.y, { steps: 3 }); } finally { await page.mouse.up({ button: 'left' }); }
      remaining -= pixels;
    }
    await framePairs(1);
    const actualYaw = await page.evaluate(() => window.__YUNSHAN__.controller.yaw);
    assert(Math.abs(angle(actualYaw - yaw)) < .03, 'Native mouse turn was not received');
    return { actualYaw };
  });
}
async function pulse(label, target) {
  const s = await snapshot(), remaining = Math.hypot(target.x - s.body.x, target.z - s.body.z);
  const holdMs = Math.max(plan.pulseMinMs, Math.min(plan.pulseMaxMs, Math.floor(remaining / 4.8 * 1000)));
  assert(++wPulses <= plan.maximumWPulses && totalWMs + holdMs <= plan.maximumWSeconds * 1000, 'Original bound W budget exhausted'); totalWMs += holdMs;
  const result = await action('W-' + label, { kind: 'real DOM keyboard', code: 'KeyW', holdMs, targetUsedForAimOnly: target }, async () => {
    // Start the real release timer when queuing keydown, rather than after
    // its acknowledgement: a busy software renderer may delay that promise.
    // Both are original trusted browser input commands in their real order.
    const down = page.keyboard.down('KeyW');
    const up = new Promise(resolve => setTimeout(resolve, holdMs)).then(() => page.keyboard.up('KeyW'));
    const delivered = await Promise.allSettled([down, up]);
    for (const result of delivered) if (result.status === 'rejected') throw result.reason;
    await page.waitForFunction(() => {
      const c = window.__YUNSHAN__.controller, o = window.__ROOT25_OBSERVER__, up = o.events.findLast(e => e.action === o.action && e.type === 'keyup' && e.code === 'KeyW');
      return up?.accepted && !c.keys.has('KeyW') && !c.walkingKeys.has('KeyW') && c.walkingInputs.length === 0 && c.walkingFrameEnd >= up.accepted.inputAt;
    }, null, { timeout: plan.actionTimeoutMs, polling: 100 });
    await framePairs(1);
    const consumption = await page.evaluate(() => {
      const c = window.__YUNSHAN__.controller, o = window.__ROOT25_OBSERVER__, events = o.events.filter(e => e.action === o.action && e.code === 'KeyW');
      const down = events.find(e => e.type === 'keydown'), up = events.findLast(e => e.type === 'keyup');
      return { trustedKeydown: !!down?.isTrusted, trustedKeyup: !!up?.isTrusted, acceptedDownAt: down?.accepted?.inputAt ?? null,
        acceptedUpAt: up?.accepted?.inputAt ?? null, observedHeldMs: down?.accepted && up?.accepted ? up.accepted.inputAt - down.accepted.inputAt : null,
        nativeEventHeldMs: down && up ? up.timeStamp - down.timeStamp : null,
        productionFrameEnd: c.walkingFrameEnd, pendingQueueLength: c.walkingInputs.length,
        frameDidConsume: !!up?.accepted && c.walkingFrameEnd >= up.accepted.inputAt && c.walkingInputs.length === 0 && !c.walkingKeys.has('KeyW') };
    });
    assert(consumption.trustedKeydown && consumption.trustedKeyup && consumption.frameDidConsume, 'No trusted native W pair consumed by a production frame');
    assert(Number.isFinite(consumption.observedHeldMs) && consumption.observedHeldMs >= 0);
    totalObservedWMs += consumption.observedHeldMs;
    assert(totalObservedWMs <= plan.maximumWSeconds * 1000, 'Observed real held-W budget exhausted');
    return { ...consumption, cumulativeRequestedWMs: totalWMs, cumulativeObservedWMs: totalObservedWMs };
  });
  const events = result.record.observations.events.filter(e => e.code === 'KeyW');
  assert(events.some(e => e.type === 'keydown' && e.isTrusted) && events.some(e => e.type === 'keyup' && e.isTrusted), 'Missing actual trusted W events');
  assert(result.after.input.queued.length === 0 && result.record.realFrameCount > 0, 'W pulse not drained by the original production frame');
  return result;
}
async function walkPoints(points, label, threshold = plan.waypointThresholdMetres) {
  assert(Array.isArray(points) && points.length, 'Authoritative path missing');
  await put('route-' + label + '.json', { label, source: 'Production navigation / production shared floorPlanRoute; numeric coordinates are read targets only, never body writes', points, threshold });
  for (let index = 0; index < points.length; index++) {
    let stalled = 0;
    for (;;) {
      deadline(); const s = await snapshot(), p = points[index], distance = Math.hypot(p.x - s.body.x, p.y - s.body.y, p.z - s.body.z);
      if (distance <= threshold) break;
      assert(Math.hypot(p.x - s.body.x, p.z - s.body.z) > .05, 'Vertical-only waypoint cannot be reached by an ordinary horizontal W pulse');
      await facePoint(p, label + '-' + index); const result = await pulse(label + '-' + index, p);
      stalled = result.record.bodyMetres < .025 ? stalled + 1 : 0;
      assert(stalled < 6, 'Real collision/route stall at ' + label + ' waypoint ' + index + '; no injection or tolerance enlargement');
    }
  }
}
async function interiorRoute(buildingId, target, label) {
  // Calls the existing geometric path query, not command()/step()/setFocus().
  // The full synchronous save equality proves the query does not alter authority.
  const result = await page.evaluate(({ buildingId, target }) => {
    const d = window.__YUNSHAN__, b = d.world.buildings.find(b => b.id === buildingId), before = d.simulation.exportSave();
    if (typeof d.simulation.floorPlanRoute !== 'function') throw Error('Frozen production floorPlanRoute query missing');
    const points = d.simulation.floorPlanRoute(b, d.controller.floor, 0, d.controller.position, target);
    return { points, before, after: d.simulation.exportSave() };
  }, { buildingId, target });
  await putSave('query-' + label + '.before', result.before); await putSave('query-' + label + '.after', result.after);
  assert.equal(result.before, result.after, 'Geometric query changed complete authority');
  return result.points;
}
async function nativeE(label, expectedInsideId) {
  const result = await action('E-' + label, { kind: 'real DOM keyboard', code: 'KeyE', requestedInsideId: expectedInsideId }, async () => {
    await page.keyboard.press('KeyE'); await framePairs(2);
    await page.waitForFunction(expected => window.__YUNSHAN__.controller.inside?.id === expected || expected === null && window.__YUNSHAN__.controller.inside === null,
      expectedInsideId, { timeout: plan.actionTimeoutMs, polling: 100 });
  });
  assert(result.record.observations.events.some(e => e.type === 'keydown' && e.code === 'KeyE' && e.isTrusted), 'Missing actual trusted E input');
  assert.equal(result.after.insideId, expectedInsideId); return result;
}
try {
  receipt.frozenBefore = await verifyFrozen('before');
  const require = createRequire(path.join(plan.source, 'package.json')), { chromium } = require('playwright-core');
  server = spawn(process.execPath, [path.join(plan.source, 'node_modules/vite/bin/vite.js'), 'preview', '--host', '127.0.0.1', '--port', String(plan.port), '--strictPort'], { cwd: plan.source, stdio: ['ignore', 'pipe', 'pipe'] });
  server.stdout.on('data', data => { serverOutput += data; }); server.stderr.on('data', data => { serverOutput += data; });
  serverIdentity = await processIdentity(server.pid); await put('owned-preview-process.json', { driverPID: process.pid, serverIdentity });
  const base = 'http://127.0.0.1:' + plan.port;
  for (let attempt = 0; attempt < 150; attempt++) {
    deadline(); assert(server.exitCode === null, 'Owned production preview exited: ' + serverOutput);
    if (serverOutput.includes(base)) break;
    assert(attempt < 149, 'Owned preview startup marker missing'); await new Promise(resolve => setTimeout(resolve, 100));
  }
  const indexResponse = await fetch(base), servedIndex = await indexResponse.text(); assert(indexResponse.ok);
  assert.equal(hash(servedIndex), plan.indexSHA256, 'Served HTML is not the bound actual production build');
  const bundleResponse = await fetch(base + plan.buildEntry); assert(bundleResponse.ok);
  assert.equal(hash(Buffer.from(await bundleResponse.arrayBuffer())), plan.buildSHA256, 'Served production bundle mismatch');
  browser = await chromium.launch({ executablePath: plan.chromium, headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  context = await browser.newContext({ viewport: plan.viewport, deviceScaleFactor: plan.deviceScaleFactor, serviceWorkers: 'block' });
  // Never use launchPersistentContext, storageState, addCookies, localStorage/IDB
  // writes, clearCookies, or another browser's profile. This context starts empty.
  page = await context.newPage(); page.setDefaultTimeout(plan.actionTimeoutMs);
  page.on('console', message => {
    const row = { at: new Date().toISOString(), type: message.type(), text: message.text(), location: message.location() };
    consoleMessages.push(row); responseTasks.push(Promise.all(message.args().map(arg => arg.jsonValue().catch(error => ({ serializationError: String(error) })))).then(args => { row.args = args; }));
  });
  page.on('pageerror', error => pageErrors.push({ at: new Date().toISOString(), message: error.message, stack: error.stack }));
  page.on('requestfailed', request => requests.push({ at: new Date().toISOString(), kind: 'failed', url: request.url(), failure: request.failure() }));
  page.on('response', response => { if (response.status() >= 400) requests.push({ at: new Date().toISOString(), kind: 'HTTP error', url: response.url(), status: response.status() }); });
  await page.addInitScript(() => {
    const observer = { action: 'startup', events: [], frames: [], stopped: false };
    window.__ROOT25_OBSERVER__ = observer;
    const eventRows = new WeakMap();
    Object.defineProperty(observer, 'noteAccepted', { value: event => {
      const row = eventRows.get(event); if (row) { row.defaultPrevented = event.defaultPrevented; row.accepted = accepted(); }
    } });
    const accepted = () => { const c = window.__YUNSHAN__?.controller; return c ? { keys: [...c.keys], walkingKeys: [...c.walkingKeys], inputAt: c.walkingInputAt,
      frameEnd: c.walkingFrameEnd, queued: c.walkingInputs.map(row => ({ at: row.at, keys: [...row.keys] })), mode: c.mode } : null; };
    for (const type of ['keydown', 'keyup', 'mousedown', 'mouseup', 'mousemove', 'blur', 'visibilitychange']) {
      const target = type === 'visibilitychange' ? document : window;
      target.addEventListener(type, event => {
        const row = { type, action: observer.action, at: performance.now(), timeStamp: event.timeStamp, isTrusted: event.isTrusted,
          code: event.code ?? null, key: event.key ?? null, repeat: event.repeat ?? null,
          x: event.clientX ?? null, y: event.clientY ?? null, movementX: event.movementX ?? null, movementY: event.movementY ?? null,
          target: event.target?.tagName ?? null, defaultPrevented: event.defaultPrevented, hidden: document.hidden, accepted: null };
        observer.events.push(row); eventRows.set(event, row);
      }, { capture: true });
    }
    document.addEventListener('webglcontextlost', event => observer.events.push({ type: 'webglcontextlost', action: observer.action, at: performance.now(), isTrusted: event.isTrusted }), { capture: true });
  });
  deadlineTimer = setTimeout(() => { receipt.deadlineReached = true; browser?.close().catch(() => {}); stopOwnedPreview().catch(() => {}); }, plan.runDeadlineMs);
  await page.goto(base + plan.pagePath, { waitUntil: 'networkidle', timeout: plan.actionTimeoutMs });
  await page.waitForFunction(() => window.__YUNSHAN__?.city.renderer.info.render.calls > 0, null, { timeout: plan.actionTimeoutMs });
  await page.evaluate(() => {
    const o = window.__ROOT25_OBSERVER__;
    // Registered after the actual application listener. Capture microtasks can
    // run between DOM listener invocations; read accepted input synchronously
    // in this later bubble listener, after the real controller has recorded it.
    for (const type of ['keydown', 'keyup', 'mousedown', 'mouseup', 'mousemove', 'blur', 'visibilitychange']) {
      const target = type === 'visibilitychange' ? document : window;
      target.addEventListener(type, event => o.noteAccepted(event));
    }
    function observe(now) {
      if (o.stopped) return; const d = window.__YUNSHAN__, c = d.controller;
      o.frames.push({ action: o.action, rafTimestamp: now, at: performance.now(), walkingFrameEnd: c.walkingFrameEnd,
        walkingResetAt: c.walkingResetAt, inputAt: c.walkingInputAt, queued: c.walkingInputs.map(row => ({ at: row.at, keys: [...row.keys] })),
        liveKeys: [...c.keys], replayKeys: [...c.walkingFrameKeys], body: c.position, playerPosition: { ...d.simulation.state.player.position },
        tick: d.simulation.state.tick, paused: d.simulation.state.paused, mode: c.mode, hidden: document.hidden });
      requestAnimationFrame(observe);
    }
    requestAnimationFrame(observe);
  }); observerReady = true;
  const boot = await page.evaluate(async () => ({ world: JSON.stringify(window.__YUNSHAN__.world), initialSave: window.__YUNSHAN__.simulation.exportSave(),
    storedSave: await window.__YUNSHAN__.storage.read(), localStorage: Object.fromEntries(Object.entries(localStorage)), cookies: document.cookie }));
  const world = JSON.parse(boot.world), initial = JSON.parse(boot.initialSave);
  receipt.worldFile = await put('actual-born-WORLD.json', boot.world); receipt.initialSave = await putSave('actual-born', boot.initialSave);
  await put('fresh-context-storage.json', { storedSave: boot.storedSave, localStorage: boot.localStorage, cookies: boot.cookies, noStorageStateSupplied: true });
  assert.equal(boot.storedSave, null, 'This must be a genuinely fresh context with no imported/default save');
  assert.equal(world.layoutVersion, plan.expectedLayout, 'URL did not select the actual new code-owned current-v8 World'); assert.equal(world.seed, plan.expectedSeed);
  assert.deepEqual(initial.state.player.position, world.spawn, 'Actual new-world body must still be at its native spawn before any movement');
  assert.equal(initial.runtime.mode, 'walk'); receipt.worldFingerprint = initial.worldFingerprint; receipt.actualLayout = world.layoutVersion;
  assert(world.buildings.length >= 150 && initial.state.citizens.length >= 200 && initial.state.vehicles.length > 10);
  const bootFrame = await snapshot(); await framePairs(2); const liveBoot = await snapshot(); receipt.ordinaryTickObserved ||= liveBoot.tick > bootFrame.tick || initial.state.tick > 0;
  await capture('ACTUAL-BIRTH-CAMERA');
  assert(receipt.ordinaryTickObserved, 'Normal fresh entry must observe ordinary live ticks');
  const nativePaused = await snapshot();
  assert.equal(nativePaused.paused, true);
  assert.deepEqual(nativePaused.body, world.spawn);
  assert.equal(nativePaused.insideId, null);
  assert.equal(nativePaused.mode, 'walk');
  assert.deepEqual(pageErrors, []);
  assert(!consoleMessages.some(row => row.type === 'error'));
  assert.equal(requests.length, 0);
  receipt.terminalSave = await putSave('actual-normal-default-terminal', nativePaused.save);
  await put('actual-normal-default-body-camera.json', withoutSave(nativePaused));
  receipt.status = 'PASS_NATIVE_NORMAL_FRESH_DEFAULT_ONLY';
  receipt.scope = 'Actual production browser fresh normal URL with debug diagnostics, without cityLayout override. Real native pause and original birth screenshot/full save. Does not repeat movement/purchase/save flow on this build.';

} catch (error) {
  receipt.status = 'FAIL'; receipt.failure = String(error.stack ?? error); process.exitCode = 1;
  if (page && !page.isClosed()) {
    try { const terminal = await snapshot(); receipt.failureSave = await putSave('FAIL-actual-complete-terminal', terminal.save); await put('FAIL-actual-terminal-body-camera.json', withoutSave(terminal)); }
    catch (captureError) { receipt.failureCaptureError = String(captureError); }
    try { await put('FAIL-ORIGINAL.png', await page.screenshot({ type: 'png', fullPage: false })); }
    catch (captureError) { receipt.failureScreenshotError = String(captureError); }
  }
} finally {
  clearTimeout(deadlineTimer);
  if (observerReady && page && !page.isClosed()) {
    try { await put('ALL-REAL-INPUT-AND-RAF-OBSERVATIONS.json', await page.evaluate(() => { window.__ROOT25_OBSERVER__.stopped = true; return window.__ROOT25_OBSERVER__; })); }
    catch (error) { receipt.observerFinalizationError = String(error); receipt.status = 'FAIL'; process.exitCode = 1; }
    try { await put('terminal-complete-webgl-info.json', await graphics()); } catch (error) { receipt.graphicsFinalizationError = String(error); }
  }
  await context?.close().catch(error => { receipt.contextCloseError = String(error); }); await browser?.close().catch(error => { receipt.browserCloseError = String(error); });
  await stopOwnedPreview();
  if (server) {
    await Promise.race([new Promise(resolve => { if (server.exitCode !== null) resolve(); else server.once('exit', resolve); }), new Promise(resolve => setTimeout(resolve, 5000))]);
    const stillOwned = await processIdentity(server.pid);
    if (stillOwned?.parent === process.pid && stillOwned.startTicks === serverIdentity?.startTicks && stillOwned.state !== 'Z') { server.kill('SIGKILL'); receipt.previewForcedKill = true; }
    receipt.previewAfterStop = await processIdentity(server.pid);
  }
  await Promise.allSettled(responseTasks);
  try {
    await put('ALL-browser-console.json', consoleMessages); await put('ALL-pageerrors.json', pageErrors); await put('ALL-requestfailures.json', requests); await put('owned-preview-stdout-stderr.log', serverOutput);
    receipt.frozenAfter = await verifyFrozen('after');
  } catch (error) { receipt.finalizationError = String(error.stack ?? error); receipt.status = 'FAIL'; process.exitCode = 1; }
  receipt.finishedAt = new Date().toISOString(); receipt.elapsedMs = Date.now() - startedMs; receipt.evidenceBytesBeforeReceipt = writtenBytes;
  receipt.artResult = 'NOT_REVIEWED'; receipt.artCompletionEstablished = false; receipt.macHardwareEvidence = false;
  await writeFile(path.join(output, 'RESULT.json'), JSON.stringify(receipt, null, 2) + '\n', { flag: 'wx' });
  console.log(JSON.stringify({ status: receipt.status, output, captures: receipt.captures.length, actions: receipt.actions.length, totalWSeconds: totalWMs / 1000, resultSHA256: hash(await readFile(path.join(output, 'RESULT.json'))), artResult: receipt.artResult }));
}

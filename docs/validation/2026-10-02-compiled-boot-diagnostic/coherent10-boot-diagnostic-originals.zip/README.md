# Frozen10 boot diagnostic — preparation and original failure

The original compiled browser11 ran once, 2026-10-02 15:09:49.628–15:11:24.671 UTC. It exited 1 before check 1: `browser-test.mjs:45` timed out after 90,000 ms waiting for `window.__YUNSHAN__?.simulation?.state?.tick >= 1`. Results were empty, `errors=[]`, aviationStage null, and no PNG was produced. Checks 2–11 did not execute. This is not a gameplay transaction failure, a proven GPU fault, or a native-home result.

`original-failure/` contains four byte-identical copies of the raw log, result and start/end manifests; `original-failure-explanation.json` gives original paths, SHA256 and evidence limits. The original wrapper was also unchanged.

## Source-count clarification

The run's numeric fields and complete hash dictionaries correctly covered **103 frozen inputs** and **98 shared executable inputs**. Both sets were identical before/after. The final `scope` prose accidentally retained `Frozen102 and shared executable97` from the preceding preparation version. That prose is incorrect; it has not been rewritten inside the original evidence. The five shared files excluded from executable equality were `.gitattributes`, `.gitignore`, `AGENTS.md`, `开发备忘录.md`, and `提示词.md`; all 103 immutable-copy inputs were still checked.

Actual build entry: `/assets/index-IZpNJKPR.js`, 647004 bytes, SHA256 `fe863519166c8abc0c7db84fc53517089532434948903fb777e1e28f0afd247b`. Original browser script SHA256 `cd7c4d616753d2c74233ca7afdc761760cfc0b4fba4096f758d22ea5cc0c95d5`. Reaching line45 implies the original own-server HTML-entry assertion passed. The wrapper's independent JS-body HTTP observation triggers only after check1 PASS; consequently it was null in this failed run. Disk-entry equality is not evidence of a captured HTTP asset body.

## Static branch evidence; causes remain unconfirmed

1. `src/main.ts:21` appends `.world-stage`; line26 awaits `readSavedGame()`.
2. Lines29–35 select the trusted world, construct Simulation and then CityRenderer. Simulation initialization is synchronous. Renderer appends its WebGL canvas at line147 before creating landscape, city, network and pools (lines233–245).
3. `main.ts:153` constructs UI; lines231–233 call initial `getView()`/`ui.update()` and request rAF.
4. Lines404–406 publish `__YUNSHAN__` in the same module task. There is no await between the initial rAF request and debug publication: debug should exist before the first application rAF callback executes.
5. The application callback schedules its next rAF at line181, returns early for a hidden document at line187, calls simulation.step at line206, then city.update/render at lines213/216. Simulation accumulates 0.25 seconds per tick (`simulation.ts:20,580–588`); the time phase increments tick at line610. An initial delta below 0.25 can leave tick0 before a synchronous scene update/render stall. A tick increment alone does not prove all ten phases or the entire frame finished.

The original wait uses optional chaining and default rAF polling. Missing debug, debug with tick0, and a blocked page execution channel can therefore yield the identical timeout. Empty console/pageerror arrays only show that no error reached those listeners. They do not identify which branch occurred.

## Independent probe scope and cleanup

`boot-probe.mjs` is **not the original browser11**, a substitute PASS, a business scenario, or native validation. It uses the same Chromium executable, SwiftShader flags, 1440×900 viewport, fresh nonpersistent context and default application settings. A unique strict preview owns port4187; occupied ports4187/4173 abort before launch. It independently verifies HTML and asset-body SHA, also captures the actual browser-loaded JS response SHA, console/pageerror/requestfailed, DOMContentLoaded/load, resources, visibility, DOM stages, debug/tick/paused/order/accumulator and renderer counters.

An init script adds an observation-only global, MutationObserver, interval, rAF heartbeat and completed-long-task observer. It does not wrap or call any production method and never writes money, actors, clock, settings, weather, bodies or commands. This diagnostic adds scheduling overhead and cannot establish FPS or hardware performance. Read-only JS and CDP requests are bounded; the navigation observation window is at most the original 90 seconds, with native cleanup outside that window. Initial/final screenshots use only remaining observation time; failed captures remain actual failures and no black placeholder is synthesized.

If read-only page evaluation still cannot return near the end of the window, at most **one** diagnostic CDP Debugger.pause is requested. A returned pause records function names and source positions without locals, immediately resumes, and is explicitly excluded from normal/native/FPS evidence. No hypothesis is emitted as a cause. A blocked execution channel without a returned stack still leaves CPU versus GPU unconfirmed.

Cleanup calls normal `browser.close()` and TERM only the preview child started by this script. It records PIDs/creation ticks/cwd and release status. It never kills an unrelated browser/server, never uses a wildcard kill, and has no automatic retry. If cleanup does not resolve, the report stays incomplete and another GPU run must wait for verified release.

Root separately authorized this one diagnostic; execute only after syntax and hash preflight pass:

```sh
YUNSHAN_BOOT10_DIAGNOSTIC_APPROVED=1 node /tmp/yunshan-coherent10-boot-diagnostic-01/boot-probe.mjs
```

The output directory must be new and empty. No shared source or frozen input is modified. The original0/11 and independent native NOT_RUN remain separate regardless of this probe's observations.

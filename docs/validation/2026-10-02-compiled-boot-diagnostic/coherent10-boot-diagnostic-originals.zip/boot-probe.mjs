import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { spawn } from 'node:child_process';
import { connect } from 'node:net';

// An independent, observational run; never runs or substitutes browser11.
assert.equal(process.env.YUNSHAN_BOOT10_DIAGNOSTIC_APPROVED, '1', 'NOT_RUN: root must grant the single diagnostic GPU slot');
const here = dirname(new URL(import.meta.url).pathname);
const contract = JSON.parse(await readFile(join(here, 'source-contract.json'), 'utf8'));
const sourceRoot = contract.sourceRoot, sharedRoot = '/workspace/yunshan';
const output = join(here, 'probe-evidence');
const port = 4187, budgetMs = 90_000;
const nonExecutable = new Set(['.gitattributes', '.gitignore', 'AGENTS.md', '开发备忘录.md', '提示词.md']);
const frozenNames = Object.keys(contract.copiedHashes);
const executableNames = frozenNames.filter(name => !nonExecutable.has(name));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const hashes = async (root, names) => Object.fromEntries(await Promise.all(names.map(async name => [name, hash(await readFile(join(root, name)))])));
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
const bounded = (task, ms, label) => {
  let timer;
  return Promise.race([task, new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`${label}: observer deadline ${ms}ms`)), ms); })]).finally(() => clearTimeout(timer));
};
const vacant = p => new Promise((resolve, reject) => {
  const socket = connect({ host: '127.0.0.1', port: p });
  socket.once('connect', () => { socket.destroy(); resolve(false); });
  socket.once('error', error => { socket.destroy(); if (error.code === 'ECONNREFUSED') resolve(true); else reject(error); });
});
const safeURL = input => { try { const url = new URL(input); return url.origin + url.pathname; } catch { return String(input).slice(0, 400); } };
const processIdentity = async pid => {
  try {
    const stat = (await readFile(`/proc/${pid}/stat`, 'utf8')).split(') ')[1].split(' ');
    const { readlink } = await import('node:fs/promises');
    return { pid, ppid: Number(stat[1]), state: stat[0], startTicks: stat[19], cwd: await readlink(`/proc/${pid}/cwd`) };
  } catch (error) { return { pid, unavailable: String(error) }; }
};
const jsonFile = (name, value) => writeFile(join(output, name), JSON.stringify(value, null, 2) + '\n');
assert.equal(frozenNames.length, 103); assert.equal(executableNames.length, 98);
assert.deepEqual(await readdir(output).catch(error => { if (error.code === 'ENOENT') return []; throw error; }), [], 'Preserve previous diagnostics; no overwrite or automatic retry');
const frozenBefore = await hashes(sourceRoot, frozenNames);
assert.deepEqual(frozenBefore, contract.copiedHashes);
assert.equal(hash(await readFile(contract.snapshotManifest)), contract.snapshotManifestSHA256);
const sharedBefore = await hashes(sharedRoot, executableNames);
assert.deepEqual(sharedBefore, Object.fromEntries(executableNames.map(name => [name, contract.copiedHashes[name]])));
assert.equal(hash(await readFile(join(sourceRoot, 'dist', contract.distEntry.slice(1)))), contract.distEntrySHA256);
assert.equal((await readFile(join(sourceRoot, 'dist/index.html'), 'utf8')).match(/<script[^>]+src="([^"]+\.js)"/)?.[1], contract.distEntry);
assert.equal(await vacant(port), true, 'Never use or stop a pre-existing server');
assert.equal(await vacant(4173), true, 'Original browser11 server must be released first');
await mkdir(output, { recursive: true });
const externalStart = { probe: hash(await readFile(new URL(import.meta.url))), contract: hash(await readFile(join(here, 'source-contract.json'))) };
const startedAt = new Date().toISOString();
const events = [], snapshots = [], observedResponses = [], cleanup = {};
let eventSeq = 0, server, browser, page, cdp, serverRaw = '', navigationStart = null, observationEndMs = null;
let failure = null, ownedBrowserIdentity = null, browserAsset = null, independentlyFetchedAsset = null;
let pauseRequested = false, pausedObserved = false, lastEvalTimedOut = false, calls = [];
const event = (type, detail = {}) => {
  const item = { seq: ++eventSeq, atUTC: new Date().toISOString(), afterNavigationMs: navigationStart === null ? null : Date.now() - navigationStart, type, ...detail };
  events.push(item);
  process.stdout.write(JSON.stringify(item) + '\n');
};
await jsonFile('run-start.json', { startedAt, state: 'DIAGNOSTIC_ONLY_AFTER_ROOT_GO', sourceRoot, inputCount: 103, executableInputCount: 98, budgetMs,
  frozenBefore, sharedBefore, externalStart, buildEntry: contract.distEntry, entrySHA256: contract.distEntrySHA256,
  originalBrowser11: { rerun: false, sourceUntouched: true, priorFailurePreserved: true },
  scope: 'Same original browser engine/flags/viewport and fresh context; read-only event/DOM/state observations, diagnostic scheduling overhead. No command, Simulation.step, settings, player/NPC/time/account mutation or formal browser11/native/FPS result.' });
try {
  const require = createRequire(join(sourceRoot, 'package.json'));
  const { chromium } = require('playwright-core');
  server = spawn(process.execPath, [join(sourceRoot, 'node_modules/vite/bin/vite.js'), 'preview', '--host', '127.0.0.1', '--port', String(port), '--strictPort'], { cwd: sourceRoot, stdio: ['ignore', 'pipe', 'pipe'] });
  cleanup.serverIdentity = await processIdentity(server.pid);
  server.stdout.on('data', data => { serverRaw += data; }); server.stderr.on('data', data => { serverRaw += data; });
  for (let n = 0; n < 100; n++) {
    if (server.exitCode !== null) throw new Error(`Own preview exited ${server.exitCode}`);
    if (serverRaw.includes(`http://127.0.0.1:${port}`)) break;
    if (n === 99) throw new Error('Own strict preview ready marker missing');
    await wait(100);
  }
  const served = await fetch(`http://127.0.0.1:${port}/`, { signal: AbortSignal.timeout(5000) });
  const servedHTML = await served.text();
  assert.equal(served.status, 200);
  assert.equal(servedHTML.match(/<script[^>]+src="([^"]+\.js)"/)?.[1], contract.distEntry);
  const response = await fetch(`http://127.0.0.1:${port}${contract.distEntry}`, { signal: AbortSignal.timeout(5000) });
  const bytes = Buffer.from(await response.arrayBuffer());
  independentlyFetchedAsset = { status: response.status, bytes: bytes.length, sha256: hash(bytes) };
  assert.equal(response.status, 200); assert.equal(hash(bytes), contract.distEntrySHA256);
  event('owned-server-provenance', { serverPID: server.pid, independentlyFetchedAsset, servedEntry: contract.distEntry });
  browser = await chromium.launch({ executablePath: process.env.YUNSHAN_CHROMIUM ?? '/usr/bin/chromium', headless: true,
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  const browserCDP = await browser.newBrowserCDPSession();
  try {
    const info = await bounded(browserCDP.send('SystemInfo.getProcessInfo'), 3000, 'browser process identity');
    const own = info.processInfo.find(item => item.type === 'browser');
    if (own) ownedBrowserIdentity = await processIdentity(own.id);
  } catch (error) { event('browser-identity-unavailable', { error: String(error) }); }
  page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  page.on('console', message => event('console', { level: message.type(), text: message.text().slice(0, 8000), location: { url: safeURL(message.location().url), lineNumber: message.location().lineNumber } }));
  page.on('pageerror', error => event('pageerror', { name: error.name, message: error.message, stack: error.stack?.slice(0, 8000) }));
  page.on('requestfailed', request => event('requestfailed', { url: safeURL(request.url()), method: request.method(), resourceType: request.resourceType(), failure: request.failure()?.errorText }));
  page.on('domcontentloaded', () => event('DOMContentLoaded'));
  page.on('load', () => event('load'));
  page.on('crash', () => event('page-crash'));
  page.on('response', response => {
    const url = new URL(response.url());
    if (url.origin !== `http://127.0.0.1:${port}`) return;
    observedResponses.push({ atUTC: new Date().toISOString(), url: safeURL(response.url()), status: response.status(), resourceType: response.request().resourceType() });
    if (url.pathname === contract.distEntry) {
      calls.push(bounded(response.body(), 5000, 'browser-loaded entry body').then(body => { browserAsset = { status: response.status(), bytes: body.length, sha256: hash(body) }; event('browser-loaded-entry', browserAsset); }).catch(error => event('browser-loaded-entry-unavailable', { error: String(error) })));
    }
  });
  // This adds observation-only browser globals/timers; no production callable is wrapped.
  await page.addInitScript(() => {
    const observation = window.__BOOT10_OBSERVATION__ = { initializedAt: performance.now(), rafCount: 0, intervalCount: 0, lastRAFAt: null, timeline: [], longTasks: [] };
    const capture = label => {
      const diagnostics = window.__YUNSHAN__, state = diagnostics?.simulation?.state;
      const sample = { label, at: performance.now(), readyState: document.readyState, hidden: document.hidden,
        stage: !!document.querySelector('.world-stage'), canvasCount: document.querySelectorAll('canvas').length,
        panel: !!document.querySelector('[data-testid="panel-toggle"]'), startupError: document.querySelector('.startup-error')?.textContent?.slice(0, 600) ?? null,
        debugPresent: !!diagnostics, tick: state?.tick ?? null, paused: state?.paused ?? null, order: state?.lastSystemOrder ? [...state.lastSystemOrder] : null };
      observation.timeline.push(sample); if (observation.timeline.length > 220) observation.timeline.shift();
    };
    document.addEventListener('readystatechange', () => capture('readystatechange'));
    document.addEventListener('DOMContentLoaded', () => capture('DOMContentLoaded'));
    window.addEventListener('load', () => capture('load'));
    document.addEventListener('visibilitychange', () => capture('visibilitychange'));
    let priorMarkers = '';
    new MutationObserver(() => {
      const markers = [!!document.querySelector('.world-stage'), document.querySelectorAll('canvas').length, !!document.querySelector('[data-testid="panel-toggle"]'), !!document.querySelector('.startup-error')].join(':');
      if (markers !== priorMarkers) { priorMarkers = markers; capture('DOM-stage-change'); }
    }).observe(document, { childList: true, subtree: true });
    setInterval(() => { observation.intervalCount++; capture('interval'); }, 500);
    const frame = at => { observation.rafCount++; observation.lastRAFAt = at; if (observation.rafCount <= 4) capture('probe-raf'); requestAnimationFrame(frame); };
    requestAnimationFrame(frame);
    try { new PerformanceObserver(list => { for (const entry of list.getEntries()) observation.longTasks.push({ startTime: entry.startTime, duration: entry.duration, name: entry.name }); }).observe({ type: 'longtask', buffered: true }); } catch {}
    capture('init-script');
  });
  cdp = await page.context().newCDPSession(page);
  await cdp.send('Performance.enable');
  cdp.on('Debugger.paused', data => {
    pausedObserved = true;
    event('single-diagnostic-debugger-pause', { reason: data.reason, callFrames: data.callFrames.map(frame => ({ functionName: frame.functionName,
      url: safeURL(frame.url), lineNumber: frame.location.lineNumber, columnNumber: frame.location.columnNumber })) });
    // Do not use paused time as simulated time, native interaction or performance evidence.
    calls.push(cdp.send('Debugger.resume').then(() => event('diagnostic-debugger-resumed')).catch(error => event('diagnostic-debugger-resume-error', { error: String(error) })));
  });
  navigationStart = Date.now();
  event('navigation-start', { url: `http://127.0.0.1:${port}/?debug=1`, waitUntil: 'commit', budgetMs });
  await page.goto(`http://127.0.0.1:${port}/?debug=1`, { waitUntil: 'commit', timeout: budgetMs });
  event('navigation-committed');
  const snapshot = async label => {
    try {
      const value = await bounded(page.evaluate(() => {
        const d = window.__YUNSHAN__, s = d?.simulation?.state, r = d?.city?.renderer?.info;
        return { at: performance.now(), url: location.origin + location.pathname + location.search, readyState: document.readyState, hidden: document.hidden,
          debugQueryPresent: new URLSearchParams(location.search).has('debug'), debugPresent: !!d, debugKeys: d ? Object.keys(d) : [],
          worldStage: !!document.querySelector('.world-stage'), canvasCount: document.querySelectorAll('canvas').length, panel: !!document.querySelector('[data-testid="panel-toggle"]'),
          startupError: document.querySelector('.startup-error')?.textContent ?? null, bodyTextPrefix: document.body?.innerText?.slice(0, 1500) ?? '',
          simulation: s ? { tick: s.tick, day: s.day, hour: s.hour, paused: s.paused, speed: s.speed, accumulator: d.simulation.runtime?.accumulator ?? null,
            lastSystemOrder: [...s.lastSystemOrder], weather: s.weather, visibility: s.visibility, citizenCount: s.citizens.length } : null,
          renderer: r ? { render: { ...r.render }, memory: { ...r.memory }, residency: d.city.scene.userData.buildingResidency ?? null } : null,
          observation: window.__BOOT10_OBSERVATION__ ?? null,
          resources: performance.getEntriesByType('resource').map(entry => ({ name: new URL(entry.name).origin + new URL(entry.name).pathname, initiatorType: entry.initiatorType, duration: entry.duration, transferSize: entry.transferSize })),
          navigation: performance.getEntriesByType('navigation').map(entry => ({ responseEnd: entry.responseEnd, domContentLoadedEventEnd: entry.domContentLoadedEventEnd, loadEventEnd: entry.loadEventEnd })) };
      }), Math.min(3000, Math.max(1, budgetMs - (Date.now() - navigationStart))), 'read-only page snapshot');
      lastEvalTimedOut = false; snapshots.push({ label, atUTC: new Date().toISOString(), value });
      event('snapshot-returned', { label, debugPresent: value.debugPresent, tick: value.simulation?.tick ?? null, readyState: value.readyState, rafCount: value.observation?.rafCount ?? null });
    } catch (error) { lastEvalTimedOut = true; snapshots.push({ label, atUTC: new Date().toISOString(), error: String(error) }); event('snapshot-unavailable', { label, error: String(error) }); }
    try {
      const metrics = await bounded(cdp.send('Performance.getMetrics'), Math.min(1500, Math.max(1, budgetMs - (Date.now() - navigationStart))), 'CDP metrics');
      event('CDP-metrics', { label, metrics: metrics.metrics.filter(m => ['Timestamp', 'TaskDuration', 'ScriptDuration', 'LayoutDuration', 'JSHeapUsedSize', 'Nodes', 'Frames', 'LayoutCount', 'RecalcStyleDuration'].includes(m.name)) });
    } catch (error) { event('CDP-metrics-unavailable', { label, error: String(error) }); }
  };
  const screenshot = async (label, filename) => {
    const remaining = budgetMs - (Date.now() - navigationStart);
    if (remaining <= 0) { event('screenshot-unavailable', { label, error: '90s observation window ended; no extended wait or synthetic image' }); return; }
    try { await page.screenshot({ path: join(output, filename), timeout: Math.min(5000, remaining) }); event('screenshot-recorded', { label, filename }); }
    catch (error) { event('screenshot-unavailable', { label, error: String(error) }); }
  };
  const checkpoints = [0, 1000, 5000, 15000, 30000, 60000, 80000, 88000];
  for (const target of checkpoints) {
    const remaining = target - (Date.now() - navigationStart);
    if (remaining > 0) await wait(remaining);
    if (Date.now() - navigationStart >= budgetMs) break;
    await snapshot(`elapsed-${target}`);
    if (target === 0) await screenshot('initial', 'observed-page-initial.png');
    if (lastEvalTimedOut && target >= 80000 && !pauseRequested && Date.now() - navigationStart < budgetMs - 3000) {
      pauseRequested = true;
      event('single-debugger-pause-request', { caution: 'Diagnostic intervention only; no normal/native/FPS claim' });
      try { await bounded(cdp.send('Debugger.enable'), 1000, 'enable single diagnostic pause'); await bounded(cdp.send('Debugger.pause'), 1000, 'single diagnostic pause'); }
      catch (error) { event('single-debugger-pause-unavailable', { error: String(error) }); }
    }
    const current = snapshots.at(-1)?.value;
    const earlier = snapshots.find(item => item.value?.simulation?.tick >= 1)?.value;
    if (target >= 15000 && current?.simulation?.tick >= 1 && current?.renderer?.render?.calls > 0 && earlier && current.simulation.tick > earlier.simulation.tick) {
      event('sufficient-independent-live-observations', { caution: 'Observation scope only, not any browser11 assertion' }); break;
    }
  }
  await screenshot('final', 'observed-page.png');
  observationEndMs = Date.now() - navigationStart;
} catch (error) { failure = String(error); event('probe-error', { error: failure }); }
finally {
  if (observationEndMs === null && navigationStart !== null) observationEndMs = Date.now() - navigationStart;
  if (browser) {
    try { await bounded(browser.close(), 10_000, 'owned browser.close'); cleanup.browserClose = 'resolved'; }
    catch (error) { cleanup.browserClose = String(error); }
  }
  if (ownedBrowserIdentity) cleanup.browserIdentityAfter = await processIdentity(ownedBrowserIdentity.pid);
  if (server) {
    if (server.exitCode === null) { cleanup.serverTERMRequested = true; server.kill('SIGTERM'); }
    for (let attempt = 0; attempt < 50 && server.exitCode === null; attempt++) await wait(100);
    cleanup.serverExitCode = server.exitCode; cleanup.serverSignalCode = server.signalCode;
    cleanup.serverIdentityAfter = await processIdentity(server.pid);
  }
  cleanup.portReleased = await vacant(port).catch(error => String(error));
  await Promise.allSettled(calls);
  const frozenAfter = await hashes(sourceRoot, frozenNames), sharedAfter = await hashes(sharedRoot, executableNames);
  const externalEnd = { probe: hash(await readFile(new URL(import.meta.url))), contract: hash(await readFile(join(here, 'source-contract.json'))) };
  const entryAfterSHA256 = hash(await readFile(join(sourceRoot, 'dist', contract.distEntry.slice(1))));
  await writeFile(join(output, 'server.log'), serverRaw);
  await jsonFile('events.json', events); await jsonFile('snapshots.json', snapshots); await jsonFile('observed-responses.json', observedResponses);
  const checks = { frozen103Stable: JSON.stringify(frozenBefore) === JSON.stringify(frozenAfter), sharedExecutable98Stable: JSON.stringify(sharedBefore) === JSON.stringify(sharedAfter),
    externalStable: JSON.stringify(externalStart) === JSON.stringify(externalEnd), entryStable: entryAfterSHA256 === contract.distEntrySHA256,
    independentHTTPMatches: independentlyFetchedAsset?.sha256 === contract.distEntrySHA256, browserLoadedEntryMatches: browserAsset?.sha256 === contract.distEntrySHA256,
    ownedPortReleased: cleanup.portReleased === true, browserClosed: cleanup.browserClose === 'resolved' };
  const recorded = !failure && Object.values(checks).every(Boolean);
  await jsonFile('run-manifest.json', { startedAt, endedAt: new Date().toISOString(), state: recorded ? 'DIAGNOSTIC_RECORDED' : 'DIAGNOSTIC_INCOMPLETE',
    failure, sourceRoot, inputCount: 103, executableInputCount: 98, frozenBefore, frozenAfter, sharedBefore, sharedAfter, externalStart, externalEnd,
    original11Rerun: false, formal11Result: null, nativeResult: null, performanceAcceptance: false,
    navigationWindowMs: observationEndMs, observationBudgetMs: budgetMs, cleanupOutsideObservationWindow: true,
    checks, independentlyFetchedAsset, browserAsset, buildEntry: contract.distEntry, entrySHA256: contract.distEntrySHA256, entryAfterSHA256,
    ownedBrowserIdentity, cleanup, debugger: { pauseRequested, pausedObserved, maxPauseCount: 1 },
    limitations: ['Original 0/11 failure remains unchanged', 'Read-only observation timers/CDP add overhead', 'Screenshot timeout is recorded; no blank image is synthesized', 'No throughput/FPS/Mac/art/native/full-city acceptance', 'No body, needs, identity, money, weather, time or command mutation by harness'] });
  console.log('DIAGNOSTIC_FINAL', JSON.stringify({ checks, recorded, failure, cleanup }));
  if (!recorded) process.exitCode = 1;
}

import os, json, time, signal, hashlib, datetime

ROOT = '/tmp/yunshan-coherent10-boot-diagnostic-01'
TARGET = 160524
EXPECTED_START = '9093305'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(pid):
    try:
        raw = open('/proc/%s/stat' % pid).read().split(') ', 1)[1].split()
        argv = [x.decode(errors='replace') for x in open('/proc/%s/cmdline' % pid, 'rb').read().split(b'\0') if x]
        profile = next((x.split('=', 1)[1] for x in argv if x.startswith('--user-data-dir=')), None)
        return {'pid': pid, 'ppid': int(raw[1]), 'state': raw[0], 'startTicks': raw[19], 'cwd': os.readlink('/proc/%s/cwd' % pid),
                'executable': argv[0] if argv else None, 'profile': profile,
                'headless': any(x == '--headless' or x.startswith('--headless=') for x in argv),
                'remoteDebuggingPipe': '--remote-debugging-pipe' in argv,
                'processType': next((x.split('=', 1)[1] for x in argv if x.startswith('--type=')), 'browser')}
    except OSError as error:
        return {'pid': pid, 'unavailable': str(error)}

def chromium_rows():
    result = []
    for name in os.listdir('/proc'):
        if not name.isdigit():
            continue
        try:
            comm = open('/proc/' + name + '/comm').read().strip()
            if comm != 'chromium':
                continue
            result.append(identity(int(name)))
        except OSError:
            pass
    return result

contract = json.load(open(ROOT + '/source-contract.json'))
skip = {'.gitattributes', '.gitignore', 'AGENTS.md', '开发备忘录.md', '提示词.md'}
def hashes(root, names):
    return {name: hashlib.sha256(open(root + '/' + name, 'rb').read()).hexdigest() for name in names}
before = identity(TARGET)
frozen_start = hashes(contract['sourceRoot'], contract['copiedHashes'])
shared_start = hashes('/workspace/yunshan', [n for n in contract['copiedHashes'] if n not in skip])
receipt = {'startedAt': now(), 'authorization': 'Root approved only this diagnostic Chrome and proven exclusive-profile descendants, normal TERM; no broad kill',
           'target': TARGET, 'expectedStartTicks': EXPECTED_START, 'before': before, 'signals': [], 'treeBefore': [],
           'frozenStart': frozen_start, 'sharedExecutableStart': shared_start}
try:
    if 'unavailable' in before:
        receipt['action'] = 'NO_SIGNAL_TARGET_ALREADY_UNAVAILABLE'
    elif before['state'] == 'Z':
        receipt['action'] = 'NO_SIGNAL_ALREADY_ZOMBIE_NOT_EXECUTING'
    else:
        assert before['startTicks'] == EXPECTED_START, 'PID creation does not match: do not signal'
        assert before['executable'] in ['/usr/lib/chromium/chromium', '/usr/bin/chromium'], 'Executable does not match'
        assert before['headless'] and before['remoteDebuggingPipe'], 'Playwright browser identity does not match'
        assert before['profile'] and before['profile'].startswith('/tmp/playwright_chromiumdev_profile-'), 'Exclusive Playwright profile not proven'
        rows = chromium_rows()
        descendants = {TARGET}
        changed = True
        while changed:
            changed = False
            for row in rows:
                if row.get('ppid') in descendants and row['pid'] not in descendants:
                    descendants.add(row['pid'])
                    changed = True
        receipt['treeBefore'] = [row for row in rows if row['pid'] in descendants]
        other_browser = [row for row in rows if row.get('profile') == before['profile'] and row.get('processType') == 'browser' and row['pid'] != TARGET and row.get('state') != 'Z']
        assert not other_browser, 'Profile exclusivity is not proven'
        verified = identity(TARGET)
        assert verified == before, 'Identity changed while verifying: do not signal'
        pidfd = os.pidfd_open(TARGET)
        try:
            signal.pidfd_send_signal(pidfd, signal.SIGTERM)
            receipt['signals'].append({'pid': TARGET, 'startTicks': EXPECTED_START, 'signal': 'SIGTERM', 'atUTC': now(), 'pidfd': True})
        finally:
            os.close(pidfd)
        receipt['action'] = 'NORMAL_TERM_ONLY_VERIFIED_BROWSER'
        for _ in range(50):
            current = identity(TARGET)
            if 'unavailable' in current or current.get('state') == 'Z':
                break
            time.sleep(.1)
except Exception as error:
    receipt['guardError'] = str(error)
    receipt['action'] = 'NO_FURTHER_SIGNAL_GUARD_OR_DELIVERY_FAILED'
receipt['after'] = identity(TARGET)
rows_after = chromium_rows()
receipt['globalNonZombieChromiumCount'] = sum(row.get('state') != 'Z' and 'unavailable' not in row for row in rows_after)
profile = before.get('profile')
receipt['sameProfileAfter'] = [row for row in rows_after if profile and row.get('profile') == profile]
receipt['frozenEnd'] = hashes(contract['sourceRoot'], contract['copiedHashes'])
receipt['sharedExecutableEnd'] = hashes('/workspace/yunshan', [n for n in contract['copiedHashes'] if n not in skip])
receipt['frozen103Stable'] = receipt['frozenStart'] == receipt['frozenEnd'] == contract['copiedHashes']
receipt['sharedExecutable98Stable'] = receipt['sharedExecutableStart'] == receipt['sharedExecutableEnd'] == {n: h for n, h in contract['copiedHashes'].items() if n not in skip}
receipt['endedAt'] = now()
outfile = ROOT + '/cleanup-receipt.json'
assert not os.path.exists(outfile), 'Preserve prior cleanup evidence; no overwrite'
with open(outfile, 'w') as stream:
    json.dump(receipt, stream, ensure_ascii=False, indent=2)
print(json.dumps({key: receipt.get(key) for key in ['action', 'before', 'after', 'signals', 'guardError', 'globalNonZombieChromiumCount', 'frozen103Stable', 'sharedExecutable98Stable']}, ensure_ascii=False))

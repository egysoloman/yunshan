# ROOT26 native01：东区56份货物与真实柜台链

两笔实际卸货各28份，来自 `shop-core-dock-building` 与 `shop-river-b57`。完整交通→商业阶段差表明，两批各被 `shop-east-b37`、`shop-east-b50` 分别实际买入14份；累计每店28份。四笔原批发收据共224云币，供应方经营账户实际净增加206.08，原税队列增加17.92。两店各阶段付款与完整库存均对齐，没有补钱、补货或注入。

本报告只解码、哈希与分析既有文件，未构造、导入或步进Simulation，未运行tests/build/browser，未修改共享源代码及备忘录。范围仅 native01 的16次完整 ordinary 冷续，输入 tick2070/clock5340，终点 tick2086/clock5404；不外推长期稳态，也不引用后续 native02/03 结果。仓库只读HEAD核为 `65d7c6fd20701388aab0acdee327003333579b59`。

原件目录为 `/tmp/ROOT26-food-access-20261007-01/native01`。门回执 `/workspace/yunshan-work/ROOT26-food-access-20261007-01/native01-gate/receipt.json` 实际PASS，09:42:33.767463→09:44:21.684503 UTC，417输入稳定、无活跃后代；原raw SHA `ecac6527c67374e4301ce878a22aac35976f9a6366bede8162ee60a15ee102e2`。`RESULT.json` 为 `ACTUAL_COMPLETED`，1构造/1导入/16 ordinary/16返回/16完成/16 reader，0命令/0状态注入；SHA `1851236c0b79e91f4f1fe93ff919dc7ff9ba3f8afefa86f379a99eae6ed129da`。输入完整save SHA `6e4812acde393a9436dfe09f4b3994a3721ccaba6ddb972c9623a9e369d02d48`，终档 `4a7d83a4a98bf35c618ea3f98944c6776b8c4c620590d0aaac54a6a228aa5ef7`，均与帧描述符一致。

17帧×4描述符共68个文件的 encoded/raw 大小及SHA逐一吻合。16窗完整phase custody没有violations/captureFailures；原RESULT最大残差 cash2.9103830456733704e−10、food1.8189894035458565e−12、debt2.2737367544323206e−13、fiscal2.3001689442025963e−10。机器汇总同目录 `NATIVE01-EAST-FREIGHT-CHAIN.json` 保留全部帧描述符、原事件序号、逐商业阶段资金/保护额、库存、真实销售、完整终点资金分解及四名居民的前后字段。文件分析脚本为 `analyze-native01-east-files.py`，只使用Python文件/JSON/gzip/hash/arithmetic。

| 原动作 | tick / clock | 完整阶段事实 |
|---|---:|---|
| cargo-arrived seq444，core dock→east | 2074 / 5356 | 交通前district freight0、core车载28；交通后freight28、唯一FIFO lot为core28，cargoSource清除，完整同窗save车cargo0。 |
| 同窗commerce | 2074 / 5356 | 未到batch（commerceAt5362），core28原lot完整保留，没有立即入b37柜台库存。 |
| wholesale seq839/840 | 2076 / 5364 | core FIFO28→0；b37库存0→14、无销售；b50库存0→11、真实销售3，所以实际新增14。两店各买14。 |
| cargo-arrived seq1111，river-b57→east | 2079 / 5376 | 交通前freight0、river车载28；交通后freight28、唯一FIFO lot为river28，cargoSource清除，完整同窗save车cargo0。 |
| wholesale seq1227/1228 | 2079 / 5376 | river FIFO28→0；b37库存14→28、无销售；b50库存3→11、真实销售6，所以实际新增14。两店各买14。 |

两辆车分别为 `vehicle-road-summit-quarter-0-summit-station-1`、`vehicle-road-river-quarter-3-river-station-1`，原卸货节点均为 `east-b37-door`。该节点是实际东区卸货入口，不能由节点名认定全部28份归b37；货物进入district FIFO后，两店才分别真实付款采购。输入save中两车已各持有28份，因此本窗证明的是既有车载物的交付、保管与购买；上游装车/生产发生在本窗以前，不能冒称本窗观察到新生产这56份。货物出车后在trace的 `freightVehicles` 过滤数组中消失，另以完整同窗save车辆cargo0核验，未把过滤数组缺项当作独立卸货证据。

`wholesale` 原payload只有供应方 `shopId`、供应方 `districtId`、amount、quantity、unitPrice，**没有retailId**。每对payload完全同形，都是14份、56云币、单价4。阶段买方归属用唯一FIFO来源、全部东区food-shop custody、真实销售回加与经营资金差确定；两店各14在阶段层面可唯一核定。原单条事件没有标记买方，机器汇总保留 `retailBuyerAttributedToSingleEvent:null`。源 `simulation.ts:2053` 的店铺遍历顺序可提供顺序推断，本报告没有把顺序推断写成原事件携带的零售ID，也不虚造一笔带retailId的批发收据。

| 商业时点/买方 | 实际付款前经营资金 | 原保护额（工资债+已承诺工资） | 可用资金 / 可负担整份 | 采购后同phase经营资金 | 库存与真实同phase销售 |
|---|---:|---:|---:|---:|---|
| 5364 b37 | 2106.3180957871646 | 0 | 2106.3180957871646 / 526 | 2050.3180957871646 | 0+14−0=14 |
| 5364 b50 | 1297.925893920907 | 21.775843811566972（5.882035649122764+15.89380816244421） | 1276.1500501093399 / 319 | 1285.0717580978708 | 0+14−3=11 |
| 5376 b37 | 2050.3180957871646 | 0 | 2050.3180957871646 / 512 | 1994.3180957871646 | 14+14−0=28 |
| 5376 b50 | 1402.6664732480408 | 21.775843811566972（11.77873964912273+9.997104162444243） | 1380.8906294364738 / 345 | 1434.6958429440015 | 3+14−6=11 |

每店每批只扣实际56；b50的同phase现金还包含真实零售净收入，5376还扣真实 business-expense seq1234 的1/6云币。不能把它的现金净增或较小净扣款当作免费采购。两次b50保护总额不变，但工资债增加、未来承诺减少；原保护字段保留，不抹去债务。5364 b50三笔销售seq841/842/843各1份、共46.897678453221586云币；5376 b50销售seq1229..1233合6份、共95.86525691589973云币。四个买方阶段现金等式的最大残差4.192202140984591e−13。

采购有限守卫来自 `src/simulation.ts:2067–2080`：district现货>0、site为market、采购起始库存<36；while还要求每店received<14、库存<70、实际经营资金≥4；quantity取FIFO现量、余下14份额度、余下70容量、floor(max(0,funds−protected)/原单价)、供应方1e9现金上限空间的最小值。此处采购条件并未以 `shop.open` 或 `employees>0` 为前置条件；柜台销售另有营业守卫。两次实际单价均4、所有买方可用额远高于56，真正买足每批14；本窗没有证据将其截断归咎为买方资金不足。供应方实付净入账后也远未到1e9上限。

core供应方5364实际独立经营账户92.78234451413626→195.82234451413626，river供应方5376实际0→103.04；各为112gross−8.96tax。每笔原wholesale前后的下一条原bus税队列读数都增加4.48，四笔合17.92；原税率0.08。`simulation.ts:909` 向税队列计批发税，`simulation.ts:2177` 直接将整个税队列转入treasury并清零，没有独立tax-collection事件。两批同窗完整save税队列均0；finance包含其他销售、公共采购与费用，不能把全财政净变化专归这17.92，也不能虚造逐供应方专属征税事件。机器汇总保留每笔下一事件税队列见证及commerce/finance的treasury与treasury+queue。

全窗两店库存与现金端点如下；东区终档freight0/FIFO空。b50的52份销售包含输入已有24份，所以柜台合57份不能写成“这56份进口货全部售出57份”。

| 店铺 | 初始库存 + 实际采购 − 实际销售 = 终档 | 全窗柜台gross / net / tax | 经营资金初始→终档 |
|---|---|---:|---:|
| b37 | 0+28−5=23 | 93.85723121832281 / 86.34865272085699 / 7.50857849746582 | 2169.4825729764584→2020.1667460527808 |
| b50 | 24+28−52=0 | 821.4000660350426 / 755.6880607522393 / 65.71200528280337 | 981.8052855174154→1599.5458543707973 |

b37原 ownerId=`citizen-19`、employees0。其第一笔实际柜台销售在5396：seq1785/1786/1787，citizen76/252/604各1份，库存28→25；5404 seq1997，citizen10买2份，库存25→23。它在拥有库存后确实能成交，employees0不能直接认定该店无法销售。b37实际两笔 business-dividend seq117/2028 给业主19，分别63.16447718929375与60.50000245524065。端点经营现金完整等式为初始−采购112+销售net86.34865272085699−分红123.6644796445344=终档，残差−1.9895196601282805e−13；第二笔分红位于最后finance，不能用最后commerce现金2080.6667485080216冒充终档2020.1667460527808。b50 owner151，分红seq118实际25.614158565522462、全窗business-expense合1/3；端点等式残差−1.5916157281026244e−12。分红来源机制见 `simulation.ts:2185–2191`。

450原 sale seq1084，tick2078/clock5372，在b50真实柜台位置 `(1167.0000000000002,207,−482.20000000000005)`，qty2、cost31.955085638633243。前后钱325.46933460446945→293.5142489658362、饱足0→52、food0→1；真实customer从b50→null，身体未注入。b50原24份已在5360耗尽，5364 core批买14后5368售4、5372再售4，此时river批尚未在5376卸货，因此450这次2份可以依时间与完整库存归首core批。5376后两来源同单价4的owned成本lot合并，`src/simulation/trade.ts:95–103` 不保留各来源的独立份数/identity；后续具体单个顾客每份究竟来自core还是river不可仅靠终档lot唯一归属，本报告保留这一边界。

457/489/153首people时点2071均将destination从b37重选b50，并真实移动；它们本窗没有sale事件，终档customer均null。钱分别235.05945833189793、391.92475191069894、516.1438556454765，food0，终档饱足分别2.300000000000159、2.300000000000159、11.900000000000116。它们是statistical tier，普通频率为16，源 `simulation.ts:1836–1843` 按 `(tick+实际数组index)%frequency` 积攒pending分钟，不能按ID字符串或 `tick-index` 计算。三者2071处理后下一普通轮次2087，超出本窗终点2086；终档pending60。没有再次people移动不能据此认定路线卡死，也不能由b50后续归零推断整窗没食物：完整记录显示它在5364–5388多次真实销售。

下一步应继续保留真实people轮次前后pending、tier、任务频率例外、decisionAt/活动、完整route/routeIndex/目的地、rider/stairCursor、position与customer绑定，以及同phase商铺funds/protected/库存/owned与consigned成本账；只有真实柜台接触后，再检查 `simulation.ts:2002–2038` 的guard：时间/能源/insolvent/lifecycle、alive、敌意与玩家产权、food商品、destination与shopping状态、hunger≤78、有限个人钱与库存、建筑距离、合法sale功能点与voxel阻挡、计数上限、成本账有效、供应方应付gross与零售净收入、各经营账户1e9容量。缺货只是其中一项。保留真实customer/sale/stored-meal/cargo-arrived/wholesale事件及完整phase回执，出现多个供应方/买方时用完整库存和现金分组，无法唯一归属则记不确定，不按结果补造事件。

机器汇总内逐frame保存真实柜台收据和阶段差，可直接接续查证，不需要重新运行已完成窗。native01证明有限交付、有限采购与一些真实恢复；剩余低饱足、到柜台时效与长时财政/供粮稳态仍未由这16窗封闭证明。

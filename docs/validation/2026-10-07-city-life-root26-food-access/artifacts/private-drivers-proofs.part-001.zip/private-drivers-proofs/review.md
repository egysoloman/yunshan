# ROOT26 供粮可达性只读审阅

2026-10-07，HEAD `65d7c6fd20701388aab0acdee327003333579b59`。只读原件/静态源核，0 Sim、0 step、0 tests/build/browser；未改 src、备忘录或旧 STOPWRITE 目录。本文没有 ROOT26 运行结果。root 独占新 cold import 后16普通窗实际门；是否重选、卸货、补货或吃饭全部须取新原phase/ALLbus，不预写 PASS 或原因。

## 原始端点与四人

完整native04终档 `/tmp/ROOT24-economy-next-day-20261007-01/native04/frames/0017-ordinary-016/whole-save.json.gz` 解压3207121B、SHA `6e4812acde393a9436dfe09f4b3994a3721ccaba6ddb972c9623a9e369d02d48`，clock5340/tick2070/hour17、speed16；commerceAt5350、taxRate0.08、无powerGrid，east energy66.36355330168696。保存声明 nearby-food-v1、road-food-pickup-v1、road-food-delivery-v1、npcMotionVersion2。既有115低饱足JSON SHA `a2342fd54d42f96878f621190655cb73d982bce90fa809f6feec8a20a5d9c232`；来源与本次四人/车辆/对方快照见 [review-snapshot.json](/workspace/yunshan-work/ROOT26-food-access-20261007-01/review-snapshot.json)。hunger是饱足量，高值表示较饱；表中岗位只用原role/workId，未推断isEmployed。

| 居民 | 原state | 目标 | 饱足 | 钱包 | food | people pending分钟 | decisionAt | 原保存route余程m |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| citizen-457 | shopping | east-b37 | 5.500000000000159 | 235.05945833189793 | 0 | 60 | 5308.177302622935 | 0 |
| citizen-489 | shopping | east-b37 | 5.500000000000159 | 391.92475191069894 | 0 | 60 | 5320.991180494893 | 0 |
| citizen-153 | moving | east-b37 | 15.100000000000115 | 516.1438556454765 | 0 | 60 | 5316.064978541108 | 815.3246046817816 |
| citizen-450 | moving | east-b50 | 0 | 325.46933460446945 | 0 | 32 | 5345.2515690664295 | 70.78359197699399 |

457/489原位同为(1062.6,172.6,-196.8)，routeIndex=routePointCount，目标east-b37保存open=true/stock0/price19.182557120508253。153也以east-b37为目标但仍moving、余程815.3246m；450仍moving、目标east-b50 stock24/open=true/price15.33677327244797。四人原activity=eat/food0/rider=null/dispatch=null，原actorProfiles均alive。**四人terminal runtime.customers均无项**；先前5280两人的customer事件不等请求一直保存到5340。commerce batch结束会清整个customers字典。[simulation.ts:2133](/workspace/yunshan/src/simulation.ts:2133)

原实际数组索引依次457/489/153/450，不是从姓名猜。仅按当前statistical频率16的静态模运算，前三人首未来处理tick2071（第1 ordinary），450为2078（第8）；若持续任务例外、tier或actor序列改变，则由新真实phase为准。频率例外包括research/road/power/clinical/education/hygiene/civic，须随phase记录，不把tier文字当已处理证明。[simulation.ts:1836](/workspace/yunshan/src/simulation.ts:1836) elapsed是原pending＋本窗实际分钟；跳过处理仍积pending，实际处理才删除pending、衰减饱足、消耗随身餐。[simulation.ts:1841](/workspace/yunshan/src/simulation.ts:1841)

## people 重选与真实到柜台

1. 必须先实际轮到此actor。alive=false清路线/骑乘后跳过；幼儿、未到站rider、警务dispatch、road任务与roadWaiting可在后续分支提前返回。捕获actorProfiles alive/age/health、frequency/当前索引、peopleElapsed、riders/dispatches及持续任务来源；未记录的内部branch标NOT_CAPTURED，不从端点反推。
2. 原meal policy + previousActivity=eat + now≥decisionAt（1e-7容差）才有reconsiderMeal。committedNeed还包含roadWaiting、未到重选时刻且旧食店开/有货/钱包≥价、rest/heal/work与clinical commitment；不能只有“旧店stock0”就说此步一定执行chooseFacility。[simulation.ts:1905](/workspace/yunshan/src/simulation.ts:1905) 真choice更新destination/activity与decisionAt=now+25+random×35；记完整前后原随机种子/运行时状态，不另调用random或chooser。[simulation.ts:1908](/workspace/yunshan/src/simulation.ts:1908)
3. 食品offer筛选先核commodity food、open、inventory≥1、钱≥列价；有玩家店仇恨还会拒。跨区且离门>1200m的店不入候选。walking anchors/tree到目标node的成本必须finite，评分为需要分减min(150,travel/12)。低饱足<30加260，只是偏好分；保留其他更高活动的选择。[simulation.ts:1592](/workspace/yunshan/src/simulation.ts:1592) [simulation.ts:1606](/workspace/yunshan/src/simulation.ts:1606) nearby-food-v1只在赢家为eat且**原分数严格相同**时比较实际travel，不能把欧氏nearest76.3m或候选154店说成合法最短路或保证切到east-b53。[meal-route.ts:6](/workspace/yunshan/src/simulation/meal-route.ts:6)
4. setDestination核功能点purpose=sale、各经过楼层权限、原floorplan route/柜台/体素与实际road prefix；同目标有效旧route可能保留。捕获destination/完整route或原routePool关联SHA、index、last target、position、npcStairCursors、road revision/block/exit permit、floorPlanProfile、身份/可达功能点。看见新destination不等路线可行；看见moving不等已到柜台。[simulation.ts:1356](/workspace/yunshan/src/simulation.ts:1356)
5. 真实move未完成就continue；完成后仍须isNearBuilding及合法activity功能点，失败为unreachable并清destination。[simulation.ts:1927](/workspace/yunshan/src/simulation.ts:1927) 只有实际eat到点才shopping并emit customer，由监听器写runtime.customers。[simulation.ts:1974](/workspace/yunshan/src/simulation.ts:1974) [simulation.ts:915](/workspace/yunshan/src/simulation.ts:915) 对450尤须串起原余程→实际arrival/position→customer→sale，不能用饱足0猜死亡或已获救。

## commerce 销售：缺货仅是一项必要守卫

| 需逐原字段核实的条件 | 实际源位置/要点 |
| --- | --- |
| 请求确实存在且shopId对应 | runtime.customers中必须有该人；shopping标签不自行生成请求。[simulation.ts:2008](/workspace/yunshan/src/simulation.ts:2008) |
| 当前phase营业许可 | between-batch走retailOpenAtPhase，直接核hour≥6且market<22/其他<20、实时电力ratio>.25或district.energy>25、非insolvent、lifecycle/title/lease允许；不能只读保存shop.open。[simulation.ts:2002](/workspace/yunshan/src/simulation.ts:2002) batch会重算open。[simulation.ts:2055](/workspace/yunshan/src/simulation.ts:2055) |
| 活体与玩家店关系 | actor alive不是false；hostilityRank≥2且玩家拥有该店会拒。[simulation.ts:2011](/workspace/yunshan/src/simulation.ts:2011) |
| 食物/目标/实际状态/饱足/钱/库存 | shopCommodity=food、destination=building、state=shopping、hunger≤78、money≥**列价**shop.price、inventory≥1。[simulation.ts:2013](/workspace/yunshan/src/simulation.ts:2013) trust>55折价在这个列价guard之后，不能凭打折价说列价guard已过。 |
| 原身体真正处在可交易位置 | 到building.position距离≤max(width,depth)/2+3；floorplan还须sale点/合法楼层/room或stairs、距点≤默认2m及无voxel阻塞。没有单独owner到店或employees>0的销售guard，不能由east-b37 employees0断言没人卖。[simulation.ts:2014](/workspace/yunshan/src/simulation.ts:2014) [simulation.ts:2350](/workspace/yunshan/src/simulation.ts:2350) |
| 真可卖数量与计数上限 | quantity=min(food<1?2:1,floor(money/discountedPrice),floor(stock))；between-batch countedUnits是retailSalesSinceBatch，batch用shop.customers；加quantity不能>100000。[simulation.ts:2022](/workspace/yunshan/src/simulation.ts:2022) |
| 原货权/成本账报价可结算 | quoteConsignmentSale可能因ownedLots与库存不一致、寄售量/货主引用/legacy资格、供应者现金headroom等抛错而continue；没有原quote/账本，不猜失败原因。[trade.ts:143](/workspace/yunshan/src/simulation/trade.ts:143) [trade.ts:180](/workspace/yunshan/src/simulation/trade.ts:180) |
| 有限经营账户接收款项 | net=cost×(1-taxRate)须≥supplierGross，retailFunds+net−supplierGross≤1e9；绑定公司capital代替shop.cash，不双加。[simulation.ts:2028](/workspace/yunshan/src/simulation.ts:2028) [simulation.ts:438](/workspace/yunshan/src/simulation.ts:438) |

成功才钱包扣cost、stock扣quantity、饱足+52、food加quantity−1、fun+8、owned/consigned lots结算、经营净现金变化并删除此request，最后emit sale。[simulation.ts:2029](/workspace/yunshan/src/simulation.ts:2029) 原NPC即食购买没有独立food-consumed事件，须以sale及完整needs/food差串起；stored-meal是下一people消费已携带餐的独立事件。失败请求可在between-batch保留，但**batch结尾整字典清空**，必须保before/after请求和customer源，而不是期待一个不存在的永久队列。shop.customers数的是销量，不等客人数。

## 补货、货运与有限对方

原east-b37经营cash2169.4825729764584/owner citizen-19、非公司绑定；原无该店private shift/欠薪/新应计工资/租约标题，stock0、ownedLots/consignmentLots无项。east-b50经营cash981.8052855174154/owner citizen-151，stock24，ownedLots10@4(created3730)+14@4.78(created5088)，有原day3两名已承诺工资班次。新phase还须核cash保护额，不能用cash总额直接当采购可用额。shopProtectedFunds=工资欠债＋同日剩余承诺工资＋租约reserved；company.capital或shop.cash只选其一。[simulation.ts:438](/workspace/yunshan/src/simulation.ts:438)

原east区freight=0、freightLots=[]；原World+shops中east当地farm/dock数量**0**。因此“当时本区直接采购/食品寄售没有当地producer候选”是端点事实；不推出跨区运不来、全国没粮或下一门必无补货。局部三条库存路径须分别捕获：

- **地区已卸货FIFO采购**：batch且market stock<36、district freight>0；每batch≤14、库存<70、funds≥4，从freightLots队首按货主quote unitPrice算quantity，受可用funds−protected、货主1e9 headroom、队首lot量限制。quote.quantity不是这条路径的限量：食品已经在车/区custody，原producer剩余stock0也能给unitPrice。实际retail扣gross、source收net并wholesale；null货主走原价4/business-expense进公库；lot/freight减与retail/ownedLots增一一对应。[simulation.ts:2067](/workspace/yunshan/src/simulation.ts:2067)
- **同区producer付费采购**：店open、market、stock<36、funds≥4，候选同区farm/dock/food/stock≥1，按原stock排序；quote.quantity、70库存界、retail可用钱、supplier现金headroom都限制整单位数量。producer原stock减少、retail库存增加、buyer gross/source net/税与ownedLots真实记账，并wholesale。某第一候选quantity≤0会break，不能只拿其他有货候选代替原迭代顺序。[simulation.ts:2090](/workspace/yunshan/src/simulation.ts:2090)
- **同区有限寄售**：店open/market/stock<4，supplyConsignment只搬当地既有food producer库存，不提前付款。target=min(70,max(4,近期180分钟真实sold))，报价还须≤retail列价×(1−tax)+EPS；真实trade.lots持有供应者货权，顾客真sale才原批次成本结算给供应者。没有专门consignment-supplied源事件，捕获库存/lots/nextLotId/stats/activity before/after；不能虚构采购事件。[simulation.ts:2103](/workspace/yunshan/src/simulation.ts:2103) [trade.ts:108](/workspace/yunshan/src/simulation/trade.ts:108)

quoteSupply以真实最近180分钟produced、earnedLaborCost、actualUtilities作税前成本报价，旧未观测stock原价4；读quote quantity/unitPrice/costWindowUnits/earnedLaborCost/actualUtilities、原activity buckets及clock，不能拿零售price当供应价。[trade.ts:85](/workspace/yunshan/src/simulation/trade.ts:85) 原producer生成食品另需open、真实productiveLabor、能源、tech及120库存界；employees0不自行生产但不抹掉已有stock。[simulation.ts:2082](/workspace/yunshan/src/simulation.ts:2082)

原已载货且位于 `road-east-b37-door-east-station` 的两车：

| 实际载具 | cargoSources原货主 | cargo | 原state | progress / direction |
| --- | --- | --- | --- | --- |
| vehicle-road-river-quarter-3-river-station-1 | shop-river-b57 | 28 | boarding | 1 / -1 |
| vehicle-road-summit-quarter-0-summit-station-1 | shop-core-dock-building | 28 | moving | 0.5969252135019455 / -1 |

river-b57是farm，原producer stock132/cash0/owner citizen-11；core-dock-building是dock，原producer stock0/cash93.67252011766624/owner citizen-17。两车各28已在真实custody，不把源stock0重复扣成“货不存在”；它们原位置还不是卸货证明。完整位置/edge/cargo与来源账户在快照JSON。

装车须原声明carrier、真实容量、空cargo与客运人数界，到真实producer门node/开放同mode edge、端点progress/direction、原lane offset位置和2m LOADING_REACH；真实producer库存减、vehicle cargo增、cargoSources绑定并emit cargo-loaded。[freight-access.ts:48](/workspace/yunshan/src/simulation/freight-access.ts:48) [simulation.ts:1123](/workspace/yunshan/src/simulation.ts:1123) 没有新采购现金在交通装车阶段支付。

新declared road-food-delivery路由按当前retail有限funds/protected、地区已有FIFO lots、供应者报价/账户headroom算三轮14批可接受数，且acceptableUnits≥完整cargo才选开放road图可达门node；是有限派送选择，不是未来收据。[freight-delivery.ts:30](/workspace/yunshan/src/simulation/freight-delivery.ts:30) [freight-delivery.ts:118](/workspace/yunshan/src/simulation/freight-delivery.ts:118) 原信号红灯、无电、roadClosed/堵车、nextDeparture/路权都可能延迟或阻断。只有真实endpoint且directed delivery.arrived，emit cargo-arrived后原vehicle.cargo清0/cargoSources删除，由监听器把amount/原shopId添加到district freight/FIFO lot，**不是直接给指定店库存或居民食物**。[simulation.ts:1103](/workspace/yunshan/src/simulation.ts:1103) [simulation.ts:1116](/workspace/yunshan/src/simulation.ts:1116) [simulation.ts:910](/workspace/yunshan/src/simulation.ts:910)

## 新16窗最小真实捕获清单

| 原件 | 必须保的真实字段/事件 |
| --- | --- |
| 逐窗完整save＋ALLbus＋phase边界 | 新cold import必须先与6e48…2d48完整字节exact，原clock5340/tick2070/speed16；每窗有before/after整档、各phase边界实际clock/tick/分钟和有序原events，缺件明确缺，不以摘要代替。 |
| people 四人前后 | 全needs/food/money/profile alive与年龄健康、array index/tier/pending、activity/decisionAt、destination、完整route/routePool+index/尾点/position、riders、dispatch、task flags/phase、NPC stair/road revision/exit permits；是否新customer/request写入、重选目标、真实move到sale功能点。不要直接调用chooser/改tier/跳deadline来制造成功。 |
| commerce 四人＋目标/新目标店 | before/after runtime.customers、commerceAt、retailSalesSinceBatch、shop open/inventory/listprice/revenue/profit/customers/employees/cash/owner与绑定company capital、税率/真实energy、lifecycle/leases、各sale点/身份/体素及原距离；ownedLots/consignedLots/货主账户与报价可结算guard。内部未捕获predicate标未知，不由stock0合成“其余全过”。 |
| 补货与采购所有真实对方 | 全district freight/FIFO lots及stock owner；supplier inventory/funds/owner/company/protected/报价与cost buckets；retail funds−protected、工资债/承诺班次/租约reserved、owned/consigned lots及stats差；wholesale/production/business-expense/相关wage等有序事件。wholesale payload只含supplier，须靠phase差识别买方，不能当payload已带targetRetail。 |
| 原货运9loaded中目标道路两车，及实际到站车 | vehicle id/position/edge/progress/direction/state/nextDeparture/passengers/cargo、cargoSources、原carrier.capacity、道路open/revision/信号/能源；cargo-loaded/vehicle-arrived/cargo-arrived含实际source/node/district/amount，随后district库存和真采购变化。不要通过静态路由预估代替实际deliver。 |
| 吃饭后果 | customer→sale的同人/店/quantity/cost链，以及钱包/店库存/ownedlots/对方净资金/税、饱足+52、携带quantity−1；后续stored-meal减少food1/饱足+52。合法路程/时间/有限工资钱粮账持续原证据，不补钱粮、不强定位。 |

当前不是因果诊断或修复请求：457/489/153旧店确实缺货，但下一步重选/真实到达/请求/营业许可/货权报价都需新原件；450有钱且原目标有粮，但原仍moving，并未建立成功柜台交易。一次64游戏分钟新窗口也不能把115人全部问题或全城长期供粮判为已解。新增实际门由root运行；本作者不运行或改源码。

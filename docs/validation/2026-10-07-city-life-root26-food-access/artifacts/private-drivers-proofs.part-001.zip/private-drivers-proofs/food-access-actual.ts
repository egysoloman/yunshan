import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, existsSync, statSync, statfsSync } from 'node:fs';
import { join } from 'node:path';
import { gzipSync, gunzipSync } from 'node:zlib';
import { Simulation } from '/workspace/yunshan/src/simulation';
import { validateSaveResources } from '/workspace/yunshan/src/persistence/save-resource';
import { partitionSave, assembleSave } from '/workspace/yunshan/src/persistence/partition';
import { attachEconomyCustodyObserver } from './custody-observer';

const sha = (data: string | Buffer) => createHash('sha256').update(data).digest('hex');
const clone = <T>(value: T): T => structuredClone(value);
const planPath = process.argv[2], plan = JSON.parse(readFileSync(planPath, 'utf8'));
const began = Date.now(), out = plan.output, frames: any[] = [], captures: any[] = [], errors: any[] = [];
assert(!existsSync(out)); mkdirSync(out);
let bytes = 0, sim: Simulation | undefined, observer: ReturnType<typeof attachEconomyCustodyObserver> | undefined;
let calls = 0, returned = 0, completed = 0, readers = 0, trace: any[] = [], lastRaw = '', status = 'FAILED', failure: string | null = null;
const clock = () => sim!.state.day * 1440 + sim!.state.hour * 60;
const runtime = () => Reflect.get(sim!, 'runtime') as any;
function write(file: string, raw: Buffer | string) {
  const data = Buffer.from(raw); assert(bytes + data.length <= plan.physicalEvidenceByteCap, 'physical evidence byte cap');
  const path = join(out, file); mkdirSync(join(path, '..'), { recursive: true }); writeFileSync(path, data, { flag: 'wx' });
  bytes += data.length; assert.equal(sha(readFileSync(path)), sha(data));
}
const json = (file: string, value: unknown) => write(file, JSON.stringify(value, null, 2) + '\n');
function compressed(file: string, raw: string) {
  write(file, gzipSync(Buffer.from(raw))); const encoded = readFileSync(join(out, file));
  assert.equal(gunzipSync(encoded).toString('utf8'), raw);
  return { file, rawBytes: Buffer.byteLength(raw), rawSHA256: sha(raw), encodedBytes: encoded.length, encodedSHA256: sha(encoded) };
}
function snapshot() {
  const r = runtime(), s = sim!.state, tracked = new Set(plan.actorIds);
  return { clock: clock(), tick: s.tick, commerceAt: r.commerceAt, payrollAt: r.payrollAt,
    actors: s.citizens.filter(a => tracked.has(a.id)).map(a => ({ actor: clone(a), index: s.citizens.indexOf(a), activity: r.activities[a.id] ?? null,
      pendingMinutes: r.peopleElapsed?.[a.id] ?? 0, decisionAt: r.decisionAt[a.id] ?? null, customer: r.customers[a.id] ?? null,
      rider: clone(r.riders[a.id] ?? null), stairCursor: clone(r.npcStairCursors?.[a.id] ?? null), profile: clone(s.extension!.actorProfiles[a.id]) })),
    shops: s.shops.filter(a => plan.shopIds.includes(a.id)).map(a => ({ shop: clone(a), funds: sim!.shopFunds(a), protected: sim!.shopProtectedFunds(a),
      payrollDebt: sim!.shopPayrollDebt(a), committedPayroll: sim!.shopCommittedPayroll(a), labor: r.shopLabor?.[a.id] ?? null })),
    freight: clone(r.freight), freightLots: clone(r.freightLots ?? {}), cargoSources: clone(r.cargoSources ?? {}),
    freightVehicles: s.vehicles.filter(a => a.cargo > 0 || r.cargoSources?.[a.id]).map(a => clone(a)),
    hungryCount: s.citizens.filter(a => a.needs.hunger < 30 && s.extension!.actorProfiles[a.id].alive).length,
    custodyStock: s.shops.filter(a => ['farm', 'dock'].includes(sim!.worldDefinition.buildings.find(b => b.id === a.buildingId)!.kind))
      .map(a => ({ id: a.id, inventory: a.inventory, funds: sim!.shopFunds(a), open: a.open })) };
}
function persist(label: string, complete: boolean) {
  const captured = observer!.current(), raw = sim!.exportSave(); lastRaw = raw;
  const prefix = 'frames/' + String(frames.length).padStart(4, '0') + '-' + label;
  const frame = { label, complete, tick: sim!.state.tick, clock: clock(),
    save: compressed(prefix + '/whole-save.json.gz', raw),
    bus: compressed(prefix + '/all-bus.json.gz', JSON.stringify(captured.events)),
    custody: compressed(prefix + '/stable-phase-custody.json.gz', JSON.stringify(captured)),
    foodTrace: compressed(prefix + '/food-access-trace.json.gz', JSON.stringify(trace)) };
  frames.push(frame); json(prefix + '/FRAME.json', frame); observer!.clearFrame(); trace = [];
  return { frame, captured, raw };
}
try {
  assert.equal(sha(readFileSync(plan.driver)), plan.driverSHA256);
  assert.equal(sha(readFileSync(plan.observer)), plan.observerSHA256);
  const worldRaw = readFileSync(plan.world), saveRaw = readFileSync(plan.save).toString('utf8');
  assert.equal(sha(worldRaw), plan.inputWorldSHA256); assert.equal(sha(saveRaw), plan.inputFullSaveSHA256);
  write('PLAN.original.json', readFileSync(planPath)); write('WORLD.original.json', worldRaw); compressed('INPUT.original.save.json.gz', saveRaw);
  write('DRIVER.original.ts', readFileSync(plan.driver)); write('OBSERVER.original.ts', readFileSync(plan.observer));
  sim = new Simulation(JSON.parse(worldRaw.toString('utf8'))); const result = sim.importSave(saveRaw); assert(result.ok, result.message);
  assert.equal(sim.exportSave(), saveRaw); assert.equal(sim.state.tick, plan.inputTick); assert.equal(clock(), plan.inputClock);
  assert.equal(sim.state.speed, 16); assert.equal(sim.state.paused, false);
  observer = attachEconomyCustodyObserver(sim, sim.worldDefinition); json('BASELINE.json', observer.start());
  const bus = Reflect.get(sim, 'bus') as any, forward = bus.emit;
  bus.emit = (event: any) => {
    let before: any = null; const system = typeof event.type === 'string' && event.type.startsWith('system:');
    if (system) { try { before = snapshot(); } catch (e) { captures.push({ when: 'before', error: String(e) }); } }
    let returned = false;
    try { forward.call(bus, event); returned = true; }
    finally { if (system) { try { trace.push({ phase: event.type.slice(7), returned, before, after: snapshot() }); } catch (e) { captures.push({ when: 'after', error: String(e) }); } } }
  };
  persist('imported', false);
  while (completed < plan.maximumSuccessfulWindows) {
    assert(Date.now() - began < plan.ordinaryWallMilliseconds, 'ordinary work wall cap');
    const disk = statfsSync(out); assert(plan.physicalEvidenceByteCap - bytes >= plan.beforeNextStepChosenFreeEvidenceBytes && disk.bavail * disk.bsize >= plan.beforeNextStepChosenFreeEvidenceBytes, 'next-step evidence reserve');
    const beforeTick = sim.state.tick, beforeClock = clock(); calls++; let nativeError: unknown = null;
    try { sim.step(.25); returned++; } catch (e) { nativeError = e; }
    const original = persist('ordinary-' + String(calls).padStart(3, '0'), !nativeError);
    if (nativeError) throw nativeError;
    assert.equal(sim.state.tick, beforeTick + 1); assert.equal(clock(), beforeClock + 4);
    assert.deepEqual(original.captured.phases.map(p => p.phase), plan.systemOrder);
    assert.equal(original.captured.violations.length, 0, JSON.stringify(original.captured.violations));
    assert.equal(original.captured.captureFailures.length, 0); assert.equal(captures.length, 0);
    validateSaveResources(JSON.parse(original.raw), original.raw); const reader = sim.validateSave(original.raw); readers++; assert(reader.ok, reader.message);
    assert.equal(sim.exportSave(), original.raw); completed++;
    if (completed % 8 === 0) console.log(JSON.stringify({ completed, tick: sim.state.tick, clock: clock(), seconds: (Date.now() - began) / 1000, bytes }));
  }
  const parts = partitionSave(lastRaw, sim.worldDefinition), manifest = parts.map((part, i) => ({ id: part.id, original: compressed('parts/' + String(i).padStart(4, '0') + '.json.gz', part.json) }));
  const physical = manifest.map(p => ({ id: p.id, json: gunzipSync(readFileSync(join(out, p.original.file))).toString('utf8') }));
  assert.equal(assembleSave(physical), lastRaw); const omitted = physical.find(p => p.id.startsWith('chunk:') && JSON.parse(p.json).arrays && Object.keys(JSON.parse(p.json).arrays).length); assert(omitted);
  assert.throws(() => assembleSave(physical.filter(p => p !== omitted))); assert.equal(sim.exportSave(), lastRaw);
  json('TERMINAL-PARTS.json', { manifest, assembledSHA256: sha(lastRaw), rejectedMissingPart: omitted.id, extraSimulations: 0, extraImports: 0, extraSteps: 0 });
  json('TERMINAL-FOOD-OBSERVATION.json', snapshot()); status = 'ACTUAL_COMPLETED';
} catch (e) {
  failure = e instanceof Error ? e.stack ?? e.message : String(e);
  if (sim && observer) { try { persist('failure-frontier', false); } catch (e) { errors.push(String(e)); } }
}
json('FRAMES.json', frames);
const report = { status, failure, constructors: sim ? 1 : 0, imports: sim ? 1 : 0, ordinaryCalls: calls, returnedWindows: returned, completedWindows: completed, readers,
  inputSaveSHA256: plan.inputFullSaveSHA256, terminalSaveSHA256: lastRaw ? sha(lastRaw) : null, tick: sim?.state.tick, clock: sim ? clock() : null,
  commands: 0, injectedBodiesMoneyNeedsStockRolesTime: 0, bytesBeforeResult: bytes, elapsedSeconds: (Date.now() - began) / 1000,
  captureFailures: captures, persistenceFailures: errors, conservationViolations: observer?.violations, maximumResidual: observer?.maxima, actualCounts: observer?.totals,
  scope: 'Exact prior terminal cold continuation. Complete original ordinary windows; no steady-state or original single-segment claim.' };
json('RESULT.json', report); console.log(JSON.stringify(report)); if (status !== 'ACTUAL_COMPLETED') process.exitCode = 1;

# ROOT26 窄求餐调度与原件对照：只读交付

状态：STATIC_REVIEW / COMPARISON_SCRIPT_PREPARED_NOT_RUN。没有执行Node、Simulation、step、测试、构建或对比脚本。未修改共享源码、旧报告和原始运行目录。

## 脚本入口与精确范围

`compare-food-access-originals.ts`仅导入Node自带FS、path、crypto、zlib、assert。输入可重复的patched-root与control-root列表及一个全新output目录。默认checkpoint硬绑定真实clock5416/tick2089完整save SHA `ce40c74205c1126519e08c5d49e32d18f22cc4acf410d07f1fa4e709ff0337b8`，从原保存确定89名alive/hunger<30居民。

- 逐原FRAMES/FRAME检查fullsave、ALLbus、custody、foodtrace的encoded/raw字节和SHA；支持原pooled-v1/paged-v1解码，只解读本地副本，不调用产品加载器。
- 流式读取，避免把全部gzip展开后的城市状态同时驻内存。重复control cold起点只在原save SHA相同下去重，销量按普通窗去重；不同patched场景绝不相加。
- 同clock5480/5576及同tick比较16/40窗；cohort当前恢复、死亡、真正购买的唯一人数和sale收据次数分别统计。allcity低饱足来自每份完整保存的全部真实alive居民。
- 每个实际cohort sale绑定原bus事件、phase、sequence及原custody/trace/save SHA。用原phase完整居民边界验证钱包扣真实收据金额、随身餐增加quantity−1、即食饱足+52（100封顶）。这是phase聚合证明，不假造逐event身体捕获。缺捕获或差额不符单列，不能当验证通过。
- 输出comparison.json、sale-phase-proofs.json、279-trajectories.json、provenance.json；每个记录保原路径/hash。完整源版本与实际运行资格仍由原RESULT和root gate回执证明，脚本不冒完整产品validator或世界物理验收。

精确启动范例（尚未执行）：

```sh
node --import tsx /workspace/yunshan-work/ROOT26-food-access-20261007-01/compare-food-access-originals.ts \
  --patched-root /tmp/ROOT26-food-access-20261007-01/patched01 \
  --patched-root /tmp/ROOT26-food-access-20261007-01/patched02 \
  --patched-root /tmp/ROOT26-food-access-20261007-01/patched03 \
  --control-root /tmp/ROOT26-food-access-20261007-01/native01 \
  --control-root /tmp/ROOT26-food-access-20261007-01/native02 \
  --control-root /tmp/ROOT26-food-access-20261007-01/native03 \
  --control-root /tmp/ROOT26-food-access-20261007-01/native04 \
  --output /workspace/yunshan-work/ROOT26-food-access-20261007-01/compare-originals-01
```

原control从5416以后必须连续、每窗4分钟；缺窗或不同checkpoint拒绝。不是接续原80窗的新游戏时间线，也不是比较不同clock端点。World291实际保存的612/616城限定，不宣称current-v8 fresh/UI、稳态、Mac或艺术结果。

## 当前窄helper

读取 `src/simulation/meal-route.ts:11–25`：仅nearby-food-v1、age>=6、activity=eat、food<1、当前饱足减完整elapsed×.05后<30，且完整剩余参考折线<=原walkingSpeed×25，或已有rider.arrived=true，才请求frequency1。core在计算原pending+minutes后调用，死者随后原分支清理并continue；成功请求不改citizen.tier或speed，原elapsed不清空、不缩成仅本分钟。

这比全体低饱足细处理窄，专门修已有求餐者的近端错失；尚未进入eat、没有route、长程求餐者保持旧分级，是明确剩余范围。

**两处命名边界**：25分钟是原reference polyline / unchanged speed的估计，不含NpcStairMotion.materialize后的额外真实楼梯步程，因此不是所有身体路径的真实25分钟上界。arrivedRider直接通过也是到站后的单次处理例外，并不受25界限。后续1885原arrivedAt仍裁可步行分钟，未见借乘车时间步行或恢复。普通未到站rider如果旧route恰满足近端估计，也可能提前处理needs；原riding早退仍拒步行/交易，不能称此helper只处理已下车者。

工资源398–410仍 `min(elapsed,480余量,真实private/publicAllowance)`，据实际到场后窗口前段发canonical wage-earned；窄调度没有增加registerAttendance调用或改工资率/资金。工作、医教等真实现场守卫仍在原people顺序内；若提早吃到并返回岗位，会合法改变之后真实出勤，不能强要求工资端点与旧分级相同。

## 聚合先后风险与验收

people按既有citizens索引处理，customer插入后commerce2012按原Object.entries结算有限库存；不是按未保存的连续到场时间排序。更及时的279可以买走原本被其他人买到的单位，并改变后续needs、RNG选择、转社交、工作/生产与经营资金。没有凭空钱粮也不等所有人的结果更好。

原宽patched02的producer记录5576：当前cohort恢复34对control43、allcity低56对47，应保留为不采用的负结果，不借279成功掩盖。root最新报告窄03已完成40primary+24shadow exact：5480恢复18对17/低71对72；5576恢复52对43/低38对47。这里注明**来自parent实际运行报告，待本读器原件复核**，本作者没有执行这些场景或自称已核全部数字。

收口应同时看同clock全城低、原89群体恢复/实际sales、每sale有限钱包与食物、每phase原cash/food/debt残差和新源自己续演exact。未到店/无钱/无营业/无库存不应免费补needs。单次4小时内改善不是供给扩产或长期稳态证明；旧家屋41/43失败的原来源、未来outward-egress修复与求餐调度另列，不能混成同源通过。

## 保存与来源

旧无mealpolicy不会触发本helper。新调度不添加保存body或marker，原cold导入即时可保持原字节；真实未来的库存竞争/RNG与旧控制不同是本功能行为差别。只验证新源同档自身+24，不要求旧未来全bytes相同。

helper原读SHA `6ce962358934386151adcd4fc7d2dac10d27e38c946b7525cb77d73377ccf2a4`。core读期间root并行修改：首次5f1f54…，末读 `8ffd1b06229e37b2e391eefbe2f80cf190e59af5c9ca6fabab7e8143c23c85f1`；不称整份core首尾不变。窄调用原文另封 `meal-narrow-core-call.original.txt`，独立SHA `cf7981832157032b669008075e9fa9b57f63eeb10b3cbc163cab5174289accba`。脚本STOPWRITE SHA `7511fa87c1d7694b9f2a99699f0660f10c65be732c826ea846d3f67bcf1dc36d`。本报告与脚本是准备/静态资料，不是运行PASS回执。

# ROOT26 求餐路线只读复核

状态：READ_ONLY_COMPLETED；本文只审原记录与源码，没有运行 Simulation、step、Node、测试、构建、浏览器或新政策。观察截止 native03 clock5596 / tick2134。native04及后续不纳入本文。

## 结论与范围

64个已完成普通窗、3段原cold续演、同一417输入来源中，初始115名低饱足居民有73人发生真实sale；剩42名仍低饱足且全部moving。不能把剩42人叫柜台销售失败，也不能据73人恢复认定全城补给或长期稳态已解决。

本轮所见主要原因是有限供货在长旅程中变化，再叠加低细节居民的延迟处理。没有找到本批42人实际碰撞/权限等待的证据；未来未走完的门口与室内路段仍未获通过证明。deadline本身没有把同目标有效路线反复清空。

实际核对：64×10阶段前后原food trace、64份全部商店custody、64份ALLbus。192份gzip均核encoded及解压SHA/字节数；连同FRAME/PLAN/RESULT/分析原件共263读入文件首尾SHA不变。部分custody阶段body原本null：全部商店只在people/commerce/finance/security/politics边界有快照，没有补造其余阶段数据。

共享HEAD `65d7c6fd20701388aab0acdee327003333579b59`；417逐文件与native01-gate/inputs-before.json一致，末检0差异。冻结清单SHA `0900cf3e46b6850af414e0c5e1611edbd57ad71482015d0e84b18275da6fda82`。实际core SHA `feb22c37261c31ceed19513f4771ba717dd172bc84927785b7e78c620e737179`。

原件入口：

- `NATIVE01-COHORT-ANALYSIS.json`、`NATIVE02-COHORT-ANALYSIS.json`、`NATIVE03-COHORT-ANALYSIS.json`及三个TERMINAL.original.save.json。
- `/tmp/ROOT26-food-access-20261007-01/native01|native02|native03/frames/*/FRAME.json`及其food-access-trace / stable-phase-custody / all-bus原gzip。
- 本文派生记录：[route-static-evidence.json](route-static-evidence.json)，原读入哈希：[route-static-read-inputs.json](route-static-read-inputs.json)，只读边界：[route-static-review-receipt.json](route-static-review-receipt.json)。

## 重选、路线与真实处理窗口

[simulation.ts:1836](/workspace/yunshan/src/simulation.ts:1836) 的普通active/regional/statistical频率分别1/4/16。原speed16每tick4实际分钟，所以稳定statistical每次处理窗口通常64分钟，已超过每次决策的25–60分钟deadline。`peopleElapsed`是真累计；跳过tick不代表被判碰撞或没路，实际处理会用全部pending+本分钟、衰减needs后删除pending（1841–1848）。tier每8tick按原focus距离重新划分（982–987），不能只按终档tier反推每个历史窗口。

`reconsiderMeal`（1905）解除既有eat承诺；原chooser可能重选，随后1911调用setDestination。但[1384](/workspace/yunshan/src/simulation.ts:1384)对同楼、仍声明的相同功能点尾点直接保留route/index。换楼的新路线以实际当前body为起点，index=1并不表示人物回到路线起点。

115人共614次实际轮到的people记录，212次目标变化：203次旧目标店在people-entry库存<1；余9次旧店开、有货且钱包够列价。9次中7次仍是求餐，2次是已吃过的居民转social；不能把这2次归为饥饿换店。这里只说明变化时的真实条件，未声称库存单字段就是每次chooser分支的唯一原因。

最终42人的69次变化中，67次旧店库存<1，余2次（368、340）新参考路线也更短。17人换店1次、23人2次、2人3次。所有新食品目标在people-entry都open、有至少1单位库存。

236次“deadline前移但目标不变”中219次路线hash不变；另17次全部是已有真实rider到站后的moving/shopping重建。最终42人的4次同目标重建也都有`arrived=true/arrivedAt`。未见将deadline到期误当无条件route重置。

最终42人全部1280个阶段前后边界没有physicalWaiting/unreachable/roadWaiting记录；实际处理的moving→moving均有身体位移。其末档没有stairCursor，42条尾点均是原World三个market声明的floor0 sale点；三个楼的publicFloors/floorPermissions/requiredPermission均未声明，按[access.ts:26](/workspace/yunshan/src/access.ts:26)为公开层。这不证明尚未走完的全部身体/voxel段合法，也不直接读取内部continuous-reject predicate。

## 153：库存变化下的三次换店

下表余路/推进是从原身体、完整reference route与index计算的三维折线长度；不是内部actualConsumed分钟，不用于跨rider或stairCursor推断时间。

| 实际people clock | 目标前→后 | 旧/新店库存 | 原窗口分钟 | 新路线推进m | 处理后余路m |
| --- | --- | --- | --- | --- | --- |
| 5344 | east-b37→east-b50 | 0 / 24 | 64 | 268.8 | 596.886 |
| 5408 | east-b50→east-b37 | 0 / 23 | 64 | 268.8 | 277.725 |
| 5472 | east-b37→east-b5 | 0 / 37 | 64 | 268.8 | 303.264 |
| 5536 | east-b5→east-b5 | 49 / 49 | 64 | 268.8 | 34.464 |

5536真实目标/路线hash不变，从303.264推进到34.464m，身体到(836.9561660573091,166.887269101969,-104)。截至5596仍未再次轮到，其pending60；不能称已到店、已吃饭或碰撞卡住。5408换店的完整新参考路线546.525m，短于原b50余路596.886m；“已很近b50却盲目重建绕远”的说法不符合该记录。

## 279：临近店门后被延迟处理与断货打断

- 5416：原rider真arrivedAt5388；本次needs窗口48分钟，步行可用最多28分钟，原core1885从到站时刻裁掉乘车部分。真实下车→moving，目标west-b41库存7，处理后余65.200m。
- 5480：下次真实处理pending60+4=64；原b41库存0，改west-b54（库存29），真实沿新路推进268.8m，处理后余42.761m。
- 5544：b54又库存0，改回b41（库存21），真实推进268.8m，余65.200m。

这是可复用原full save的具名因果候选：对原近端路线的处理被延迟，重选又发生在当前库存断货之后。不能从65.2/4.2推断其过去某分钟已经真实到柜台或保证当时能买；没有实际counterfactual执行。

## 三个最终目标店的供货与余路

| 店 | 仍低人数 | 64窗people-entry库存范围 | <1窗数 | clock5596库存 | 末档reference余路m |
| --- | --- | --- | --- | --- | --- |
| summit-b8 | 17 | 16–32 | 0 | 16 | 103.898–657.656 |
| west-b41 | 12 | 0–28 | 21 | 15 | 5.003–87.018 |
| east-b5 | 13 | 35–49 | 0 | 45 | 34.464–466.684 |

三店在这些people-entry边界都open。west-b41在5440–5520的21个边界断货，5524真库存14，5536为23，末5596为15。summit-b8和east-b5没有断货边界，所以42人仍低不能全归为当前目标无粮：包括长路程、此前缺货换目标与尚未结算的tier时间。可用库存不等已向42人预约，后续仍可能先被别人购走；也不等食品生产/货运/资金闭环充足。

## 路由守卫与尚未证明的风险

[walkingTree1244–1253](/workspace/yunshan/src/simulation.ts:1244)是开放road/bridge图的edge.length最短路。chooseFacility1594只计真实anchor+目标road node，没有目标node→door→sale室内尾程。nearby-food-v1只比较严格同score的食物offer，且travel惩罚最多150；没有欧氏最邻近或全身体路径最短保证。

setDestination1370筛sale目的/经过楼层ACL/ground层，1391找原floorplan route，室外拼接1313–1319主要检查road guard。食物offer没有publicRestReachable1553–1586那样的全站点预检。sale点按actor/building确定性hash先后选，不保证选最短内室尾点。

实际mover1764–1823仍负责真实.body35cm、高172cm、墙/柜台、voxel、楼层ACL及道路守卫；physical blocked会physicalWaiting，road blocked可能重算后仍moving，因此边界state不能当内部拒绝计数。参考路线规划不等全程实际通行，floorPlanRoute2361没有voxel回调，实际走时才拒动态体素。

这些是STATIC_NOT_REPRODUCED的通用接缝，未证明是本42人的原因。若出现后续低人身体不再推进，需要补捕：实际chosen候选travel/score、chosen sale点id、频率原因、availableMinutes/arrival源、describe结果与首个拒绝segment、对应support/head/ACL/voxel/counter/road predicate。只写只读observer，不另调用chooser/random或修改状态。

## root提出的紧急求餐调度方案：静态意见，未实现

仅nearby-food-v1、存活且可自主求餐年龄>=6、`food<1`、`max(0,hunger−(peopleElapsed+this.minutes)*.05)<30`时frequency1，沿当前有承诺任务的原模式，可以针对279这种延迟。不要仅限定当前activity=eat，否则原work/null目标的饥饿者仍等到普通分级窗口。不得加健康回血、粮食预约、开夜店或强制选择eat。

必须仍原样处理完整elapsed、原needs衰减、原到站裁时、工作出勤与有限日/班次/资助工资上限；不要清pending或把首次flush减成只本分钟。已有task frequency1只合并布尔条件，不能同actor多处理一次。private/public wage守卫不改，实际在岗/营业时段可能更及时，实际计薪总量仍由现原上限裁；需要真工资区间与现金守恒回归，不能只比较工资额端点。

Legacy无mealpolicy分级不变。已有同policy保存可立即完整字节导入，但新调度会改变真实后续库存竞争、选择时点和RNG序列，不能宣称未来与原64窗逐字相同。应验证原cold即时exact、新源同档自身+24exact、tier原值/速度不手改、无餐/无钱/夜间无营业仍不得免费恢复、已有随身餐不造额外采购。首次保留pending的完整flush也不能冒“历史每分钟已在新目标上”；当前路径仍按原core处理，必须明示范围。

性能边界：这个条件没有7人固定上限，饥饿成人可扩到全体；需要真实后续负载观察。纯文件读取的耗时不是游戏性能。本文没有实施该方案或运行修复后案例。

## 原件与限制

只读原review.md和现调用链；本轮AGENTS完整、提示词相关、备忘录相关入口已读，未声称重读全部多年备忘录。`tests/meal-route-policy.test.ts`原2案覆盖同score纯选择与保存声明切换，未覆盖默认饥饿者在途中deadline/断货/同目标route保存；本作者没有重跑它们。

纯文件读器第一版对原null custody body报TypeError，保在独立/tmp读器原件；第二版仅跳过原本缺失的阶段body，原192gzip全部核实后退出0。这个读器错误不是生产业务FAIL。原source、所有native evidence及政策没有改动；不宣称修复、全城稳态、macOS、美术或完整项目验收。

/** Pure original-file reader. No Simulation/product imports, commands, RNG, or state writes.
 * PREPARED_NOT_RUN: this producer has not executed this script or typechecked it.
 * node --import tsx compare-food-access-originals.ts --patched-root DIR [repeat]
 *   --control-root DIR [repeat] --output NEW_DIR [--checkpoint ORIGINAL_SAVE]
 */
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { resolve, join, relative, isAbsolute, basename } from 'node:path';
import { gunzipSync } from 'node:zlib';

type Obj = Record<string, unknown>;
type Point = { x: number; y: number; z: number };
type Proof = { path: string; bytes: number; sha256: string; rawBytes?: number; rawSHA256?: string };
type Frame = { label: string; complete: boolean; tick: number; clock: number;
  save: Obj; bus: Obj; custody: Obj; foodTrace: Obj };
type Actor = { id: string; alive: boolean; hunger: number; money: number; food: number;
  state: string; goal: unknown; position: Point; routeIndex: number; route: Point[] };
type Boundary = { id: string; hunger: number; money: number; food: number };
type FrameRow = { root: string; frame: Frame; proofs: Record<string, Proof>; save: Obj;
  actors: Map<string, Actor>; bus: Obj[]; custody: Obj; trace: Obj[] };
type FrameReference = { root: string; frame: Frame; descriptor: unknown };
type EventReceipt = { root: string; frameClock: number; sequence: number; phase: string;
  eventClock: number; event: Obj; sourceBusSHA256: string; sourceCustodySHA256: string };
type Stage = { root: string; plan: Obj; result: Obj; frames: FrameReference[]; imported: FrameReference };

const sha = (b: Buffer) => createHash('sha256').update(b).digest('hex');
const obj = (v: unknown, label: string): Obj => { assert(v !== null && typeof v === 'object' && !Array.isArray(v), label); return v as Obj; };
const array = (v: unknown, label: string): unknown[] => { assert(Array.isArray(v), label); return v; };
const number = (v: unknown, label: string): number => { assert(typeof v === 'number' && Number.isFinite(v), label); return v; };
const string = (v: unknown, label: string): string => { assert(typeof v === 'string', label); return v; };
const bool = (v: unknown, label: string): boolean => { assert(typeof v === 'boolean', label); return v; };
const point = (v: unknown, label: string): Point => { const p = obj(v, label); return { x: number(p.x, label), y: number(p.y, label), z: number(p.z, label) }; };
const allProofs: Proof[] = [];
const readPlain = (path: string): { value: unknown; proof: Proof } => {
  const raw = readFileSync(path), proof = { path: resolve(path), bytes: raw.length, sha256: sha(raw) };
  allProofs.push(proof); return { value: JSON.parse(raw.toString('utf8')) as unknown, proof };
};
function boundPath(root: string, file: unknown): string {
  const part = string(file, 'recorded relative path'); assert(!isAbsolute(part), 'recorded file must be relative');
  const path = resolve(root, part), rel = relative(root, path);
  assert(rel !== '..' && !rel.startsWith('../'), 'recorded path leaves root'); return path;
}
function compressed(root: string, spec: Obj): { value: unknown; proof: Proof; raw: Buffer } {
  const path = boundPath(root, spec.file), encoded = readFileSync(path), raw = gunzipSync(encoded);
  assert.equal(encoded.length, number(spec.encodedBytes, 'encoded bytes'), path);
  assert.equal(sha(encoded), string(spec.encodedSHA256, 'encoded SHA'), path);
  assert.equal(raw.length, number(spec.rawBytes, 'raw bytes'), path);
  assert.equal(sha(raw), string(spec.rawSHA256, 'raw SHA'), path);
  const proof = { path, bytes: encoded.length, sha256: sha(encoded), rawBytes: raw.length, rawSHA256: sha(raw) };
  allProofs.push(proof); return { value: JSON.parse(raw.toString('utf8')) as unknown, proof, raw };
}
function decodeSave(value: unknown): { save: Obj; actors: Map<string, Actor>; clock: number; tick: number } {
  const save = obj(value, 'save'), state = obj(save.state, 'save.state');
  assert.equal(save.format, 'yunshan-save');
  const profiles = obj(obj(state.extension, 'extension').actorProfiles, 'actor profiles');
  const pooled = save.routeEncoding === 'pooled-v1' || save.routeEncoding === 'paged-v1';
  assert(save.routeEncoding === undefined || pooled, 'unsupported original route encoding');
  const originalPool = save.routePool === undefined ? [] : array(save.routePool, 'route pool');
  const pool = (save.routeEncoding === 'paged-v1' ? originalPool.flatMap((v,i)=>array(v, `route page:${i}`)) : originalPool)
    .map((v, i) => point(v, `pool:${i}`));
  const actors = new Map<string, Actor>();
  for (const entry of array(state.citizens, 'citizens')) {
    const a = obj(entry, 'citizen'), id = string(a.id, 'citizen id'), needs = obj(a.needs, 'needs');
    assert(!actors.has(id), 'duplicate citizen');
    const route = array(a.route ?? [], 'route').map((v, i) => {
      if (pooled) { const index = number(v, 'pooled index'); assert(Number.isInteger(index) && index >= 0 && index < pool.length, `route:${id}:${i}`); return pool[index]!; }
      return point(v, `route:${id}:${i}`);
    });
    const money = number(a.money, 'wallet'), food = number(a.food, 'carried food'), hunger = number(needs.hunger, 'hunger');
    assert(money >= 0 && money <= 1e9 && Number.isInteger(food) && food >= 0 && food <= 6 && hunger >= 0 && hunger <= 100, 'finite original wallet/food/needs');
    const index = number(a.routeIndex ?? 0, 'routeIndex'); assert(Number.isInteger(index) && index >= 0 && index <= route.length);
    actors.set(id, { id, alive: bool(obj(profiles[id], `profile:${id}`).alive, 'alive'), hunger, money, food,
      state: string(a.state, 'state'), goal: a.destinationId, position: point(a.position, 'position'), routeIndex: index, route });
  }
  return { save, actors, clock: number(state.day, 'day') * 1440 + number(state.hour, 'hour') * 60, tick: number(state.tick, 'tick') };
}
function parseFrame(value: unknown): Frame {
  const f = obj(value, 'FRAME');
  return { label: string(f.label, 'label'), complete: bool(f.complete, 'complete'), tick: number(f.tick, 'tick'), clock: number(f.clock, 'clock'),
    save: obj(f.save, 'save reference'), bus: obj(f.bus, 'bus reference'), custody: obj(f.custody, 'custody reference'), foodTrace: obj(f.foodTrace, 'trace reference') };
}
function loadFrame(reference: FrameReference): FrameRow {
  const {root,frame:f}=reference, saveRef=string(f.save.file,'save file');
  const metadataPath=join(resolve(root,saveRef),'..','FRAME.json');
  assert.deepEqual(readPlain(metadataPath).value,reference.descriptor,`FRAMES/FRAME mismatch ${root}:${f.label}`);
  const s=compressed(root,f.save),b=compressed(root,f.bus),c=compressed(root,f.custody),t=compressed(root,f.foodTrace);
  const decoded=decodeSave(s.value);assert.equal(decoded.clock,f.clock);assert.equal(decoded.tick,f.tick);
  const row:FrameRow={root,frame:f,proofs:{save:s.proof,bus:b.proof,custody:c.proof,trace:t.proof},save:decoded.save,
    actors:decoded.actors,bus:array(b.value,'all bus').map(v=>obj(v,'bus row')),custody:obj(c.value,'custody'),trace:array(t.value,'trace').map(v=>obj(v,'trace phase'))};
  if(f.label!=='imported') {
    assert(f.complete,`incomplete frame ${f.label}`);assert.equal(row.trace.length,10);assert.equal(array(row.custody.phases,'custody phases').length,10);
    for(const phase of row.trace)assert.equal(phase.returned,true,'original phase did not return');
  }
  return row;
}
function stage(root: string): Stage {
  const plan = obj(readPlain(join(root, 'PLAN.original.json')).value, 'plan');
  const result = obj(readPlain(join(root, 'RESULT.json')).value, 'result');
  assert.equal(result.status, 'ACTUAL_COMPLETED', `unfinished stage ${root}`);
  const world = readFileSync(join(root, 'WORLD.original.json'));
  allProofs.push({ path: join(root, 'WORLD.original.json'), bytes: world.length, sha256: sha(world) });
  assert.equal(sha(world), string(plan.inputWorldSHA256, 'world SHA'));
  const input = readFileSync(join(root, 'INPUT.original.save.json.gz')), inputRaw = gunzipSync(input);
  allProofs.push({ path: join(root, 'INPUT.original.save.json.gz'), bytes: input.length, sha256: sha(input), rawBytes: inputRaw.length, rawSHA256: sha(inputRaw) });
  assert.equal(sha(inputRaw), string(plan.inputFullSaveSHA256, 'input save SHA'));
  const frames: FrameReference[] = []; let imported: FrameReference | undefined;
  for (const original of array(readPlain(join(root, 'FRAMES.json')).value, 'FRAMES')) {
    const f=parseFrame(original),reference={root,frame:f,descriptor:original};
    if(f.label==='imported'){assert(!imported,'duplicate import');assert.equal(f.save.rawSHA256,plan.inputFullSaveSHA256);imported=reference;continue;}
    assert(f.complete,`incomplete frame ${f.label}`);frames.push(reference);
  }
  assert(imported, 'missing original import');
  let prev = imported;
  for (const f of frames) { assert.equal(f.frame.clock, prev.frame.clock + 4); assert.equal(f.frame.tick, prev.frame.tick + 1); prev = f; }
  assert.equal(frames.length, number(result.completedWindows, 'completed count'));
  assert.equal(prev.frame.save.rawSHA256, result.terminalSaveSHA256, 'terminal original SHA');
  return { root, plan, result, frames, imported };
}
const distance = (a: Point, b: Point) => Math.hypot(a.x-b.x, a.y-b.y, a.z-b.z);
function remaining(a: Actor): number {
  if (a.routeIndex >= a.route.length) return 0;
  let r = distance(a.position, a.route[a.routeIndex]!);
  for (let i = a.routeIndex + 1; i < a.route.length; i++) r += distance(a.route[i-1]!, a.route[i]!);
  return r;
}
function boundary(value: unknown): Map<string, Boundary> {
  const b = obj(value, 'captured phase body'), m = new Map<string, Boundary>();
  for (const v of array(b.citizens, 'captured citizens')) { const a = obj(v, 'captured actor'), id = string(a.id, 'id');
    m.set(id, { id, hunger: number(obj(a.needs, 'needs').hunger, 'hunger'), money: number(a.money, 'money'), food: number(a.food, 'food') }); }
  return m;
}
function receipts(f: FrameRow, cohort: Set<string>): EventReceipt[] {
  return f.bus.flatMap((row): EventReceipt[] => {
    const e = obj(row.event, 'event');
    if (e.type !== 'sale' || typeof e.citizenId !== 'string' || !cohort.has(e.citizenId)) return [];
    assert.equal(row.originalEmitReturned, true, 'sale emitter did not return');
    assert(number(e.amount, 'sale amount') >= 0); assert(Number.isInteger(number(e.quantity, 'sale quantity')) && Number(e.quantity) >= 1);
    return [{ root: f.root, frameClock: f.frame.clock, sequence: number(row.sequence, 'sequence'), phase: string(row.phase, 'event phase'),
      eventClock: number(row.clock, 'event clock'), event: e, sourceBusSHA256: f.proofs.bus!.rawSHA256!, sourceCustodySHA256: f.proofs.custody!.rawSHA256! }];
  });
}
function receiptProofs(f: FrameRow, rs: EventReceipt[]): Obj[] {
  const groups = new Map<string, EventReceipt[]>();
  for (const r of rs) { const key = `${r.phase}:${string(r.event.citizenId, 'buyer')}`; const a = groups.get(key) ?? []; a.push(r); groups.set(key, a); }
  return [...groups.values()].map(group => {
    const id = string(group[0]!.event.citizenId, 'buyer'), phase = group[0]!.phase;
    const phases = array(f.custody.phases, 'custody phases').map(v => obj(v, 'custody phase'));
    const capture = phases.find(p => p.phase === phase);
    if (!capture || capture.before === null || capture.after === null || capture.before === undefined || capture.after === undefined)
      return { status: 'MISSING_CAPTURE_NOT_PROVEN', id, phase, receipts: group };
    const before = boundary(capture.before).get(id), after = boundary(capture.after).get(id);
    if (!before || !after) return { status: 'MISSING_ACTOR_NOT_PROVEN', id, phase, receipts: group };
    const amount = group.reduce((s,r) => s + number(r.event.amount, 'amount'), 0);
    const stored = group.reduce((s,r) => s + number(r.event.quantity, 'quantity') - 1, 0);
    const expectedHunger = Math.min(100, before.hunger + group.length * 52);
    const walletResidual = after.money - (before.money - amount), foodResidual = after.food - (before.food + stored), hungerResidual = after.hunger - expectedHunger;
    return { status: Math.abs(walletResidual) <= 1e-7 && foodResidual === 0 && Math.abs(hungerResidual) <= 1e-7 ? 'CAPTURED_PHASE_MATCH' : 'CAPTURED_PHASE_MISMATCH_REQUIRES_CAUSE_REVIEW',
      scope: 'Original phase aggregate, not fabricated per-event body captures. Other same-phase effects are not silently reconciled.',
      root: f.root, clock: f.frame.clock, tick: f.frame.tick, id, phase, before, after, amount, stored,
      immediateMeals: group.length, expectedHunger, walletResidual, foodResidual, hungerResidual, receipts: group,
      custodyRawSHA256: f.proofs.custody!.rawSHA256, traceRawSHA256: f.proofs.trace!.rawSHA256, saveRawSHA256: f.proofs.save!.rawSHA256 };
  });
}
function actorRecord(f: FrameRow, id: string): Obj {
  const a = f.actors.get(id); assert(a, `missing ${id}`);
  const runtime = obj(f.save.runtime, 'runtime');
  const phase=f.trace.find(p=>p.phase==='people');
  const selected=(side:unknown):unknown=>{
    if(side===null||side===undefined)return null;
    const s=obj(side,'trace snapshot');return {clock:s.clock,tick:s.tick,
      actor:array(s.actors,'tracked actors').map(v=>obj(v,'tracked actor')).find(v=>obj(v.actor,'actor').id===id)??null,
      shops:s.shops??null};
  };
  return { clock: f.frame.clock, tick: f.frame.tick, actor: { ...a, route: undefined }, referenceRemainingM: remaining(a),
    referenceScope: 'Derived saved polyline only, not physical actualConsumed minutes',
    pending: obj(runtime.peopleElapsed ?? {}, 'peopleElapsed')[id] ?? null,
    decisionAt: obj(runtime.decisionAt ?? {}, 'decisionAt')[id] ?? null,
    activity: obj(runtime.activities ?? {}, 'activities')[id] ?? null, rider: obj(runtime.riders ?? {}, 'riders')[id] ?? null,
    peopleTrace:phase?{phase:'people',before:selected(phase.before),after:selected(phase.after)}:null,
    saveSHA256: f.proofs.save!.rawSHA256, busSHA256: f.proofs.bus!.rawSHA256,
    custodySHA256: f.proofs.custody!.rawSHA256, traceSHA256: f.proofs.trace!.rawSHA256 };
}
function metrics(f: FrameRow, cohort: Set<string>, cumulative: EventReceipt[]): Obj {
  const low = [...f.actors.values()].filter(a => a.alive && a.hunger < 30);
  const cohortLow = [...cohort].filter(id => { const a=f.actors.get(id); assert(a, `missing original actor ${id}`); return a.alive && a.hunger < 30; });
  const recovered = [...cohort].filter(id => { const a=f.actors.get(id)!; return a.alive && a.hunger >= 30; });
  const dead = [...cohort].filter(id => !f.actors.get(id)!.alive);
  return { root: f.root, clock: f.frame.clock, tick: f.frame.tick, allCityAliveLowCount: low.length,
    cohortLowCount: cohortLow.length, cohortCurrentlyRecoveredCount: recovered.length, cohortDeadCount: dead.length,
    cohortUniqueActuallyPurchasedCount: new Set(cumulative.map(r => r.event.citizenId)).size,
    actualCohortSaleReceipts: cumulative.length, cohortCurrentLowIds: cohortLow, cohortRecoveredIds: recovered,
    finiteOriginalWalletFoodCheckedActors: f.actors.size, saveRawSHA256: f.proofs.save!.rawSHA256 };
}
function main(): void {
  const args = process.argv.slice(2), patchedRoots: string[] = [], controlRoots: string[] = [];
  let output: string | undefined, checkpoint = join('/workspace/yunshan-work/ROOT26-food-access-20261007-01', 'CONTROL-5416.original.save.json');
  for (let i=0;i<args.length;i+=2) {
    const flag=args[i], value=args[i+1]; assert(value, `missing value ${flag}`);
    if (flag==='--patched-root') patchedRoots.push(resolve(value));
    else if (flag==='--control-root') controlRoots.push(resolve(value));
    else if (flag==='--output') { assert(!output); output=resolve(value); }
    else if (flag==='--checkpoint') checkpoint=resolve(value);
    else assert.fail(`unknown flag ${flag}`);
  }
  assert(output && patchedRoots.length && controlRoots.length, 'require patched-root, control-root, output');
  assert(!existsSync(output), 'output must be a new directory');
  for (const root of [...patchedRoots,...controlRoots]) assert(output !== root && !output.startsWith(root+'/'), 'output may not alter input root');
  const checkpointRead = readPlain(checkpoint), decoded = decodeSave(checkpointRead.value);
  assert.equal(checkpointRead.proof.sha256, 'ce40c74205c1126519e08c5d49e32d18f22cc4acf410d07f1fa4e709ff0337b8', 'this reader is bound to genuine original5416');
  assert.equal(decoded.clock, 5416); assert.equal(decoded.tick, 2089);
  const cohort = new Set([...decoded.actors.values()].filter(a=>a.alive && a.hunger<30).map(a=>a.id)); assert.equal(cohort.size, 89);
  const controls=controlRoots.map(stage),patched=patchedRoots.map(stage);
  const maxComparisonClock=Math.max(...patched.map(s=>s.frames.at(-1)?.frame.clock??5416));
  const controlFrames=new Map<number,FrameReference>();
  for(const s of controls)for(const f of [s.imported,...s.frames]){
    const prev=controlFrames.get(f.frame.clock);
    if(prev){assert.equal(prev.frame.save.rawSHA256,f.frame.save.rawSHA256,'control overlap must be identical');if(!prev.frame.complete&&f.frame.complete)controlFrames.set(f.frame.clock,f);}
    else controlFrames.set(f.frame.clock,f);
  }
  const originalCheckpoint = controlFrames.get(5416); assert(originalCheckpoint, 'control original5416 frame required');
  assert.equal(originalCheckpoint.frame.save.rawSHA256, checkpointRead.proof.sha256, 'same-byte control checkpoint');
  const controlOrdered = [...controlFrames.values()].filter(f=>f.frame.clock>5416).sort((a,b)=>a.frame.clock-b.frame.clock);
  for (let i=0;i<controlOrdered.length;i++) { assert.equal(controlOrdered[i]!.frame.clock, 5420+i*4, 'missing control ordinary window'); assert.equal(controlOrdered[i]!.frame.tick,2090+i); }
  const comparisons: Obj[] = [], runs: Obj[] = [], salesProof: Obj[] = [], trajectories: Obj[] = [];
  const controlMetrics=new Map<number,Obj>();let cs:EventReceipt[]=[];
  // Stream full originals: only one decompressed frame is retained at a time.
  for(const reference of controls.flatMap(s=>[s.imported,...s.frames]).sort((a,b)=>a.frame.clock-b.frame.clock||Number(b.frame.complete)-Number(a.frame.complete))){
    const f=loadFrame(reference);
    const expected=controls.find(s=>s.root===f.root)!;if(f.frame.complete)assert.deepEqual(f.trace.map(p=>p.phase),expected.plan.systemOrder);
    if(f.frame.clock<=5416||controlMetrics.has(f.frame.clock))continue;
    const rs=receipts(f,cohort);cs=[...cs,...rs];controlMetrics.set(f.frame.clock,metrics(f,cohort,cs));
    if(f.frame.clock<=maxComparisonClock){salesProof.push(...receiptProofs(f,rs));trajectories.push({scenario:'control-original',...actorRecord(f,'citizen-279'),salesThisWindow:rs.filter(r=>r.event.citizenId==='citizen-279')});}
  }
  for (const s of patched) {
    const imported=loadFrame(s.imported);
    assert.equal(imported.proofs.save!.rawSHA256, checkpointRead.proof.sha256, 'patched same-byte start');
    assert.equal(s.plan.inputWorldSHA256, controls[0]!.plan.inputWorldSHA256, 'same original world');
    assert.equal(imported.save.worldFingerprint, decoded.save.worldFingerprint, 'same world identity');
    let cumulative: EventReceipt[]=[],finalMetric:Obj|null=null;
    for (const reference of s.frames) {
      const f=loadFrame(reference);assert.deepEqual(f.trace.map(p=>p.phase),s.plan.systemOrder);
      const rs=receipts(f,cohort); cumulative=[...cumulative,...rs]; salesProof.push(...receiptProofs(f,rs));
      finalMetric=metrics(f,cohort,cumulative);
      trajectories.push({ scenario:basename(s.root), ...actorRecord(f,'citizen-279'), salesThisWindow:rs.filter(r=>r.event.citizenId==='citizen-279') });
      if (f.frame.clock!==5480 && f.frame.clock!==5576) continue;
      const c=controlFrames.get(f.frame.clock); assert(c && c.frame.complete, 'missing exact complete control clock'); assert.equal(c.frame.tick,f.frame.tick);
      const cm=controlMetrics.get(f.frame.clock);assert(cm,'missing control receipt metrics');const pm=finalMetric;
      comparisons.push({ status:'EXACT_CLOCK_ORIGINAL_FILE_COMPARISON', windowFrom5416:(f.frame.clock-5416)/4,
        clock:f.frame.clock, tick:f.frame.tick, scenario:basename(s.root), control:cm, patched:pm,
        warning:'Distinct replays from genuine5416, not one continued original80 timeline. Current recovery and cumulative purchases are separate counts.' });
    }
    runs.push({ root:s.root, status:s.result.status, ordinaryWindows:s.frames.length, inputSHA256:s.imported.frame.save.rawSHA256,
      final:finalMetric,
      actual279Sales:cumulative.filter(r=>r.event.citizenId==='citizen-279'), originalResult:s.result });
  }
  const uniques = new Map<string,Obj>();
  for (const p of salesProof) { const key=`${String(p.root)}:${String(p.clock)}:${String(p.phase)}:${String(p.id)}`; uniques.set(key,p); }
  const checks=[...uniques.values()];
  mkdirSync(output);
  const write=(name:string,value:unknown) => writeFileSync(join(output!,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
  write('comparison.json',{ scope:'PURE_IO_NO_SIM_NO_IMPORT_VALIDATION_NO_COUNTERFACTUAL', checkpoint:checkpointRead.proof,
    cohortDefinition:'89 alive citizens with hunger<30 in genuine5416; current recovered is alive hunger>=30, not inferred from a missing actor or merely moving.',
    comparisonStatus:'ORIGINAL_EVIDENCE_ONLY', comparisons,runs,
    salePhaseProofCounts:{total:checks.length,matched:checks.filter(p=>p.status==='CAPTURED_PHASE_MATCH').length,
      missing:checks.filter(p=>String(p.status).startsWith('MISSING')).length,mismatch:checks.filter(p=>p.status==='CAPTURED_PHASE_MISMATCH_REQUIRES_CAUSE_REVIEW').length},
    limits:['World291 actual saved 612/616 city only; no current-v8 fresh/UI/steady/Mac/art claim.',
      'This reader never executes any scenario; actual run/source scope comes only from original run RESULT and gate receipts.',
      'Broad01/02 and narrow03 are separate replays; duplicate clocks are not pooled across patched scenarios.',
      'A phase mismatch is retained for causal review; missing captures never count as proved food+52 or wallet settlement.'] });
  write('sale-phase-proofs.json',checks); write('279-trajectories.json',trajectories);
  const changed=allProofs.filter(p=>sha(readFileSync(p.path))!==p.sha256); assert.equal(changed.length,0,'original changed during read');
  write('provenance.json',{ status:'PURE_FILE_COMPARISON_COMPLETED', script:resolve(process.argv[1]!), scriptSHA256:sha(readFileSync(process.argv[1]!)),
    argv:process.argv.slice(2),originalFiles:allProofs,allOriginalEncodedSHAStable:true,productImports:0,simulations:0,steps:0 });
  console.log(JSON.stringify({output,comparisons:comparisons.length,readFiles:allProofs.length,cohort:cohort.size,salePhaseProofs:checks.length}));
}

try { main(); } catch (e) { console.error(e instanceof Error ? e.stack : String(e)); process.exitCode=1; }

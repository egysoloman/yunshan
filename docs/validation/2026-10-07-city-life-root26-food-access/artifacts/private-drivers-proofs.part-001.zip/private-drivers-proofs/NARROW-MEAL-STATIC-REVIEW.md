# ROOT26 narrow meal 静态复审

日期：2026-10-07。范围：当前 helper、people/movement 调用路径、旧 5 case 候选及独立 narrow 6 case 私稿。只读源码并写本私稿；本代理没有运行 Simulation、step、Node、test、tsc、build 或 browser，没有写共享源码或共享测试。

结论：当前 helper 的距离与时间算术匹配 narrow 目标；新私稿的 80m eat 阈值/冷续跑、200m eat 与附近 social 延后、240m 折返延后设计均有静态依据。此结论不是执行通过，也不构成默认城市、自然主存档、全城供粮或自然行为验收；实际运行门仍仅由 root 执行。

## 已审输入快照

| 输入 | SHA-256 |
| --- | --- |
| `/workspace/yunshan/src/simulation/meal-route.ts` | `efc6594a6e54713a22b7f57b0a875083deeb45ca6d234dae75c462a3cd91c822` |
| `/workspace/yunshan/src/simulation.ts` | `5f1f54f26e5086f4ec28a7133cecbc867687991cda72574c0eb1dff704fc6979` |
| `/workspace/yunshan/tests/urgent-meal-processing.test.ts` | `e38afa0d4546a1fe3c7c5981b8255b25756d3f1c8b0922b3d33195ea00b4a3b9` |
| `/workspace/yunshan-work/ROOT26-food-access-20261007-01/urgent-meal-processing.test.ts` | `e38afa0d4546a1fe3c7c5981b8255b25756d3f1c8b0922b3d33195ea00b4a3b9` |
| `/workspace/yunshan-work/ROOT26-food-access-20261007-01/urgent-meal-processing-narrow.test.ts` | `5900101b98e88636715012d7fd76328d13675f149ba8eef8646b9655325cd855` |

若其他代理继续修改 narrow 私稿，以上测试判断绑定本表所列快照；后续 SHA 需单独登记。

## Helper 与调用的实际契约

- `meal-route.ts:14–16` 先要求 policy 为 `nearby-food-v1`、age ≥ 6、activity 为 `eat`、carried food < 1，以及 `hunger - elapsed * .05 < 30`；只有满足这些条件，已观测 arrived rider 才绕过剩余路线界限。
- `simulation.ts:1837–1847` 的 elapsed 是真实积存分钟加当前分钟；fine processing 清除 pending 并使用同一 elapsed 衰减 hunger，不额外创造或重用分钟。
- `meal-route.ts:17–25` 从当前位置连到 routeIndex 对应点，再累加之后每一条 x/y/z 欧氏距离。判定使用完整 remaining arc，不使用 endpoint 直距、道路 metadata length 或此前已走的 arc。
- 晴/云/雾 caller 速度均为 4.2m/min，25 分钟界限为 **105m**；雨为 3.1m/min，界限为 **77.5m**。`remaining > limit` 才排除，因此精确界限本身被接受。
- 空路线、负数/非整数/大于 route.length 的 index、非有限累计距离返回 false。index 等于 route.length 时仍核对当前位置到最后端点的距离；不能因 cursor 到末尾而把异地位置直接当成零剩余距离。
- `simulation.ts:1769–1822` 移动仍使用上述原速度与真实路线；helper 只影响处理频率。`simulation.ts:1884–1892` arrived rider 仍用实际 observed arrival clock 限制 walking availableMinutes：`min(elapsed, max(0, observedClock - arrivedAt))`，随后重建真实目的地路线。没有把此前骑乘分钟转换成步行预算。
- `simulation.ts:1912` 原 decision 窗口仍为 25–60 分钟；`1908–1914` 在 deadline 到期重新选择，而非通过 urgency 延长 deadline。

## 旧 5 case 与新 6 case 的静态核对

1. **2.625m 实际 sale point case 保持适用。** 初始位置与真实 ground sale point 共 y/x，只差 z 2.625m；本例有 supported floor 与无墙/实体阻挡断言。晴天每 .25 分钟最多 1.05m，因此三 tick 为 1.05 + 1.05 + .525 = 2.625m，耗时 .75 分钟，arrival hunger 为 20 - .75 × .05 = 19.9625。customer/commerce sale 的 wallet、finite stock、revenue、funds 断言保留；这些仍需实际门确认。
2. **旧 urgent social continuous case 应替换。** 旧 `clockRoute` 默认 social 且到 home 200m，本来就不满足 narrow 条件。新私稿用 200m eat 与 80m social 并列保 coarse：前者 200 > 105，后者 activity 不匹配；前 3 tick 位置与 hunger 不变、pending .25/.5/.75 有依据。
3. **carried/child/ordinary/legacy 的行为目标保持，fixture 已改为 80m eat。** 旧 social/200m 组合无法独立检验这些 guard；新短 eat fixture 分别由 food=1、age=5、hunger=60、legacy policy 排除，因此排除理由不再被 social/long 条件遮蔽。前 2 tick 无 stored-meal、不动且积存真实分钟，静态上成立。
4. **critical threshold case 必须使用短 eat。** 新 fixture 初始 x=320,y=0,z=20，到真实 market door x=400,y=0,z=20，处于原 200→400 public bridge 的 suffix，剩余确为 80m。它只设置 synthetic 初始 snapshot，没有在运行后搬动身体。30.04 在 elapsed .25/.5/.75 时 projected hunger 分别为 30.0275/30.015/30.0025，仍 ≥30；tick4 elapsed1 时为 29.99，开始 fine，走4.2m并删除 pending；tick5再扣 .0125 到29.9775，只走1.05m。该算术与 helper/caller 匹配。
5. **cold import + 8 ordinary tick case 使用同一 80m eat。** 两分钟 city time 对应 hunger 30.04 - 2×.05 = 29.94，走 2×4.2 = 8.4m；不存在 arrival 或补餐，最后仍距 door71.6m。初始 constructor 为晴，源码 runtime.weatherAt=540 分钟，测试仅480→482分钟；新私稿也显式断言 constructor 晴/speed1，无须强改天气。即时全存档相等、后续逐 tick 全存档相等只能由运行结果确认。
6. **新增折返完整路线 case 有效覆盖 endpoint 误判。** 从(320,0,20)经(320,0,100)、(400,0,100)到(400,0,20)，三条真实 bridge 各80m，full arc240m、endpoint直距80m。full arc/4.2≈57.142857分钟 >25，而 endpoint/4.2≈19.047619分钟 <25；因此仍 coarse。fixture 是受控既有未到期 eat intent，原世界还存在直接 bridge，它并不证明 planner 会自然选择该折返。新私稿的标题/断言已称 meal destination/market door，未把未到达 door 说成 sale counter 验收。

## 数值与完整路线 cornercase 建议

下列为现有 6 case 尚未独立覆盖的边界，不是已发现的源码失败；可由 root 决定是否另加小范围 helper 断言，不能据此扩大现有实际运行门。

| 边界 | 当前源码行为 | 最小有区分度的验证 |
| --- | --- | --- |
| 雨速界限 | 77.5m 可 fine，80m 会 coarse | 同一 critical/eat 输入，仅 caller speed 改3.1，对77.5m与80m分别判定；不要把晴80m fixture宣称为雨短路 |
| 精确25分钟 | 晴105m接受，>105m排除 | 105m与105.0001m；完整剩余arc必须实际构造，不把断言误差容忍加进policy |
| 3D 而非平面距离 | y 与x/z一样计入arc | projected XZ短、完整3D>105m的helper输入；当前240m折返全部y=0，只证明多段完整arc，不能单独证明y分量 |
| 路线已走部分 | 从当前位置与当前index继续计算 | 已走前缀很长，但真实剩余80m应fine；避免重新累计route[0]到当前位置 |
| 短首段、长尾段 | 必须检查route所有后续段 | 当前折返首段80m<105、后续将总长推至240，已可抓只看next waypoint的错误 |
| 已到route末尾 | 仍核对真实endpoint位置 | index==length且position==endpoint为零距离；index==length但位置离endpoint>105m应coarse |
| projected hunger精确30 | equality保coarse，strictly below才fine | 短eat route，构造 projected hunger正好30与略低于30两个输入；当前30.04四tick涵盖跨阈值但未独立覆盖精确相等 |
| arrived rider | 所有need/activity/policy guards仍先执行，再保真实arrival分钟 | 仅使用系统实际记录的arrival做integration；不要通过伪造arrivedAt来验收catch-up预算 |

说明级建议：私稿文件头“Only initial body/needs/activity … assigned”还漏列 `controlledRoute` 实际设置的 destinationId/route/routeIndex/state/decisionAt。应明确称为 synthetic initial body/needs 与 captured route/activity/decision intent；这属于 fixture 披露改进，不是数值失败。

剩余阻点：本代理受明确0执行约束，尚无任何narrow运行结果；root实际门及自然默认城市证据仍待完成。原shared测试与原私稿SHA相同，本代理未修改它们，也没有改写root原261测试统计。

#!/usr/bin/env python3
"""Draft ROOT26 evidence packer. Root alone supplies a plan and executes it.

Usage: python pack-root26.py /absolute/path/plan.json
Plan: {"destination": "/absolute/new/directory", "groups": [
  {"name": "evidence", "roots": [{"path": "/absolute/source", "prefix": "evidence"}],
   "files": [{"path": "/absolute/extra.txt", "archiveName": "extra.txt"}]}]}

No application imports, environment capture, network or subprocesses are used.
Sources are read-only. Success exists only when index.json says complete.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile
from dataclasses import dataclass
from typing import BinaryIO, Iterator


MIB = 1024 * 1024
RAW_LIMIT = 70 * MIB
ZIP_LIMIT = 90 * MIB
GIT_FILE_LIMIT = 100 * MIB
BUFFER_SIZE = MIB
EXCLUDED_DIRECTORIES = frozenset({"node_modules", ".git"})
SCHEMA = "root26-evidence-pack-v1"


class PackError(Exception):
    pass


@dataclass(frozen=True)
class Member:
    source: Path
    archive_name: str
    size: int
    sha256: str

    def record(self) -> dict:
        return {"archiveName": self.archive_name, "source": str(self.source),
                "bytes": self.size, "sha256": self.sha256}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PackError(message)


def unique_json_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        require(key not in result, f"Duplicate JSON key: {key!r}")
        result[key] = value
    return result


def only_fields(value: object, allowed: set[str], label: str) -> dict:
    require(isinstance(value, dict), f"{label} must be an object")
    require(not (set(value) - allowed), f"Unknown {label} fields: {sorted(set(value) - allowed)}")
    return value


def absolute_path(value: object, label: str) -> Path:
    require(isinstance(value, str) and bool(value), f"{label} must be a nonempty absolute path")
    require(not any(ord(char) < 32 or ord(char) == 127 for char in value), f"Control character in {label}")
    require(value.startswith("/") and not value.startswith("//"), f"{label} must be an absolute POSIX path")
    require("\\" not in value, f"Backslash in {label}")
    require(not any(part in {".", ".."} for part in value.split("/")), f"Noncanonical traversal in {label}")
    return Path(value)


def relative_name(value: object, label: str, allow_empty: bool = False) -> str:
    require(isinstance(value, str), f"{label} must be a string")
    if allow_empty and value == "":
        return ""
    require(bool(value) and not value.startswith("/"), f"{label} must be a nonempty relative path")
    require("\\" not in value and ":" not in value, f"Unsafe separator or drive in {label}")
    require(not any(ord(char) < 32 or ord(char) == 127 for char in value), f"Control character in {label}")
    parts = value.split("/")
    require(all(part and part not in {".", ".."} for part in parts), f"Unsafe path component in {label}")
    require(str(PurePosixPath(value)) == value, f"Noncanonical {label}")
    require(len(value.encode("utf-8")) <= 65535, f"ZIP filename exceeds its encoded length limit: {label}")
    return value


def no_symlink_stat(path: Path) -> os.stat_result:
    """Reject a symlink in any ancestor, including the requested root itself."""
    cursor = Path("/")
    result = cursor.lstat()
    for component in path.parts[1:]:
        require(stat.S_ISDIR(result.st_mode), f"Source ancestor is not a directory: {cursor}")
        cursor /= component
        result = cursor.lstat()
        require(not stat.S_ISLNK(result.st_mode), f"Symlink forbidden: {cursor}")
    return result


@contextlib.contextmanager
def open_source(path: Path) -> Iterator[BinaryIO]:
    """Use directory descriptors so neither parents nor the leaf follow links."""
    directory_fd = os.open("/", os.O_RDONLY | os.O_DIRECTORY)
    leaf_fd = None
    try:
        for component in path.parts[1:-1]:
            next_fd = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=directory_fd)
            os.close(directory_fd)
            directory_fd = next_fd
        leaf_fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory_fd)
        require(stat.S_ISREG(os.fstat(leaf_fd).st_mode), f"Only regular source files are accepted: {path}")
        with os.fdopen(leaf_fd, "rb") as handle:
            leaf_fd = None
            yield handle
    finally:
        if leaf_fd is not None:
            os.close(leaf_fd)
        os.close(directory_fd)


def stable_identity(info: os.stat_result) -> tuple:
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def stream_bytes(source: BinaryIO, destination: BinaryIO | None = None, limit: int | None = None) -> tuple[int, str]:
    digest, count = hashlib.sha256(), 0
    while True:
        block = source.read(BUFFER_SIZE)
        if not block:
            break
        count += len(block)
        require(limit is None or count <= limit, "Source grew beyond the allowed raw-file limit")
        digest.update(block)
        if destination is not None:
            destination.write(block)
    return count, digest.hexdigest()


def source_digest(path: Path) -> tuple[int, str]:
    with open_source(path) as handle:
        before = os.fstat(handle.fileno())
        require(before.st_size <= RAW_LIMIT, f"Single file exceeds 70 MiB: {path}")
        size, digest = stream_bytes(handle, limit=RAW_LIMIT)
        after = os.fstat(handle.fileno())
        require(stable_identity(before) == stable_identity(after) and size == before.st_size,
                f"Source changed while hashing: {path}")
        return size, digest


def artifact_record(path: Path) -> dict:
    with path.open("rb") as handle:
        size, digest = stream_bytes(handle)
    require(size < GIT_FILE_LIMIT, f"Generated file must be strictly smaller than 100 MiB: {path.name}")
    return {"file": path.name, "bytes": size, "sha256": digest}


def write_bytes_exclusive(path: Path, payload: bytes) -> dict:
    require(len(payload) < GIT_FILE_LIMIT, f"Generated file must be strictly smaller than 100 MiB: {path.name}")
    with path.open("xb") as handle:
        handle.write(payload)
    return {"file": path.name, "bytes": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}


def write_json_exclusive(path: Path, value: object) -> dict:
    payload = (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")
    return write_bytes_exclusive(path, payload)


def collect_root(root: Path, prefix: str, skipped: list[dict]) -> list[tuple[Path, str]]:
    require(not any(part in EXCLUDED_DIRECTORIES for part in root.parts), f"Explicit source root is inside an excluded directory: {root}")
    require(stat.S_ISDIR(no_symlink_stat(root).st_mode), f"Source root is not a directory: {root}")
    result = []
    for directory, dirnames, filenames in os.walk(root, topdown=True, followlinks=False, onerror=lambda error: (_ for _ in ()).throw(error)):
        current = Path(directory)
        require(stat.S_ISDIR(no_symlink_stat(current).st_mode), f"Walk directory changed: {current}")
        retained = []
        for name in sorted(dirnames):
            child = current / name
            info = child.lstat()
            # Even an excluded name must not be followed or conceal a symlink.
            require(not stat.S_ISLNK(info.st_mode), f"Symlink forbidden: {child}")
            require(stat.S_ISDIR(info.st_mode), f"Walk directory changed type: {child}")
            if name in EXCLUDED_DIRECTORIES:
                skipped.append({"path": str(child), "reason": "excluded directory", "name": name})
            else:
                retained.append(name)
        dirnames[:] = retained
        for name in sorted(filenames):
            path = current / name
            info = path.lstat()
            require(not stat.S_ISLNK(info.st_mode), f"Symlink forbidden: {path}")
            require(stat.S_ISREG(info.st_mode), f"Only regular source files are accepted: {path}")
            require(info.st_size <= RAW_LIMIT, f"Single file exceeds 70 MiB: {path}")
            tail = path.relative_to(root).as_posix()
            archive_name = relative_name(f"{prefix}/{tail}" if prefix else tail, "walk archiveName")
            result.append((path, archive_name))
    return result


def collect_plan(plan: object) -> tuple[Path, list[dict]]:
    plan = only_fields(plan, {"destination", "groups"}, "plan")
    destination = absolute_path(plan.get("destination"), "destination")
    require(not destination.exists() and not destination.is_symlink(), f"Destination must be a new directory: {destination}")
    require(stat.S_ISDIR(no_symlink_stat(destination.parent).st_mode), "Destination parent must already be a real directory")
    groups_input = plan.get("groups")
    require(isinstance(groups_input, list) and bool(groups_input), "groups must be a nonempty array")
    groups, names = [], set()
    for raw_group in groups_input:
        group = only_fields(raw_group, {"name", "roots", "files"}, "group")
        name = relative_name(group.get("name"), "group name")
        require("/" not in name and len(name.encode("utf-8")) <= 100, "Group name must be a single short path component")
        require(name.casefold() not in names, f"Duplicate group name: {name}")
        names.add(name.casefold())
        roots, files = group.get("roots", []), group.get("files", [])
        require(isinstance(roots, list) and isinstance(files, list), "group roots and files must be arrays")
        pairs, skipped = [], []
        for raw_root in roots:
            item = only_fields(raw_root, {"path", "prefix"}, "root")
            root = absolute_path(item.get("path"), "root.path")
            prefix = relative_name(item.get("prefix"), "root.prefix", allow_empty=True)
            pairs.extend(collect_root(root, prefix, skipped))
        for raw_file in files:
            item = only_fields(raw_file, {"path", "archiveName"}, "file")
            path = absolute_path(item.get("path"), "file.path")
            require(not any(part in EXCLUDED_DIRECTORIES for part in path.parts), f"Explicit file is inside an excluded directory: {path}")
            info = no_symlink_stat(path)
            require(stat.S_ISREG(info.st_mode), f"Explicit source is not a regular file: {path}")
            require(info.st_size <= RAW_LIMIT, f"Single file exceeds 70 MiB: {path}")
            pairs.append((path, relative_name(item.get("archiveName"), "file.archiveName")))
        seen = set()
        for _, archive_name in pairs:
            require(archive_name not in seen, f"Duplicate archive path in group {name}: {archive_name}")
            seen.add(archive_name)
        groups.append({"name": name, "pairs": sorted(pairs, key=lambda pair: pair[1]),
                       "roots": roots, "files": files, "skippedDirectories": skipped})
    return destination, groups


def split_members(members: list[Member]) -> list[list[Member]]:
    """Raw bytes never exceed 70 MiB; bound ZIP metadata as well as payload."""
    chunks, current, raw_bytes, estimated_zip = [], [], 0, 65536
    for member in members:
        require(member.size <= RAW_LIMIT, f"Single file exceeds 70 MiB: {member.source}")
        # Conservative extra space for deflate blocks, UTF-8 names, ZIP64
        # records and central directory entries. Actual ZIP size is still checked.
        estimate = member.size + (member.size // 16384 + 1) * 32 + 512 + 2 * len(member.archive_name.encode("utf-8"))
        require(estimate + 65536 < ZIP_LIMIT, f"A single ZIP entry cannot fit its size bound: {member.archive_name}")
        if current and (raw_bytes + member.size > RAW_LIMIT or estimated_zip + estimate >= ZIP_LIMIT):
            chunks.append(current)
            current, raw_bytes, estimated_zip = [], 0, 65536
        current.append(member)
        raw_bytes += member.size
        estimated_zip += estimate
    if current or not chunks:
        chunks.append(current)  # Empty groups remain explicit, with one valid ZIP.
    require([member for chunk in chunks for member in chunk] == members, "Chunking lost or reordered a member")
    return chunks


def make_zip(destination: Path, name: str, ordinal: int, members: list[Member]) -> dict:
    basename = f"{name}.part-{ordinal:03d}"
    archive_path = destination / f"{basename}.zip"
    require(sum(member.size for member in members) <= RAW_LIMIT, "Chunk exceeds 70 MiB uncompressed")
    with archive_path.open("xb") as output:
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
            for member in members:
                with open_source(member.source) as source:
                    before = os.fstat(source.fileno())
                    with archive.open(member.archive_name, "w", force_zip64=True) as target:
                        size, digest = stream_bytes(source, target, limit=RAW_LIMIT)
                    after = os.fstat(source.fileno())
                require(stable_identity(before) == stable_identity(after), f"Source changed during ZIP write: {member.source}")
                require(size == member.size and digest == member.sha256, f"ZIP write differs from original before SHA: {member.source}")
    zip_record = artifact_record(archive_path)
    require(zip_record["bytes"] < ZIP_LIMIT, f"ZIP must be strictly smaller than 90 MiB: {archive_path.name}")
    # This streams decompressed originals through zipfile's CRC verification.
    with zipfile.ZipFile(archive_path, "r") as archive:
        infos = archive.infolist()
        require([info.filename for info in infos] == [member.archive_name for member in members], "ZIP members differ from complete planned chunk")
        require(len({info.filename for info in infos}) == len(infos), "Duplicate ZIP member")
        for info, member in zip(infos, members):
            require(not info.is_dir() and info.compress_type == zipfile.ZIP_DEFLATED and not info.flag_bits & 1, f"Unexpected ZIP entry type: {info.filename}")
            require(info.file_size == member.size, f"ZIP member size metadata differs: {info.filename}")
            with archive.open(info, "r") as source:
                size, digest = stream_bytes(source, limit=RAW_LIMIT)
            require(size == member.size and digest == member.sha256, f"Decompressed ZIP bytes/SHA differ: {info.filename}")
    manifest = {"schema": SCHEMA, "group": name, "chunk": ordinal, "allChunksRequired": True,
                "archive": zip_record, "uncompressedBytes": sum(member.size for member in members),
                "memberCount": len(members), "members": [member.record() for member in members],
                "verification": "Every decompressed member matches original byte count and SHA-256."}
    manifest_record = write_json_exclusive(destination / f"{basename}.members.json", manifest)
    return {**zip_record, "chunk": ordinal, "uncompressedBytes": manifest["uncompressedBytes"],
            "memberCount": len(members), "manifest": manifest_record, "members": manifest["members"]}


README = """# ROOT26 complete evidence chunks

Every chunk of every group is required. Parts contain disjoint complete original
files under their complete archive names; no path prefix or failure evidence is
truncated. Do not treat a first part or a partial run as the complete delivery.

Only index.json with status complete declares success. It lists every ZIP,
member, original SHA-256/byte count, member manifest, and generated artifact hash.
source-before.json maps all included originals before packing; source-after.json
verifies all original files again after every ZIP has been written and read back.
Each ZIP's decompressed bytes and CRC were checked against the before map.

Raw chunks are at most 70 MiB, every ZIP is strictly below 90 MiB, and every
generated file is strictly below 100 MiB. ZIP_DEFLATED uses compression level 6.
Original gzip/ZIP files remain complete original bytes inside their ZIP members.

Source symlinks and special files are rejected. Regular node_modules and .git
directories are deliberately skipped and listed in the index. Explicit sources
inside those directories are rejected. Empty groups produce one explicit empty
ZIP. All output files use exclusive creation; existing destinations are rejected.

If failure.json exists, the run failed and any emitted chunks are incomplete.
The packer never uploads, imports application code, collects process environment,
executes tests/builds, or runs subprocesses. The operator supplies only the exact
authorized original sources in the JSON plan.
"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("plan", help="Absolute path to the JSON packing plan")
    args = parser.parse_args()
    destination, created, completed_groups = None, False, []
    try:
        require(os.name == "posix" and hasattr(os, "O_NOFOLLOW") and hasattr(os, "O_DIRECTORY"), "A POSIX host with no-follow descriptor support is required")
        plan_path = absolute_path(args.plan, "plan path")
        no_symlink_stat(plan_path)
        with open_source(plan_path) as source:
            plan_bytes = source.read(16 * MIB + 1)
        require(len(plan_bytes) <= 16 * MIB, "Plan exceeds 16 MiB")
        plan = json.loads(plan_bytes, object_pairs_hook=unique_json_object)
        destination, groups = collect_plan(plan)
        originals = {}
        for group in groups:
            for source_path, _ in group["pairs"]:
                if source_path not in originals:
                    originals[source_path] = source_digest(source_path)
            group["members"] = [Member(source_path, archive_name, *originals[source_path]) for source_path, archive_name in group["pairs"]]
            group["chunks"] = split_members(group["members"])
        os.mkdir(destination, mode=0o700)
        created = True
        readme_record = write_bytes_exclusive(destination / "README.md", README.encode("utf-8"))
        before_records = [{"source": str(path), "bytes": value[0], "sha256": value[1]} for path, value in sorted(originals.items(), key=lambda pair: str(pair[0]))]
        before_record = write_json_exclusive(destination / "source-before.json", {"schema": SCHEMA, "files": before_records,
            "groups": [{"name": group["name"], "members": [member.record() for member in group["members"]]} for group in groups]})
        for group in groups:
            chunk_records = []
            for ordinal, chunk in enumerate(group["chunks"], 1):
                chunk_records.append(make_zip(destination, group["name"], ordinal, chunk))
                print(f"Verified {group['name']} part {ordinal}: {len(chunk)} complete members", flush=True)
            require(sum(item["memberCount"] for item in chunk_records) == len(group["members"]), "Group member count differs after packing")
            require([entry for chunk in chunk_records for entry in chunk["members"]] == [member.record() for member in group["members"]], "Group originals are incomplete after packing")
            completed_groups.append({"name": group["name"], "allChunksRequired": True, "roots": group["roots"], "files": group["files"],
                "skippedDirectories": group["skippedDirectories"], "memberCount": len(group["members"]),
                "uncompressedBytes": sum(member.size for member in group["members"]), "chunks": chunk_records})
        after_records = []
        for source_path, expected in sorted(originals.items(), key=lambda pair: str(pair[0])):
            actual = source_digest(source_path)
            require(actual == expected, f"Original changed after packing: {source_path}")
            after_records.append({"source": str(source_path), "bytes": actual[0], "sha256": actual[1]})
        require(after_records == before_records, "After source map is not byte/SHA exact")
        after_record = write_json_exclusive(destination / "source-after.json", {"schema": SCHEMA, "allOriginalsMatchBefore": True, "files": after_records})
        index = {"schema": SCHEMA, "status": "complete", "allChunksRequired": True,
            "plan": {"source": str(plan_path), "bytes": len(plan_bytes), "sha256": hashlib.sha256(plan_bytes).hexdigest()},
            "limits": {"chunkUncompressedBytesAtMost": RAW_LIMIT, "zipBytesStrictlyBelow": ZIP_LIMIT, "generatedFileBytesStrictlyBelow": GIT_FILE_LIMIT},
            "compression": {"method": "ZIP_DEFLATED", "level": 6}, "readme": readme_record,
            "sourceBefore": before_record, "sourceAfter": after_record, "uniqueOriginalFileCount": len(originals),
            "totalMemberCount": sum(group["memberCount"] for group in completed_groups),
            "totalZipCount": sum(len(group["chunks"]) for group in completed_groups), "groups": completed_groups}
        write_json_exclusive(destination / "index.json", index)
        print(f"Complete verified pack: {destination / 'index.json'}", flush=True)
        return 0
    except (Exception, KeyboardInterrupt) as error:
        if created and destination is not None:
            try:
                write_json_exclusive(destination / "failure.json", {"schema": SCHEMA, "status": "failed", "allChunksRequired": True,
                    "errorType": type(error).__name__, "error": str(error), "completedGroups": completed_groups,
                    "partialOutputFiles": sorted(path.name for path in destination.iterdir())})
            except Exception as failure_error:
                print(f"Could not write failure record: {failure_error}", file=sys.stderr)
        print(f"Packing failed: {type(error).__name__}: {error}", file=sys.stderr)
        return 130 if isinstance(error, KeyboardInterrupt) else 1


if __name__ == "__main__":
    raise SystemExit(main())

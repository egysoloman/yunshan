"""Pure file decoding, hashes, and arithmetic. Does not import or run game code."""
import gzip
import hashlib
import json
import math
from pathlib import Path

BASE = Path('/tmp/ROOT26-food-access-20261007-01/native01')
OUT = Path('/workspace/yunshan-work/ROOT26-food-access-20261007-01')
TARGETS = ['shop-east-b37', 'shop-east-b50']
SUPPLIERS = ['shop-core-dock-building', 'shop-river-b57']

def sha(b):
    return hashlib.sha256(b).hexdigest()

def read(path):
    b = path.read_bytes()
    return json.loads(gzip.decompress(b) if path.suffix == '.gz' else b)

def event(row):
    return {k: row[k] for k in ['sequence', 'phase', 'tick', 'clock', 'event', 'taxRate', 'taxQueueBeforeForward', 'treasuryBeforeForward', 'originalEmitReturned']}

def shop(trace, which, sid):
    return next(r for r in trace[which]['shops'] if r['shop']['id'] == sid)

def cash(c, sid):
    return next(a['amount'] for a in c['cash']['accounts'] if a['id'] == f'shop.{sid}.cash')

def food(c):
    return {a['sourceId']: a['amount'] for a in c['food']['holdings'] if a['kind'] == 'food-shop'}

def actor(trace, which, idx):
    a = next(r for r in trace[which]['actors'] if r['index'] == idx)
    r = {k: a[k] for k in ['index', 'activity', 'pendingMinutes', 'decisionAt', 'customer', 'rider', 'stairCursor']}
    r['actor'] = {k: v for k, v in a['actor'].items() if k != 'route'}
    r['routeLength'] = len(a['actor']['route'])
    r['routeSHA256CanonicalJSON'] = sha(json.dumps(a['actor']['route'], separators=(',', ':')).encode())
    return r

verified, frames, bus, timeline, cargo, batches, actor_samples = [], [], [], [], [], [], []
initial = read(BASE / 'frames/0000-imported/whole-save.json.gz')
world = read(BASE / 'WORLD.original.json')
buildings = {b['id']: b for b in world['buildings']}
east_ids = [s['id'] for s in initial['state']['shops'] if s['districtId'] == 'east']
initial_stock = {s['id']: s['inventory'] for s in initial['state']['shops'] if s['id'] in TARGETS}
initial_funds = {s['id']: s['cash'] for s in initial['state']['shops'] if s['id'] in TARGETS}

for directory in sorted((BASE / 'frames').iterdir()):
    manifest = read(directory / 'FRAME.json')
    for kind in ['save', 'bus', 'custody', 'foodTrace']:
        d = manifest[kind]
        encoded = (BASE / d['file']).read_bytes()
        decoded = gzip.decompress(encoded)
        assert len(encoded) == d['encodedBytes'] and sha(encoded) == d['encodedSHA256'], d['file']
        assert len(decoded) == d['rawBytes'] and sha(decoded) == d['rawSHA256'], d['file']
        verified.append({'kind': kind, **d})
    frames.append({'path': str(directory / 'FRAME.json'), 'sha256': sha((directory / 'FRAME.json').read_bytes()), **manifest})
    if manifest['label'] == 'imported':
        continue
    events = read(directory / 'all-bus.json.gz')
    bus.extend(events)
    custody = read(directory / 'stable-phase-custody.json.gz')
    trace = read(directory / 'food-access-trace.json.gz')
    tc = next(x for x in trace if x['phase'] == 'commerce')
    people = next(x for x in custody['phases'] if x['phase'] == 'people')
    commerce = next(x for x in custody['phases'] if x['phase'] == 'commerce')
    finance = next(x for x in custody['phases'] if x['phase'] == 'finance')
    before, after = food(people), food(commerce)
    sales = [x for x in events if x['event']['type'] == 'sale' and x['event'].get('shopId') in TARGETS]
    by_shop = {}
    for sid in TARGETS:
        own_sales = [x for x in sales if x['event']['shopId'] == sid]
        sold = sum(x['event']['quantity'] for x in own_sales)
        by_shop[sid] = {'inventoryBefore': before[sid], 'inventoryAfter': after[sid], 'actualSaleQuantity': sold,
                        'grossStockAddition': after[sid] - before[sid] + sold,
                        'sales': [event(x) for x in own_sales], 'before': shop(tc, 'before', sid), 'after': shop(tc, 'after', sid),
                        'custodyCashBefore': cash(people, sid), 'custodyCashAfter': cash(commerce, sid)}
        assert abs(by_shop[sid]['before']['funds'] - cash(people, sid)) < 1e-9
        assert abs(by_shop[sid]['after']['funds'] - cash(commerce, sid)) < 1e-9
    timeline.append({'frame': manifest['label'], 'tick': manifest['tick'], 'clock': manifest['clock'],
                     'commerceAtBefore': tc['before']['commerceAt'], 'commerceAtAfter': tc['after']['commerceAt'],
                     'eastFreightBefore': tc['before']['freight'].get('east', 0), 'eastFreightAfter': tc['after']['freight'].get('east', 0),
                     'eastLotsBefore': tc['before']['freightLots'].get('east', []), 'eastLotsAfter': tc['after']['freightLots'].get('east', []),
                     'shops': by_shop, 'custodyErrors': {k: custody[k] for k in ['violations', 'captureFailures']}})
    for row in events:
        e = row['event']
        if e['type'] != 'cargo-arrived' or e.get('districtId') != 'east':
            continue
        tt = next(x for x in trace if x['phase'] == 'traffic')
        vehicle_id = e['vehicleId']
        save = read(directory / 'whole-save.json.gz')
        vehicle_terminal = next(v for v in save['state']['vehicles'] if v['id'] == vehicle_id)
        cargo.append({'originalEvent': event(row), 'phaseTrace': {side: {
            'freight': tt[side]['freight'].get('east', 0), 'lots': tt[side]['freightLots'].get('east', []),
            'cargoSource': tt[side]['cargoSources'].get(vehicle_id),
            'vehicle': next((v for v in tt[side]['freightVehicles'] if v['id'] == vehicle_id), None)} for side in ['before', 'after']},
            'sameWindowWholeSaveVehicle': vehicle_terminal,
            'note': 'A cleared vehicle is absent from the freightVehicles trace filter; its whole-save cargo is separately retained.'})
    wholesale = [x for x in events if x['event']['type'] == 'wholesale' and x['event'].get('shopId') in SUPPLIERS]
    if wholesale:
        source_ids = sorted({x['event']['shopId'] for x in wholesale})
        assert len(source_ids) == 1
        source = source_ids[0]
        gross = sum(x['event']['amount'] for x in wholesale)
        tax = sum(x['event']['amount'] * x['taxRate'] for x in wholesale)
        witnesses = []
        for x in wholesale:
            following = next(r for r in events if r['sequence'] == x['sequence'] + 1)
            increment = following['taxQueueBeforeForward'] - x['taxQueueBeforeForward']
            assert abs(increment - x['event']['amount'] * x['taxRate']) < 1e-10
            witnesses.append({'event': event(x), 'followingSequence': following['sequence'],
                              'nextTaxQueueBeforeForward': following['taxQueueBeforeForward'], 'actualQueueIncrement': increment,
                              'retailIdInPayload': 'retailId' in x['event'], 'retailBuyerAttributedToSingleEvent': None})
        source_before, source_after = cash(people, source), cash(commerce, source)
        assert abs(source_after - source_before - (gross - tax)) < 1e-9
        allocations = []
        for sid in TARGETS:
            r = by_shop[sid]
            qty = r['grossStockAddition']
            assert qty == 14
            own_sales = r['sales']
            sale_gross = sum(x['event']['amount'] for x in own_sales)
            sale_net = sum(x['event']['amount'] * (1 - x['taxRate']) for x in own_sales)
            fees = [event(x) for x in events if x['event']['type'] == 'business-expense' and x['event'].get('shopId') == sid]
            fee_amount = sum(x['event']['amount'] for x in fees)
            residual = r['custodyCashAfter'] - r['custodyCashBefore'] - (-qty * 4 + sale_net - fee_amount)
            assert abs(residual) < 1e-9
            available = r['before']['funds'] - r['before']['protected']
            allocations.append({'retailShopId': sid, 'sourceShopId': source, 'quantity': qty, 'grossPurchasePayment': qty * 4,
                                'attribution': 'Unique source at phase level, derived from sole FIFO lot + complete food custody + real sales; no single wholesale event label invented.',
                                'before': r['before'], 'after': r['after'], 'availableFundsBefore': available,
                                'unitPriceObserved': 4, 'affordableWholeUnitsBefore': math.floor(max(0, available) / 4),
                                'stockThreshold': 36, 'perRetailBatchLimit': 14, 'stockCapacity': 70,
                                'cashBefore': r['custodyCashBefore'], 'cashAfter': r['custodyCashAfter'],
                                'concurrentRetailSaleGross': sale_gross, 'concurrentRetailSaleNet': sale_net,
                                'concurrentBusinessExpenses': fees, 'cashArithmeticResidual': residual})
        assert sum(x['quantity'] for x in allocations) == sum(x['event']['quantity'] for x in wholesale) == 28
        assert tc['before']['freightLots']['east'] == [{'shopId': source, 'quantity': 28}]
        batches.append({'frame': manifest['label'], 'tick': manifest['tick'], 'clock': manifest['clock'],
                        'sourceShopId': source, 'wholesaleEvents': witnesses, 'allocations': allocations,
                        'quantity': 28, 'gross': gross, 'sourceNet': source_after - source_before, 'taxQueued': tax,
                        'sourceFundsBefore': source_before, 'sourceFundsAfter': source_after,
                        'sourceFiniteHeadroomUnitsBefore': (1e9 - source_before) / (4 * (1 - wholesale[0]['taxRate'])),
                        'allEastFoodCustody': [{'shopId': sid, 'before': before[sid], 'after': after[sid],
                           'saleQuantity': sum(x['event']['quantity'] for x in events if x['event']['type'] == 'sale' and x['event'].get('shopId') == sid)} for sid in east_ids],
                        'pooledFinance': {'commerceTreasury': commerce['publicBudget']['cash'], 'commerceTreasuryPlusTaxQueue': commerce['fiscal'],
                            'financeTreasury': finance['publicBudget']['cash'], 'financeTreasuryPlusTaxQueue': finance['fiscal'],
                            'note': 'Tax queue is pooled with other sales/procurement. Source simulation.ts:2177 transfers and clears it directly; no tax-collection event invented.'}})
    if manifest['tick'] in [2071, 2078, 2086]:
        phase = next(x for x in trace if x['phase'] == ('people' if manifest['tick'] == 2071 else 'commerce'))
        actor_samples.append({'tick': manifest['tick'], 'clock': manifest['clock'], 'phase': phase['phase'],
                              'actors': {str(idx): {side: actor(phase, side, idx) for side in ['before', 'after']} for idx in [457, 489, 153, 450]}})

terminal = read(BASE / 'frames/0016-ordinary-016/whole-save.json.gz')
sale_events = [event(x) for x in bus if x['event']['type'] == 'sale' and x['event'].get('shopId') in TARGETS]
dividends = [event(x) for x in bus if x['event']['type'] == 'business-dividend' and x['event'].get('shopId') in TARGETS]
balances = []
for sid in TARGETS:
    s = next(s for s in terminal['state']['shops'] if s['id'] == sid)
    sales = [x for x in sale_events if x['event']['shopId'] == sid]
    fees = [event(x) for x in bus if x['event']['type'] == 'business-expense' and x['event'].get('shopId') == sid]
    distributions = [x for x in dividends if x['event']['shopId'] == sid]
    quantities = sum(x['event']['quantity'] for x in sales)
    additions = sum(x['quantity'] for b in batches for x in b['allocations'] if x['retailShopId'] == sid)
    assert initial_stock[sid] + additions - quantities == s['inventory']
    net = sum(x['event']['amount'] * (1 - x['taxRate']) for x in sales)
    gross = sum(x['event']['amount'] for x in sales)
    fee = sum(x['event']['amount'] for x in fees)
    dividend = sum(x['event']['amount'] for x in distributions)
    residual = s['cash'] - initial_funds[sid] - (-additions * 4 + net - fee - dividend)
    balances.append({'shopId': sid, 'initialInventory': initial_stock[sid], 'purchased': additions, 'actualSold': quantities,
                     'terminalInventory': s['inventory'], 'initialCash': initial_funds[sid], 'terminalCash': s['cash'],
                     'saleGross': gross, 'saleNet': net, 'saleTax': gross - net, 'purchaseGross': additions * 4,
                     'businessExpenses': fees, 'businessDividends': distributions, 'cashResidualAfterListedFlows': residual,
                     'note': 'Endpoint residual may include other real payroll/finance flows; procurement phase residuals above isolate exact actual payments.'})

lot_samples = []
for dirname in ['0000-imported', '0005-ordinary-005', '0006-ordinary-006', '0008-ordinary-008', '0009-ordinary-009', '0016-ordinary-016']:
    s = read(BASE / f'frames/{dirname}/whole-save.json.gz')
    lot_samples.append({'frame': dirname, 'tick': s['state']['tick'], 'ownedLots': {sid: s['state']['trade']['ownedLots'].get(sid, []) for sid in TARGETS},
                        'consignmentLots': s['state']['trade']['lots'], 'taxQueueAtWholeSave': s['runtime']['taxes']})
result = read(BASE / 'RESULT.json')
receipt_path = OUT / 'native01-gate/receipt.json'
source_paths = ['src/simulation.ts', 'src/simulation/trade.ts', 'src/simulation/freight-delivery.ts', 'src/simulation/freight-access.ts', 'src/simulation/meal-route.ts', 'src/simulation/shop_lifecycle.ts']
source_hashes = {s: sha((Path('/workspace/yunshan') / s).read_bytes()) for s in source_paths}
assert frames[0]['save']['rawSHA256'] == result['inputSaveSHA256']
assert frames[-1]['save']['rawSHA256'] == result['terminalSaveSHA256']
summary = {
    'scope': 'Native01 only; pure file decoding/hash/arithmetic; no Simulation constructors/imports/steps/tests/build/browser invoked by this analysis; no source or memo writes.',
    'repositoryHeadSuppliedByRoot': '65d7c6fd20701388aab0acdee327003333579b59', 'sourcesReadSHA256': source_hashes,
    'originalDirectory': str(BASE), 'resultPath': str(BASE / 'RESULT.json'), 'resultSHA256': sha((BASE / 'RESULT.json').read_bytes()), 'result': result,
    'gateReceiptPath': str(receipt_path), 'gateReceiptSHA256': sha(receipt_path.read_bytes()), 'gateReceipt': read(receipt_path),
    'verification': {'allFrameDescriptorCount': len(verified), 'allEncodedAndDecodedHashesAndSizesExact': True,
                     'framesComplete': all(x['complete'] for x in frames), 'phaseCustodyNoViolations': all(not x['custodyErrors']['violations'] and not x['custodyErrors']['captureFailures'] for x in timeline),
                     'resultInputAndTerminalSHAExact': True},
    'verifiedFrameManifests': frames, 'cargoArrivals': cargo, 'fifoProcurementBatches': batches,
    'totals': {'unloaded': sum(x['originalEvent']['event']['amount'] for x in cargo), 'purchased': sum(b['quantity'] for b in batches),
               'wholesaleGross': sum(b['gross'] for b in batches), 'supplierNet': sum(b['sourceNet'] for b in batches),
               'wholesaleTaxQueued': sum(b['taxQueued'] for b in batches), 'terminalEastFreight': terminal['runtime']['freight'].get('east', 0),
               'terminalEastFreightLots': terminal['runtime']['freightLots'].get('east', []),
               'relatedRetailSold': sum(x['event']['quantity'] for x in sale_events)},
    'retailInventoryAndCashBalances': balances, 'commerceTimeline': timeline, 'actualRelatedCounterSales': sale_events,
    'fourActorPhaseSamples': actor_samples, 'fourActorSales': [event(x) for x in bus if x['event']['type'] == 'sale' and x['event'].get('citizenId') in ['citizen-457', 'citizen-489', 'citizen-153', 'citizen-450']],
    'ownedLotSamples': lot_samples,
    'eastLocalProducerSites': [{'shopId': s['id'], 'kind': buildings[s['buildingId']]['kind']} for s in initial['state']['shops'] if s['districtId'] == 'east' and buildings[s['buildingId']]['kind'] in ['farm', 'dock']],
    'limitations': [
        'Each wholesale pair has identical payload without retailId. Phase-level buyers are unique from sole source lot, full custody, sales and cash; no individual event-to-retail pairing is asserted.',
        'Cargo node east-b37-door is a district unloading location, not proof all 28 belongs to b37. District FIFO purchases split 14+14.',
        '52 b50 counter-sale units include its initial 24, so related retail total57 is not 57 units from these imported56.',
        'Owned stock lots with equal unit price merge (src/simulation/trade.ts:95-103); after second arrival, exact later per-unit supplier lineage is not retained by saved lot identity.',
        'Citizen450 sale predates river delivery and follows initial b50 stock exhaustion, uniquely placing its2 sale units in first core batch; broader later supplier-per-sale attribution is not claimed.',
        'Zero stock alone cannot prove meal failure. Actual route/contact, customer binding, schedule/energy/lifecycle, finite money and sale/custody validity guards require actor-phase evidence.',
        'No long-term steady state, native02/03 result, additional physical window, browser, gameplay fix or injection claimed.'
    ]
}
assert summary['totals']['unloaded'] == summary['totals']['purchased'] == 56
output = OUT / 'NATIVE01-EAST-FREIGHT-CHAIN.json'
output.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'output': str(output), 'bytes': output.stat().st_size, 'sha256': sha(output.read_bytes()), 'totals': summary['totals'],
                  'balances': [{k:r[k] for k in ['shopId','initialInventory','purchased','actualSold','terminalInventory','initialCash','terminalCash','saleGross','cashResidualAfterListedFlows']} for r in balances],
                  'verifiedDescriptors': len(verified)}, ensure_ascii=False))

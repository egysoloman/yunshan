import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync, unlinkSync, linkSync } from 'node:fs';
import { join } from 'node:path';
import { gzipSync, gunzipSync } from 'node:zlib';
import { recheckFoodAccess } from '/workspace/yunshan/scripts/food-access-recheck';
const source = '/tmp/ROOT26-food-access-20261007-01/native01', out = process.argv[2];
assert(out && !existsSync(out)); mkdirSync(out);
const sha = (data: string | Buffer) => createHash('sha256').update(data).digest('hex');
const walk = (root: string, prefix = ''): string[] => readdirSync(join(root, prefix), { withFileTypes: true }).flatMap(entry => {
  assert(entry.isFile() || entry.isDirectory()); const path = join(prefix, entry.name); return entry.isDirectory() ? walk(root, path) : [path];
}).sort();
const files = walk(source), before = Object.fromEntries(files.map(file => [file, sha(readFileSync(join(source, file)))]));
function clone(name: string) {
  const root = join(out, name); mkdirSync(root);
  for (const file of files) { mkdirSync(join(root, file, '..'), { recursive: true }); linkSync(join(source, file), join(root, file)); }
  return root;
}
function detached(root: string, file: string, data: string | Buffer) {
  const path = join(root, file); unlinkSync(path); writeFileSync(path, data, { flag: 'wx' });
}
function replace(root: string, record: any, raw: string) {
  const encoded = gzipSync(Buffer.from(raw)); detached(root, record.file, encoded);
  Object.assign(record, { rawBytes: Buffer.byteLength(raw), rawSHA256: sha(raw), encodedBytes: encoded.length, encodedSHA256: sha(encoded) });
}
const rows: any[] = [];
for (const kind of ['physical-byte', 'food-with-updated-hashes', 'missing-sale-with-updated-hashes']) {
  const root = clone(kind), frames = JSON.parse(readFileSync(join(root, 'FRAMES.json'), 'utf8'));
  const frame = frames[1]; let expected: RegExp;
  if (kind === 'physical-byte') {
    const encoded = readFileSync(join(root, frame.save.file)); encoded[Math.floor(encoded.length / 2)] ^= 1; detached(root, frame.save.file, encoded);
    expected = /encoded original SHA/;
  } else if (kind === 'food-with-updated-hashes') {
    const save = JSON.parse(gunzipSync(readFileSync(join(root, frame.save.file))).toString('utf8'));
    save.state.citizens[0].food = (save.state.citizens[0].food ?? 0) + 1;
    replace(root, frame.save, JSON.stringify(save)); detached(root, 'FRAMES.json', JSON.stringify(frames));
    expected = /whole original food equals feedback custody/;
  } else {
    const bus = JSON.parse(gunzipSync(readFileSync(join(root, frame.bus.file))).toString('utf8'));
    const index = bus.findIndex((row: any) => row.event.type === 'sale'); assert(index >= 0, 'remove an actual original sale');
    const removed = bus.splice(index, 1)[0]; replace(root, frame.bus, JSON.stringify(bus)); detached(root, 'FRAMES.json', JSON.stringify(frames));
    expected = /independent complete bus equals custody original bus/; rows.push({ removedActualSale: removed.event, originalSequence: removed.sequence });
  }
  let rejection = '';
  assert.throws(() => { try { recheckFoodAccess([root]); } catch (e) { rejection = String(e); throw e; } }, expected);
  rows.push({ case: kind, rejected: true, expected: String(expected), originalRootMutated: false, rejection });
}
assert.deepEqual(Object.fromEntries(walk(source).map(file => [file, sha(readFileSync(join(source, file)))])), before, 'every original byte remains exact');
const result = { status: 'PASS', negativeCases: 3, constructors: 0, imports: 0, steps: 0,
  scope: 'Detached evidence corruptions only; never loaded into a Simulation or used as gameplay input.', originalFilesUnchanged: files.length, rows };
writeFileSync(join(out, 'RESULT.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' }); console.log(JSON.stringify(result));

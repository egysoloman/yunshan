import assert from 'node:assert/strict';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { recheckFoodAccess } from '/workspace/yunshan/scripts/food-access-recheck';
const out=process.argv[2]; assert(out && !existsSync(out)); mkdirSync(out);
const base='/tmp/ROOT26-food-access-20261007-01';
const plans=[['control80',['native01','native02','native03','native04']],['broad-rejected40',['patched02']],['narrow48-two-source-segments',['patched03','patched04']]] as const;
const rows=[];
for(const [name,runs] of plans){
 const result=recheckFoodAccess(runs.map(run=>join(base,run)));
 assert.equal(result.status,'PASS_SEALED_ORIGINAL_RECHECK');
 writeFileSync(join(out,name+'.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 const row={name,status:result.status,windows:result.completeOriginalWindows,phases:result.completeStablePhases,actuallyAte:result.cohortActuallyAte,recovered:result.cohortRecoveredAtTerminal,remaining:result.cohortRemainingLow.length,allLow:result.allCitizensLow,constructors:0,imports:0,steps:0,scope:name==='narrow48-two-source-segments'?'40 pre-egress-source419 + 8 final421 cold continuation; not one source/fresh48':'Independent original run lineage; never extend another branch'};
 rows.push(row);console.log(JSON.stringify(row));
}
writeFileSync(join(out,'RESULT.json'),JSON.stringify({status:'PASS',runs:rows,simulations:0,imports:0,steps:0,scope:'Positive full physical original rechecks, each lineage independently; no missing captures upgraded.'},null,2)+'\n',{flag:'wx'});

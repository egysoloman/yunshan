#!/usr/bin/env python3
"""PREPARED_NOT_RUN: plot actual original-file comparison JSON, with no Sim.

Future root-only invocation:
  python3 plot-food-access.py --comparison-dir /absolute/actual-comparison \
      --output-dir /absolute/new-plot-directory

Reads only comparison.json/provenance.json for chart data. No scenario runner,
product import, subprocess, simulation, step, or invented observation is used.
Requires Python 3 and matplotlib; uses Agg and English text for export.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys
from typing import Any


CHECKPOINT_CLOCK = 5416
EXPECTED_CLOCKS = (5480, 5576)
EXPECTED_COHORT = 89
SCENARIOS = (
    ("control-original", "Control original", "#777777"),
    ("patched02", "Rejected broad (patched02)", "#c54444"),
    ("patched03", "Adopted narrow (patched03)", "#2878bd"),
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def object_value(value: Any, label: str) -> dict[str, Any]:
    require(isinstance(value, dict), f"{label} must be a JSON object")
    return value


def integer(value: Any, label: str, minimum: int = 0) -> int:
    require(type(value) in (int, float) and math.isfinite(value), f"{label} must be finite")
    require(value == int(value) and value >= minimum, f"{label} must be an integer >= {minimum}")
    return int(value)


def string_value(value: Any, label: str) -> str:
    require(isinstance(value, str) and bool(value), f"{label} must be a nonempty string")
    return value


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha_value(value: Any, label: str) -> str:
    value = string_value(value, label)
    require(re.fullmatch(r"[0-9a-f]{64}", value) is not None, f"{label} must be a SHA-256")
    return value


def read_json(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    require(path.is_file() and not path.is_symlink(), f"input must be a regular nonsymlink file: {path}")
    raw = path.read_bytes()
    value = object_value(json.loads(raw), str(path))
    return value, {"path": str(path), "bytes": len(raw), "sha256": sha256(raw)}


def branch_of(label: str) -> str | None:
    matches = [branch for branch in ("patched02", "patched03")
               if re.search(rf"(?:^|[-_.]){branch}(?:$|[-_.])", label, re.IGNORECASE)]
    require(len(matches) <= 1, f"ambiguous patched scenario label: {label}")
    return matches[0] if matches else None


def actor_ids(value: Any, label: str) -> set[str]:
    require(isinstance(value, list), f"{label} must be an array")
    values = [string_value(item, label) for item in value]
    require(len(set(values)) == len(values), f"{label} contains duplicate actor IDs")
    return set(values)


def parse_metric(value: Any, clock: int, tick: int, label: str) -> dict[str, Any]:
    metric = object_value(value, label)
    require(integer(metric.get("clock"), f"{label}.clock") == clock, f"{label} clock differs from comparison")
    require(integer(metric.get("tick"), f"{label}.tick") == tick, f"{label} tick differs from comparison")
    low = integer(metric.get("cohortLowCount"), f"{label}.cohortLowCount")
    recovered = integer(metric.get("cohortCurrentlyRecoveredCount"), f"{label}.cohortCurrentlyRecoveredCount")
    dead = integer(metric.get("cohortDeadCount"), f"{label}.cohortDeadCount")
    require(low + recovered + dead == EXPECTED_COHORT, f"{label} does not account for the same 89-person cohort")
    low_ids = actor_ids(metric.get("cohortCurrentLowIds"), f"{label}.cohortCurrentLowIds")
    recovered_ids = actor_ids(metric.get("cohortRecoveredIds"), f"{label}.cohortRecoveredIds")
    require(len(low_ids) == low and len(recovered_ids) == recovered, f"{label} cohort count/ID mismatch")
    require(not low_ids.intersection(recovered_ids), f"{label} low/recovered actor IDs overlap")
    actor_count = integer(metric.get("finiteOriginalWalletFoodCheckedActors"), f"{label}.checkedActors", EXPECTED_COHORT)
    city_low = integer(metric.get("allCityAliveLowCount"), f"{label}.allCityAliveLowCount")
    require(low <= city_low <= actor_count, f"{label} all-city low count is inconsistent")
    return {
        "clock": clock,
        "tick": tick,
        "root": string_value(metric.get("root"), f"{label}.root"),
        "cohortSize": low + recovered + dead,
        "cohortLowCount": low,
        "cohortCurrentlyRecoveredCount": recovered,
        "cohortDeadCount": dead,
        "allCityAliveLowCount": city_low,
        "finiteOriginalWalletFoodCheckedActors": actor_count,
        "cohortCurrentLowIds": sorted(low_ids),
        "cohortRecoveredIds": sorted(recovered_ids),
        "saveRawSHA256": sha_value(metric.get("saveRawSHA256"), f"{label}.saveRawSHA256"),
    }


def parse_rows(comparison: dict[str, Any], provenance: dict[str, Any]) -> tuple[list[dict[str, Any]], list[str], dict[str, str]]:
    require(comparison.get("scope") == "PURE_IO_NO_SIM_NO_IMPORT_VALIDATION_NO_COUNTERFACTUAL", "unexpected comparison scope")
    require(comparison.get("comparisonStatus") == "ORIGINAL_EVIDENCE_ONLY", "comparison is not original evidence")
    definition = string_value(comparison.get("cohortDefinition"), "cohortDefinition")
    require(definition.startswith("89 alive citizens with hunger<30 in genuine5416;"), "unexpected original cohort definition")
    require(provenance.get("status") == "PURE_FILE_COMPARISON_COMPLETED", "comparison producer did not complete")
    require(provenance.get("allOriginalEncodedSHAStable") is True, "comparison producer did not establish input stability")
    sha_value(provenance.get("scriptSHA256"), "provenance.scriptSHA256")
    for key in ("productImports", "simulations", "steps"):
        require(type(provenance.get(key)) is int and provenance[key] == 0, f"provenance {key} must be literal zero")
    checkpoint = object_value(comparison.get("checkpoint"), "checkpoint")
    checkpoint_sha = sha_value(checkpoint.get("sha256"), "checkpoint.sha256")
    original_files = provenance.get("originalFiles")
    require(isinstance(original_files, list), "provenance.originalFiles must be an array")
    require(any(isinstance(proof, dict) and proof.get("path") == checkpoint.get("path")
                and proof.get("sha256") == checkpoint_sha and proof.get("bytes") == checkpoint.get("bytes")
                for proof in original_files), "checkpoint proof is absent from producer provenance")

    values = comparison.get("comparisons")
    require(isinstance(values, list), "comparison.comparisons must be an array")
    selected: dict[str, dict[int, dict[str, Any]]] = {"patched02": {}, "patched03": {}}
    control_originals: dict[int, dict[str, Any]] = {}
    selected_labels: dict[str, str] = {}
    excluded: set[str] = set()
    observed_ids: set[str] = set()
    for index, value in enumerate(values):
        row = object_value(value, f"comparisons[{index}]")
        label = string_value(row.get("scenario"), f"comparisons[{index}].scenario")
        branch = branch_of(label)
        if branch is None:
            excluded.add(label)
            continue
        require(row.get("status") == "EXACT_CLOCK_ORIGINAL_FILE_COMPARISON", f"{label} is not an exact original-file comparison")
        clock = integer(row.get("clock"), f"{label}.clock")
        require(clock in EXPECTED_CLOCKS, f"unexpected chart clock in {label}: {clock}")
        tick = integer(row.get("tick"), f"{label}.tick")
        require(row.get("windowFrom5416") == (clock - CHECKPOINT_CLOCK) / 4, f"{label} has inconsistent inherited elapsed windows")
        require(clock not in selected[branch], f"duplicate {branch} comparison at {clock}; observations must not be pooled")
        require(branch not in selected_labels or selected_labels[branch] == label, f"multiple original runs matched {branch}")
        selected_labels[branch] = label
        control_raw = object_value(row.get("control"), f"{label}.control")
        if clock in control_originals:
            require(control_originals[clock] == control_raw, f"control originals disagree between scenarios at {clock}")
        else:
            control_originals[clock] = control_raw
        control = parse_metric(control_raw, clock, tick, f"{label}.control")
        patched = parse_metric(row.get("patched"), clock, tick, f"{label}.patched")
        selected[branch][clock] = {"sourceComparisonIndex": index, "sourceScenario": label, **patched}
        for metric in (control, patched):
            observed_ids.update(metric["cohortCurrentLowIds"])
            observed_ids.update(metric["cohortRecoveredIds"])
    require(len(observed_ids) <= EXPECTED_COHORT, "observed actor IDs exceed the shared original cohort")
    require(set(control_originals) == set(EXPECTED_CLOCKS), "control must have both exact chart clock points")
    for branch in selected:
        require(set(selected[branch]) == set(EXPECTED_CLOCKS), f"{branch} must have exactly two points at 5480 and 5576")

    runs = comparison.get("runs")
    require(isinstance(runs, list), "comparison.runs must be an array")
    for branch, label in selected_labels.items():
        matching = [object_value(run, "run") for run in runs
                    if isinstance(run, dict) and Path(string_value(run.get("root"), "run.root")).name == label]
        require(len(matching) == 1, f"{label} requires exactly one original run record")
        run = matching[0]
        require(run.get("status") == "ACTUAL_COMPLETED", f"{label} replay did not actually complete")
        require(run.get("inputSHA256") == checkpoint_sha, f"{label} did not start from the same original checkpoint bytes")
        for row in selected[branch].values():
            require(row["root"] == run["root"], f"{label} metric root differs from its actual run")

    rows = []
    for scenario, _, _ in SCENARIOS:
        for clock in EXPECTED_CLOCKS:
            metric = (parse_metric(control_originals[clock], clock, integer(control_originals[clock].get("tick"), "control.tick"), "control")
                      if scenario == "control-original" else selected[scenario][clock])
            rows.append({"scenario": scenario, **metric})
    return rows, sorted(excluded), selected_labels


def clock_label(clock: int) -> str:
    day, minute = divmod(clock, 1440)
    hour, minute = divmod(minute, 60)
    return f"Day {day} {hour:02d}:{minute:02d}\n+{clock - CHECKPOINT_CLOCK} min from {CHECKPOINT_CLOCK}"


def write_json_new(path: Path, value: Any) -> None:
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=True, indent=2, allow_nan=False)
        stream.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--comparison-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    require(args.comparison_dir.is_absolute() and args.output_dir.is_absolute(), "input and output directories must be absolute")
    input_dir = args.comparison_dir.resolve(strict=True)
    require(input_dir.is_dir(), "comparison directory does not exist")
    require(not args.output_dir.exists() and not args.output_dir.is_symlink(), "output directory must be new")
    output_dir = args.output_dir.resolve(strict=False)
    require(output_dir != input_dir and input_dir not in output_dir.parents, "output may not modify the input comparison directory")
    require(output_dir.parent.is_dir(), "output parent directory must already exist")
    comparison, comparison_proof = read_json(input_dir / "comparison.json")
    provenance, provenance_proof = read_json(input_dir / "provenance.json")
    rows, excluded, labels = parse_rows(comparison, provenance)

    import matplotlib
    matplotlib.use("Agg", force=True)
    import matplotlib.pyplot as plt

    matplotlib.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "svg.fonttype": "none",
                               "svg.hashsalt": comparison_proof["sha256"], "axes.spines.top": False,
                               "axes.spines.right": False, "axes.titleweight": "semibold"})
    elapsed = [clock - CHECKPOINT_CLOCK for clock in EXPECTED_CLOCKS]
    figure, axes = plt.subplots(1, 2, figsize=(12.4, 5.8))
    for scenario, label, color in SCENARIOS:
        points = [next(row for row in rows if row["scenario"] == scenario and row["clock"] == clock) for clock in EXPECTED_CLOCKS]
        for axis, field in zip(axes, ("cohortCurrentlyRecoveredCount", "allCityAliveLowCount")):
            values = [point[field] for point in points]
            axis.plot(elapsed, values, color=color, marker="o", markersize=7, linewidth=2.5, label=label)
            offset = {"control-original": (7, -14), "patched02": (7, 8), "patched03": (7, 3)}[scenario]
            for minute, value in zip(elapsed, values):
                axis.annotate(str(value), (minute, value), xytext=offset, textcoords="offset points", color=color, fontsize=10, fontweight="semibold")
    for axis in axes:
        axis.set_xticks(elapsed, [clock_label(clock) for clock in EXPECTED_CLOCKS])
        axis.set_xlim(elapsed[0] - 15, elapsed[-1] + 15)
        axis.set_ylabel("People")
        axis.grid(axis="y", color="#dddddd", linewidth=.7)
        axis.set_axisbelow(True)
        axis.yaxis.get_major_locator().set_params(integer=True)
    cohort_size = rows[0]["cohortSize"]
    axes[0].set_title(f"Currently recovered in original cohort (n = {cohort_size})", pad=14)
    axes[0].set_ylim(0, cohort_size)
    axes[1].set_title("All-city alive residents with satiety below 30", pad=14)
    highest_low = max(row["allCityAliveLowCount"] for row in rows)
    axes[1].set_ylim(0, max(1, math.ceil(highest_low * 1.16)))
    figure.suptitle("Original saved city: food-access replay", fontsize=17, fontweight="semibold", y=.98)
    handles, legend_labels = axes[0].get_legend_handles_labels()
    figure.legend(handles, legend_labels, loc="lower center", bbox_to_anchor=(.5, .075), ncol=3, frameon=False)
    figure.text(.5, .025, "Same original cohort and exact inherited clock points; counts are read from original-file comparison JSON.",
                ha="center", color="#666666", fontsize=9)
    figure.subplots_adjust(left=.07, right=.98, bottom=.25, top=.81, wspace=.25)

    output_dir.mkdir(exist_ok=False)
    chart_files = []
    try:
        for extension in ("png", "svg"):
            path = output_dir / f"food-access-replay.{extension}"
            with path.open("xb") as stream:
                figure.savefig(stream, format=extension, dpi=180,
                               metadata={"Date": None} if extension == "svg" else {"Software": "ROOT26 original-file comparison plot"})
            raw = path.read_bytes()
            chart_files.append({"path": str(path), "bytes": len(raw), "sha256": sha256(raw)})
    finally:
        plt.close(figure)
    for proof in (comparison_proof, provenance_proof):
        raw = Path(proof["path"]).read_bytes()
        require(len(raw) == proof["bytes"] and sha256(raw) == proof["sha256"], "input JSON changed during plotting")
    script_path = Path(__file__).resolve()
    metadata = {
        "status": "ACTUAL_ORIGINAL_FILE_COMPARISON_PLOT_COMPLETED",
        "literalNoSim": True,
        "fresh-v8": False,
        "art": False,
        "mac": False,
        "steady": False,
        "scope": "Original saved-city replay chart only; false flags are acceptance claims, not absence of exported images.",
        "script": {"path": str(script_path), "sha256": sha256(script_path.read_bytes())},
        "argv": sys.argv[1:],
        "inputFiles": [comparison_proof, provenance_proof],
        "allInputSHAStable": True,
        "sourceProducerStatus": provenance["status"],
        "sourceProducerScriptSHA256": sha_value(provenance.get("scriptSHA256"), "provenance.scriptSHA256"),
        "sourceCheckpoint": comparison["checkpoint"],
        "cohortDefinition": comparison["cohortDefinition"],
        "cohortSize": cohort_size,
        "checkpointClock": CHECKPOINT_CLOCK,
        "exactClockPoints": list(EXPECTED_CLOCKS),
        "elapsedMinutesFromCheckpoint": elapsed,
        "clockLabels": [clock_label(clock) for clock in EXPECTED_CLOCKS],
        "selectedScenarioLabels": labels,
        "excludedScenarioLabels": excluded,
        "patched01ExcludedFromChart": True,
        "parsedRows": rows,
        "artifacts": chart_files,
        "simulations": 0,
        "steps": 0,
    }
    write_json_new(output_dir / "metadata.json", metadata)
    print(json.dumps({"output": str(output_dir), "artifacts": chart_files, "parsedRows": len(rows), "literalNoSim": True}))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"plot-food-access: {error}", file=sys.stderr)
        sys.exit(1)

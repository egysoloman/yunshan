# ROOT26 movement-only voxel egress 私有草稿

2026-10-07 10:50 UTC。**DRAFT / NOT_INSTALLED / NOT_RUN；本 agent 0 Node / 0 Simulation / 0 World factory / 0 step / 0 test / 0 build / 0 browser。** 仅本新目录写入；旧 ROOT25 STOPWRITE 与共享 src/tests/memo 未改。root 决定安装及串行运行，正在运行的 419 freeze 不由此草稿改变。

parent 的实际证据已确认 inherited：HEAD65d 原 home suite 同样 5/7、两条状态断言 FAIL（原 417 图谱稳定、raw `166428d7…a415`）；targeted capture02 同样 FAIL1/1、2.277609s、417稳定/noactive/raw `89731e…4b91`。这些为 parent 提供的实际事实，完整原 hash/receipt 应由 parent 关联，不以缩写代完整回执。

原 capture 文件保留在 `/tmp/ROOT26-food-access-20261007-01/baseline-home-capture02/`。parent 给出的 citizen0 起点为 `(-408.8,76.6,301.59999999999997)`，cube 中心 `(-408.8,77.4,301.6)`；终态身体未动，physicalWaiting，route 下一点 `(-406.8,76.6,301.8)`。草稿纯测试直接以这些输入计算首 .05 m 提案；未执行该测试或新的 Simulation。

## 文件与合同

- `voxel-movement.ts`：纯 `blocksVoxelMovement(from,to,voxels)`，true 为 voxel 子守卫拒绝。无状态修改、事件、缓存、policy、save 字段；只使用既有纯 cylinder sweep。
- `voxel-movement.test.ts`：21 个有实际反例/边界作用的纯测试草稿；不构造 Simulation/World，不调用 step。站立/休息 predicate 直接调用现有 `homeRestPointBlockedByVoxels`，证明 movement 能获有限脱困而 standing 仍 blocked。
- 本说明：连续段数学、ULP退化、安装边界、root 运行方式与未运行限制。

### 原站立阻挡保持不变

cube XZ 半宽 q=.1，身体半径 r=.35，高度1.72，脚接触 allowance .01。令 p(t) 为身体脚点，c 为 cube 中心。真实水平重叠是

`D_C(p) = max(|p.x-c.x|-.1,0)^2 + max(|p.z-c.z|-.1,0)^2 < .35^2 - 1e-7`。

真实垂直重叠仍是 `cube.top > feet+.01 && cube.bottom < feet+1.72`。helper 用同一计算只分类“这个 cube 在起点已经重叠”；**standing/rest/meal 所有消费者仍保留原 homeRestPointBlockedByVoxels，不能替换为 movement helper。** 一个能走出嵌入 cube 的身体在走出前也不能恢复/吃到现场收益。

### 起点清楚的任何 cube：完整3D sweep

每个 cube 独立检查，不存在“从别的 cube 脱困就免检此 cube”的豁免。起点未重叠时，终点新重叠直接拒绝；另外调用生产 `blocksSweptUprightCylinder` 检查整个线段。XZ 只平移到 cube 中心，**Y 保留 world from.y/to.y，box bottom/top 保留 cube.y±.1**。仍传 r=.35、height1.72、footAllowance=.01，不能把 Y 设0再用整段投影替代实际时间相关的交集。

既有纯 sweep 把 feet 的严格开区间 `(cube.bottom-height,cube.top-footAllowance)` 与 t∈[0,1] 相交，并在该 interval 的真实 XZ 线段上求到 rectangle 的最小距离。因此任意大 sweep 两端均清楚也不能跳过中间 cube；没有依赖原 mover ≤.05 m 的采样。

独立参数例：中心Y=.8的 cube 给出 feet band `(-1.02,.89)`。路径 `(-2,Y=-3)→(2,Y=0)` 从 t=.66 才进入该 band，此时 X=.64，已越过最大水平接触 .1+.35=.45；它应该 clear。原 `(-2,-3)→(2,+3)` 在 t=.5 为 X0/Y0，确实碰撞。这两例都在纯测试中。

### 起点已有重叠的 cube：水平脱困证书

只允许 from.y===to.y；对上升/下降/斜向位移不授予旧重叠例外。令二维 offset a=p(0)−c、delta v=p(1)−p(0)。每个旧重叠 cube 必须同时满足：

1. 真实 endpoint 中心距平方严格增加：`|a+v|² > |a|²`。零位移不获许可。
2. 中心距初导半值 `a·v≥0`（仅 ULP center 退化按下文处理）。`|a+t v|²` 为凸函数，初导非负后导数只增，整段中心距不会先下降。
3. `D_C'(0+)/2 = residual_q(a.x)*v.x + residual_q(a.z)*v.z ≥0`，其中 residual_q 是到闭 AABB 的有符号超出量。到凸集合的距离平方为凸 C¹ 函数；初导非负保证 D_C 在整个段不减。因此原在实际 cube 外的身体不能再进入实际 cube，即使 endpoint 很远。
4. 半宽 q+r 的 expanded AABB 距离平方也要求初导非负。所有原径向重叠均在这个 expanded rectangle 的零距离平台内，这一项不能单独证明脱困，必须保留中心与实际 cube 的约束。
5. 若 a 在**实际闭 cube footprint（含面、角）**内，M(t)=max(|a.x+t v.x|,|a.z+t v.z|) 的右初导取所有活跃最近面外向速度的最大值，须≥0。M 为凸函数，因此 signed interior depth `.1-M(t)` 不增加。不能只检查严格 interior，否则从面先进去的反例会漏掉。
6. 为严格禁止已有 inside 身体浅层横穿 cube，额外保守要求各非退化偏移轴 `a_i*v_i≥0`。每个已有偏移轴的绝对值不减，也不能跨它的中心平面；真中心可任选退出方向。**这条只用于实际 cube 内**，不能推广到 rounded-corner overlap，因为一些合法角点向外移动必须有一个轴稍向内。

不要求 `D_C(end)>D_C(start)`：中心初步 .05 m 仍位于 ±.1 footprint，D_C 前后都0。这样的约束会复现原陷阱。平台内的严格进展来自中心 endpoint 距离增加、signed depth 不增，以及不横穿轴约束。

反例说明额外 inside 约束的必要性：`a=(.09,.08), v=(-.03,.04)` 的步长恰 .05 m；中心初导为+.0005、endpoint 中心距更大，D_C 从0增加到.0004。但最初 t<1/7 离最近X面更远，先深入 cube。`a=(.1,.09), v=(-.01,.02)` 同样会从真实面先进入 solid。再如 `a=(.01,.05),v=(-.12,.03)` 可通过 signed depth 与中心规则，却浅层横穿X中心轴；保守逐轴 inside 规则明确拒绝。这三类都在纯测试中。

反向边界：`a=(.30,.25),v=(-.02,.04)` 已在实际 C 外但身体仍 overlap，D_C 与中心距都增，属于合法 rounded-corner egress；不能对它应用 inside 的逐轴或 M 规则。纯测试覆盖此例。

## 浮点退化与严格拒绝

原 capture 的 Z 差为−5.68e−14，来自同一 lattice 点的 world 加减和 snapshot snap。纯数学把它当成实际负Z侧，会拒绝合法正Z退出。草稿只在中心/活跃面退化分类使用

`ulp = Number.EPSILON * 8 * max(1, |from.x|, |from.z|, |cube.x|, |cube.z|)`。

距离中心不超过这个预算的轴视为数学中心；活跃面并列也限此预算。**不对负导数加入−1e−7容忍，不改原1e−7径向重叠EPS，不扩大垂直接触，不把终点严格增加改成EPS通过。** 对可测的1e−9向内及32×ULP偏移反转均要求拒绝。该处理只消除表示同一点的舍入退化；身体、cube、路线实际数据不改写。

所有实际传给 sweep 的 finite/有效算术需验证，包括 native delta XZ 平方和 local delta XZ 平方、local endpoints、cube.y±.1 及 bottom<top。±1e154 虽个别坐标与 endpoint rectangle distance 可有限，delta平方仍可溢出；1e308 Y 的±.1 box可折叠。两类 pure case 必须返回 blocked。sweep 仅 RangeError 另作 fail-closed=true；其他错误不吞。

## root 安装及串行验证

候选最小生产接入是新增 `src/simulation/voxel-movement.ts`（换首行绝对 import 为 `../geometry/upright-cylinder-sweep`），在 `citizenPhysicalSegmentAllowed` 仅把第一条 endpoint voxel 拒绝换成 movement 子守卫 `blocksVoxelMovement(from,to,state.voxels)`。后续原墙、support、permission、door、market counter 与 road 检查必须继续执行，不能在 egress 获准后直接 return true。homeRestPointBlockedByVoxels 的选床/站立/恢复/就餐守卫不改；Controller 不由本草稿修改。

原 caller 的多 cube loop必须全检查；任何新 cube hit、任何旧 cube 更深入均拒绝。原 voxel/body/support/门的几何和保存字段不改。这个规则不会为被多块真正包围的身体造无碰撞出口；全部床侧 cube 若真实形成无合法方向，实际 physicalWaiting 仍是有效结果，不凭目标已选强改 moving。

下列命令只供 **root 在当前重门关闭后** 通过原 gate 串行执行；本 agent 未执行：

```bash
cd /workspace/yunshan
node --import tsx --test --test-isolation=process --test-concurrency=1 \
  /workspace/yunshan-work/ROOT26-food-access-20261007-01/home-egress-draft/voxel-movement.test.ts
```

私有测试保留绝对 production pure/home-rest imports，加载模块不构造 Simulation；安装后 relative imports 由 root 明确调整。纯草稿21项结果目前 **NOT_RUN**；不能称已通过。root 决定安装后还须用未放松的原 home suite/native完整 save 原件验证实际出口行为，并保留旧两 FAIL、旧 capture 与源码图谱。真实床退出、door/body守卫、保存与资金/需求不恢复的证据不能由纯测试替代。

读取时依赖 SHA256：

| 生产只读依赖 | SHA256 |
| --- | --- |
| src/geometry/upright-cylinder-sweep.ts | 9cb9693aabbb58abc267d5251c89404ab38584f1302296191a560c4520d6fe7f |
| src/simulation/home-rest.ts | 60b2126e46cc0207ee8ce5de0312b9ca9d8003291325a359d026e9093d0bb006 |

STOPWRITE 在这3个私有文件计算最终 SHA 后生效；实际执行与共享安装均由 root 独占。

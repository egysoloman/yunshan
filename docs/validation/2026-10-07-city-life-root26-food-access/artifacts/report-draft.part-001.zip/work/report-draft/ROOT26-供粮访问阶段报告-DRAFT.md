# ROOT26：原居民供粮访问接续（私有阶段稿）

本阶段三段有限原生续档门均实际完成，但食品、财政与完整游戏仍为 **PARTIAL**。本稿只新增 ROOT26 事实，不重交或改写 ROOT24–25 报告。待根代理核对路线诊断与后续是否需要修源码；本文不提前认定路线原因或产品修复通过。

## 原世界与真实接续

读取原 World291/SHA `2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512`、612 栋/616 名原NPC，原世界指纹 b85fa6ec。首输入是原 ROOT24 真终档 `6e4812acde393a9436dfe09f4b3994a3721ccaba6ddb972c9623a9e369d02d48`，clock5340/tick2070。三段分别从上一段完整终档冷恢复，原 speed16、每次 `.25` 普通步不变；累计 **64 新普通窗、3 cold段、3构造/3import、64完整reader**，5340→5596（17:00→21:16，共256游戏分钟）、tick2070→2134。每段0命令、0身体/钱包/需求/库存/身份/时钟注入，所有10个实际phase、fullsave和ALLbus原件由root门捕获。此是旧v6世界自然接续，不是新普通URL v8出生、单fresh64或原单fresh360。

| 原门 | 普通窗 | clock | tick | 冻结输入 | driver/gate秒 | 原raw SHA256 |
|---|---:|---|---|---:|---|---|
| native01 | 16 | 5340→5404 | 2070→2086 | 417 | 106.123 / 107.917040 | ecac6527c67374e4301ce878a22aac35976f9a6366bede8162ee60a15ee102e2 |
| native02 | 32 | 5404→5532 | 2086→2118 | 417 | 156.094 / 156.899856 | 4c7ef37662202b3f141f85f6047fd004b47fab818f3f70fa9ffea3797d817e13 |
| native03 | 16 | 5532→5596 | 2118→2134 | 417 | 83.98 / 84.752002 | b626494a8bea7b78d0ce4dcbbd7bf439a447ac7f33858c17b63d1889cbca36ad |

三gate均实际 PASS/exit0/inputsStable=true/activeDescendants=[]；三个 RESULT 为 ACTUAL_COMPLETED，capture/persistence/conservation失败均空。各门输入417图完全相同；本阶段未改生产功能源码、几何、原游戏规则或旧 tests，只新增私有 driver/observer 和原件。本文作者自身执行0 Simulation/step/tests/types/build/browser/GPU，仅读既有原件与源码。

## 原115人实际恢复与仍未完成

| 原终点 | 原115中已有具名恢复 | 原115仍低 | 全城低30 |
|---|---:|---:|---:|
| native01 / 5404 | 23 | 92 | 93 |
| native02 / 5532 | 63 | 52 | 52 |
| native03 / 5596 | 73 | 42 | 43 |

末端 **73名不同原居民真实成交吃饭**，原群体sale事件共97笔；42原居民仍低饱足且全部moving，另1名新增低，不能写成115全部获救。42的真实目的地为 summit-b8 17人、west-b41 12人、east-b5 13人。饱足hunger越高越饱；保存的钱、位置、目标或moving状态均不能代柜台成交或合法路径通过证据。是否因路程、评分、重选节律、库存或实体阻挡仍待新的只读定位，未实施sourcefix。

四名跟踪居民中：450于clock5372在east-b50真实sale，随后5500消耗随身餐；457与489于5408在east-b37真实sale，随后5536各消耗随身餐。153末端仍moving→east-b5、food0、饱足2.300000000000116，没有其sale；不是四人全恢复。616名原NPC逐ID均存活；原分析 `allAlive=617` 是含player的profile数，不能写617NPC。

全城三RESULT累计 **355柜台餐、20随身餐**；新粮产 `6.75690851239997`、材料产 `29.744983004638996`。原先零粮店曾完成有限补货/成交，不等所有店终态库存充足；终态east-b37/east-b50/summit-b2原数据仍open且库存0。native01在east-b37-door有两笔各28的cargo-arrived，shopId是原货主core-dock/river-b57，进入地区FIFO而非直接指定零售粮或居民食物；不能仅凭nodeId或cargo事件宣称完整供应商付款链。

## 钱粮与保存的限定通过

新NPC earned合计 `865.1335291820008`，本17:00–21:16窗口NPC paid/publicPaid/privatePaid均0；只核该时段新债来源，不冒下一工资窗口或长期财政可持续。三原门最大cash/food/debt/fiscal残差分别为 `2.9103830456733704e-10` / `1.8189894035458565e-12` / `2.2737367544323206e-13` / `2.3001689442025963e-10`，各原值保留在 [实际摘要](ROOT26-ACTUAL-EVIDENCE-SUMMARY.json)。没有补钱、造库存、延长游戏deadline或降低断言。

各段130/127/129个实际地理part已由producer物理写/read/decode并组装与对应whole完整字节相同；各自删一个真实chunk拒读，额外Sim/import/step均0。每一成功普通窗都有原完整reader。末档SHA `e96028a3fd76377d3ac5ca0f4e5cec3d1db359cbcd9b291f77ce0e213d0c07a7`。这不是本阶段future24、浏览器UI重载、崩溃恢复、新地图或全部旧档加载验收。

## 原要求保护与接续

[新52列矩阵](MATRIX-38-ROOT26-DRAFT.csv) 只追加ROOT26计划/实现/运行/验证/剩余5列；旧 **47headers、1786data cells、38IDs和顺序全exact**，旧ROOT18–25的RUNNING/NOT_RUN/FAIL等当时记录逐字保留。[只含追加列](MATRIX-ROOT26-APPEND-ONLY.csv) 与 [逐格保护回执](MATRIX-PRESERVATION-ROOT26.json) 可独立核对；38域全PARTIAL。

食品实情写入FOOD及直接相关商业、物流、日常需求、财政、保存与验证域；能源、医疗卫生病毒、科技教育政治、完整自然家庭世代、环境、灾害、产权拆迁新路、统计流式、2D/Worker等没有因此完成。原ROOT24 native03四缺phase/FAIL与两个cold段360 canonical/361物理call边界仍保留，新64窗不回填旧缺失。ART_FAIL、MacNOT_RUN、14日供粮现金财政稳态NOT_RUN继续。

当前下一步为剩余42人与新增低饱足居民的真实route/终端售点/成本与供料诊断，由root判断最小业务修复及后续有限原生门；不得从本稿预授权补钱粮、瞬移或改继承旧世界。Library、本stage源码commit/push与最终交付尚待root真实回执；本作者未上传、创建ZIP、修改shared源码/备忘录或旧STOPWRITE目录。

原件入口：`/tmp/ROOT26-food-access-20261007-01/native01|native02|native03`，gate与各cohort分析在`/workspace/yunshan-work/ROOT26-food-access-20261007-01`。[输入字节绑定](DRAFT-INPUT-SNAPSHOT.json) 列实际文件SHA；仅容器路径不是已送达附件。

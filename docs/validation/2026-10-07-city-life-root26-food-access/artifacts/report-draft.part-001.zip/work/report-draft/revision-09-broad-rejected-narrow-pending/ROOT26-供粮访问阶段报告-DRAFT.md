# ROOT26：宽急餐真实负结果与收窄方案待验（新实际修订稿）

宽急餐候选有限运行与同源24保存验证实际通过，279局部提前成交，但整体恢复少于旧对照；root已不采用宽方案作为最终游戏修复。当前收窄源码已实现，实际门尚PENDING。全城有限供给与夜间供餐仍未解决。旧80窗、旧报告及其FAIL原件全部保留，新运行从5416原档另作对照，不接旧80时间线。全38域仍PARTIAL，ART_FAIL/MacNOT_RUN及14日稳态NOT_RUN保持。

## 宽急餐候选实际门，不涵盖当前收窄源码

已实跑的宽源仅`src/simulation/meal-route.ts`、`src/simulation.ts`两生产文件与旧417源不同；`nearby-food-v1`、age>=6、food<1且原elapsed投影饱足<30时请求正常people frequency1。沿原累计elapsed、身体移动、访问权限、营业/库存/钱包和出勤工资上限；legacy无此policy沿原频率。没有tier/focus写入、补钱粮、强活动或开夜店。

| 实际门 | 418输入来源 | driver / gate秒 | 原raw SHA |
|---|---|---:|---|
| typecheck01 | 宽方案两MOD业务图 | — / 17.447651 | 76162e465989f3f070a9de8db711fbf358e53b74d09ce1bbdb57c727e4c4a16d |
| patched01 | 同一两MOD图 | 91.876 / 94.171033 | 4a9d3849add1d0c33d838030d4b28b81edbd498ffd2304789ae9ec9f09f40e97 |
| patched02 | 与patched01同图 | 284.73 / 285.857677 | 9894bcadba651cf1512131b0fc1f8c58fbeb12bb9064eec3ef7f5ad889d9eea7 |

三门均真实closed PASS、exit0、inputsBefore=After/418stable、activeDescendants=[]。当前共享生产源码已进一步收窄，pure auditor/测试也有后续变化，详[当前快照](CURRENT-SHARED-READONLY-SNAPSHOT.json)；函数文件数量418不代表来源字节相同，不能把旧pure门自动延伸至最新脚本。

## 对照正反结果

完整原checkpoint SHA `ce40c74205c1126519e08c5d49e32d18f22cc4acf410d07f1fa4e709ff0337b8`，clock5416/tick2089、speed16/unpaused、616NPC、89低饱足居民；不是旧115群。patched01一构造一import/16普通窗，至5480/tick2105，末SHA `9fb70980aaeb569437afc408376e2eca5a9ac38c6bf163b5cfc35135b2f9bec7`；0命令/需求钱粮身体身份库存时间注入，16reader、160主phase守恒，捕获/持久化/守恒失败空，129真part组装whole exact并缺真chunk拒。

279在5432真实west-b41 sale quantity1/cost17.966614100760214；旧同clock5480仍未sale。新终饱足63.7对旧11.7，钱包真实付款。此例支持宽方案可防16分钟附近成餐被旧64分钟延迟错失；因整体结果更差，root没有把宽方案作为最终修复。此结果不验证新收窄源。

| 同一89低群/全城口径 | 旧对照5480 | 新5480 | 旧对照5576 | 新5576 |
|---|---:|---:|---:|---:|
| 原群有sale且恢复人数 | 17 | 13 | 43 | 34 |
| 全城低饱足人数 | 72 | 76 | 47 | 56 |

新运行两端恢复都少于旧对照，全城低更多，必须保这项负结果。新5576中279于5544再次真实sale quantity2/cost36.00312070430272，末shopping/饱足100/food1；旧5576仍未sale。两边tiersUnchanged均false，表示确有原classify随body位移每8tick自然重分，不是fix写tier。比较原件：[5480](../../PATCHED01-CONTROL-COMPARISON.json)、[5576](../../PATCHED02-CONTROL-COMPARISON.json)。

## 仅该宽源的主热24与冷影子24

patched02从同一5416原档另构造/导入，主40窗至5576/tick2129。前16与patched01的17份输入/窗save、ALLbus、custody、foodTrace rawSHA逐项相同；[重放原件](../../PATCHED01-02-FIRST16-EXACT-REPLAY.json)已核，重复16不加到新canonical时间线上。在第16窗原9fb…bec7 fullsave再构造一个shadow/cold import，即刻export bytesexact；之后主hot24与冷shadow24逐窗完整save字节相同，24 returned/exact，2构造/2import共64物理step，40reader。末完整SHA `7b1fef331d28eb8cdc374dd37ca2c6e8d350909ec752f296a04491b052add3c1`。

主40窗有400真实custody phase；shadow24只保存并比较完整字节，没有另挂独立custody observer，不说影子另有240份捕获阶段。每主窗原cash/food/debt/fiscal守恒通过，最大残差为 1.7462298274040222e-10 / 1.8189894035458565e-12 / 2.2737367544323206e-13 / 3.055333763768431e-11。131真实part组装末whole exact并拒缺chunk，分区额外Sim/import/step0；两构造来自主/影子验证，不把分区额外0误写全场只有1构造。

这是真宽源同源future24保存验证，只绑定实际宽418图，不能移交给当前收窄源，不是旧80接续、单fresh116或修复后重跑原全部80窗。只读作者核原closed门、RESULT、FIRST16 SHA记录与24comparison小原件，没有重跑Sim/解压全部帧/测试或把派生记录当新增观察。

## 原测试失败、基线复现与当前待验

宽相关tests01实际FAIL：43项/41pass/2fail、419stable/active[]、raw8ae904e2af584b30917162b25ebace6a3dc285622a38aa5d2a9e2bece9aa6f17。失败是`npc-home-rest-voxels`两项：同原床侧起点放voxel、堵全床侧保公共休息fallback；真实physicalWaiting对期待moving，原122/220行。baseline-home01在完整原HEAD417图（逐项等原native04）实际再FAIL：7项/5pass/2fail、60.226740s/417stable/active[]、raw166428d7576c50f7257276ddddc3d85600d93d81b3332bfcded809d38476a415；同名两项同断言复现。可确认这些legacy失败在原源也存在，保原FAIL，不归因急餐、不改原261测试或把预期改松。完整来源在证据摘要。

当前root已收窄：onlypolicy+activity=eat+age>=6+food<1+原elapsed投影饱足<30，且已到站mealrider或完整参考route余程<=原walkingSpeed×25分钟（原最早决策间隔）。长途及非eat仍原处理频率，完整elapsed/到站裁时/移动/工资/营业库存钱粮守卫沿原声明。**新收窄方案typecheck/tests/同5416普通对照及future24全部PENDING实际新门**；参考route余程不是物理通达验收。

## 钱粮与仍缺内容

patched02主40共197柜台餐/15stored，产生food1.0743647328613164/material2.1510779069859334，earned262.6704962838238/paid0；首16已包含，不将patched01再累加。616基线NPC逐IDalive，原payrollAt6780尚未跨，不能以paid0和守恒称下一工资/长期财政通过。

原417四cold段80窗5340→5660仍保：86/115真实sale恢复、29原低+1新低、393柜台/23stored、210shop全部closed、6原cohort hunger0food0；153有5600 sale而无后续stored witness。纯recheck01是旧417+script的另一418图，31.703037s actualPASS、80 fullsave/800phase/850双SHA/0新Sim/import/step/nativeReader；不与宽业务418或当前收窄419混用。前三64窗route-static-review的212目标变化203旧空库存/9旧开且有货与长路/延迟原因仍是该子集记录，不说全部身体通路已证明。

宽方案与当前收窄实现都没有制造粮、预约库存或夜间营业，有限供给竞争与全城分配仍缺，夜间服务必须守原owner/身份许可、钱/成本/库存、营业劳动、工资债和时间规则。下一工资、14日现金财政供粮稳态、正常第一人称玩家/新普通URL与其他38域完整流程继续未验。新收窄typecheck/tests/普通与保存门、3篡改回归、最新auditor、Library、本stageGit提交推送仍待root实际新门/回执，不预写送达或PASS。

[38×52矩阵](MATRIX-38-ROOT26-DRAFT.csv)仅修订新ROOT26五列，旧47headers/1786cells/38IDs顺序exact，全38PARTIAL；[保全](MATRIX-PRESERVATION-ROOT26.json)。本作者0Sim/step/tests/build/browser/GPU/共享写/ZIP/上传；仅新私有文稿。revision05与所有前稿及rev03真实身份守卫准备FAIL原件均原字节保留。



### ROOT26 宽候选真实负结果，收窄方案待验；宽源future24相同但供给仍PARTIAL（2026-10-07，私有追加草稿）

已实跑宽源两MOD meal-route.ts/simulation.ts仅nearby-food-v1/age>=6/food<1/原elapsed投影satiety<30请求正常people frequency1，沿原tier自然classify、完整elapsed/移动/ACL/库存营业钱包/工资上限/legacy。宽图418 typecheck01实际PASS17.447651s；patched01同图cold16 PASS94.171033s，5416 ce40…37b8→5480/2105/9fb…bec7，0注入，129part exact/缺chunk拒。2795432真sale qty1/cost17.966614100760214而旧5480无sale；但原5416低89群恢复旧17/新13，全城低旧72/新76，不冒全局改善。两边tiersUnchanged=false为原classify随真实位移变化，fix不写tier/focus。

patched02同418源closedPASS285.857677s/raw9894bcad…eea7，driver284.73s，另从5416主40至5576/tick2129/7b1fef331d28eb8cdc374dd37ca2c6e8d350909ec752f296a04491b052add3c1。前16完整save/bus/custody/trace rawSHA同patched01，重复不新增canonical；第16末coldshadow再导入9fb档，后主hot24/影子24完整save逐窗bytesexact，2Sim/2import/64物理step/40reader，主400phase守恒，shadow无另custody observer；131真实part whole exact/缺chunk拒、分区额外Sim0。非原80续或单原116timeline。5576低89群旧43恢复/新34，全低旧47/新56；279新5432+5544两真sale，旧同末无sale，宽源有近端16-vs64局部改善但全局恢复变少，root已撤作最终游戏修复；新收窄未验。

主40柜台197/stored15、food1.0743647328613164/material2.1510779069859334、earned262.6704962838238/paid0，616NPC alive、payrollAt6780未跨，首16不重复加总。旧80/原115群/210夜间closed/6hunger0food0/153有sale无stored仍保；旧417+pure工具另一418图recheck01原80/800phase/850双SHA actualPASS与宽急餐两MOD门区分，收窄新源码未验。宽tests01 41/43 FAIL的2legacy床侧voxel physicalWaiting!=moving在原HEAD完整417 baseline-home01也5/7 FAIL复现，两失败保，不归急餐不改原261。当前root再收窄onlypolicy+eat+age>=6+food<1+projected<30，且arrivedmealrider或完整余程<=原walkspeed*25min，非eat/长路沿原频率；新source/typecheck/tests/同5416 ordinary/future24、当前auditor/篡改门/Library/Git全待实际回执，不继承宽418的24exact。有限供给分配/夜间服务/工资/14日稳态、ART_FAIL/MacNOT_RUN与38PARTIAL不由窄fix关闭。

新私稿report-draft/revision-09-broad-rejected-narrow-pending，旧revision05及所有前稿/准备FAIL字节保；旧47headers/1786cells/38IDs次序exact，全38PARTIAL。作者0Sim/step/tests/build/browser/GPU/共享memo/src写/ZIP/上传；容器私稿不是Library已交付。

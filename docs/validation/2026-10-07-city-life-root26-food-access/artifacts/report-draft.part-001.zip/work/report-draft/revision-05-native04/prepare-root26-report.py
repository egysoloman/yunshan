from pathlib import Path
import csv,io,json,hashlib
from decimal import Decimal
from datetime import datetime,timezone
repo=Path('/workspace/yunshan');work=Path('/workspace/yunshan-work/ROOT26-food-access-20261007-01')
old=work/'report-draft';out=Path(__file__).resolve().parent
baseline=repo/'docs/validation/2026-10-07-city-life-root24-25/REQUIREMENTS-38.csv'
native=Path('/tmp/ROOT26-food-access-20261007-01')
sha=lambda b:hashlib.sha256(b).hexdigest()
def load(p):return json.loads(p.read_text())
def write(n,s):
 p=out/n
 if p.exists():raise RuntimeError('Preserve this revision: '+str(p))
 p.write_text(s,encoding='utf-8')
def save(n,j):write(n,json.dumps(j,ensure_ascii=False,indent=2)+'\n')
priorCompletedRevision=old/'revision-04-native04'
priorCompletedManifest=load(priorCompletedRevision/'DRAFT-SHA256.json')
assert all(sha((priorCompletedRevision/n).read_bytes())==v['sha256'] for n,v in priorCompletedManifest['files'].items())
failedRevision=old/'revision-03-native04'
failedRevisionHashes={f.name:sha(f.read_bytes()) for f in failedRevision.iterdir() if f.is_file()}
priorRevision=old/'revision-02-native04'
priorRevisionManifest=load(priorRevision/'DRAFT-SHA256.json')
assert all(sha((priorRevision/n).read_bytes())==v['sha256'] for n,v in priorRevisionManifest['files'].items())
priorManifest=load(old/'DRAFT-SHA256.json')
assert all(sha((old/n).read_bytes())==v['sha256'] for n,v in priorManifest['files'].items())
baselineBytes=baseline.read_bytes();original=list(csv.reader(io.StringIO(baselineBytes.decode('utf-8-sig'),newline='')))
firstDraft=list(csv.reader(io.StringIO((old/'MATRIX-38-ROOT26-DRAFT.csv').read_text(encoding='utf-8-sig'),newline='')))
assert len(original)==39 and len(original[0])==47 and len(firstDraft[0])==52
assert firstDraft[0][:47]==original[0] and [r[:47] for r in firstDraft[1:]]==original[1:]
runs=[];inputs=[baseline,old/'DRAFT-SHA256.json',old/'MATRIX-38-ROOT26-DRAFT.csv',repo/'AGENTS.md',repo/'提示词.md',repo/'开发备忘录.md',work/'NATIVE04-TERMINAL.original.save.json',priorRevision/'DRAFT-SHA256.json',priorCompletedRevision/'DRAFT-SHA256.json']
for name in ['native01','native02','native03','native04']:
 g=work/(name+'-gate');p=native/name;r=load(p/'RESULT.json');gate=load(g/'receipt.json');plan=load(work/(name.upper()+'-PLAN.json'));parts=load(p/'TERMINAL-PARTS.json');frozen=load(g/'inputs-before.json')
 assert frozen==load(g/'inputs-after.json') and len(frozen)==417
 assert gate['status']=='PASS' and gate['exitCode']==0 and gate['inputsStable'] and not gate['activeDescendants'] and not gate['timedOut']
 assert r['status']=='ACTUAL_COMPLETED' and r['failure'] is None
 assert r['ordinaryCalls']==r['returnedWindows']==r['completedWindows']==r['readers']==plan['maximumSuccessfulWindows']
 assert r['commands']==r['injectedBodiesMoneyNeedsStockRolesTime']==0
 assert not r['captureFailures'] and not r['persistenceFailures'] and not r['conservationViolations']
 assert sha((g/'raw.log').read_bytes())==gate['rawSHA256']
 assert parts['assembledSHA256']==r['terminalSaveSHA256']
 assert parts['extraSimulations']==parts['extraImports']==parts['extraSteps']==0
 if runs:assert r['inputSaveSHA256']==runs[-1]['result']['terminalSaveSHA256'] and frozen==runs[-1]['frozenInputs']
 runs.append({'name':name,'result':r,'gate':gate,'inputClock':plan['inputClock'],'inputTick':plan['inputTick'],'frozenInputs':frozen,'physicalParts':len(parts['manifest']),'missingChunkRejected':parts['rejectedMissingPart']})
 inputs.extend([g/'receipt.json',g/'inputs-before.json',g/'inputs-after.json',p/'RESULT.json',p/'FRAMES.json',p/'TERMINAL-PARTS.json',work/(name.upper()+'-COHORT-ANALYSIS.json')])
recheckGate=load(work/'recheck01-gate/receipt.json');recheckReport=load(work/'SEALED-80-RECHECK.json');recheckFrozen=load(work/'recheck01-gate/inputs-before.json')
assert len(recheckFrozen)==418 and recheckFrozen==load(work/'recheck01-gate/inputs-after.json')
assert recheckGate['status']=='PASS' and recheckGate['exitCode']==0 and recheckGate['inputsStable'] and not recheckGate['activeDescendants']
assert sha((work/'recheck01-gate/raw.log').read_bytes())==recheckGate['rawSHA256']
assert recheckReport['status']=='PASS_SEALED_ORIGINAL_RECHECK' and recheckReport['completeOriginalWindows']==80 and recheckReport['completeStablePhases']==800
assert recheckReport['steps']==recheckReport['constructors']==recheckReport['imports']==recheckReport['nativeReaderCalls']==0
assert all(recheckFrozen[k]==v for k,v in runs[-1]['frozenInputs'].items())
routeEvidence=load(work/'route-static-evidence.json');routeReceipt=load(work/'route-static-review-receipt.json');routeSummary=routeEvidence['summary']
assert routeSummary['ordinaryFrames']==64 and routeSummary['goalChanges']==212 and routeSummary['changeOldShopClasses']=={'OLD_SHOP_STOCK_BELOW_ONE':203,'OLD_SHOP_OPEN_STOCKED_AFFORDABLE':9}
assert routeSummary['remaining42PhaseBadStateObservations']==routeSummary['remaining42ZeroChordProcessedMovingCount']==0
assert routeReceipt['status']=='READ_ONLY_COMPLETED' and routeReceipt['readOriginalFiles']==263 and routeReceipt['allReadOriginalEncodedSHAStable'] and routeReceipt['all417CurrentSourcesExact']
sharedBefore={p:sha((repo/p).read_bytes()) for p in recheckFrozen}
currentNativeSourceDifferences=[{'path':p,'ordinary417SHA256':v,'currentSharedSHA256':sharedBefore[p]} for p,v in runs[-1]['frozenInputs'].items() if sharedBefore[p]!=v]
inputs.extend([work/'recheck01-gate/receipt.json',work/'recheck01-gate/inputs-before.json',work/'recheck01-gate/inputs-after.json',work/'recheck01-gate/raw.log',work/'SEALED-80-RECHECK.json',work/'route-static-review.md',work/'route-static-evidence.json',work/'route-static-review-receipt.json',work/'route-static-read-inputs.json',repo/'scripts/food-access-recheck.ts',failedRevision/'REVISION03-PREPARATION-FAIL.json'])
save('CURRENT-SHARED-READONLY-SNAPSHOT.json',{'at':datetime.now(timezone.utc).isoformat(),'selectedSourceCount':len(sharedBefore),'currentSourceSHA256':sharedBefore,'currentVsFourOrdinaryGates':currentNativeSourceDifferences,'scope':'Current snapshot is not a new simulation PASS; four ordinary gates bound historical417; pure recheck418=historical417+new audit script.','patched01Status':'PENDING root actual receipt; independent5416 control replay, not80window continuation'})
save('PURE-RECHECK01-RECEIPT-SUMMARY.json',{'gate':recheckGate,'reportPath':str(work/'SEALED-80-RECHECK.json'),'reportSHA256':sha((work/'SEALED-80-RECHECK.json').read_bytes()),'originalWindows':80,'originalStablePhases':800,'dualSHAOriginals':recheckReport['dualSHAOriginals'],'extraSimStepImport':0,'coreEqualsFourHistoricalGates':True,'scriptSHA256':recheckFrozen['scripts/food-access-recheck.ts'],'original417PlusAuditSourceCount':418,'doesNotValidateNewModifiedGameplay':True,'threeTamperTestsStatus':'PENDING actual root gate'})
inputRecords={str(p):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in inputs}
cohort=load(work/'NATIVE04-COHORT-ANALYSIS.json');fullBytes=(work/'NATIVE04-TERMINAL.original.save.json').read_bytes();full=json.loads(fullBytes);s=full['state'];ids=set(load(work/'NATIVE01-PLAN.json')['actorIds']);profiles=s['extension']['actorProfiles']
assert sha(fullBytes)==runs[-1]['result']['terminalSaveSHA256']==cohort['terminalSaveSHA256']
assert len(s['citizens'])==len({a['id'] for a in s['citizens']})==616
assert all(profiles[a['id']]['alive'] for a in s['citizens'])
assert len(s['shops'])==210 and not any(a['open'] for a in s['shops'])
low=[a for a in s['citizens'] if a['id'] in ids and a['needs']['hunger']<30]
zero=[a['id'] for a in s['citizens'] if a['id'] in ids and a['needs']['hunger']==0 and a.get('food',0)==0]
assert len(low)==cohort['cohortStillLow']==29 and len(ids)-len(low)==cohort['cohortRecovered']==86
assert set(zero)==set(cohort['cohortZeroSatiety']) and len(zero)==6
assert cohort['states']=={'moving':25,'riding':4} and cohort['activities']=={'rest':15,'eat':14}
assert cohort['uniqueCohortActuallyAte']==86 and cohort['cohortSaleCount']==122 and cohort['totalLow']==30
totals={k:sum(r['result']['actualCounts'][k] for r in runs) for k in runs[0]['result']['actualCounts']}
printedTotals={k:str(sum(Decimal(str(json.loads((native/r['name']/'RESULT.json').read_text(),parse_float=Decimal)['actualCounts'][k])) for r in runs)) for k in totals}
maximum={k:max(r['result']['maximumResidual'][k] for r in runs) for k in runs[0]['result']['maximumResidual']}
assert sum(r['result']['ordinaryCalls'] for r in runs)==80 and totals['counterMeals']==393 and totals['storedMeals']==23 and totals['npcPaid']==0
assert full['runtime']['payrollAt']==6780
sale153=[v for v in cohort['fourEvents'] if v['event']['type']=='sale' and v['event']['citizenId']=='citizen-153']
assert len(sale153)==1 and sale153[0]['clock']==5600 and sale153[0]['event']['quantity']==2
assert not any(v['event']['type']=='stored-meal' and v['event']['citizenId']=='citizen-153' for v in cohort['fourEvents'])
save('ROOT26-ACTUAL-EVIDENCE-SUMMARY.json',{'version':'native01–04 new revision; previous three-segment draft preserved','nativeFrozenInputCountPerRun':417,'oldWorldSHA256':load(work/'NATIVE04-PLAN.json')['inputWorldSHA256'],'startFullSaveSHA256':runs[0]['result']['inputSaveSHA256'],'terminalFullSaveSHA256':sha(fullBytes),'clockStart':5340,'clockEnd':5660,'tickStart':2070,'tickEnd':2150,'ordinaryWindows':80,'coldSegments':4,'constructors':4,'imports':4,'readers':80,'commands':0,'injection':0,'actualCountFloatSums':totals,'exactDecimalSumOfPrintedRESULTNumbers':printedTotals,'sumPrecisionNote':'Decimal sums are exact additions of printed source numbers, not a stronger physical precision claim; each original per-run value is retained.','maximumResidualAcrossRuns':maximum,'cohortInitial':115,'recoveredWithSaleWitness':86,'cohortSaleEvents':122,'cohortStillLow':29,'allResidentsLow':30,'remainingStates':cohort['states'],'remainingActivities':cohort['activities'],'originalCohortZeroSatietyAndFood':zero,'aliveNPCsVerifiedFromWholeSave':616,'actorProfilesIncludingPlayer':len(profiles),'endpointShops':210,'endpointOpenShops':0,'fourEvents':cohort['fourEvents'],'no153StoredMealWitness':True,'payrollAt':6780,'frozenRuns':[{k:v for k,v in r.items() if k!='frozenInputs'} for r in runs],'pureRecheck01':{'status':recheckReport['status'],'boundInputs':418,'historical417PlusNewScript':True,'windows':80,'stablePhases':800,'dualSHAOriginals':recheckReport['dualSHAOriginals'],'stepsConstructorsImportsNativeReaders':0},'routeDiagnostic':{'originalPath':str(work/'route-static-review.md'),'originalSHA256':sha((work/'route-static-review.md').read_bytes()),'scope':'First64 historical windows only','summary':routeSummary},'currentModifiedGameplay':{'sourceDifferencesFromOrdinary417':currentNativeSourceDifferences,'actualPatched01Gate':'PENDING'},'pending':'Nighttime access/supply allocation; current fix/typecheck/tamper tests/control replay/Library/Git actual gates; pure recheck itself passed, not gameplay repair.'})
runSummary='native01/02/03/04各实际PASS/417stable/active[]；16+32+16+16=80完整ordinary/readers，4cold段/4Sim/4imports，5340→5660/tick2070→2150；0命令/注入。'
foodSummary='原115中23→63→73→86具名真实sale恢复，122原cohort sale；29仍低(25moving/4riding、15rest/14eat)，全城低30；393柜台/23随身餐；153于5600真sale，四target全sale但153无stored witness。'
fundSummary='本17:00–22:20 earned约996.325269443、paid0；food约6.7569085124/material约29.7449830046；cash/food/debt/fiscal最大残差'+ '/'.join(str(maximum[k]) for k in ['cash','food','debt','fiscal'])+'。'
changes=[('冷续16+32+16普通窗','冷续16+32+16+16普通窗'),('native01/02/03','native01/02/03/04'),('16+32+16=64','16+32+16+16=80'),('64完整ordinary/readers','80完整ordinary/readers'),('3cold段/3Sim/3imports','4cold段/4Sim/4imports'),('5340→5596/tick2070→2134','5340→5660/tick2070→2150'),('食品64窗','食品80窗'),('新64窗','新80窗'),('3组物理parts','4组物理parts'),('3段64完整whole','4段80完整whole'),('不冒单fresh64','不冒单fresh80'),('原115低饱足居民中23→63→73人有具名sale恢复；终点原42仍低且全moving，全城低43=原42+新1；355柜台餐+20随身餐。450/457/489真sale后stored-meal；153仍moving/food0、无sale。',foodSummary)]
appendRows=[]
for r in firstDraft[1:]:
 fields=r[47:].copy()
 for i,v in enumerate(fields):
  for a,b in changes:v=v.replace(a,b)
  fields[i]=v
 appendRows.append([r[0],*fields])
byid={r[0]:r for r in appendRows}
def setrow(ident,run,verify,remaining,implementation=None):
 r=byid[ident]
 if implementation:r[2]=implementation
 r[3]=run;r[4]=verify;r[5]=remaining
setrow('FOOD-01',runSummary+' '+foodSummary+' '+fundSummary,'PARTIAL；4有限原生门各PASS，86/115非115全恢复；终点210shop全closed/6原cohort hunger0food0，夜间供餐与分配仍缺。','夜间有限食品服务与供应分配需真实权利/钱/库存/劳动/营业规则方案；29原低+1新低与下个原payroll6780待验。前三64窗只读诊断支持供给竞争/长路，非已修业务。旧417+pure工具的418图recheck01实际PASS，80原窗800phase/850双SHA/0新Sim；两MOD新业务/typecheck/3篡改测试/对照重放/Library/Git仍PENDING。')
setrow('MAP-02','前三64窗只读原诊断已绑定route-static-review.md/证据JSON/263读入稳定回执：115cohort212目标变化，203旧目标stock0/9旧店仍开且有货；42的原边界无unreachable/physicalWaiting/roadWaiting，处理moving均位移。','PARTIAL；诊断支持供给竞争/长路，不能推全路径保证或业务已修；原件已绑定；源修复后的身体旅程未由此证明。','从29原低夜间rest/eat和营业关闭继续合法夜间供餐/分配；不得靠改地图、补钱粮、欧氏近店或强定位制造完成。')
setrow('SHOP-01',foodSummary+' 终5660全部210shop open=false。','PARTIAL；实际有限餐与夜间关闭，不等经营买租/困难重开、行业更替和完整供需稳态。','有限经营/夜间服务与分配需按真实原身份、owner、成本、库存、工资与权限设计；原自然新租户/产权全链仍欠。')
setrow('POL-02',runSummary+' '+fundSummary,'PARTIAL；未跨原payrollAt6780、paid0，守恒不等下一工资/长期财政持续。','后续实际工资窗口、有限公私账户/债与夜间服务成本；原医疗cap14等具体审批不由食品证明。')
setrow('TRA-01','native01原east两笔各28 cargo-arrived按实际node/货主进入地区FIFO，非直接给指定零售或居民。'+foodSummary,'PARTIAL；有限原物流和餐来源通过，不冒所有订单/供应商到账及夜间食品供给完整。','供给与夜间门店分配须按原FIFO/lots/有限funds保护/真实库存追；不得从到门cargo推补给每个低饱足居民。')
setrow('LIFE-01',foodSummary,'PARTIAL；NPC CPU原普通窗，不是玩家第一人称完整生活；终夜间15rest/14eat未保证餐后归家闭环。','住房/办公/厨卫/家居与真正玩家夜间日常仍欠；本阶段无新浏览器门。')
setrow('LIFE-03','hunger高表示饱；原115中29终低、全城低30，6原cohort hunger0food0；616NPC逐IDalive。','PARTIAL；不以存活或有钱说营养已足；夜间15rest/14eat表示实际活动选择，不猜已获救/死亡。','6零饱足零携粮及另1新低的真实后续餐/健康与整体营养心理长期反馈待验。')
setrow('SAVE-01',runSummary+' 原130/127/129/128物理part分别write/read/assemble whole exact，各缺真chunk拒；0额外Sim/import/step。','PARTIAL；4组parts/80每窗reader限定PASS，非本阶段未来24/正常UI reload/所有旧save/崩溃恢复。','recheck01旧417+新pure工具418图实际PASS：80 fullsave反馈cash/food/debt深equal、800phase重算、850双SHA/lineage，0新Sim/import/step/nativeReader；3篡改测试/修复后保存门待实际root回执，原预算不放宽。')
setrow('VAL-01',runSummary+' '+foodSummary,'PARTIAL；四普通门绑定原417；纯recheck01绑定旧417+工具418图，其PASS不等当前两MOD业务或修复后新运行PASS。','旧fail/缺4phase永保；ART_FAIL/MacNOT_RUN/长期14日稳态NOT_RUN/38PARTIAL；Library和Git以之后root真实回执为准。')
setrow('PER-01',runSummary+' recheck01另31.703037s纯文件审计，非游戏性能benchmark。','PARTIAL；本轮只有限原件捕获，没有性能benchmark/GL/Mac/真统计流式验收。','全部原tier/速度/实体/资源预算保留；新增审计工具不是性能修复。')
byid['FOOD-01'][2]='历史80原窗未改业务；root随后仅meal-route.ts/simulation.ts加入nearby-policy年龄>=6/无携粮/elapsed投影饱足<30连续people处理。正常移动/elapsed/tier/工资legacy沿原规则声明；实际修复后门PENDING。新增pure script只重检原件，非玩法供餐。'
byid['SAVE-01'][2]='旧80窗原native写读/parts沿原规则；新scripts/food-access-recheck.ts独立pure审计，不导Simulation/不step，已有旧417+script的418原件门PASS；新业务存档续演门PENDING。'
byid['PER-01'][2]='历史80原窗保原频率/速度/实体数与预算；当前新增meal连续people条件保tier原值而可能增加实际处理负载，修复后真实性能未由旧门或31.703037s纯文件审计证明。'
byid['SYS-01'][2]='旧80窗沿原World和业务，当前fresh默认v8保持；root随后接入2MOD食品连续处理和独立pure审计，新源功能门PENDING，旧有限运行不能代现默认全流程。'
headers=firstDraft[0];table=[headers,*[r[:47]+byid[r[0]][1:] for r in original[1:]]]
assert all(r[50].startswith('PARTIAL') for r in table[1:])
def csvwrite(name,rows):
 b=io.StringIO(newline='');csv.writer(b,lineterminator='\n').writerows(rows);write(name,'\ufeff'+b.getvalue())
csvwrite('MATRIX-38-ROOT26-DRAFT.csv',table);csvwrite('MATRIX-ROOT26-APPEND-ONLY.csv',[['id']+headers[47:],*appendRows])
written=list(csv.reader(io.StringIO((out/'MATRIX-38-ROOT26-DRAFT.csv').read_text(encoding='utf-8-sig'),newline='')))
assert written[0][:47]==original[0] and [r[:47] for r in written[1:]]==original[1:]
save('MATRIX-PRESERVATION-ROOT26.json',{'status':'PASS_ORIGINAL_1786_DATA_CELLS_AND_47_HEADERS_EXACT','baseline':str(baseline),'baselineSHA256':sha(baselineBytes),'rows':38,'oldColumns':47,'newColumns':52,'oldDataCells':1786,'oldHeaders':47,'originalIDsAndOrderExact':True,'all38DomainsRemainPartial':True,'earlierThreeSegmentDraftBytesUnchanged':True,'revision02BytesUnchanged':True,'revision04BytesUnchanged':True,'draftSHA256':sha((out/'MATRIX-38-ROOT26-DRAFT.csv').read_bytes())})
gateTable='\n'.join(f"| {r['name']} | {r['result']['ordinaryCalls']} | {r['inputClock']}→{r['result']['clock']} | {r['result']['elapsedSeconds']} / {(datetime.fromisoformat(r['gate']['endedAt'])-datetime.fromisoformat(r['gate']['startedAt'])).total_seconds():.6f} | {r['physicalParts']} | {r['gate']['rawSHA256']} |" for r in runs)
report=f'''# ROOT26：供粮访问四段有限接续（新私有修订稿）

本稿新增native04实际结果，保留原三段报告/矩阵/SHA与revision-02原字节；本修订纠正新矩阵计划列的四段窗数，并加入原诊断绑定、实际pure重检及后续源实现待验范围。**80个有限普通窗通过，完整食品系统与全38域仍PARTIAL。** 86/115有具名sale恢复，29仍低；夜间供餐和有限供应分配成为下一阶段明确缺口。四段原普通窗没有游戏业务修复；root随后接入的两生产文件实现及修复后门另列PENDING。

## 原生范围与实际回执

原World291/b85fa6ec、612建筑/616NPC，从ROOT24原终档6e481…2d48 cold继续，四段16+32+16+16共80普通窗、4构造/4import、80reader。clock5340→5660（17:00→22:20，320游戏分钟）、tick2070→2150；原speed16/每次.25不变，0命令/身体钱粮需求库存身份时间注入。每个gate都是同一417冻结输入stable、exit0/PASS、activeDescendants=[]，RESULT均ACTUAL_COMPLETED，无capture/persistence/conservation失败。不是单fresh80/旧360或新普通URL v8旅程。

| 原门 | 完整普通窗 | clock | driver/gate秒 | 真实parts | 原raw SHA256 |
|---|---:|---|---|---:|---|
{gateTable}

native04的日期计算gate85.638675s、driver84.888s，沿原receipt/RESULT，不沿早期消息近似时长。末whole SHA `{sha(fullBytes)}`；逐段终档与下一完整输入SHA相同。130/127/129/128实际地理parts分别物理写/read/decode/assemble字节exact，各删真chunk拒；额外Sim/import/step0。未跑本阶段未来24/正常UIreload/崩溃恢复或新地图保存。

## 真实居民结果与夜间缺项

原115的真实恢复23→63→73→86，最后86名不同居民有实际sale、原群体122次sale。原29仍低，全城30低=原29+1新低；29中25moving/4riding，活动15rest/14eat。终点完整原save逐ID核6名饱足0且food0：219、340、362、368、428、571。616名原NPC均alive，profiles含player为617，不写617NPC。

四target这次全有真实sale：450于5372、457/489于5408，153终于5600于east-b5买2份、cost29.980531266965833，末shopping/饱足52/food1。450在5500、457/489在5536各有stored-meal；153没有后续stored witness，不能称四人全完成携粮后续餐。全城四RESULT共393柜台餐与23随身餐。

**终点全部210 shop open=false，食品店开放数0。** 86人恢复不等夜间29人都有可用供餐，也不等无库存/营业竞争。本次粮产约6.7569085124、材料约29.7449830046，末两段生产0；没有造粮或暗补钱包。下一应明确夜间经营/随身粮与有限供应分配方案，仍服从原owner/身份许可、劳动营业、库存、钱包、成本、工资债及时间规则，不以诊断工具代服务。

父代理已收前三64窗只读诊断：115cohort共212次目标变化，203次旧目标stock0、9次旧店仍open有货；42的原边界无unreachable/physicalWaiting/roadWaiting，实际处理moving均有位移。这支持供给竞争/长路的局部解释，不证明所有后续合法通路或完整修复。原件已绑定[route-static-review.md](../../route-static-review.md)、[支持JSON](../../route-static-evidence.json)及263原件SHA稳定只读回执；本作者核派生记录及回执，未再运行其读器或另复算全部gzip。原42的两名有库存换店也可更短，不把203个旧空库存目标视作全部单因。

## 钱粮、工具与剩余

四RESULT新earned约996.325269443、NPC paid/publicPaid/privatePaid均0。终payrollAt6780尚未跨；不声称工资已付或财政长期可持续。最大cash/food/debt/fiscal残差为{' / '.join(str(maximum[k]) for k in ['cash','food','debt','fiscal'])}。全部逐run原值和打印数的十进制合计保在[实际证据摘要](ROOT26-ACTUAL-EVIDENCE-SUMMARY.json)；数值舍入口径明确，不拿更长小数当新增物理精度。

独立pure recheck01已有实际closed PASS：31.703037s、418输入stable/active[]，rawSHA b829c1ab9026425bcacb7bf8d00b0489a0708fdea02aef8778743ba107dc4205，[SEALED-80-RECHECK](../../SEALED-80-RECHECK.json) SHA c2a6f9a202f29fba6895a0f917c05fc204d0d072c53e35bf32be9af0700c1348。80份完整原save反馈cash/food/debt重算deep-equal、800phase守恒、850原件双SHA/typedBUS与custody及四段lineage通过，0新Sim/import/step/nativeReader。其418图是原417源加新纯审计script，core仍feb22c37/meal-route03f42f53；此PASS只加强原记录验证，不能称当前游戏修复已通过。3篡改拒绝回归尚PENDING实际门。

root随后实际修改meal-route.ts与simulation.ts：仅nearby-food-v1、age>=6、food<1、原累计elapsed投影satiety<30请求正常people frequency1，tier原值、累计elapsed、移动/出勤/工资上限与legacy条件保持。当前源码SHA在[只读快照](CURRENT-SHARED-READONLY-SNAPSHOT.json)，本作者仅静态读取，不以静态声明代测试。**当前修复/typecheck/修复后ordinary门PENDING**。计划patched01从实际5416原ce40…37b8 full save重放16窗，以旧native02窗004–019作对照；这不是旧80窗时间线接续，也不是原80窗全在修复后跑过。夜间开店、有限粮分配与工资跨窗仍各欠。

本次文档生成rev03曾因当前源与历史417不同的身份守卫真实停止，原[准备FAIL](../revision-03-native04/REVISION03-PREPARATION-FAIL.json)保留。本修订记录当前读前后一致与历史图差异，不删除FAIL、不回写原417运行门。

[38×52新矩阵](MATRIX-38-ROOT26-DRAFT.csv)仅追加ROOT26五列，旧47headers/1786cells/38IDs次序exact，所有38域仍PARTIAL。原三段草稿完全保留，旧STOPWRITE与shared src/memo无本作者写入。原ROOT24四缺phase/FAIL和360 canonical/361物理call仍保，新80窗不回填。完整能源、医疗卫生病毒、科技教育政治、家庭自然世代、产权改造拆迁新路/灾害、统计流式/适配、美术ART_FAIL与MacNOT_RUN仍开放；14日现金财政供粮稳态NOT_RUN。

本作者0Sim/step/tests/types/build/browser/GPU，仅静态JSON/CSV/SHA核对与新私稿。Library/本stageGit提交推送和最终交付PENDING实际root回执，未制作新ZIP或上传；容器路径不是已送达附件。
'''
write('ROOT26-供粮访问阶段报告-DRAFT.md',report)
write('MEMO-APPEND-ROOT26-DRAFT.md',f'''\n\n### ROOT26 原食品接续80有限窗实际完成，夜间供餐与分配仍PARTIAL（2026-10-07，私有四段追加草案）

native01/02/03/04各417 frozen stable/active[]/PASS，16+32+16+16=80原普通窗、4cold段/4Sim/import/80reader，原World291/b85fa6ec从6e481…2d48，5340→5660（17:00→22:20/320分钟）、tick2070→2150，0命令/钱粮需求身体身份库存时间注入；四门绑定未修复417，非单fresh80/旧360或新v8普通URL。末全档SHA {sha(fullBytes)}，130/127/129/128各真part物理读/assemble同whole与缺chunk拒，额外Sim/import/step0，future24/UIreload未跑。

原115中23→63→73→86人具名sale恢复，末29仍低(25moving4riding/15rest14eat)，全城30低含1新低；122原cohort sale、393全城柜台/23随身餐。616NPC逐IDalive，617profile含player；6原cohort(219/340/362/368/428/571)hunger0food0由末whole核。153于5600真实east-b5 qty2/cost29.980531266965833，四target全sale，仅450457489有stored-meal，不称153已后续食用。

终5660全部210shop closed/foodStoresOpen0，夜间供餐和有限分配仍明确缺口；粮产约6.7569085124/material29.7449830046，新earned约996.325269443/paid0，原payrollAt6780未跨，最长14日财政/供粮稳态仍未验。最大cash/food/debt/fiscal {'/'.join(str(maximum[k]) for k in ['cash','food','debt','fiscal'])}；不补钱粮、不弱断言。前三64窗只读212重选203旧目标stock0/9open有货、原42无unreachable/physicalWaiting/roadWaiting且moving处理有位移，支持供给竞争/长路，但原route-static-review.md/支持JSON/263读入稳定回执已绑定；本作者未再运行读器、不冒所有原因唯一。

独立recheck01已closed PASS31.703037s/418stable active[]，80原窗800phase/850双SHA/full反馈重算equal、0新Sim/import/step/nativeReader；418是旧417+pure工具，非新业务通过。root随后仅meal-route.ts/simulation.ts实现饥饿无粮age>=6 nearby-policy投影频率1，原tier/elapsed/移动/工资legacy保持声明；新typecheck/3篡改tests/patched01实际门PENDING，patched01拟从5416原档对照旧native02窗004–019重放16，非80续。新四段私稿在ROOT26/report-draft/revision-05-native04，旧三段稿及revision-02/03/04原SHA不改；rev03因真实源不同守卫停止FAIL保；47旧headers/1786cells/38IDs顺序exact，全38PARTIAL，旧FAIL/缺4phase、ART_FAIL、MacNOT_RUN保。作者0Sim/step/tests/build/browser/共享写，Library/本stageGit实际回执待root，不预写送达。\n''')
assert all(sha((old/n).read_bytes())==v['sha256'] for n,v in priorManifest['files'].items())
assert baseline.read_bytes()==baselineBytes and all(sha(p.read_bytes())==inputRecords[str(p)]['sha256'] for p in inputs)
assert all(sha((priorRevision/n).read_bytes())==v['sha256'] for n,v in priorRevisionManifest['files'].items())
assert all(sha((failedRevision/n).read_bytes())==h for n,h in failedRevisionHashes.items())
assert all(sha((priorCompletedRevision/n).read_bytes())==v['sha256'] for n,v in priorCompletedManifest['files'].items())
sharedAfter={p:sha((repo/p).read_bytes()) for p in sharedBefore};assert sharedAfter==sharedBefore
save('DRAFT-INPUT-SNAPSHOT.json',{'at':datetime.now(timezone.utc).isoformat(),'files':inputRecords,'sameFrozen417AcrossFourRuns':True,'historicalFourGates417BeforeAfterExact':True,'currentSelected418BeforeAfterExact':True,'currentVsHistorical417Differences':currentNativeSourceDifferences,'previousThreeSegmentDraftHashesExact':True,'previousRevision02HashesExact':True,'previousRevision04HashesExact':True,'pureAudit418Status':'recheck01 actualPASS; historical417+new script, not modified gameplay','newModifiedGameplayTypecheckTamperControlStatus':'PENDING actual root gate','diagnosisBinding':'route-static-review.md/supportJSON/263-read receipt bound; current author did not rerun reader','authorSimStepTestsBuildBrowserGPU':0,'authorSharedWrites':0,'authorUploadsZIP':0})
save('READONLY-PRESERVATION-ROOT26.json',{'at':datetime.now(timezone.utc).isoformat(),'old47Headers1786CellsExact':True,'previousThreeSegmentDraftFilesExact':True,'previousRevision02FilesExact':True,'previousRevision04FilesExact':True,'historicalFourGates417BeforeAfterExact':True,'currentSelected418ReadBeforeAfterExact':True,'currentSharedMatchesHistorical417':not currentNativeSourceDifferences,'revision03PreparationFailurePreserved':True,'oldSTOPWRITEDirectoryWrites':0,'sharedMemoWrites':0,'sharedSourceWrites':0,'executionSimStepTestsBuildBrowserGPU':0,'LibraryZIP':0,'sourceMethod':'Per-file original raw SHA; no invented JS graph digest'})
save('DRAFT-SHA256.json',{'at':datetime.now(timezone.utc).isoformat(),'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in out.iterdir() if p.is_file() and p.name!='DRAFT-SHA256.json'},'status':'PRIVATE_FOUR_SEGMENT_DRAFT_WITH_ACTUAL_PURE_RECHECK_ONLY_MODIFIED_GAMEPLAY_PENDING_NO_DELIVERY_CLAIM'})
print(json.dumps({'status':'FOUR_SEGMENT_PRIVATE_DRAFT_READY','output':str(out),'oldDraftPreserved':True,'matrixRows':38,'matrixColumns':52,'oldCells':1786,'canonicalWindows':80,'cohortRecovered':86,'cohortStillLow':29,'allLow':30,'endpointAll210ShopsClosed':True,'pending':'night food/supply; modified gameplay/typecheck/tamper/control/Library/Git actual receipts; pure recheck01 already actualPASS'},ensure_ascii=False,indent=2))

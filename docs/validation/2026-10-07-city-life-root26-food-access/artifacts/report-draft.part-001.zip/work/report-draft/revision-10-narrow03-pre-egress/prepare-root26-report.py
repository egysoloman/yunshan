from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
import csv, hashlib, io, json, re, sys

repo = Path('/workspace/yunshan')
work = Path('/workspace/yunshan-work/ROOT26-food-access-20261007-01')
native = Path('/tmp/ROOT26-food-access-20261007-01')
out = Path(__file__).resolve().parent
drafts = out.parent
prior = drafts / 'revision-09-broad-rejected-narrow-pending'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
now = lambda: datetime.now(timezone.utc).isoformat()
assert len(sys.argv) == 2, 'Provide the actual closed final build gate name.'
build_name = sys.argv[1].removesuffix('-gate')
preserved = {str(p): sha(p) for p in drafts.rglob('*') if p.is_file() and out not in p.parents}
prep = {str(p): sha(p) for p in out.iterdir() if p.is_file()}
inputs = {}

def bind(p):
    p = Path(p)
    inputs[str(p)] = {'bytes': p.stat().st_size, 'sha256': sha(p)}
    return p

def write(name, text):
    p = out / name
    assert not p.exists(), 'Do not overwrite an existing original: ' + str(p)
    p.write_text(text, encoding='utf-8')

def save(name, value):
    write(name, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def gate(name, expected='PASS'):
    g = work / (name + '-gate')
    r, b, a = load(g / 'receipt.json'), load(g / 'inputs-before.json'), load(g / 'inputs-after.json')
    assert r['status'] == expected and r['inputsStable'] and not r['activeDescendants']
    assert b == a and len(b) == r['inputCount'] and sha(g / 'raw.log') == r['rawSHA256']
    if expected == 'PASS': assert r['exitCode'] == 0 and not r['timedOut']
    for n in ['receipt.json', 'inputs-before.json', 'inputs-after.json', 'raw.log']: bind(g / n)
    raw = (g / 'raw.log').read_text()
    return {'receipt': r, 'gateSeconds': (datetime.fromisoformat(r['endedAt']) - datetime.fromisoformat(r['startedAt'])).total_seconds(),
            'runnerSummary': {k: int(v) for k, v in re.findall(r'^ℹ (tests|pass|fail|cancelled|skipped|todo) (\d+)$', raw, re.M)},
            'passedNames': re.findall(r'^✔ (.+?) \([\d.]+ms\)$', raw, re.M), 'frozenInputs': b}

names = ['narrow-tests02', 'patched03', 'recheck-negative01', 'home-tests04', 'regression06-remainder', 'patched04', 'recheck-positive02', build_name]
gates = {n: gate(n) for n in names}
gates['regression05'] = gate('regression05', 'TIMEOUT_PARTIAL')
gates['home-tests03'] = gate('home-tests03', 'FAIL')
gates['baseline-home-capture02'] = gate('baseline-home-capture02', 'FAIL')
old = load(bind(work / 'native04-gate/inputs-before.json'))
source419 = gates['patched03']['frozenInputs']
source421 = gates['patched04']['frozenInputs']
assert len(old) == 417 and len(source419) == 419 and len(source421) == 421
assert all(gates[n]['frozenInputs'] == source421 for n in ['home-tests04', 'regression05', 'regression06-remainder', 'recheck-positive02', build_name])
current = {p: sha(repo / p) for p in source421}
assert current == source421
assert set(p for p in source421 if p not in old) == {'scripts/food-access-recheck.ts', 'src/simulation/voxel-movement.ts', 'tests/urgent-meal-processing.test.ts', 'tests/voxel-movement.test.ts'}
assert {p for p in old if old[p] != source421[p]} == {'src/simulation.ts', 'src/simulation/meal-route.ts'}
assert {p for p in source421 if p not in source419 or source421[p] != source419[p]} == {'src/simulation.ts', 'src/simulation/voxel-movement.ts', 'tests/voxel-movement.test.ts'}
assert source421['src/simulation/home-rest.ts'] == old['src/simulation/home-rest.ts']
lineage = load(bind(out / 'SOURCE-LINEAGE-ORIGINAL261-READONLY.json'))
original_test_paths = [p for p in old if p.startswith('tests/')]
assert all(current[p] == old[p] for p in original_test_paths)
passed = sum([gates[n]['passedNames'] for n in ['home-tests04', 'regression05', 'regression06-remainder']], [])
assert len(passed) == len(set(passed)) == 103
assert gates['regression05']['runnerSummary'] == {'tests':44, 'pass':40, 'fail':0, 'cancelled':4, 'skipped':0, 'todo':0}
assert gates['home-tests04']['runnerSummary']['pass'] == 28 and gates['regression06-remainder']['runnerSummary']['pass'] == 35

checkpoint = load(bind(work / 'MEMO-CHECKPOINT26-APPEND.json'))
memo = bind(repo / '开发备忘录.md')
memo_bytes = memo.read_bytes()
assert len(memo_bytes) >= 621373 and hashlib.sha256(memo_bytes[:621373]).hexdigest() == 'eb83606ecbb17b8bcd821dc8b9b4ac343a54a13ab5fb530230c3a58aa006a393'
assert hashlib.sha256(memo_bytes[:616779]).hexdigest() == '778b49c8d220e91a06beac8d2df349bd759a0cbb54e49666d6a094abc9584cd1'
for p in [repo/'AGENTS.md', repo/'提示词.md', out/'PATCHED03-READONLY-CONTROL-SUMMARY.json', out/'NEW-CLOSED-RECEIPTS-READONLY.json', out/'FINAL421-CLOSED-GATES-READONLY.json', out/'PATCHED04-READONLY-CONTINUATION-SUMMARY.json', out/'MEMO-CHECKPOINT26-PRESERVATION-READONLY.json', prior/'DRAFT-SHA256.json']: bind(p)
results = {n: load(bind(native / n / 'RESULT.json')) for n in ['patched03', 'patched04']}
for n, count, future in [('patched03',40,24), ('patched04',8,4)]:
    r = results[n]
    assert r['status'] == 'ACTUAL_COMPLETED' and r['failure'] is None and r['completedWindows'] == r['readers'] == count
    assert r['shadowExact'] == r['shadowSteps'] == r['shadowReturned'] == future
    assert r['constructors'] == r['imports'] == 2 and r['commands'] == r['injectedBodiesMoneyNeedsStockRolesTime'] == 0
    assert not r['captureFailures'] and not r['persistenceFailures'] and not r['conservationViolations']
    for p in [work/(n.upper()+'-PLAN.json'), native/n/'FRAMES.json', native/n/'TERMINAL-PARTS.json', native/n/'SHADOW-COLD-IMPORT.json']: bind(p)
    comparisons = sorted((native/n/'shadow').glob('*.comparison.json'))
    assert len(comparisons) == future
    for p in comparisons:
        j = load(bind(p)); assert j['fullBytesExact'] and j['primary']['rawSHA256'] == j['cold']['rawSHA256']
assert results['patched03']['terminalSaveSHA256'] == results['patched04']['inputSaveSHA256'] == '836e6d9f99f226ce91a62784e0774203374c8fc2f3b59f31233dad92066af363'
positive = load(bind(native/'recheck-positive02/RESULT.json'))
audits = {n:load(bind(native/'recheck-positive02'/ (n+'.json'))) for n in ['control80','broad-rejected40','narrow48-two-source-segments']}
assert positive['status'] == 'PASS' and positive['simulations'] == positive['imports'] == positive['steps'] == 0
assert [(a['completeOriginalWindows'],a['completeStablePhases'],a['dualSHAOriginals']) for a in audits.values()] == [(80,800,850),(40,400,343),(48,480,516)]
assert audits['narrow48-two-source-segments']['cohortActuallyAte'] == audits['narrow48-two-source-segments']['cohortRecoveredAtTerminal'] == 58
assert audits['narrow48-two-source-segments']['allCitizensLow'] == 32
for n,a in audits.items(): assert a['constructors'] == a['imports'] == a['steps'] == a['nativeReaderCalls'] == 0 and not a['steadyStateClaimed'] and not a['missingCaptureUpgrade'] and not a['gameplayRepairClaimed']
bind(work/'recheck-positive-all.ts')
old_report = load(bind(drafts/'revision-05-native04/ROOT26-ACTUAL-EVIDENCE-SUMMARY.json'))
prior_summary = load(bind(prior/'ROOT26-ACTUAL-EVIDENCE-SUMMARY.json'))
summary = {'status':'PRIVATE_ACTUAL_NARROW419_FINAL421_CLOSURES_BOUND_ALL38_PARTIAL', 'at':now(),
 'oldOriginal80':old_report, 'rejectedBroadOriginalEvidence':prior_summary,
 'gates':{n:{k:v for k,v in g.items() if k!='frozenInputs'} for n,g in gates.items()},
 'narrow419':results['patched03'], 'final421Continuation8':results['patched04'],
 'pureFinal421Recheck':{'result':positive,'audits':audits},
 'uniqueActualFinal421PassedNames':sorted(set(passed)), 'uniqueActualFinal421PassedCases':103,
 'original261TestsAreProtectedPathsNotCases':True, 'old261NoBytesChanged':True,
 'allOriginal417TestsPathsUnchanged':len(original_test_paths), 'originalWhole8FileGatePASSClaimed':False,
 'sourceScopes':{'original417':old,'narrow03Actual419':source419,'final421':source421},
 'futureScope':'narrow419 primary40/shadow24 exact; final421 cold primary8/shadow4 exact; never a same-source fresh48 run or old80 continuation.',
 'oldReader244OptionalBranch':'NOT_RUN (no configured env); not inferred from actual case title.',
 'homeVoxelScope':'placeSnapshotVoxel synthetic controlled native snapshot, not normal player construction UI.',
 'futureUnclosed':'Night/supply/families/nextpayroll6780/14day/ART_FAIL/MacNOT_RUN; Library/Git await actual root receipts.',
 'authorSimStepTestsBuildBrowserGPUSharedWrites':0}
save('ROOT26-ACTUAL-EVIDENCE-SUMMARY.json', summary)

baseline = bind(repo/'docs/validation/2026-10-07-city-life-root24-25/REQUIREMENTS-38.csv')
old_rows = list(csv.reader(baseline.open(encoding='utf-8-sig')))
rows = list(csv.reader((prior/'MATRIX-38-ROOT26-DRAFT.csv').open(encoding='utf-8-sig')))
assert len(rows)==len(old_rows)==39 and len(old_rows[0])==47 and len(rows[0])==52
assert rows[0][:47]==old_rows[0] and [r[:47] for r in rows[1:]]==old_rows[1:]
byid={r[0]:r for r in rows[1:]}
for r in rows[1:]:
    r[47]='保本域原完整目标；本轮旧417四cold段80原窗、独立5416宽负候选与收窄419对照40、最终421冷续8分来源闭门；不改世界、人口或本域剩余要求。'
    if r[48].startswith('本域业务/源码无新增'):
        r[48]='本域业务无新增；相关普通食品/身体移动门与纯原件重检不等本域全流程完成。'
        r[49]='本域独立完整端到端NOT_RUN；本stage有限食品重放与原测试局部回归不能代本域自然全流程、长期或GUI验证。'
        r[50]='PARTIAL；本域未新增完整完成门，原已实局部PASS/FAIL与具体剩余继续保留。'

def update(ident,plan=None,implementation=None,run=None,verify=None,remaining=None):
    for i,v in enumerate([plan,implementation,run,verify,remaining],47):
        if v is not None: byid[ident][i]=v

impl='最终收窄沿nearby-food-v1/age>=6/activity=eat/food<1/原elapsed投影hunger<30，已到站mealrider或完整参考折线余程<=未改walkingSpeed*25min正常people frequency1；非eat/长路沿原频率、tier/focus/elapsed/钱包库存营业工资守卫不改。另movement-only voxel允许既有重叠身体水平严格向外离开，完整sweep拒新重叠；站立/rest/meal原谓词不变。'
narrowrun='同原5416 ce40档419 source patched03主40+shadow24 actualPASS254.753447s，5480旧89群恢复17/新18，全城低72/71；5576旧43/新52、全城低47/38。279新5432真实saleqty1/cost17.966614100760214，旧5480无sale。421另从03末836e档冷续主8+shadow4 actualPASS79.828184s→5608/t2137/bbaa6a7a…ad29，非单源48/旧80续。'
pure='最终421 pure recheck-positive02 PASS62.253600s：旧80/800phase/850双SHA、已拒宽40/400/343、收窄两段48/480/516分别独立重核钱粮债与原feedback/全部10phase/BUS writer/parts/shadow；0Sim/import/step/nativeReader。两段末58/89实际sale且恢复、31仍低/全城32，238counter18stored。'
old80='旧417 native01–04独立80窗5340→5660，86/115真实sale恢复/29仍低/全城低30/210shop全部closed，6原群hunger0food0；1535600有sale无后续stored witness。'
closed='最终同421 home04 28PASS + reg05 completed40PASS/4cancel + reg06 35PASS =103 unique通过名称；reg05真实240sTIMEOUT保，未称完整8files一次PASS。最终build '+build_name+' actualPASS'+str(gates[build_name]['gateSeconds'])+'s；原261 tests/夹具路径逐字不动。'
remaining='有限供給分配/夜间合法营业、下一payroll6780与14日稳态、全城所有路线/玩家正常UI生活未完成；Library/Git仅root实际回执后另追加。'
update('SYS-01',implementation='417原80、418已拒宽源、419收窄03、421最终egress+8冷续与最新pure工具分别绑定；原World291不改，旧CPU档不代fresh v8完整产品。',run=narrowrun+' '+closed,verify='PARTIAL；实际有限运行与回归闭门，各源/范围分别真实；完整3D/2D/文字/宿主/fresh默认端到端仍欠。')
update('MAP-02',implementation=impl+' 原地图/道路/踏面不变。',run='原前三64窗212次目标变化203旧库存0/9旧店开有货；42边界moving无所列waiting/unreachable且处理有位移，诊断非全路物理证明。 '+narrowrun,verify='PARTIAL；完整参考余程只定调度边界，真实高层几何/24tick保存是相关原测试范围，供需与全路通达未全验。')
update('FOOD-01',plan='保有限食品完整目标；宽源负结果保，收窄同5416原档实际对照40+24future，最终组合421另8+4future；最新pure三链分开实核。',implementation=impl,run=old80+' '+narrowrun+' '+pure,verify='PARTIAL；窄修复实际防近端64min错失并改善所验同钟群，全城有限供给/夜间餐仍未解决；宽40负结果不抹去。',remaining=remaining)
update('SHOP-01',implementation=impl,run=narrowrun+' '+pure+' 原80终5660全部210shop closed保持；421末5608不同钟不冒夜间全解。',verify='PARTIAL；真实付款库存成交获餐已实，夜间供给/经营重开/自然新租户完整链仍欠。')
update('TRA-01',implementation=impl+' 原FIFO/lot/货主/库存/道路权限不扩。',run=narrowrun,verify='PARTIAL；近端购餐不代全物流配送与每低饱足居民供货。')
update('LIFE-01',implementation=impl,run=narrowrun+' home04原7bed/voxel回归PASS，21新pure egress PASS；放块是synthetic placeSnapshotVoxel非玩家建造UI。',verify='PARTIAL；身体离开原放块重叠实测修复，正常第一人称家居/厨卫/夜间日常全流程未新验。')
update('LIFE-03',implementation=impl,run='原03终5576 616NPCalive，旧89群43恢复/新52，全城低47/38；两来源末5608具名58恢复/31仍低/全低32。旧80的六零饱足零携粮仍保原事实。',verify='PARTIAL；获餐/存活改善不等全城营养、健康心理与长期寿命闭合。')
update('BLD-01',implementation='新增纯voxel运动子守卫保.2m块/.35radius/1.72height/.01feet原实体；不改站立/rest/meal/player权限、墙体/支撑/床许可/门/道路守卫。',run='home04 21新pure+7原home共28PASS；原两legacy physicalWaiting FAIL在417复现，421正常moving修复；10原native captures保。',verify='PARTIAL；放块为synthetic受控snapshot、未验正常建造UI/整楼施工/房屋改造。')
update('POL-02',run='419主40earned262.77067088031504/paid0，food1.0743647328613164/material2.1510779069859334，206counter16stored；421另8 earned73.8405644012972/paid0、32counter2stored，生产food/material0；所有主10phase守恒原值。未跨6780payroll。',verify='PARTIAL；原工资/出勤/钱粮债guard未放宽，下一工资/公共财政长期供給仍未验。')
update('PER-01',implementation='窄近端餐仅正常frequency1；不写tier/focus，原每8tick真实位移classify自然变化。voxel完整sweep不靠0.05m采样或改移动预算。',run=narrowrun+' reg06真24tick重建case238.364682s，reg05TIMEOUT不能推断微步死循环。',verify='PARTIAL；有限运行/回归实际秒数非benchmark、GL/Mac或统计流式性能达标。',remaining='真实负载与平台性能、长期14日稳态继续未验；旧预算/实体契约不放宽。')
update('SAVE-01',implementation='419 patched03 hot24/coldshadow24 complete-save逐窗exact；421 patched04实际冷入836档主8+shadow4 exact。主40/8 custody400/80phase，shadow只全档比较未另独立observer。',run=narrowrun+' '+pure+' reg06原高楼mid-riser complete/partition/selector/RPG重建24实际tickPASS、15坏cursor原子拒；未配置244旧reader分支NOT_RUN。',verify='PARTIAL；各实际源future24/4分别通过，不称421主40/48；新pure工具不是游戏repair，缺4旧phase仍FAIL不补造。',remaining=remaining)
update('ADP-01',run='reg06实际原高层native complete/partition/selector/RPG重建24tickPASS原件24files；旧reader244可选无env NOT_RUN。',verify='PARTIAL；仅原core bridge相关回归，不代新bundle/MZ/default正常UI端到端。')
update('VAL-01',implementation='全部actual gate/source/hash原件与宽负结果/原417home FAIL/home03加载FAIL/reg05超时保；无源跨升级。checkpoint全文保后追加closure。',run=closed+' '+pure,verify='PARTIAL；103是421实际去重cases，261是原受保护路径非cases；20 narrowtests02与03不同mealSHA单独列，38域与ART_FAIL/MacNOT_RUN不关闭。',remaining=remaining)
assert rows[0][:47]==old_rows[0] and [r[:47] for r in rows[1:]]==old_rows[1:]
assert all(r[50].startswith('PARTIAL') for r in rows[1:])
def csv_text(data):
    s=io.StringIO(newline=''); csv.writer(s,lineterminator='\n').writerows(data); return '\ufeff'+s.getvalue()
write('MATRIX-38-ROOT26-DRAFT.csv',csv_text(rows))
write('MATRIX-ROOT26-APPEND-ONLY.csv',csv_text([[rows[0][0]]+rows[0][47:]]+[[r[0]]+r[47:] for r in rows[1:]]))
save('MATRIX-PRESERVATION-ROOT26.json',{'oldBaseline':str(baseline),'oldSHA256':sha(baseline),'old47HeadersExact':True,'old1786CellsExact':True,'old38IDOrderExact':True,'rows':38,'columns':52,'appendColumns':5,'all38PARTIAL':True,'originalOldFileWrites':0})

gate_table='\n'.join('| '+n+' | '+str(g['receipt']['inputCount'])+' | '+g['receipt']['status']+' | '+str(g['gateSeconds'])+' | '+g['receipt']['rawSHA256']+' |' for n,g in gates.items())
report=f'''# ROOT26：收窄近端餐修复与最终 421 源有限闭门（revision10 私稿）

收窄后的近端餐调度已用原生同钟对照验证：从5416同一原档，5576时初始89低饱足居民恢复旧43/新52，全城低饱足旧47/新38。最终421源另冷续8窗并4窗hot/cold完整存档逐字相同；相关最终测试去重103项实际通过，原失败和超时保留。有限供给分配、夜间供餐与所有38需求域仍PARTIAL，ART_FAIL、MacNOT_RUN、14日稳态NOT_RUN不变。本稿不包含尚无回执的Library保存或本stageGit交付。

## 真实来源与实现边界

原World291 SHA`2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512`是current-v6/fingerprint b85fa6ec、612建筑/616NPC；本stage旧档对照不代当前fresh默认v8普通URL验收。original417、已拒宽候选418、收窄03实际419、最终421四种来源分别绑定。最终相对原417只MOD simulation.ts/meal-route.ts，NEW pure recheck脚本、urgent测试、voxel运动模块与其测试4路径；417其余全输入保，全部原tests/路径逐字不动。[完整来源](SOURCE-LINEAGE-ORIGINAL261-READONLY.json)。261是ROOT24–25保护的测试/夹具/辅助数据路径数，非case数；原417全部tests/266路径同样不改。20项narrow-tests02实际PASS，但其meal helper SHA`efc6594a…c822`与03的`6ce96235…f2a4`不同，差为注释与finitewalkingrate guard，20项结果不冒同精确03源。

窄修复仅nearby-food-v1/age>=6/activity=eat/food<1/原累计elapsed投影hunger<30，并且已到站mealrider或完整参考折线余程不超过原walkingSpeed×25min，选择原people正常frequency1。雨中3.1/其他4.2速度不变，长路/非eat/儿童/携粮/legacy沿原频率。未写tier/focus、身体/钱粮/库存/角色/时间；原classification每8tick随真实body变化，双方tiersUnchanged=false不是人工注入。参考折线边界只是调度选择，不是全物理路线通达证明。

最终421另加入movement-only voxel子守卫：对已经与放块重叠的NPC，仅水平严格向外、径向净空不降低且不深入/穿越块心时可离开；全3D sweep拒新重叠，异常有限数拒绝。原.2m方块、.35m半径/1.72m高/.01m脚底、站立/rest/meal和玩家判定不变，墙/支撑/权限/门/柜台/道路仍原守卫。home-rest生产SHA`60b2126e…b006`保持。放块来自明确synthetic `placeSnapshotVoxel`受控原生snapshot，不能冒正常玩家建造UI验收。

## 同钟对照、真实成交与仍低群

完整原checkpoint`ce40c74205c1126519e08c5d49e32d18f22cc4acf410d07f1fa4e709ff0337b8`，5416/t2089，89低群。419 patched03主40/24shadow、2构造/2import/40reader、0命令及注入，实际PASS254.753447s，至5576/t2129/末`836e6d9f99f226ce91a62784e0774203374c8fc2f3b59f31233dad92066af363`，400主phase守恒，24shadow逐窗whole bytesexact。shadow没有独立另240 phase捕获。131真实parts末whole exact并拒缺chunk；分区额外Sim/import/step0。

| 原5416初始89群 | 旧5480 | 新4195480 | 旧5576 | 新4195576 |
|---|---:|---:|---:|---:|
| 恢复人数 | 17 | 18 | 43 | 52 |
| 全城低饱足 | 72 | 71 | 47 | 38 |

只读作者独立解读四份完整原save与dualSHA，人数一致；[原读回](PATCHED03-READONLY-CONTROL-SUMMARY.json)。真实sale关联以根最新pure recheck BUS/phase/body/wallet writer原件核。279于5432真实west-b41售qty1/cost17.966614100760214，旧5480尚无sale；03终shopping/hunger100/food1，旧5576moving/hunger8.499999999999773/food0。这支持窄近端调度防原64min处理延迟错失，未增加食物或开店。

421 patched04是从03末836档另冷构造/导入，主8/4shadow、2Sim/2import/8reader，0命令注入，79.828184s，5576→5608/t2137，末`bbaa6a7a5e0bfcda107d22e62a820c6aa65336b3e0a48266f00846e2306dad29`。80主phase守恒、shadow4 fullbytesexact、129parts whole exact/缺part拒。03自然城没有放置voxel，所以该8窗是最终组合源的有限兼容接续，不声称在此城市观察了放块egress。40旧419+8新421为两来源48主窗，不能称单421主40或fresh同源48，更不接original80。

最新最终421纯重检62.253600s/PASS，从完整原件分别重算三链：旧80/800phase/850双SHA；已拒宽40/400/343；收窄两来源48/480/516。0Sim/import/step/nativeReader。所有主phase原cash/food/debt fullsnapshot等原feedback，guard/custody、原BUS与cust原件、每sale实际身体/付款/food writer、parts/段lineage及原hot/coldshadow双SHA全核。两来源末58/89具名实际sale且恢复，31仍低、全城32；238柜台/18stored。新pure工具是原件审计，不是游戏修复，不补任何历史缺捕获。

## 原负结果、原测试与最终实际门

宽418候选仍明确拒作最终gameplay修复。虽279提前成交且宽future24 fullsave exact，从同5416档5576恢复新34对旧43，全城低56对旧47；5480恢复13对旧17/全低76对72。两次宽前16原save/BUS/custody/trace逐SHA重放相同，只说明物理复现；不新增canonical窗或覆盖窄源结果。[保原宽稿](../revision-09-broad-rejected-narrow-pending/ROOT26-供粮访问阶段报告-DRAFT.md)。

宽tests01真实41pass/2fail，原417 baseline-home01同两legacy床侧放块physicalWaiting!=moving复现5pass/2fail；baseline-capture02实际FAIL1/1含3原完整save/cause保。最终home04真实21新pure+7原home=28PASS，两原legacy断言已PASS，原测试字节不改。安装03错误header slice匹配注释`import to`，实际两文件加载FAIL/0behavioral cases，保brokenoriginal与04-CORRECTION，修正只去两错误header行；不把安装加载失败当游戏逻辑FAIL。

reg05原421门240.263373s真实TIMEOUT_PARTIAL，44runner条目40pass/0fail/4cancel，四个取消文件保；不能叫完整8files一次PASS，也不能推断微步死循环。reg06四余文件实际35/35PASS，动态14 doorway实例在计数内。原高层native实际运动case6.552017s，24真tick complete/partition/selector/RPG重建case238.364682s，解释长case真实成本；15坏cursor原子拒与真实上/下恢复通过，24份原件保。含oldreader的标题不能覆盖未设置env的旧244可选读器分支，该分支NOT_RUN。[最终421回执/103unique名称](FINAL421-CLOSED-GATES-READONLY.json)。home04 28 + reg05 completed40 + reg06 35 =103 unique PASS名称，无重复；不与旧20窄test或41宽test再加成一轮。

| 实际闭门 | 输入数 | 状态 | gate秒 | 原raw SHA256 |
|---|---:|---|---:|---|
{gate_table}

final421 home04/reg05/reg06/patched04/recheck-positive02/{build_name}逐项来源相同，before=after/421stable/active=[]；build仅为该真实源构建门，不替GPU、正常URL旅程、Mac或长期仿真。旧419 narrow03来源未升级。[实际证据摘要](ROOT26-ACTUAL-EVIDENCE-SUMMARY.json)。3tamper回归在另一实际419源PASS/225原files未改/0Sim，不能当最终421上新重跑；其auditor源码与421相同，但门绑定仍原419范围。

## 钱粮、历史80与下一缺口

419主40 food1.0743647328613164/material2.1510779069859334，206counter/16stored，earned262.77067088031504/paid0；最大原cash/food/debt/fiscal残差1.7462298274040222e-10 / 1.8189894035458565e-12 / 2.2737367544323206e-13 / 3.410605131648481e-11。421另8 food/material0、32counter/2stored、earned73.8405644012972/paid0，残差1.7462298274040222e-10 / 0 / 1.1368683772161603e-13 / 6.430411758628907e-12。未跨原payrollAt6780，不能称下一工资/长期财政成功。

original417四cold段80仍原事实：5340→5660/t2070→2150，616基线NPC alive（617profiles含player，不是617NPC），86/115具名sale恢复，29低+1新低，393counter/23stored；6原群hunger0food0，210shop终全closed。153于5600真sale qty2/cost29.980531266965833，只有其余三target有后stored，153无后stored witness。前三64原诊断212目标变化203旧stock0/9旧店开有货、42moving边界无所列waiting/unreachable且有位移，仅支持供给竞争/长路/处理间隔的局部原因，不是全路修复。原旧4缺phase/FAIL不由本stage新80或pure审计补造。

下一完整缺口为有限供给竞争与分配、合法夜间餐食经营，须保真实owner/许可、成本/劳动/钱包库存/工资债与时间；不能凭空补食物或让所有店夜开。其他能源/家庭/医卫/社会/建造等原完整目标未由食品完成。正常玩家第一人称新生活、14日现金财政供粮稳态、ART_FAIL与MacNOT_RUN继续。Library/Git由根取得真实回执后追加，本文不预写提交或送达。

[新52列38行矩阵](MATRIX-38-ROOT26-DRAFT.csv)只追加ROOT26五列，旧47headers/1786cells/38IDs次序exact，全38PARTIAL。[memo追加私稿](MEMO-APPEND-ROOT26-DRAFT.md)必须接在已实际621373bytes checkpoint全文之后，保原timestamp RUNNING/NOT_RUN不回写；本作者0Sim/step/tests/build/browser/GPU/共享写/ZIP/上传，全部前稿和FAIL原件保。
'''
write('ROOT26-供粮访问阶段报告-DRAFT.md',report)
write('MEMO-APPEND-ROOT26-DRAFT.md',f'''\n\n### ROOT26 收窄近端餐实际改善；最终421有限兼容闭门（2026-10-07，checkpoint26后追加closure私稿）

保原checkpoint26全文621373bytes/SHAeb83606ecbb17b8bcd821dc8b9b4ac343a54a13ab5fb530230c3a58aa006a393及其原616779bytes prefix；原时间点RUNNING/NOT_RUN保持历史，不回改。此后新增actual：419 narrow03 5416 ce40原档主40+shadow24闭PASS254.753447s/raw249419cc…759b9，2Sim/import/40reader、0注入、400主phase守恒，末5576/t2129/836e6d9f…af363。原89低群5480恢复旧17/新18、全低72/71；5576旧43/新52、全低47/38；2795432真实saleqty1/cost17.966614100760214，旧5480未售。频率仅nearby-food-v1/eat/age>=6/food<1/projectedhunger<30，已到站rider或完整参考折线余程<=原walkingSpeed*25min，非eat/长路沿原频率，未写tier/focus或补钱粮。

最终421新增movement-only voxel egress子守卫，.2m块/.35radius/1.72height/.01foot不变；已重叠身体可水平严格向外离开、全sweep拒新重叠，站立/rest/meal/player和原墙/支撑/床权限/门/道路不改。home04实际28/28PASS(21新pure+7原home)60.956525s/raw1491e1a…ada5f；放块明确synthetic placeSnapshotVoxel受控snapshot，非玩家建造UI。原417两legacy床侧FAIL复现与capture02 FAIL保。安装03错误header加载FAIL2files/0behavioralcase及brokenoriginal保，04只去两错header不改谓词断言。reg05 240.263373s TIMEOUT_PARTIAL/40pass0fail4cancel保；reg06 35/35PASS274.111118s/rawf6214069…46b4，含14动态doorway；真native24tick分块/selector/RPG重建case238.364682s，15坏cursor拒，未配置244旧reader分支NOT_RUN。home28+reg05完成40+reg0635名字无重，共103实际final421通过cases，原261是tests/夹具路径不是cases，字节全部原样，不冒whole8filegate一轮PASS。

421 patched04从03原末836档另cold主8+shadow4闭PASS79.828184s/raw750910cb…e9e，2Sim/import/8reader、0注入、80主phase守恒，5576→5608/t2137/末bbaa6a7a5e0bfcda107d22e62a820c6aa65336b3e0a48266f00846e2306dad29；shadow4全档exact/129parts真重建拒缺。419原40+421新8是两源48，不升级成421主40/fresh同源48或原80续。最终421 pure recheck-positive02实际PASS62.253600s/rawf544d9a…e1df：旧80/800phase/850双SHA、已拒宽40/400/343、窄两段48/480/516独立原完整save/feedback/custody/BUS真实sale writer/parts/shadow重核，0Sim/import/step/nativeReader。两段末58/89真实sale恢复，31仍低/全低32，238counter18stored；pure工具不是gameplay repair。最终{build_name} actualPASS{gates[build_name]['gateSeconds']}s/raw{gates[build_name]['receipt']['rawSHA256']}，同final421完整图稳定，不能代新浏览器/Mac/14日。

主41940 earned262.77067088031504/paid0，food1.0743647328613164/material2.1510779069859334；最终421另8 earned73.8405644012972/paid0、生产food/mat0。未跨6780payroll。原宽4185576恢复34对旧43/全低56对47，拒作最终游戏修复；宽future24只绑宽源，旧宽前16复现不新加canonical。20 narrowtests02 helperSHA与03不同单独范围；3tamper实际419回归PASS未冒final421重跑。原80/115低群与六零饱足零携粮/210夜闭/153有sale无后stored继续原实情；有限供给分配/夜间服务、原缺phaseFAIL、完整家族能源等38域、ART_FAIL/MacNOT_RUN/14日稳态仍未闭。Library/Git仅以后根实际回执另追加，不预写送达。

新私稿revision-10-narrow03-pre-egress（目录保原命名，文件真实明确最终source421）；全前稿/FAIL保字节，旧47headers/1786cells/38ID次序exact，全38PARTIAL，作者0Sim/step/tests/build/browser/GPU/共享src或memo写/ZIP/上传。\n''')
assert all(sha(Path(p)) == h for p,h in preserved.items())
assert all(sha(Path(p)) == h for p,h in prep.items())
assert all(sha(Path(p)) == v['sha256'] for p,v in inputs.items())
assert {p:sha(repo/p) for p in source421}==current
save('DRAFT-INPUT-SNAPSHOT.json',{'at':now(),'files':inputs,'sourceScopes':{'old417':old,'narrow419':source419,'final421':source421},'current421BeforeAfterExact':True,'priorDraftFilesExact':True,'preparationOriginalsExact':True,'authorSimStepTestsBuildBrowserGPUSharedWrites':0})
save('READONLY-PRESERVATION-ROOT26.json',{'at':now(),'old47Headers1786Cells38IDOrderExact':True,'all38PARTIAL':True,'protectedOriginal261PathsExact':True,'priorDraftHashes':preserved,'preparationHashes':prep,'current421BeforeAfterExact':True,'memoFullReadBeforeAfterExact':True,'checkpointFull621373PrefixExact':True,'checkpointTimestampStatementsPreserved':True,'memoAppendOnly':'root appends draft after full current memo; no replacement','sharedWrites':0,'oldSTOPWRITEWrites':0,'SimStepTestsBuildBrowserGPU':0,'ZIPUploads':0})
save('DRAFT-SHA256.json',{'at':now(),'status':'PRIVATE_ACTUAL_NARROW419_FINAL421_REPORT_READY_ALL38_PARTIAL_LIBRARY_GIT_PENDING','files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file() and p.name!='DRAFT-SHA256.json'}})
print(json.dumps({'status':'PRIVATE_REPORT_READY','output':str(out),'old1786CellsExact':True,'all38PARTIAL':True,'final421UniqueActualPassCases':103,'narrowRecovery5576':52,'oldRecovery5576':43,'twoSource48Recovery5608':58,'authorRuntimeCalls':0},ensure_ascii=False))

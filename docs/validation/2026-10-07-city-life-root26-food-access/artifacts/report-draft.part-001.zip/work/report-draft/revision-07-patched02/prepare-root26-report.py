from pathlib import Path
from datetime import datetime, timezone
import csv, hashlib, io, json

repo = Path('/workspace/yunshan')
work = Path('/workspace/yunshan-work/ROOT26-food-access-20261007-01')
native = Path('/tmp/ROOT26-food-access-20261007-01')
drafts = work / 'report-draft'
prior = drafts / 'revision-05-native04'
out = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
load = lambda p: json.loads(p.read_text())
prior_manifest = load(prior / 'DRAFT-SHA256.json')
assert all(sha(prior / n) == v['sha256'] for n, v in prior_manifest['files'].items())
preserved = {str(p): sha(p) for p in drafts.rglob('*') if p.is_file() and out not in p.parents}
inputs = [repo / 'AGENTS.md', repo / '提示词.md', repo / '开发备忘录.md', prior / 'DRAFT-SHA256.json', prior / 'ROOT26-ACTUAL-EVIDENCE-SUMMARY.json']

def write(name, value):
    p = out / name
    assert not p.exists(), 'Preserve existing artifact: ' + str(p)
    p.write_text(value, encoding='utf-8')

def save(name, value):
    write(name, json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def gate(name):
    g = work / (name + '-gate')
    r = load(g / 'receipt.json')
    b, a = load(g / 'inputs-before.json'), load(g / 'inputs-after.json')
    assert r['status'] == 'PASS' and r['exitCode'] == 0 and not r['timedOut']
    assert r['inputsStable'] and not r['activeDescendants'] and b == a and len(b) == r['inputCount']
    assert sha(g / 'raw.log') == r['rawSHA256']
    inputs.extend(g / n for n in ['receipt.json', 'inputs-before.json', 'inputs-after.json', 'raw.log'])
    return {'receipt': r, 'gateSeconds': (datetime.fromisoformat(r['endedAt']) - datetime.fromisoformat(r['startedAt'])).total_seconds(), 'frozenInputs': b}

gates = {name: gate(name) for name in ['typecheck01', 'patched01', 'patched02', 'recheck01']}
patched_source = gates['patched02']['frozenInputs']
assert len(patched_source) == 418 and patched_source == gates['patched01']['frozenInputs'] == gates['typecheck01']['frozenInputs']
old_source = load(work / 'native04-gate/inputs-before.json')
assert len(old_source) == 417
assert all(gates['recheck01']['frozenInputs'][p] == h for p, h in old_source.items())
body_differences = [p for p, h in old_source.items() if patched_source[p] != h]
assert set(body_differences) == {'src/simulation.ts', 'src/simulation/meal-route.ts'}
selected_current_before = {p: sha(repo / p) for p in patched_source}
current_differences = [{'path': p, 'patchedGateSHA256': h, 'currentSharedSHA256': selected_current_before[p]} for p, h in patched_source.items() if selected_current_before[p] != h]

results = {}
parts = {}
for name, count in [('patched01', 16), ('patched02', 40)]:
    p = native / name
    r = load(p / 'RESULT.json')
    plan = load(work / (name.upper() + '-PLAN.json'))
    manifest = load(p / 'TERMINAL-PARTS.json')
    assert r['status'] == 'ACTUAL_COMPLETED' and r['failure'] is None
    assert r['ordinaryCalls'] == r['returnedWindows'] == r['completedWindows'] == r['readers'] == count
    assert r['commands'] == r['injectedBodiesMoneyNeedsStockRolesTime'] == 0
    assert not r['captureFailures'] and not r['persistenceFailures'] and not r['conservationViolations']
    assert r['inputSaveSHA256'] == plan['inputFullSaveSHA256'] == 'ce40c74205c1126519e08c5d49e32d18f22cc4acf410d07f1fa4e709ff0337b8'
    assert plan['inputClock'] == 5416 and plan['inputTick'] == 2089
    assert sha(Path(plan['driver'])) == plan['driverSHA256'] and sha(Path(plan['observer'])) == plan['observerSHA256']
    assert sha(p / 'DRIVER.original.ts') == plan['driverSHA256'] and sha(p / 'OBSERVER.original.ts') == plan['observerSHA256']
    assert manifest['assembledSHA256'] == r['terminalSaveSHA256'] and manifest['rejectedMissingPart'].startswith('chunk:')
    assert manifest['extraSimulations'] == manifest['extraImports'] == manifest['extraSteps'] == 0
    results[name] = r
    parts[name] = {'physicalParts': len(manifest['manifest']), 'missingActualChunkRejected': manifest['rejectedMissingPart'], 'wholeSHA256': manifest['assembledSHA256']}
    inputs.extend([work / (name.upper() + '-PLAN.json'), p / 'RESULT.json', p / 'FRAMES.json', p / 'TERMINAL-PARTS.json', p / 'DRIVER.original.ts', p / 'OBSERVER.original.ts', Path(plan['driver']), Path(plan['observer'])])

r1, r2 = results['patched01'], results['patched02']
assert r1['clock'] == 5480 and r1['tick'] == 2105 and r1['constructors'] == r1['imports'] == 1
assert r2['clock'] == 5576 and r2['tick'] == 2129 and r2['constructors'] == r2['imports'] == 2
assert r2['shadowSteps'] == r2['shadowReturned'] == r2['shadowExact'] == 24
shadow_import = load(native / 'patched02/SHADOW-COLD-IMPORT.json')
assert shadow_import['inputSHA256'] == r1['terminalSaveSHA256'] and shadow_import['atPrimaryWindow'] == 16 and shadow_import['expectedFutureWindows'] == 24
assert shadow_import['bodyMoneyNeedsTimeStockInjections'] == 0
inputs.append(native / 'patched02/SHADOW-COLD-IMPORT.json')
shadow_files = sorted((native / 'patched02/shadow').glob('*.comparison.json'))
assert len(shadow_files) == 24
shadow_rows = []
for p in shadow_files:
    j = load(p)
    assert j['fullBytesExact'] and j['originalShadowError'] is None
    assert j['primary']['rawSHA256'] == j['cold']['rawSHA256'] and j['primary']['rawBytes'] == j['cold']['rawBytes']
    shadow_rows.append({'file': str(p), 'fullBytesExact': True, 'rawBytes': j['primary']['rawBytes'], 'rawSHA256': j['primary']['rawSHA256']})
    inputs.append(p)

frames1, frames2 = load(native / 'patched01/FRAMES.json'), load(native / 'patched02/FRAMES.json')
assert len(frames1) == 17 and len(frames2) == 41
repeat = load(work / 'PATCHED01-02-FIRST16-EXACT-REPLAY.json')
assert repeat['status'] == 'PASS' and repeat['first16RepeatedNotAdditionalCanonicalWindows'] and repeat['constructors'] == repeat['steps'] == 0
assert len(repeat['records']) == 17
for x, y, record in zip(frames1, frames2[:17], repeat['records']):
    for field, key in [('save', 'saveRawSHA256'), ('bus', 'busRawSHA256'), ('phaseCustody', 'custodyRawSHA256'), ('foodTrace', 'foodTraceRawSHA256')]:
        assert x[field]['rawSHA256'] == y[field]['rawSHA256'] == record[key]

c1 = load(work / 'PATCHED01-CONTROL-COMPARISON.json')
c2 = load(work / 'PATCHED02-CONTROL-COMPARISON.json')
assert c1['control']['initialCohort'] == c1['patched']['initialCohort'] == c2['control']['initialLow'] == c2['patched']['initialLow'] == 89
assert (c1['control']['cohortRecovered'], c1['patched']['cohortRecovered'], c1['control']['totalLow'], c1['patched']['totalLow']) == (17, 13, 72, 76)
assert (c2['control']['recoveredAtTerminal'], c2['patched']['recoveredAtTerminal'], c2['control']['totalLow'], c2['patched']['totalLow']) == (43, 34, 47, 56)
assert not c1['control']['tiersUnchanged'] and not c1['patched']['tiersUnchanged']
assert not c1['control']['279Sales'] and not c2['control']['279Sales']
assert c1['patched']['279Sales'][0]['clock'] == 5432 and c1['patched']['279Sales'][0]['event']['quantity'] == 1
assert c1['patched']['279Sales'][0]['event']['amount'] == 17.966614100760214
assert [e['clock'] for e in c2['patched']['279Sales']] == [5432, 5544]
terminal = work / 'PATCHED02-TERMINAL.original.save.json'
full = load(terminal)
assert sha(terminal) == r2['terminalSaveSHA256']
assert len(full['state']['citizens']) == 616 and all(full['state']['extension']['actorProfiles'][a['id']]['alive'] for a in full['state']['citizens'])
assert full['runtime']['payrollAt'] == 6780 and r1['actualCounts']['npcPaid'] == r2['actualCounts']['npcPaid'] == 0
inputs.extend([work / 'PATCHED01-02-FIRST16-EXACT-REPLAY.json', work / 'PATCHED01-CONTROL-COMPARISON.json', work / 'PATCHED02-CONTROL-COMPARISON.json', terminal, work / 'CONTROL-5416.original.save.json'])
records = {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in inputs}

summary = {'status': 'READONLY_ACTUAL_TYPECHECK_PATCHED01_PATCHED02_BOUND', 'original80': load(prior / 'ROOT26-ACTUAL-EVIDENCE-SUMMARY.json'), 'gates': {n: {k:v for k,v in g.items() if k != 'frozenInputs'} for n,g in gates.items()}, 'patchedSourceInputCount': 418, 'bodyDifferencesFromHistorical417': body_differences, 'patched01': r1, 'patched02': r2, 'parts': parts, 'first16Repeat': repeat, 'shadowColdImport': shadow_import, 'shadow24OriginalComparisonRecords': shadow_rows, 'comparisonAt5480': c1, 'comparisonAt5576': c2, 'aliveNPCsAtPatched5576': 616, 'payrollAt': 6780, 'noSingle116Or80ContinuationClaim': True, 'shadowCustodyScope': 'Primary40 has400 observer phases; shadow24 is full whole-save equality, no separate shadow custody observer captured.', 'currentSharedVsPatchedGate': current_differences, 'future': 'Tamper regression/tests/latest auditor version/Library/Git gates PENDING unless root separately supplies actual receipts; food supply/night/14day still not solved.'}
save('ROOT26-ACTUAL-EVIDENCE-SUMMARY.json', summary)
save('CURRENT-SHARED-READONLY-SNAPSHOT.json', {'at': datetime.now(timezone.utc).isoformat(), 'selected418CurrentSourceSHA256': selected_current_before, 'historicalPatched418SourceSHA256': patched_source, 'currentVsActualPatchedGate': current_differences, 'note': 'Count418 does not establish identical source graph; current auditor changes are not covered by old audit/replay gates.'})

baseline = repo / 'docs/validation/2026-10-07-city-life-root24-25/REQUIREMENTS-38.csv'
old_rows = list(csv.reader(baseline.open(encoding='utf-8-sig')))
prior_rows = list(csv.reader((prior / 'MATRIX-38-ROOT26-DRAFT.csv').open(encoding='utf-8-sig')))
assert len(old_rows) == 39 and len(old_rows[0]) == 47 and len(prior_rows[0]) == 52
assert prior_rows[0][:47] == old_rows[0] and [r[:47] for r in prior_rows[1:]] == old_rows[1:]
rows = [r.copy() for r in prior_rows]
byid = {r[0]:r for r in rows[1:]}
def update(ident, plan=None, implementation=None, run=None, verify=None, remaining=None):
    r = byid[ident]
    for i,v in enumerate([plan, implementation, run, verify, remaining], 47):
        if v is not None: r[i] = v
old80 = '历史417源native01–04四cold段80窗5340→5660，86/115真实sale恢复/29仍低，全城低30/210shop终点全closed；新源另从5416原ce40档做独立对照重放，不接80时间线。'
newrun = '当前两MOD同418源typecheck01 PASS17.447651s、patched01 cold16 PASS94.171033s、patched02 primary40+shadow24 PASS285.857677s/2构造2import/40reader；5416→5576，0命令注入/失败，first16完整save/bus/custody/trace SHA重放exact、后24完整hot/cold save逐窗bytesexact。'
negative = '279于5432真sale qty1/cost17.966614100760214，5544再qty2；旧同5576无sale。但原5416低89群5480恢复旧17/新13、5576旧43/新34，全城低5576旧47/新56，未解决全城供给。'
impl = 'root仅meal-route.ts/simulation.ts加nearby-food-v1、age>=6、food<1、原elapsed投影satiety<30时正常people frequency1；不写tier/focus，不补粮钱/夜店，累计elapsed/真实移动/权限/工资上限/legacy沿原流程。'
update('FOOD-01', plan='保完整有限食品目标；旧80原件与pure重检保，当前窄频率修复从5416原checkpoint实际重放16/40并24hot-cold，具名与全局正反均核。', implementation=impl, run=old80+' '+newrun+' '+negative, verify='PARTIAL；narrowfix防附近64min错失已在279实际成立；局部改善不等89群或全城改善，finite供给/夜间关闭仍缺。', remaining='继续真实夜间有限食品经营与供应分配，保产权/工资/钱库存/营业权限；下个原payroll6780、长期14日稳态、当前auditor新版/篡改测试/Library/Git实际门仍待。')
update('SYS-01', implementation='旧80源417/纯工具旧417+script418/两MOD新418分别绑定；旧World291与当前fresh默认v8保持，未以旧save CPU对照代新普通URL全部产品验收。', run=newrun, verify='PARTIAL；普通当前源有限门通过，完整3D/2D/文字/宿主与fresh v8全流程仍按原域目标未完成。')
update('MAP-02', implementation=impl+' 不改原地图/几何/路网。', run='前三64原417诊断212目标变化203旧空库存/9旧店开且有货，原42边界无unreachable/physicalWaiting/roadWaiting且处理moving有位移；原route-static-review及263file稳定回执已绑定。 '+negative, verify='PARTIAL；原诊断与279新真实成交范围清楚，不等所有路线通达或完整路由/供给修复。', remaining='其余长路、实际供货竞争、夜间餐与动态几何权限仍需本域实证；不从参考折线路线推物理可达。')
update('SHOP-01', implementation=impl, run=negative+' 原80终5660全部210shop open=false；新5576不能冒已验夜间终点。', verify='PARTIAL；近端成交改善与全城恢复更少均保，完整供需/夜间服务/租买经营与重开仍欠。')
update('LIFE-01', implementation=impl, run=negative, verify='PARTIAL；NPC原普通CPU对照非玩家第一人称新完整生活；279有餐不等家居/夜间日常全部闭环。')
update('LIFE-03', run='新patched5576基线616NPC逐IDalive，89群34恢复/全城低56，旧同clock43恢复/低47。原80另末6hunger0food0与29原低保持事实。', verify='PARTIAL；不把存活、钱包足或279饱足100视作全城营养达标。')
update('SAVE-01', implementation='当前两MOD418 source同档cold即刻export exact；future私有driver第一次16复现另patched01完整save/bus/custody/trace SHA，之后主hot24/新coldshadow24逐窗fullbytesexact；shadow没有独立custody observer。', run=newrun+' patched01 129/patch02 131真实part组装whole exact，各缺chunk拒，分区未加额外Sim/import/step。末7b1fef33…add3c1。', verify='PARTIAL；新源同源24future保存一致实际通过，非全部旧save/正常UIreload/崩溃恢复/独立116原时间线。', remaining='原资源上限不放宽；旧FAIL/缺4phase保持；最新auditor改动与3篡改测试实际门另待。')
update('POL-02', run='新patched02 primary40 earned262.6704962838238/paid0，food1.0743647328613164/material2.1510779069859334，197柜台/15stored；首16已包含，不与patched01再相加。未跨6780 payroll；每主窗十phase守恒通过。', verify='PARTIAL；实际原工资guard未放宽，未跨支付窗，不能据同源future24/paid0称下一工资/长期财政闭合。')
update('TRA-01', implementation=impl+' 原物流/FIFO/owner/货主与库存未扩特权。', run=negative, verify='PARTIAL；真实279购餐不代完整订单/货运到账/有限夜间零售分配。')
update('PER-01', implementation='仅选择正常frequency1；原tier classification仍每8tick按实际body/focus自然重分，control/patched tiersUnchanged均false，非fix写tier或人工focus注入。', run=newrun, verify='PARTIAL；body处理负载可能增加，本次有限运行不是benchmark/统计流式/GL/Mac/性能达标。', remaining='原速度/预算/实体/分级契约保；当前饥饿actor负载与实际平台性能、14日稳态均未完整验。')
update('VAL-01', implementation='新实际closed typecheck/两patched来源、原80/pure recheck来源分别绑定；保所有旧稿及rev03真实准备守卫FAIL，不替换旧失败。', run=old80+' '+newrun, verify='PARTIAL；本报告只认已闭实际门，当前auditor再次改变不能自动继承旧418图PASS；38域与ART_FAIL/MacNOT_RUN保持。', remaining='篡改tests/最新pure工具门/Library本stageGit以root新回执另追加；完整14日稳态/其他域未由食品关闭。')
assert rows[0][:47] == old_rows[0] and [r[:47] for r in rows[1:]] == old_rows[1:]
assert all(r[50].startswith('PARTIAL') for r in rows[1:])
def write_csv(name, table):
    b=io.StringIO(newline='');csv.writer(b,lineterminator='\n').writerows(table);write(name,'\ufeff'+b.getvalue())
write_csv('MATRIX-38-ROOT26-DRAFT.csv', rows)
write_csv('MATRIX-ROOT26-APPEND-ONLY.csv', [['id']+rows[0][47:], *[[r[0]]+r[47:] for r in rows[1:]]])
save('MATRIX-PRESERVATION-ROOT26.json', {'status':'PASS_ORIGINAL_1786_DATA_CELLS_AND_47_HEADERS_EXACT', 'baseline':str(baseline),'baselineSHA256':sha(baseline),'rows':38,'oldColumns':47,'oldDataCells':1786,'newColumns':52,'oldHeadersExact':True,'oldIDsOrderExact':True,'all38Partial':True,'priorRevision05Preserved':True,'draftSHA256':sha(out/'MATRIX-38-ROOT26-DRAFT.csv')})

report=f'''# ROOT26：近端求餐窄修复与同源保存验证（新实际修订稿）

当前源有限验证实际通过，279较及时购餐的具名问题已改善；全城有限供给与夜间供餐仍未解决。旧80窗、旧报告及其FAIL原件全部保留，新运行从5416原档另作对照，不接旧80时间线。全38域仍PARTIAL，ART_FAIL/MacNOT_RUN及14日稳态NOT_RUN保持。

## 当前源实际门

新源仅`src/simulation/meal-route.ts`、`src/simulation.ts`两生产文件与旧417源不同；`nearby-food-v1`、age>=6、food<1且原elapsed投影饱足<30时请求正常people frequency1。沿原累计elapsed、身体移动、访问权限、营业/库存/钱包和出勤工资上限；legacy无此policy沿原频率。没有tier/focus写入、补钱粮、强活动或开夜店。

| 实际门 | 418输入来源 | driver / gate秒 | 原raw SHA |
|---|---|---:|---|
| typecheck01 | 两MOD当前业务图 | — / {gates['typecheck01']['gateSeconds']:.6f} | {gates['typecheck01']['receipt']['rawSHA256']} |
| patched01 | 同一两MOD图 | {r1['elapsedSeconds']} / {gates['patched01']['gateSeconds']:.6f} | {gates['patched01']['receipt']['rawSHA256']} |
| patched02 | 与patched01同图 | {r2['elapsedSeconds']} / {gates['patched02']['gateSeconds']:.6f} | {gates['patched02']['receipt']['rawSHA256']} |

三门均真实closed PASS、exit0、inputsBefore=After/418stable、activeDescendants=[]。当前共享pure auditor另有后续变化，详[当前快照](CURRENT-SHARED-READONLY-SNAPSHOT.json)；函数文件数量418不代表来源字节相同，不能把旧pure门自动延伸至最新脚本。

## 对照正反结果

完整原checkpoint SHA `ce40c74205c1126519e08c5d49e32d18f22cc4acf410d07f1fa4e709ff0337b8`，clock5416/tick2089、speed16/unpaused、616NPC、89低饱足居民；不是旧115群。patched01一构造一import/16普通窗，至5480/tick2105，末SHA `{r1['terminalSaveSHA256']}`；0命令/需求钱粮身体身份库存时间注入，16reader、160主phase守恒，捕获/持久化/守恒失败空，129真part组装whole exact并缺真chunk拒。

279在5432真实west-b41 sale quantity1/cost17.966614100760214；旧同clock5480仍未sale。新终饱足63.7对旧11.7，钱包真实付款。此例支持16分钟附近可成餐而旧64分钟延迟错失，但不是全城救助通过。

| 同一89低群/全城口径 | 旧对照5480 | 新5480 | 旧对照5576 | 新5576 |
|---|---:|---:|---:|---:|
| 原群有sale且恢复人数 | 17 | 13 | 43 | 34 |
| 全城低饱足人数 | 72 | 76 | 47 | 56 |

新运行两端恢复都少于旧对照，全城低更多，必须保这项负结果。新5576中279于5544再次真实sale quantity2/cost36.00312070430272，末shopping/饱足100/food1；旧5576仍未sale。两边tier变化标志均false是原自然classify随body位移每8tick重分，不是fix写tier。比较原件：[5480](../../PATCHED01-CONTROL-COMPARISON.json)、[5576](../../PATCHED02-CONTROL-COMPARISON.json)。

## 主热24与冷影子24

patched02从同一5416原档另构造/导入，主40窗至5576/tick2129。前16与patched01的17份输入/窗save、ALLbus、custody、foodTrace rawSHA逐项相同；[重放原件](../../PATCHED01-02-FIRST16-EXACT-REPLAY.json)已核，重复16不加到新canonical时间线上。在第16窗原9fb…bec7 fullsave再构造一个shadow/cold import，即刻export bytesexact；之后主hot24与冷shadow24逐窗完整save字节相同，24 returned/exact，2构造/2import共64物理step，40reader。末完整SHA `{r2['terminalSaveSHA256']}`。

主40窗有400真实custody phase；shadow24只保存并比较完整字节，没有另挂独立custody observer，不说影子另有240份捕获阶段。每主窗原cash/food/debt/fiscal守恒通过，最大残差为 {r2['maximumResidual']['cash']} / {r2['maximumResidual']['food']} / {r2['maximumResidual']['debt']} / {r2['maximumResidual']['fiscal']}。131真实part组装末whole exact并拒缺chunk，分区额外Sim/import/step0；两构造来自主/影子验证，不把分区额外0误写全场只有1构造。

这是真同源future24保存验证，不是旧80接续、单fresh116或修复后重跑原全部80窗。只读作者核原closed门、RESULT、FIRST16 SHA记录与24comparison小原件，没有重跑Sim/解压全部帧/测试或把派生记录当新增观察。

## 钱粮与仍缺内容

patched02主40共197柜台餐/15stored，产生food1.0743647328613164/material2.1510779069859334，earned262.6704962838238/paid0；首16已包含，不将patched01再累加。616基线NPC逐IDalive，原payrollAt6780尚未跨，不能以paid0和守恒称下一工资/长期财政通过。

原417四cold段80窗5340→5660仍保：86/115真实sale恢复、29原低+1新低、393柜台/23stored、210shop全部closed、6原cohort hunger0food0；153有5600 sale而无后续stored witness。纯recheck01是旧417+script的另一418图，31.703037s actualPASS、80 fullsave/800phase/850双SHA/0新Sim/import/step/nativeReader；不与当前业务418混用。前三64窗route-static-review的212目标变化203旧空库存/9旧开且有货与长路/延迟原因仍是该子集记录，不说全部身体通路已证明。

窄fix没有制造粮、预约库存或夜间营业，有限供给竞争与全城分配仍缺，夜间服务必须守原owner/身份许可、钱/成本/库存、营业劳动、工资债和时间规则。下一工资、14日现金财政供粮稳态、正常第一人称玩家/新普通URL与其他38域完整流程继续未验。3篡改回归/tests、最新auditor、Library、本stageGit提交推送仍待root实际新门/回执，不预写送达或PASS。

[38×52矩阵](MATRIX-38-ROOT26-DRAFT.csv)仅修订新ROOT26五列，旧47headers/1786cells/38IDs顺序exact，全38PARTIAL；[保全](MATRIX-PRESERVATION-ROOT26.json)。本作者0Sim/step/tests/build/browser/GPU/共享写/ZIP/上传；仅新私有文稿。revision05与所有前稿及rev03真实身份守卫准备FAIL原件均原字节保留。
'''
write('ROOT26-供粮访问阶段报告-DRAFT.md', report)
write('MEMO-APPEND-ROOT26-DRAFT.md', f'''\n\n### ROOT26 当前近端求餐窄修复实际通过，同源future24完整save相同；全城供给仍PARTIAL（2026-10-07，私有追加草稿）

root两MOD meal-route.ts/simulation.ts仅nearby-food-v1/age>=6/food<1/原elapsed投影satiety<30请求正常people frequency1，沿原tier自然classify、完整elapsed/移动/ACL/库存营业钱包/工资上限/legacy。当前图418 typecheck01实际PASS17.447651s；patched01同图cold16 PASS94.171033s，5416 ce40…37b8→5480/2105/9fb…bec7，0注入，129part exact/缺chunk拒。2795432真sale qty1/cost17.966614100760214而旧5480无sale；但原5416低89群恢复旧17/新13，全城低旧72/新76，不冒全局改善。两边tiersUnchanged=false为原classify随真实位移变化，fix不写tier/focus。

patched02同418源closedPASS285.857677s/raw9894bcad…eea7，driver284.73s，另从5416主40至5576/tick2129/7b1fef331d28eb8cdc374dd37ca2c6e8d350909ec752f296a04491b052add3c1。前16完整save/bus/custody/trace rawSHA同patched01，重复不新增canonical；第16末coldshadow再导入9fb档，后主hot24/影子24完整save逐窗bytesexact，2Sim/2import/64物理step/40reader，主400phase守恒，shadow无另custody observer；131真实part whole exact/缺chunk拒、分区额外Sim0。非原80续或单原116timeline。5576低89群旧43恢复/新34，全低旧47/新56；279新5432+5544两真sale，旧同末无sale，近端16-vs64错失局部解决不等全城供给。

主40柜台197/stored15、food1.0743647328613164/material2.1510779069859334、earned262.6704962838238/paid0，616NPC alive、payrollAt6780未跨，首16不重复加总。旧80/原115群/210夜间closed/6hunger0food0/153有sale无stored仍保；旧417+pure工具另一418图recheck01原80/800phase/850双SHA actualPASS与当前两MOD门区分。当前pure auditor又变SHA不能自动继承旧门；篡改tests/新工具门/Library/Git待root实际回执。有限供给分配/夜间服务/工资/14日稳态、ART_FAIL/MacNOT_RUN与38PARTIAL不由窄fix关闭。

新私稿report-draft/revision-07-patched02，旧revision05及所有前稿/准备FAIL字节保；旧47headers/1786cells/38IDs次序exact，全38PARTIAL。作者0Sim/step/tests/build/browser/GPU/共享memo/src写/ZIP/上传；容器私稿不是Library已交付。\n''')
assert all(sha(Path(p)) == h for p,h in preserved.items())
assert all(sha(Path(p)) == v['sha256'] for p,v in records.items())
selected_current_after = {p: sha(repo / p) for p in selected_current_before}
assert selected_current_after == selected_current_before
save('DRAFT-INPUT-SNAPSHOT.json', {'at':datetime.now(timezone.utc).isoformat(),'files':records,'sourceScopes':{'oldOrdinary417':old_source,'actualPatched418':patched_source,'currentVsPatched':current_differences},'boundCurrent418SelectedBeforeAfterExact':True,'allPriorDraftFilesBeforeAfterExact':True,'authorSimStepTestsBuildBrowserGPUSharedWrites':0})
save('READONLY-PRESERVATION-ROOT26.json', {'at':datetime.now(timezone.utc).isoformat(),'old47Headers1786CellsExact':True,'all38Partial':True,'allPriorDraftFilesUnchanged':True,'priorDraftHashes':preserved,'selectedCurrent418SourceReadBeforeAfterExact':True,'historicalGateGraphEqualsCurrent':not current_differences,'sharedWrites':0,'oldSTOPWRITEWrites':0,'SimStepTestsBuildBrowserGPU':0,'uploadsZIP':0})
save('DRAFT-SHA256.json', {'at':datetime.now(timezone.utc).isoformat(),'status':'PRIVATE_ACTUAL_PATCHED02_DRAFT_CURRENT_OTHER_TESTS_LIBRARY_GIT_PENDING','files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file() and p.name != 'DRAFT-SHA256.json'}})
print(json.dumps({'status':'PRIVATE_PATCHED02_REPORT_READY','output':str(out),'oldCellsExact':1786,'rows':38,'columns':52,'allPartial':True,'patched01':16,'patched02Main':40,'shadow':24,'newGlobalRecoveredAt5576':34,'oldGlobalRecoveredAt5576':43,'currentVsPatchedSource':current_differences},ensure_ascii=False,indent=2))

from pathlib import Path
import csv, io, json, hashlib
from datetime import datetime, timezone

repo=Path('/workspace/yunshan')
work=Path('/workspace/yunshan-work/ROOT26-food-access-20261007-01')
out=work/'report-draft'
prior=repo/'docs/validation/2026-10-07-city-life-root24-25'
native=Path('/tmp/ROOT26-food-access-20261007-01')
baseline=prior/'REQUIREMENTS-38.csv'
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(name,value):
    path=out/name
    if path.exists():raise RuntimeError('Preserve existing draft; use a new revision filename: '+str(path))
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def text(name,value):
    path=out/name
    if path.exists():raise RuntimeError('Preserve existing draft: '+str(path))
    path.write_text(value,encoding='utf-8')
def jsonfile(path):return json.loads(path.read_text(encoding='utf-8'))
baselineBytes=baseline.read_bytes()
rows=list(csv.reader(io.StringIO(baselineBytes.decode('utf-8-sig'),newline='')))
headers=rows[0];data=rows[1:]
assert len(headers)==47 and len(data)==38 and all(len(r)==47 for r in data)
appendOnly=list(csv.reader(io.StringIO((prior/'MATRIX-ROOT24-25-APPEND-ONLY.csv').read_text(encoding='utf-8-sig'),newline='')))
assert len(appendOnly)==39 and len(appendOnly[0])==11
for row,app in zip(data,appendOnly[1:]):
    assert row[0]==app[0]
    assert all(row[headers.index(k)]==v for k,v in zip(appendOnly[0][1:],app[1:]))
bound=[];inputs=[baseline,prior/'MATRIX-ROOT24-25-APPEND-ONLY.csv',prior/'HANDOFF.md',prior/'STOPWRITE.json',repo/'AGENTS.md',repo/'提示词.md',repo/'开发备忘录.md',work/'food-access-actual.ts',work/'custody-observer.ts']
for run in ['native01','native02','native03']:
    gate=work/(run+'-gate')
    receipt=jsonfile(gate/'receipt.json');result=jsonfile(native/run/'RESULT.json');plan=jsonfile(work/(run.upper()+'-PLAN.json'));frames=jsonfile(native/run/'FRAMES.json');parts=jsonfile(native/run/'TERMINAL-PARTS.json')
    before=jsonfile(gate/'inputs-before.json');after=jsonfile(gate/'inputs-after.json')
    assert receipt['status']=='PASS' and receipt['exitCode']==0 and receipt['inputsStable'] and receipt['activeDescendants']==[] and receipt['inputCount']==417
    assert before==after and len(before)==417
    assert result['status']=='ACTUAL_COMPLETED' and result['failure'] is None
    assert result['ordinaryCalls']==result['returnedWindows']==result['completedWindows']==result['readers']==plan['maximumSuccessfulWindows']
    assert result['commands']==result['injectedBodiesMoneyNeedsStockRolesTime']==0
    assert result['captureFailures']==result['persistenceFailures']==result['conservationViolations']==[]
    assert result['inputSaveSHA256']==plan['inputFullSaveSHA256']
    assert parts['assembledSHA256']==result['terminalSaveSHA256']
    assert parts['extraSimulations']==parts['extraImports']==parts['extraSteps']==0
    assert len(frames)==result['completedWindows']+1
    assert sha((gate/'raw.log').read_bytes())==receipt['rawSHA256']
    assert sha((native/run/'DRIVER.original.ts').read_bytes())==plan['driverSHA256']
    assert sha((native/run/'OBSERVER.original.ts').read_bytes())==plan['observerSHA256']
    inputs.extend([gate/'receipt.json',gate/'inputs-before.json',gate/'inputs-after.json',native/run/'RESULT.json',native/run/'FRAMES.json',native/run/'TERMINAL-PARTS.json',native/run/'PLAN.original.json',work/(run.upper()+'-PLAN.json'),work/(run.upper()+'-COHORT-ANALYSIS.json')])
    bound.append({'name':run,'receipt':receipt,'result':result,'planSummary':{k:v for k,v in plan.items() if k not in ['actorIds','shopIds']},'physicalPartCount':len(parts['manifest']),'rejectedMissingPhysicalPart':parts['rejectedMissingPart'],'frameCount':len(frames),'frozenInputs':before})
assert bound[1]['result']['inputSaveSHA256']==bound[0]['result']['terminalSaveSHA256']
assert bound[2]['result']['inputSaveSHA256']==bound[1]['result']['terminalSaveSHA256']
assert bound[0]['frozenInputs']==bound[1]['frozenInputs']==bound[2]['frozenInputs']
sharedBefore={p:sha((repo/p).read_bytes()) for p in bound[2]['frozenInputs']}
assert sharedBefore==bound[2]['frozenInputs']
inputRecords={str(p):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in inputs}
save('DRAFT-INPUT-SNAPSHOT.json',{'at':datetime.now(timezone.utc).isoformat(),'kind':'Read-only document inputs, bound to actual closed ROOT26 receipts','files':inputRecords,'functionalInputCount':417,'actualSharedMatchesNativeFrozenInputs':True,'draftAuthorExecution':{'Simulation':0,'step':0,'tests':0,'types':0,'build':0,'browser':0,'GPU':0,'sharedWrites':0,'Library':0}})
totals={k:sum(b['result']['actualCounts'][k] for b in bound) for k in bound[0]['result']['actualCounts']}
maximum={k:max(b['result']['maximumResidual'][k] for b in bound) for k in bound[0]['result']['maximumResidual']}
cohort01=jsonfile(work/'NATIVE01-COHORT-ANALYSIS.json');cohort02=jsonfile(work/'NATIVE02-COHORT-ANALYSIS.json');cohort=jsonfile(work/'NATIVE03-COHORT-ANALYSIS.json')
assert cohort['cohortRecovered']==cohort['uniqueCohortActuallyAte']==73
assert cohort['cohortStillLow']==42 and cohort['totalLow']==43 and cohort['states']=={'moving':42}
assert cohort['initialLow']==115 and cohort['allSaleCount']==totals['counterMeals']==355 and cohort['allStoredMeals']==totals['storedMeals']==20
assert cohort['finalSaveSHA256']==bound[-1]['result']['terminalSaveSHA256']
assert totals['npcPaid']==totals['publicNpcPaid']==totals['privateNpcPaid']==totals['npcPaymentCount']==0
foodSummary='原115低饱足居民中23→63→73人有具名sale恢复；终点原42仍低且全moving，全城低43=原42+新1；355柜台餐+20随身餐。450/457/489真sale后stored-meal；153仍moving/food0、无sale。'
runSummary='native01/02/03实际PASS，各417输入stable/active[]；16+32+16=64完整ordinary/readers，3cold段/3Sim/3imports；clock5340→5596/tick2070→2134，零命令/零钱粮身体需求身份时间注入。'
fundSummary=f"新earned{totals['npcEarned']}、NPC paid0；粮产{totals['foodProduced']}、材料产{totals['materialProduced']}；最大cash/food/debt/fiscal残差{maximum['cash']}/{maximum['food']}/{maximum['debt']}/{maximum['fiscal']}。"
saveSummary='终档130/127/129真实地理part分别落盘readback/assemble与各whole SHA exact；每段缺真实chunk拒，0额外Sim/import/step。未做本阶段未来24/正常UI重载、崩溃恢复或新地图保存。'
newheaders=['ROOT26计划','ROOT26实现','ROOT26运行','ROOT26验证','ROOT26剩余']
commonPlan='保本域原完整目标；本轮仅从旧World291/6e481真实终档，冷续16+32+16普通窗定位供粮与原钱粮来源，不改世界或居民。'
commonImpl='本域业务/源码无新增；新私有食品trace driver和custody observer只捕获原普通十阶段、fullsave、ALLbus和真实part。'
commonRun='本域独立完整端到端NOT_RUN；本轮食品64窗不能代本域自然全流程、长期或GUI验证。'
commonVerify='PARTIAL；无本域新增完成结论，既有局部PASS/FAIL继续按原输入和范围保留。'
special={
 'SYS-01':(commonPlan,'表现/业务权威未换；同一旧World与原原生Simulation只读观察，当前新fresh默认v8不被本次旧v6续档替代。',runSummary,'PARTIAL；完整3D/2D/文字产品及宿主仍按原要求未完成。','未新增2D/文字/Worker或UI验收；新门不代ROOT25普通fresh/39交互。'),
 'MAP-02':(commonPlan,commonImpl,'记录原115人真实重选/行动/补货/柜台餐来源；当前路线原因仅待核，不从坐标或moving直接判定不可达。','PARTIAL；实际保存位置/目标可作诊断输入，欧氏近店不等原图/body最短合法路径。','42仍低的原route/余程/目标售点、合法评分/调度/库存与真实身体阻断待定位；不得造原因或补粮。'),
 'POL-02':(commonPlan,commonImpl,runSummary+' '+fundSummary,'PARTIAL；本17:00–21:16窗口NPC支付0、只新earned，守恒通过不等财政可持续/所有预算服务通过。','下一真实工资窗口、有限公共/私营账户支付与债、原医疗cap14和日常审批仍待验。'),
 'SHOP-01':(commonPlan,commonImpl,foodSummary,'PARTIAL；真实柜台成交是有限普通窗口，不等自然买租重开、行业更替、全部市场供需稳态。','42原居民仍低；终点目标店/来源库存有限，困难退出/新租户及原经营权完整链仍欠。'),
 'FOOD-01':(commonPlan,commonImpl,runSummary+' '+foodSummary+' '+fundSummary,'PARTIAL；3有限原生门各PASS，73/115恢复非115全恢复；未14日/长期供粮财政稳态。','终点42全moving；citizen-153未成交，路线真实原因待核/产品sourcefix未实施；三目的店summit-b8(17)/west-b41(12)/east-b5(13)，新1低居民另追；有限补货/下一工资与持续供给待验。'),
 'TRA-01':(commonPlan,commonImpl,'native01原east区有两笔cargo-arrived各28，nodeId=east-b37-door；货主为shop-core-dock-building与shop-river-b57，不把nodeId当指定零售库存或已发给居民。'+foodSummary,'PARTIAL；原有物流与柜台原events可追踪，未新增路网/具名订单规则或全链覆盖；供应商到账须原账户/lots/采购来源核。','货运进入地区FIFO与零售采购/售出成本结算须区分；无所有供应商货款/跨区调度和长期供需完成claim。'),
 'LIFE-01':(commonPlan,commonImpl,foodSummary,'PARTIAL；为NPC原生CPU有限吃饭窗口，玩家命令/餐均0；不是第一人称住房/厨卫/办公/家具完整日常。','原完整第一人称生活与家居仍欠；本阶段无新浏览器/原生UI动作。'),
 'LIFE-03':(commonPlan,commonImpl,'饱足是hunger，高为饱；原低115→终42未恢复/全城43低。616NPC逐IDalive，actorProfiles alive617含player；不是617NPC。','PARTIAL；未改变需求/健康阈值，未把走路标签或有钱当吃饭证据；营养心理与自然医卫全链未验。','42原低及1新低仍需真实餐与后续健康；复杂营养/心理/多主体长期反馈仍欠。'),
 'PER-01':(commonPlan,'只新增私有有限原件捕获；每段原native预算/物理证据cap与下步reserve严格保留，未改分级频率/速度或实体数。',runSummary,'PARTIAL；各gate有时长/预算与原件，但本作者无性能实验；不能据此称真统计区/流式性能或Mac达标。','聚合↔个体资金身份恢复/真实流式DB/规模与Mac性能仍欠，未扩大benchmark。'),
 'SAVE-01':(commonPlan,commonImpl,runSummary+' '+saveSummary,'PARTIAL；3段64完整whole reader与3组物理parts限定PASS；旧四缺phase/旧FAIL不回填，不冒单fresh64或360。','未来24/正常UI重载/跨地图和WorldPatch/崩溃恢复等本阶段NOT_RUN；原8M/资源界不放宽。'),
 'VAL-01':(commonPlan,'新本stage私有报告+矩阵append；旧47headers/1786cells/38IDs次序保，旧STOPWRITE目录无写入。',runSummary+' '+foodSummary,'PARTIAL；所有新事实绑定三RESULT/gate/原part/分析，不预写路线原因或产品修复PASS。','ART_FAIL、MacNOT_RUN、旧ROOT24缺4phase/FAIL、38完整目标PARTIAL/长期稳态NOT_RUN保持；本stageLibrary/commit/push待root实际回执。'),
}
appendRows=[]
for row in data:
    ident=row[0]
    values=special.get(ident,(commonPlan,commonImpl,commonRun,commonVerify,'本域原具体剩余继续；本stage无独立完成门。'+row[headers.index('latest_remaining')]))
    assert len(values)==5 and values[3].startswith('PARTIAL')
    appendRows.append([ident,*values])
def writecsv(name,table):
    buf=io.StringIO(newline='');writer=csv.writer(buf,lineterminator='\n');writer.writerows(table);text(name,'\ufeff'+buf.getvalue())
writecsv('MATRIX-38-ROOT26-DRAFT.csv',[headers+newheaders,*[old+new[1:] for old,new in zip(data,appendRows)]])
writecsv('MATRIX-ROOT26-APPEND-ONLY.csv',[['id']+newheaders,*appendRows])
newrows=list(csv.reader(io.StringIO((out/'MATRIX-38-ROOT26-DRAFT.csv').read_text(encoding='utf-8-sig'),newline='')))
assert newrows[0][:47]==headers and [r[:47] for r in newrows[1:]]==data
assert [r[0] for r in newrows[1:]]==[r[0] for r in data]
assert all(r[50].startswith('PARTIAL') for r in newrows[1:])
save('MATRIX-PRESERVATION-ROOT26.json',{'status':'PASS_ORIGINAL_1786_DATA_CELLS_AND_47_HEADERS_EXACT','privateDraftOnly':True,'baseline':str(baseline),'baselineSHA256':sha(baselineBytes),'baselineRows':38,'baselineColumns':47,'preservedOriginalDataCells':1786,'preservedOriginalHeaders':47,'originalIDsAndOrderExact':True,'draftRows':38,'draftColumns':52,'addedColumns':newheaders,'all38DomainsRemainPartial':True,'draftSHA256':sha((out/'MATRIX-38-ROOT26-DRAFT.csv').read_bytes()),'historicalCells':'Historical ROOT18–25 RUNNING/NOT_RUN/FAIL values retained verbatim; no retrospective rewrite.'})
summary={'scope':'ROOT26 new private documents only; immutable actual receipts, no simulation by this author','worldSHA256':bound[0]['planSummary']['inputWorldSHA256'],'startingSaveSHA256':bound[0]['result']['inputSaveSHA256'],'terminalSaveSHA256':bound[-1]['result']['terminalSaveSHA256'],'clockStart':5340,'clockEnd':5596,'tickStart':2070,'tickEnd':2134,'canonicalNewOrdinaryWindows':64,'coldSegments':3,'constructors':3,'imports':3,'readers':64,'commands':0,'injectedBodiesMoneyNeedsStockRolesTime':0,'actualCountsTotals':totals,'maximumResidualAcrossRuns':maximum,'physicalParts':[{'run':b['name'],'parts':b['physicalPartCount'],'missingPartRejected':b['rejectedMissingPhysicalPart']} for b in bound],'cohortProgress':[{'clock':5404,'originalRecovered':len(cohort01['initialRecovered']),'originalStillLow':cohort01['remainingInitialLow'],'totalLow':cohort01['totalLow']},{'clock':5532,'originalRecovered':cohort02['cohortRecovered'],'originalStillLow':cohort02['cohortStillLow'],'totalLow':cohort02['totalLow']},{'clock':5596,'originalRecovered':73,'originalStillLow':42,'totalLow':43}],'cohortSaleEvents':97,'uniqueCohortActuallyAte':73,'remainingStates':cohort['states'],'remainingDestinations':cohort['destinations'],'allAliveProfilesReportedByOriginalAnalysis':617,'allAliveNPCs':616,'populationExplanation':'Original final full save has 616 state.citizens; actorProfiles includes extra player. Helper independently verified 616 alive/dead0/missing0.','fourEvents':cohort['fourEvents'],'routeCause':'PENDING read-only diagnosis; no product source fix or completed cure claimed','runs':[{k:v for k,v in b.items() if k!='frozenInputs'} for b in bound]}
save('ROOT26-ACTUAL-EVIDENCE-SUMMARY.json',summary)
table='\n'.join('| '+ ' | '.join([b['name'],str(b['result']['ordinaryCalls']),f"{b['planSummary']['inputClock']}→{b['result']['clock']}",f"{b['planSummary']['inputTick']}→{b['result']['tick']}",str(b['receipt']['inputCount']),f"{b['result']['elapsedSeconds']} / {(datetime.fromisoformat(b['receipt']['endedAt'])-datetime.fromisoformat(b['receipt']['startedAt'])).total_seconds():.6f}",b['receipt']['rawSHA256']])+' |' for b in bound)
report=f'''# ROOT26：原居民供粮访问接续（私有阶段稿）

本阶段三段有限原生续档门均实际完成，但食品、财政与完整游戏仍为 **PARTIAL**。本稿只新增 ROOT26 事实，不重交或改写 ROOT24–25 报告。待根代理核对路线诊断与后续是否需要修源码；本文不提前认定路线原因或产品修复通过。

## 原世界与真实接续

读取原 World291/SHA `{summary['worldSHA256']}`、612 栋/616 名原NPC，原世界指纹 b85fa6ec。首输入是原 ROOT24 真终档 `{summary['startingSaveSHA256']}`，clock5340/tick2070。三段分别从上一段完整终档冷恢复，原 speed16、每次 `.25` 普通步不变；累计 **64 新普通窗、3 cold段、3构造/3import、64完整reader**，5340→5596（17:00→21:16，共256游戏分钟）、tick2070→2134。每段0命令、0身体/钱包/需求/库存/身份/时钟注入，所有10个实际phase、fullsave和ALLbus原件由root门捕获。此是旧v6世界自然接续，不是新普通URL v8出生、单fresh64或原单fresh360。

| 原门 | 普通窗 | clock | tick | 冻结输入 | driver/gate秒 | 原raw SHA256 |
|---|---:|---|---|---:|---|---|
{table}

三gate均实际 PASS/exit0/inputsStable=true/activeDescendants=[]；三个 RESULT 为 ACTUAL_COMPLETED，capture/persistence/conservation失败均空。各门输入417图完全相同；本阶段未改生产功能源码、几何、原游戏规则或旧 tests，只新增私有 driver/observer 和原件。本文作者自身执行0 Simulation/step/tests/types/build/browser/GPU，仅读既有原件与源码。

## 原115人实际恢复与仍未完成

| 原终点 | 原115中已有具名恢复 | 原115仍低 | 全城低30 |
|---|---:|---:|---:|
| native01 / 5404 | 23 | 92 | 93 |
| native02 / 5532 | 63 | 52 | 52 |
| native03 / 5596 | 73 | 42 | 43 |

末端 **73名不同原居民真实成交吃饭**，原群体sale事件共97笔；42原居民仍低饱足且全部moving，另1名新增低，不能写成115全部获救。42的真实目的地为 summit-b8 17人、west-b41 12人、east-b5 13人。饱足hunger越高越饱；保存的钱、位置、目标或moving状态均不能代柜台成交或合法路径通过证据。是否因路程、评分、重选节律、库存或实体阻挡仍待新的只读定位，未实施sourcefix。

四名跟踪居民中：450于clock5372在east-b50真实sale，随后5500消耗随身餐；457与489于5408在east-b37真实sale，随后5536各消耗随身餐。153末端仍moving→east-b5、food0、饱足2.300000000000116，没有其sale；不是四人全恢复。616名原NPC逐ID均存活；原分析 `allAlive=617` 是含player的profile数，不能写617NPC。

全城三RESULT累计 **355柜台餐、20随身餐**；新粮产 `{totals['foodProduced']}`、材料产 `{totals['materialProduced']}`。原先零粮店曾完成有限补货/成交，不等所有店终态库存充足；终态east-b37/east-b50/summit-b2原数据仍open且库存0。native01在east-b37-door有两笔各28的cargo-arrived，shopId是原货主core-dock/river-b57，进入地区FIFO而非直接指定零售粮或居民食物；不能仅凭nodeId或cargo事件宣称完整供应商付款链。

## 钱粮与保存的限定通过

新NPC earned合计 `{totals['npcEarned']}`，本17:00–21:16窗口NPC paid/publicPaid/privatePaid均0；只核该时段新债来源，不冒下一工资窗口或长期财政可持续。三原门最大cash/food/debt/fiscal残差分别为 `{maximum['cash']}` / `{maximum['food']}` / `{maximum['debt']}` / `{maximum['fiscal']}`，各原值保留在 [实际摘要](ROOT26-ACTUAL-EVIDENCE-SUMMARY.json)。没有补钱、造库存、延长游戏deadline或降低断言。

各段130/127/129个实际地理part已由producer物理写/read/decode并组装与对应whole完整字节相同；各自删一个真实chunk拒读，额外Sim/import/step均0。每一成功普通窗都有原完整reader。末档SHA `{summary['terminalSaveSHA256']}`。这不是本阶段future24、浏览器UI重载、崩溃恢复、新地图或全部旧档加载验收。

## 原要求保护与接续

[新52列矩阵](MATRIX-38-ROOT26-DRAFT.csv) 只追加ROOT26计划/实现/运行/验证/剩余5列；旧 **47headers、1786data cells、38IDs和顺序全exact**，旧ROOT18–25的RUNNING/NOT_RUN/FAIL等当时记录逐字保留。[只含追加列](MATRIX-ROOT26-APPEND-ONLY.csv) 与 [逐格保护回执](MATRIX-PRESERVATION-ROOT26.json) 可独立核对；38域全PARTIAL。

食品实情写入FOOD及直接相关商业、物流、日常需求、财政、保存与验证域；能源、医疗卫生病毒、科技教育政治、完整自然家庭世代、环境、灾害、产权拆迁新路、统计流式、2D/Worker等没有因此完成。原ROOT24 native03四缺phase/FAIL与两个cold段360 canonical/361物理call边界仍保留，新64窗不回填旧缺失。ART_FAIL、MacNOT_RUN、14日供粮现金财政稳态NOT_RUN继续。

当前下一步为剩余42人与新增低饱足居民的真实route/终端售点/成本与供料诊断，由root判断最小业务修复及后续有限原生门；不得从本稿预授权补钱粮、瞬移或改继承旧世界。Library、本stage源码commit/push与最终交付尚待root真实回执；本作者未上传、创建ZIP、修改shared源码/备忘录或旧STOPWRITE目录。

原件入口：`/tmp/ROOT26-food-access-20261007-01/native01|native02|native03`，gate与各cohort分析在`/workspace/yunshan-work/ROOT26-food-access-20261007-01`。[输入字节绑定](DRAFT-INPUT-SNAPSHOT.json) 列实际文件SHA；仅容器路径不是已送达附件。
'''
text('ROOT26-供粮访问阶段报告-DRAFT.md',report)
memo=f'''\n\n### ROOT26 食品原生接续实际有限通过，原剩余路线待定位（2026-10-07，私有追加草案）

本阶段仅新私有driver/audit原件，生产417功能图/原世界几何/旧规则tests没有修改。旧World291/b85fa6ec、612建筑/616NPC从ROOT24真6e481…2d48终档冷续native01/02/03三门，各417输入stable/active[]/exit0/PASS；原16+32+16=64普通窗/64reader、3cold段/3Sim/import、0命令及身体钱粮需求库存身份时间注入，clock5340→5596（17:00→21:16）、tick2070→2134，不冒单fresh64、旧单fresh360或新普通URL v8旅程。

115原低饱足居民真实具名恢复23→63→73，终点原42仍低且全moving，全城43低含1新低；原群体97sale、全城355柜台餐/20随身餐，616原NPC全alive（profiles617含player，非617NPC）。450真5372sale/5500stored；457489真5408sale/5536stored；153末moving/east-b5/food0/饱足2.3且无sale，不说四人全获救。剩42目标summit-b8 17、西区west-b41 12、east-b5 13，真实路线与重选/供给原因仍待核，尚无本stage业务sourcefix或115全恢复证明。

新粮产{totals['foodProduced']}、材料{totals['materialProduced']}，NPCearned{totals['npcEarned']}、本17–21窗口NPC实付0；cash/food/debt/fiscal最大残差{maximum['cash']}/{maximum['food']}/{maximum['debt']}/{maximum['fiscal']}。工资下一窗口/有限补货支付与14日稳态未验；终点east-b37/east-b50/summit-b2仍open但stock0，cargo-arrived nodeId不等直接零售补粮。每段130/127/129真实物理part回读assemble与whole exact、各缺真chunk拒/0额外Sim/import/step；末档完整SHA {summary['terminalSaveSHA256']}，本阶段future24/UIreload/新地图仍NOT_RUN。

新私有38×52矩阵只append5列，47原headers/1786原data cells/38IDs与顺序exact，全38PARTIAL；原ROOT24四缺phase/FAIL不回填，ART_FAIL/MacNOT_RUN与完整家庭、能源医疗科技政治教育卫生病毒/动态城灾害/统计流式等剩余保留。报告/逐格保护/原receipt source SHA在ROOT26/report-draft，仅新stage事实，不重交旧报告。作者0Sim/step/tests/build/browser/共享写；Library/本stagecommit/push待root实际外置回执，未预填送达。\n'''
text('MEMO-APPEND-ROOT26-DRAFT.md',memo)
sharedAfter={p:sha((repo/p).read_bytes()) for p in sharedBefore}
protectedChanges=[str(p) for p in inputs if sha(p.read_bytes())!=inputRecords[str(p)]['sha256']]
assert baseline.read_bytes()==baselineBytes and not protectedChanges and sharedBefore==sharedAfter
save('READONLY-PRESERVATION-ROOT26.json',{'at':datetime.now(timezone.utc).isoformat(),'sharedFunctionalInputs':417,'sharedBeforeAfterExact':True,'allBoundDocumentEvidenceInputsBeforeAfterExact':True,'originalMatrixFileBytesUnchanged':True,'oldSTOPWRITEDirectoryMutationsByAuthor':0,'sharedMemoMutationsByAuthor':0,'sharedSourceMutationsByAuthor':0,'executionsByAuthor':{'Simulation':0,'step':0,'tests':0,'tsc':0,'build':0,'browser':0,'GPU':0},'uploadsByAuthor':0,'zipCreationByAuthor':0,'sourceHashMethod':'Per-file raw SHA256, no reconstructed JS graph digest claim.'})
records={p.name:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in out.iterdir() if p.is_file() and p.name!='DRAFT-SHA256.json'}
save('DRAFT-SHA256.json',{'at':datetime.now(timezone.utc).isoformat(),'files':records,'stage':'ROOT26 private append-only report; no final delivery/commit/upload claim'})
print(json.dumps({'status':'PRIVATE_ROOT26_DRAFT_READY','matrixRows':38,'matrixColumns':52,'preservedOriginalDataCells':1786,'sourceUnchanged':True,'report':str(out/'ROOT26-供粮访问阶段报告-DRAFT.md'),'memoDraftOnly':str(out/'MEMO-APPEND-ROOT26-DRAFT.md'),'cohortRecovered':73,'stillLowOriginal':42,'fullRequirementStatus':'PARTIAL'},ensure_ascii=False,indent=2))

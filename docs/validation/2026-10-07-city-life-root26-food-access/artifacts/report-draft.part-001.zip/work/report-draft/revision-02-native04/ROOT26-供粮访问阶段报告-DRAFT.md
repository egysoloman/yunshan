# ROOT26：供粮访问四段有限接续（新私有修订稿）

本稿新增native04实际结果，保留原三段报告/矩阵/SHA原字节。**80个有限普通窗通过，完整食品系统与全38域仍PARTIAL。** 86/115有具名sale恢复，29仍低；夜间供餐和有限供应分配成为下一阶段明确缺口。本阶段没有游戏业务修复。

## 原生范围与实际回执

原World291/b85fa6ec、612建筑/616NPC，从ROOT24原终档6e481…2d48 cold继续，四段16+32+16+16共80普通窗、4构造/4import、80reader。clock5340→5660（17:00→22:20，320游戏分钟）、tick2070→2150；原speed16/每次.25不变，0命令/身体钱粮需求库存身份时间注入。每个gate都是同一417冻结输入stable、exit0/PASS、activeDescendants=[]，RESULT均ACTUAL_COMPLETED，无capture/persistence/conservation失败。不是单fresh80/旧360或新普通URL v8旅程。

| 原门 | 完整普通窗 | clock | driver/gate秒 | 真实parts | 原raw SHA256 |
|---|---:|---|---|---:|---|
| native01 | 16 | 5340→5404 | 106.123 / 107.917040 | 130 | ecac6527c67374e4301ce878a22aac35976f9a6366bede8162ee60a15ee102e2 |
| native02 | 32 | 5404→5532 | 156.094 / 156.899856 | 127 | 4c7ef37662202b3f141f85f6047fd004b47fab818f3f70fa9ffea3797d817e13 |
| native03 | 16 | 5532→5596 | 83.98 / 84.752002 | 129 | b626494a8bea7b78d0ce4dcbbd7bf439a447ac7f33858c17b63d1889cbca36ad |
| native04 | 16 | 5596→5660 | 84.888 / 85.638675 | 128 | 02ce5b905e4f2be9e78a800a20e4709e1310f8b6659c3b9855dab327b51b3589 |

native04的日期计算gate85.638675s、driver84.888s，沿原receipt/RESULT，不沿早期消息近似时长。末whole SHA `3bb3ed56da5205283daa304262a03104fa7903f385eb072e6a83d2f731e5a62a`；逐段终档与下一完整输入SHA相同。130/127/129/128实际地理parts分别物理写/read/decode/assemble字节exact，各删真chunk拒；额外Sim/import/step0。未跑本阶段未来24/正常UIreload/崩溃恢复或新地图保存。

## 真实居民结果与夜间缺项

原115的真实恢复23→63→73→86，最后86名不同居民有实际sale、原群体122次sale。原29仍低，全城30低=原29+1新低；29中25moving/4riding，活动15rest/14eat。终点完整原save逐ID核6名饱足0且food0：219、340、362、368、428、571。616名原NPC均alive，profiles含player为617，不写617NPC。

四target这次全有真实sale：450于5372、457/489于5408，153终于5600于east-b5买2份、cost29.980531266965833，末shopping/饱足52/food1。450在5500、457/489在5536各有stored-meal；153没有后续stored witness，不能称四人全完成携粮后续餐。全城四RESULT共393柜台餐与23随身餐。

**终点全部210 shop open=false，食品店开放数0。** 86人恢复不等夜间29人都有可用供餐，也不等无库存/营业竞争。本次粮产约6.7569085124、材料约29.7449830046，末两段生产0；没有造粮或暗补钱包。下一应明确夜间经营/随身粮与有限供应分配方案，仍服从原owner/身份许可、劳动营业、库存、钱包、成本、工资债及时间规则，不以诊断工具代服务。

父代理已收前三64窗只读诊断：115cohort共212次目标变化，203次旧目标stock0、9次旧店仍open有货；42的原边界无unreachable/physicalWaiting/roadWaiting，实际处理moving均有位移。这支持供给竞争/长路的局部解释，不证明所有后续合法通路或完整修复。该诊断原件路径绑定尚待root补充，本稿不把父消息当已独立复算的cause证明。

## 钱粮、工具与剩余

四RESULT新earned约996.325269443、NPC paid/publicPaid/privatePaid均0。终payrollAt6780尚未跨；不声称工资已付或财政长期可持续。最大cash/food/debt/fiscal残差为2.9103830456733704e-10 / 1.8189894035458565e-12 / 4.547473508864641e-13 / 2.3001689442025963e-10。全部逐run原值和打印数的十进制合计保在[实际证据摘要](ROOT26-ACTUAL-EVIDENCE-SUMMARY.json)；数值舍入口径明确，不拿更长小数当新增物理精度。

下一仅规划新增独立418纯原件重检工具及3篡改拒绝回归：重算原80窗十phase守恒、全save反馈cash/food/debt深equal、typedBUS/trace/parts编码解码双SHA及四段lineage。**工具/tests实际门PENDING**，不能将只读检查工具称为游戏repair，更不能预写PASS。产品功能原417字节未被本阶段普通门改变；未来418工具与原417运行范围另列。

[38×52新矩阵](MATRIX-38-ROOT26-DRAFT.csv)仅追加ROOT26五列，旧47headers/1786cells/38IDs次序exact，所有38域仍PARTIAL。原三段草稿完全保留，旧STOPWRITE与shared src/memo无本作者写入。原ROOT24四缺phase/FAIL和360 canonical/361物理call仍保，新80窗不回填。完整能源、医疗卫生病毒、科技教育政治、家庭自然世代、产权改造拆迁新路/灾害、统计流式/适配、美术ART_FAIL与MacNOT_RUN仍开放；14日现金财政供粮稳态NOT_RUN。

本作者0Sim/step/tests/types/build/browser/GPU，仅静态JSON/CSV/SHA核对与新私稿。Library/本stageGit提交推送和最终交付PENDING实际root回执，未制作新ZIP或上传；容器路径不是已送达附件。

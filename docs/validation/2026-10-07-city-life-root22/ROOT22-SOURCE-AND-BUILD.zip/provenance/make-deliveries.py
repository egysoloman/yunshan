import hashlib, json, pathlib, zipfile

source = pathlib.Path('/workspace/yunshan')
work = pathlib.Path('/workspace/yunshan-work/ROOT22-maintenance-integration-20261007-01')
docs = source / 'docs/validation/2026-10-07-city-life-root22'
sha = lambda data: hashlib.sha256(data).hexdigest()
frozen = json.loads((work / 'FROZEN-397.json').read_text())
for name, digest in frozen.items():
    assert sha((source / name).read_bytes()) == digest
assert len(frozen) == 397

def tree(root, prefix):
    return {prefix + '/' + str(p.relative_to(root)): p for p in sorted(root.rglob('*')) if p.is_file()}

def archive(name, entries):
    target = docs / name
    assert not target.exists()
    before = {member: {'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())} for member, path in sorted(entries.items())}
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for member, path in sorted(entries.items()):
            output.write(path, member)
    with zipfile.ZipFile(target) as packed:
        assert len(packed.infolist()) == len(before)
        for member, expected in before.items():
            raw = packed.read(member)
            assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
            assert sha(entries[member].read_bytes()) == expected['sha256']
    receipt = {'filename': name, 'bytes': target.stat().st_size, 'sha256': sha(target.read_bytes()),
        'members': before, 'memberCount': len(before),
        'zipExpandedMemberBytes': sum(row['bytes'] for row in before.values()),
        'note': 'Expanded member sizes retain gzip members as gzip bytes; decoded native full-save bytes are separately recorded in RESULT.',
        'everyMemberReadbackExact': True, 'dependenciesCopied': False}
    (docs / (name + '.receipt.json')).write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    return {key: receipt[key] for key in ['filename', 'bytes', 'sha256', 'memberCount', 'zipExpandedMemberBytes', 'everyMemberReadbackExact']}

entries = {name: source / name for name in frozen}
entries.update(tree(source / 'dist', 'dist'))
for name in ['AGENTS.md', '提示词.md', '开发备忘录.md']:
    entries[name] = source / name
entries.update(tree(docs, 'docs/validation/2026-10-07-city-life-root22'))
entries['original-inputs/WORLD291.original.json'] = pathlib.Path('/workspace/yunshan-work/ROOT16-food-integration-20261005-01/originals/WORLD-ORIGINAL.json')
entries['original-inputs/ROOT20-PRIMARY-1700.save.json'] = source / 'docs/validation/2026-10-05-city-life-root20/ROOT20-PRIMARY-1700.save.json'
entries['provenance/FROZEN-397.json'] = work / 'FROZEN-397.json'
entries['provenance/BASELINE-392.json'] = work / 'BASELINE-392.json'
entries['provenance/FINAL-INTEGRITY.json'] = work / 'FINAL-INTEGRITY.json'
entries['provenance/make-deliveries.py'] = pathlib.Path(__file__)
result = [archive('ROOT22-SOURCE-AND-BUILD.zip', entries)]

entries = {}
for name in ['tsc01', 'pure01', 'native01', 'legacy-equivalence01', 'legacy-rules01', 'build01', 'ui01', 'legacy-plan', 'ui-plan', 'baseline']:
    entries.update(tree(work / name, name))
for name in ['PLAN.json', 'BASELINE-392.json', 'FROZEN-397.json', 'FINAL-INTEGRITY.json', 'run-phase.py', 'make-deliveries.py']:
    entries['root/' + name] = work / name
entries.update(tree(pathlib.Path('/tmp/ROOT22-legacy-compat/run01'), 'legacy-independent-actual01'))
for name in ['baseline-source', 'candidate-source']:
    directory = pathlib.Path('/tmp/ROOT22-legacy-compat') / name
    entries.update(tree(directory / 'src', 'legacy-frozen/' + name + '/src'))
    for file in ['package.json', 'tsconfig.json', 'SOURCE-MANIFEST.json', 'FREEZE-RECEIPT.json']:
        entries['legacy-frozen/' + name + '/' + file] = directory / file
result.append(archive('ROOT22-ORIGINAL-VALIDATION.zip', entries))
(docs / 'ARCHIVE-SUMMARY.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(result, ensure_ascii=False))

# ROOT21 legacy／finite-storage-v1 顺序兼容对照准备

状态：PREPARED_ONLY，Sim／测试／构建／native／Git 一律未运行。本目录和 `/tmp/ROOT21-legacy-compat` 为新建独立目录；没有写仓库 `src`／`scripts` 或修改原输入。根代理决定启动与每进程 cap。

原 source382 从 `ROOT20-SOURCE-AND-BUILD.zip` 只恢复全部 96 个 `src` 文件、`package.json`、`tsconfig.json`，共 98 件／2,464,412 字节，逐件 SHA 匹配 BASELINE-382。恢复源根 `/tmp/ROOT21-legacy-compat/baseline-source`；`node_modules` 仅为现有依赖的符号链接。完整清单、ZIP SHA、原 fixture SHA 在 PREPARATION-RECEIPT.json；未使用不完整的 originals/src 作为依赖闭包。

候选必须先停止源编辑，再冻结全部 `src` 与两份配置。freeze-source.py 只复制这些文件，核对源前后／副本完全一致，产出 SOURCE-MANIFEST.json；旧目录不覆盖。capture.mjs 在模块导入前及结束后复核冻结源，不把未知候选当作已验收。

主档：原 World291 JSON SHA `2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512`，612 建筑／11 区／674 节点／691 边，未声明 powerGrid。原完整主存档 SHA `4610ab1059b52cfd4bbfa17badf209a7a33ab986735d83b8a5da8c8a9e5ddf6a`，616 居民，v4／motion2，tick1710／clock3900／第3日17:00／speed8。两源各新进程 1 构造、1 原完整字节 import，读回须逐字相同，再 4 次原 `step(.25)`；预期终 tick1714／clock3908，0 命令、0 Focus／钱／料／需求／身份／岗位／时刻编辑。

v1 对照：V1-WORLD.json 是原 `originals/tests/power-grid-fixture.ts` 的 gridWorld 静态字面翻译，原函数没有执行。有限电池 10000 PMinutes、maximumP100，四建筑、三条原道路、原供电节点／两馈线／island；合同 version1 与 save 版本不同。基线单独构造保存原 cold full save，再 self-import；候选新进程 import 同一基线原完整 cold 字节。每源 4 次原 step(.25)／speed1，预期 tick4／clock481。此窄窗口保留冷启动和相同原生序列，未跑旧 integration 全流程，也不证明完整 v1 耗尽／生产／分区未来覆盖。

事件观察在原 `connectSystems` 入口连接到同一实例 bus；此前构造仅建立居民／社交／商铺／车队，不发射 bus 事件。包装只捕获，然后以相同 this、原事件对象和参数调用原 emit，保留 canonical WeakMap／WeakSet 身份、返回值、异常和嵌套调用顺序。每发射原 JSON 文本不 parse/repack；另保存 own-key 顺序、undefined／-0 与 descriptor 的补充快照、seq／parent／depth／stage／tick／clock。十相位完成观察器只读；每步保存完整最终 export，包含 feedback 之后的 stair prune。state.events 通知单独包含在完整存档里。部分相位只记录顺序与分钟，不作为可恢复存档。

完整输入、构造 cold save、import 后及每步完整存档、全量原 bus events 均 gzip 保存，每件写后解压读回核对原始 bytes／SHA；GZIP-DECODED-PROOFS.json 留存压缩与解码收据。frame0 与每步原完整 native validateSave 都运行，且读前后 full save 须不变。比较器验证所有 gzip 证明，对每个完整存档、每条事件及相位字节 exact compare；所有不同完整快照仍保留，另外将全部结构差异写入 ALL-STRUCTURAL-DIFFERENCES.jsonl.gz，包含对象键序／数组顺序／缺失字段，不截断 differences。

**本驱动没有执行新的现金／食品因果闭合审计。** 结果无论 PASS／FAIL 都明确 moneyFoodCausalAudit=NOT_PERFORMED_NO_BALANCE_OR_SUSTAINABILITY_CLAIM。兼容 PASS 只说明该原输入、该有限普通步窗口 full save／bus／phase 精确相同；不扩大为主城发电、自然16日稳态、v2 水电验收、设备钱料工、GPU／Mac 或完整游戏目标通过。主档历史现金审计也不代证这新增窗口。

根代理可执行命令（本代理未执行）：

```bash
python /workspace/yunshan-work/ROOT21-energy-integration-20261005-01/legacy-plan/freeze-source.py \
  --source /workspace/yunshan \
  --destination /tmp/ROOT21-legacy-compat/candidate-source
bash /workspace/yunshan-work/ROOT21-energy-integration-20261005-01/legacy-plan/run-sequential.sh \
  --candidate /tmp/ROOT21-legacy-compat/candidate-source \
  --out /tmp/ROOT21-legacy-compat/run01 \
  --cap-seconds 120 --memory-mb 3072 --steps 4
```

cap120 与 memory3072 为示例，由根代理选择；脚本要求显式 cap／memory，4 个新 node 进程严格顺序，无并发。整组 4 构造／4import／16普通step／20原 full validateSave（另4 import 自带 reader），2 primary 各约 15–60 秒，2 紧凑 v1 各约 1–10 秒只是保守规划，未实测。每进程 timeout 先 TERM 后 5 秒 KILL；失败保留 raw logs／已写完整证据，旧输入、源与目录不覆盖。冻源约额外2.5MB，完整 gzip 快照／事件预估10–30MB；原未压缩全存档总量约45MB（主要为两主档各6份），实际由 gzip receipts 计，不能冒充已运行成本。

终态未有运行 RESULT。仍待根 gate：冻结候选、实际 capped sequential capture、两份 compare RESULT，按实际失效原因修复后另建新 run 目录；原失败不可覆盖。

// Prepared only: execution belongs to the root's sequential capped gate.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { gzipSync, gunzipSync } from 'node:zlib';

const values = new Map();
for (let i = 2; i < process.argv.length; i += 2) {
  const name = process.argv[i], value = process.argv[i + 1];
  assert(['--source', '--world', '--input', '--out', '--steps', '--mode', '--label'].includes(name) && value !== undefined && !values.has(name), `Invalid argument ${name}`);
  values.set(name, value);
}
const required = name => { assert(values.has(name), `Missing ${name}`); return values.get(name); };
const source = resolve(required('--source')), output = resolve(required('--out'));
const worldFile = resolve(required('--world')), mode = required('--mode'), label = required('--label');
const steps = Number(required('--steps'));
assert(['primary-no-grid', 'storage-v1'].includes(mode));
assert(Number.isInteger(steps) && steps >= 1 && steps <= 16, 'Narrow ordinary-step window only');
assert(mode !== 'primary-no-grid' || values.has('--input'), 'Primary must import original full save');
const phases = ['time', 'environment', 'energy', 'traffic', 'people', 'commerce', 'finance', 'security', 'politics', 'feedback'];
const sha = data => createHash('sha256').update(data).digest('hex');
const json = (name, data) => writeFileSync(join(output, name), JSON.stringify(data, null, 2) + '\n', { flag: 'wx' });
function sourceHashes(directory = 'src') {
  const files = [];
  for (const entry of readdirSync(join(source, directory), { withFileTypes: true }).sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0)) {
    assert(entry.isFile() || entry.isDirectory(), `Unexpected functional source entry ${entry.name}`);
    const path = directory + '/' + entry.name;
    if (entry.isDirectory()) files.push(...sourceHashes(path)); else files.push(path);
  }
  return files;
}
function inspectSource() {
  const paths = [...sourceHashes(), 'package.json', 'tsconfig.json'].sort();
  return Object.fromEntries(paths.map(path => [path, sha(readFileSync(join(source, path)))]));
}
const manifestBytes = readFileSync(join(source, 'SOURCE-MANIFEST.json'));
const expectedSource = JSON.parse(manifestBytes.toString('utf8'));
const sourceBefore = inspectSource();
assert.deepEqual(sourceBefore, expectedSource, 'Frozen source differs before import');
mkdirSync(output, { recursive: false });
const proof = [];
function compressed(name, bytes) {
  const raw = Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes, 'utf8');
  const packed = gzipSync(raw, { level: 6 });
  const file = name + '.gz';
  writeFileSync(join(output, file), packed, { flag: 'wx' });
  const readBack = gunzipSync(readFileSync(join(output, file)));
  assert(readBack.equals(raw), `Decoded gzip differs: ${name}`);
  const receipt = { file, rawBytes: raw.length, sha256: sha(raw), gzipBytes: packed.length, gzipSha256: sha(packed), decodedSha256: sha(readBack), decodedReadbackEqual: true };
  proof.push(receipt); return receipt;
}
// Keeps undefined, own-key order, -0 and descriptor flags as supplemental proof.
// Native JSON text remains separately preserved without parse/repack.
function payload(value, ancestry = new Set()) {
  if (value === null) return ['null'];
  const kind = typeof value;
  if (kind === 'undefined') return ['undefined'];
  if (kind === 'number') return ['number', Object.is(value, -0) ? '-0' : String(value)];
  if (kind === 'string' || kind === 'boolean') return [kind, value];
  assert(kind === 'object' && !ancestry.has(value), 'Unsupported native event payload');
  const seen = new Set(ancestry); seen.add(value);
  return [Array.isArray(value) ? 'array' : 'object', Reflect.ownKeys(value).map(key => {
    assert(typeof key === 'string', 'Symbol event key unsupported');
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    assert(Object.hasOwn(descriptor, 'value'), 'Accessor event payload unsupported');
    return [key, descriptor.enumerable, descriptor.writable, descriptor.configurable, payload(descriptor.value, seen)];
  })];
}
const worldBytes = readFileSync(worldFile), world = JSON.parse(worldBytes.toString('utf8'));
if (mode === 'primary-no-grid') assert(!Object.hasOwn(world, 'powerGrid'), 'World291 must remain undeclared');
else assert(world.powerGrid?.version === 1 && world.powerGrid.kind === 'finite-storage-network', 'Only original storage-v1 fixture');
compressed('world-input.json', worldBytes);
let sim, stage = 'construct', frame = -1, sequence = 0, pendingEvents = [], phaseObservations = [], stack = [];
const allEventTypeCounts = {}, snapshots = [];
let constructorCount = 0, importCount = 0, stepCount = 0, readerCount = 0;
const startedAt = new Date().toISOString();
let installed = false;
function observeBus(city) {
  assert(!installed, 'Only one Simulation per fresh process'); installed = true;
  const bus = Reflect.get(city, 'bus'), emit = Reflect.get(bus, 'emit');
  assert(bus && typeof emit === 'function', 'Native bus is unavailable');
  Reflect.set(bus, 'emit', function (...args) {
    assert(args.length === 1 && typeof args[0]?.type === 'string', 'Native bus signature changed');
    const event = args[0], seq = sequence++;
    pendingEvents.push({ sequence: seq, parentSequence: stack.at(-1) ?? null, depth: stack.length, stage, frame,
      tickAtEmit: city.state.tick, clockAtEmit: city.state.extension?.lastUpdate ?? city.state.day * 1440 + city.state.hour * 60,
      type: event.type, nativeJson: JSON.stringify(event), originalPayload: payload(event) });
    allEventTypeCounts[event.type] = (allEventTypeCounts[event.type] ?? 0) + 1;
    stack.push(seq);
    try { return Reflect.apply(emit, this, args); } finally { stack.pop(); }
  });
}
function flushEvents(name) {
  const receipt = compressed(name + '.events.jsonl', pendingEvents.map(event => JSON.stringify(event) + '\n').join(''));
  const count = pendingEvents.length; pendingEvents = []; return { ...receipt, eventCount: count };
}
function snapshot(name, validate = true) {
  const text = sim.exportSave();
  let read = null;
  if (validate) {
    readerCount++; read = sim.validateSave(text);
    assert(read.ok, `Full native reader rejected ${name}: ${read.message}`);
    assert.equal(sim.exportSave(), text, 'Read-only native reader changed live full save');
  }
  const saved = compressed(name + '.save.json', text);
  const record = { frame, name, tick: sim.state.tick, clock: sim.state.extension?.lastUpdate ?? sim.state.day * 1440 + sim.state.hour * 60,
    day: sim.state.day, hour: sim.state.hour, speed: sim.state.speed, paused: sim.state.paused,
    phaseOrder: [...sim.state.lastSystemOrder], powerGridVersion: sim.state.powerGrid?.version ?? null, fullReader: read, save: saved };
  snapshots.push(record); return text;
}
try {
  const { Simulation } = await import(pathToFileURL(join(source, 'src/simulation.ts')).href);
  // The original core emits no bus events before connectSystems. Attach here
  // to also preserve constructor-installed extension events; forward unchanged.
  const connect = Reflect.get(Simulation.prototype, 'connectSystems');
  assert(typeof connect === 'function', 'Native initialization seam unavailable');
  Reflect.set(Simulation.prototype, 'connectSystems', function (...args) { observeBus(this); return Reflect.apply(connect, this, args); });
  try { constructorCount++; sim = new Simulation(world); } finally { Reflect.set(Simulation.prototype, 'connectSystems', connect); }
  assert(installed);
  snapshot('constructor', false);
  const inputFile = values.has('--input') ? resolve(values.get('--input')) : null;
  const inputBytes = inputFile ? (inputFile.endsWith('.gz') ? gunzipSync(readFileSync(inputFile)) : readFileSync(inputFile)) : Buffer.from(sim.exportSave(), 'utf8');
  compressed('original-full-input.save.json', inputBytes);
  stage = 'import'; frame = 0; importCount++;
  const loaded = sim.importSave(inputBytes.toString('utf8'));
  assert(loaded.ok, `Original full-save import failed: ${loaded.message}`);
  const postImport = snapshot('frame-000');
  assert(Buffer.from(postImport, 'utf8').equals(inputBytes), 'Original full input fails byte-exact roundtrip');
  const startupEvents = flushEvents('startup');
  for (const phase of phases) sim.onPhase(phase, (state, minutes) => phaseObservations.push({ phase, tick: state.tick,
    clock: state.extension?.lastUpdate ?? state.day * 1440 + state.hour * 60, minutes, order: [...state.lastSystemOrder] }));
  const initialTick = sim.state.tick, initialClock = sim.state.extension?.lastUpdate ?? sim.state.day * 1440 + sim.state.hour * 60;
  assert(!sim.state.paused);
  const frameEvents = [];
  for (frame = 1; frame <= steps; frame++) {
    stage = 'step'; phaseObservations = []; const priorTick = sim.state.tick;
    stepCount++; sim.step(.25);
    assert.equal(sim.state.tick, priorTick + 1, 'One ordinary .25 step must advance one native tick');
    assert.deepEqual(phaseObservations.map(observation => observation.phase), phases, 'Native phase order changed');
    assert.deepEqual(pendingEvents.filter(event => event.type.startsWith('system:')).map(event => event.type.slice(7)), phases, 'Native bus phase order changed');
    assert.deepEqual(sim.state.lastSystemOrder, phases);
    const prefix = 'frame-' + String(frame).padStart(3, '0');
    json(prefix + '.phases.json', phaseObservations);
    snapshot(prefix);
    frameEvents.push({ frame, events: flushEvents(prefix) });
  }
  stage = 'complete';
  const sourceAfter = inspectSource();
  assert.deepEqual(sourceAfter, sourceBefore, 'Frozen source changed during capture');
  assert.equal(sha(readFileSync(worldFile)), sha(worldBytes), 'Trusted world input changed');
  if (inputFile) {
    const endInput = inputFile.endsWith('.gz') ? gunzipSync(readFileSync(inputFile)) : readFileSync(inputFile);
    assert(endInput.equals(inputBytes), 'Original full-save input changed');
  }
  json('GZIP-DECODED-PROOFS.json', proof);
  json('SUMMARY.json', { status: 'CAPTURE_COMPLETED_COMPARISON_PENDING', label, mode, startedAt, endedAt: new Date().toISOString(), source,
    sourceManifestSha256: sha(manifestBytes), sourceBefore, sourceAfter, sourceStable: true, worldInputPath: worldFile, worldInputSha256: sha(worldBytes),
    inputFile, originalInputSha256: sha(inputBytes), originalInputByteRoundtrip: true,
    initialTick, initialClock, finalTick: sim.state.tick, finalClock: sim.state.extension?.lastUpdate ?? sim.state.day * 1440 + sim.state.hour * 60,
    constructorCount, importCount, stepCount, readerCount, steps, realSecondsPerStep: .25, unchangedOriginalSpeed: sim.state.speed,
    directCommands: 0, setFocusCalls: 0, directStateWorldBodyMoneyStockNeedsIdentityClockEdits: 0,
    nativeEvents: sequence, allEventTypeCounts, startupEvents, frameEvents, snapshots,
    eventCaptureScope: 'Every bus.emit call from native connectSystems initialization entry through import and ordinary steps; same bus this, args and canonical event object forwarded unchanged. State notices remain in complete saves.',
    moneyFoodCausalAudit: 'NOT_PERFORMED_NO_BALANCE_OR_SUSTAINABILITY_CLAIM',
    scope: 'Exact legacy/no-grid or finite-storage-v1 compatibility for this narrow original-input window only; no finite-hydro/default-city generation or long-run claim.' });
} catch (error) {
  try { if (pendingEvents.length) flushEvents('failure-pending'); } catch {}
  try { if (sim) compressed('failure-full-state.save.json', sim.exportSave()); } catch {}
  json('FAILURE.json', { status: 'FAILED_RETAIN_ALL_EVIDENCE', label, mode, stage, frame, startedAt, endedAt: new Date().toISOString(),
    constructorCount, importCount, stepCount, readerCount, error: error instanceof Error ? error.stack : String(error), proofsAlreadyWritten: proof });
  throw error;
}

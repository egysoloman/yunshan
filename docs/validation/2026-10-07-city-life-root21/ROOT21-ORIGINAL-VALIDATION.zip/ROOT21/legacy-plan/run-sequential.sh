#!/usr/bin/env bash
# Prepared only. Each invocation is fresh and every capture is sequential.
set -euo pipefail
plan_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
candidate_source=
run_output=
cap_seconds=
memory_mb=
steps=4
while (( $# )); do
  (( $# >= 2 )) || { echo 'Each argument needs a value' >&2; exit 2; }
  case "$1" in
    --candidate) candidate_source=$2 ;;
    --out) run_output=$2 ;;
    --cap-seconds) cap_seconds=$2 ;;
    --memory-mb) memory_mb=$2 ;;
    --steps) steps=$2 ;;
    *) echo "Unknown argument: $1" >&2; exit 2 ;;
  esac
  shift 2
done
[[ -n "$candidate_source" && -n "$run_output" && "$cap_seconds" =~ ^[1-9][0-9]*$ && "$memory_mb" =~ ^[1-9][0-9]*$ && "$steps" =~ ^[1-9][0-9]*$ ]] || { echo 'Root must provide candidate, new output, cap seconds and memory MB' >&2; exit 2; }
(( steps <= 16 )) || { echo 'Only a narrow window of at most 16 steps is supported' >&2; exit 2; }
baseline_source=/tmp/ROOT21-legacy-compat/baseline-source
world_file=/workspace/yunshan-work/ROOT16-food-integration-20261005-01/originals/WORLD-ORIGINAL.json
primary_file=/workspace/yunshan/docs/validation/2026-10-05-city-life-root20/ROOT20-PRIMARY-1700.save.json
mkdir -- "$run_output"
capture() {
  local source_dir=$1 branch_name=$2 mode=$3 world_path=$4
  shift 4
  timeout --signal=TERM --kill-after=5s "${cap_seconds}s" node --max-old-space-size="$memory_mb" \
    --import "$source_dir/node_modules/tsx/dist/loader.mjs" "$plan_dir/capture.mjs" \
    --source "$source_dir" --world "$world_path" --out "$run_output/$branch_name" \
    --mode "$mode" --label "$branch_name" --steps "$steps" "$@" \
    > "$run_output/$branch_name.stdout.log" 2> "$run_output/$branch_name.stderr.log"
}
capture "$baseline_source" baseline-primary primary-no-grid "$world_file" --input "$primary_file"
capture "$candidate_source" candidate-primary primary-no-grid "$world_file" --input "$primary_file"
capture "$baseline_source" baseline-v1 storage-v1 "$plan_dir/V1-WORLD.json"
capture "$candidate_source" candidate-v1 storage-v1 "$plan_dir/V1-WORLD.json" \
  --input "$run_output/baseline-v1/original-full-input.save.json.gz"
result=0
python "$plan_dir/compare.py" --baseline "$run_output/baseline-primary" --candidate "$run_output/candidate-primary" --out "$run_output/compare-primary" || result=1
python "$plan_dir/compare.py" --baseline "$run_output/baseline-v1" --candidate "$run_output/candidate-v1" --out "$run_output/compare-v1" || result=1
exit "$result"

#!/usr/bin/env python3
"""Copy only functional src + two configs, verifying stability. Never imports JS."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True)
parser.add_argument('--destination', required=True)
args = parser.parse_args()
source = Path(args.source).resolve()
destination = Path(args.destination).absolute()

def scan(root):
    paths = sorted((root / 'src').rglob('*'))
    assert all(not path.is_symlink() for path in paths), 'Functional source symlink unsupported'
    files = [p for p in paths if p.is_file()] + [root / 'package.json', root / 'tsconfig.json']
    return dict(sorted((str(p.relative_to(root)), hashlib.sha256(p.read_bytes()).hexdigest()) for p in files))

before = scan(source)
destination.mkdir(parents=False, exist_ok=False)
for relative in before:
    target = destination / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source / relative, target)
after = scan(source)
copied = scan(destination)
assert before == after == copied, 'Source changed during freeze; retain failed copy, do not run'
(destination / 'node_modules').symlink_to('/workspace/yunshan/node_modules', target_is_directory=True)
manifest_bytes = (json.dumps(copied, indent=2) + '\n').encode()
(destination / 'SOURCE-MANIFEST.json').write_bytes(manifest_bytes)
(destination / 'FREEZE-RECEIPT.json').write_text(json.dumps({
    'status': 'FROZEN_NOT_RUN', 'source': str(source), 'destination': str(destination),
    'fileCount': len(copied), 'bytes': sum((destination / p).stat().st_size for p in copied),
    'manifestSha256': hashlib.sha256(manifest_bytes).hexdigest(),
    'sourceBeforeAfterAndCopyEqual': True, 'dependencies': 'existing node_modules symlink',
    'excluded': ['tests', 'scripts', 'docs', 'adapters', 'dist', 'git', 'dependency copy'],
}, indent=2) + '\n')
print(str(destination / 'SOURCE-MANIFEST.json'))

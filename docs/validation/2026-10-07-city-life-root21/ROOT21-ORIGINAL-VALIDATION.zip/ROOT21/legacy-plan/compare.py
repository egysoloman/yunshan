#!/usr/bin/env python3
"""Compare every retained capture artifact, keeping complete structural diffs."""
import argparse
import base64
import gzip
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--baseline', required=True)
parser.add_argument('--candidate', required=True)
parser.add_argument('--out', required=True)
args = parser.parse_args()
baseline, candidate, output = (Path(p).resolve() for p in [args.baseline, args.candidate, args.out])
output.mkdir(parents=False, exist_ok=False)
sha = lambda b: hashlib.sha256(b).hexdigest()

def read_capture(directory):
    summary = json.loads((directory / 'SUMMARY.json').read_text())
    assert summary['status'] == 'CAPTURE_COMPLETED_COMPARISON_PENDING'
    assert summary['sourceStable'] and summary['originalInputByteRoundtrip']
    proofs = json.loads((directory / 'GZIP-DECODED-PROOFS.json').read_text())
    files = {}
    for item in proofs:
        encoded = (directory / item['file']).read_bytes()
        raw = gzip.decompress(encoded)
        assert len(raw) == item['rawBytes'] and sha(raw) == item['sha256'] == item['decodedSha256'], item['file']
        assert len(encoded) == item['gzipBytes'] and sha(encoded) == item['gzipSha256'], item['file']
        files[item['file']] = raw
    for p in directory.glob('*.phases.json'):
        files[p.name] = p.read_bytes()
    return summary, files

old_summary, old_files = read_capture(baseline)
new_summary, new_files = read_capture(candidate)
for key in ['mode', 'steps', 'initialTick', 'initialClock', 'finalTick', 'finalClock', 'constructorCount', 'importCount', 'stepCount', 'readerCount', 'worldInputSha256', 'originalInputSha256']:
    assert old_summary[key] == new_summary[key], f'Driver precondition differs: {key}'

missing = object()
different_files, receipts = [], []
diff_count = 0
with gzip.open(output / 'ALL-STRUCTURAL-DIFFERENCES.jsonl.gz', 'wt', encoding='utf8', compresslevel=6) as stream:
    def emit(file, path, kind, before, after):
        global diff_count
        diff_count += 1
        record = {'file': file, 'path': path, 'kind': kind,
                  'beforePresent': before is not missing, 'afterPresent': after is not missing}
        if before is not missing: record['before'] = before
        if after is not missing: record['after'] = after
        stream.write(json.dumps(record, ensure_ascii=False, separators=(',', ':')) + '\n')

    def differences(file, path, before, after):
        if before is missing or after is missing:
            emit(file, path, 'presence', before, after); return
        if type(before) is not type(after):
            emit(file, path, 'type-or-value', before, after); return
        if isinstance(before, dict):
            if list(before) != list(after): emit(file, path, 'own-key-order-or-presence', list(before), list(after))
            for key in dict.fromkeys([*before, *after]):
                differences(file, path + [key], before.get(key, missing), after.get(key, missing))
        elif isinstance(before, list):
            if len(before) != len(after): emit(file, path, 'array-length', len(before), len(after))
            for index in range(max(len(before), len(after))):
                differences(file, path + [index], before[index] if index < len(before) else missing, after[index] if index < len(after) else missing)
        elif before != after:
            emit(file, path, 'value', before, after)

    for name in sorted(set(old_files) | set(new_files)):
        before, after = old_files.get(name), new_files.get(name)
        equal = before is not None and after is not None and before == after
        receipt = {'file': name, 'equal': equal, 'baselineBytes': len(before) if before is not None else None,
                   'candidateBytes': len(after) if after is not None else None,
                   'baselineSha256': sha(before) if before is not None else None,
                   'candidateSha256': sha(after) if after is not None else None}
        receipts.append(receipt)
        if equal: continue
        different_files.append(name)
        if before is None or after is None:
            emit(name, [], 'artifact-presence', before if before is not None else missing, after if after is not None else missing)
            continue
        offset = next((index for index, (a, b) in enumerate(zip(before, after)) if a != b), min(len(before), len(after)))
        receipt['firstDifferentByteOffset'] = offset
        receipt['baselineContextBase64'] = base64.b64encode(before[max(0, offset - 64):offset + 64]).decode()
        receipt['candidateContextBase64'] = base64.b64encode(after[max(0, offset - 64):offset + 64]).decode()
        if '.events.jsonl' in name:
            a = [json.loads(row) for row in before.decode().splitlines()]
            b = [json.loads(row) for row in after.decode().splitlines()]
        else:
            a, b = json.loads(before), json.loads(after)
        differences(name, [], a, b)

result = {'status': 'PASS_EXACT_FULL_SAVES_EVENTS_PHASES' if not different_files else 'FAIL_EXACT_DIFFERENCES_RETAINED',
          'baseline': str(baseline), 'candidate': str(candidate), 'mode': old_summary['mode'],
          'stepsPerSource': old_summary['steps'], 'constructorCount': old_summary['constructorCount'] + new_summary['constructorCount'],
          'importCount': old_summary['importCount'] + new_summary['importCount'],
          'nativeReaderChecks': old_summary['readerCount'] + new_summary['readerCount'],
          'initialClock': old_summary['initialClock'], 'finalClock': old_summary['finalClock'],
          'allRetainedArtifactCount': len(receipts), 'differentFiles': different_files, 'fullStructuralDifferenceCount': diff_count,
          'receipts': receipts, 'baselineSourceManifestSha256': old_summary['sourceManifestSha256'],
          'candidateSourceManifestSha256': new_summary['sourceManifestSha256'],
          'decodedGzipProofsVerified': True, 'allFullSavesAndAllEventRecordsRetained': True,
          'moneyFoodCausalAudit': 'NOT_PERFORMED_NO_BALANCE_OR_SUSTAINABILITY_CLAIM',
          'scope': 'Only this original-input ordinary-step compatibility window; no v2 hydro, new money-food causal balance, long-run economy, GPU or Mac conclusion.'}
(output / 'RESULT.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: result[key] for key in ['status', 'mode', 'differentFiles', 'fullStructuralDifferenceCount']}, ensure_ascii=False))
raise SystemExit(0 if not different_files else 1)

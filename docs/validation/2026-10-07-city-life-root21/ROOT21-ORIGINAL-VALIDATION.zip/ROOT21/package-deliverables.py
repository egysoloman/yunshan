from pathlib import Path
import zipfile,json,hashlib,datetime
repo=Path('/workspace/yunshan'); work=Path('/workspace/yunshan-work/ROOT21-energy-integration-20261005-01'); out=repo/'docs/validation/2026-10-07-city-life-root21'
sha=lambda data: hashlib.sha256(data).hexdigest()
functional=json.loads((work/'build-final/inputs-before.json').read_text())
assert all(sha((repo/p).read_bytes())==h for p,h in functional.items())
source={f'functional/{p}':repo/p for p in functional}
for p in (repo/'dist').rglob('*'):
 if p.is_file():source['build/'+str(p.relative_to(repo/'dist'))]=p
for p in out.iterdir():
 if p.is_file() and p.suffix!='.zip' and not p.name.endswith('RECEIPT.json'):source['delivery/'+p.name]=p
for name in ['AGENTS.md','提示词.md','开发备忘录.md']:source['project/'+name]=repo/name
source['manifests/FINAL-392-SOURCE-MANIFEST.json']=work/'FINAL-392-SOURCE-MANIFEST.json'
source['inputs/default-World291.json']=Path('/workspace/yunshan-work/ROOT16-food-integration-20261005-01/originals/WORLD-ORIGINAL.json')
source['inputs/default-primary4610.save.json']=repo/'docs/validation/2026-10-05-city-life-root20/ROOT20-PRIMARY-1700.save.json'
source['inputs/hydro-World.original.json']=work/'native01/artifacts/fed/World.original.json'
source['inputs/hydro-TERMINAL.raw.json']=work/'native01/artifacts/TERMINAL.raw.json'
original={}
for p in work.rglob('*'):
 if p.is_file() and not p.is_symlink() and not p.name.startswith('LIBRARY-'): original['ROOT21/'+str(p.relative_to(work))]=p
for p in Path('/tmp/ROOT21-legacy-compat/run01').rglob('*'):
 if p.is_file():original['legacy/actual/'+str(p.relative_to('/tmp/ROOT21-legacy-compat/run01'))]=p
for p in Path('/tmp/ROOT21-legacy-compat/baseline-source').rglob('*'):
 if p.is_file() and not p.is_symlink():original['legacy/baseline-source/'+str(p.relative_to('/tmp/ROOT21-legacy-compat/baseline-source'))]=p
original['legacy/candidate-SOURCE-MANIFEST.json']=Path('/tmp/ROOT21-legacy-compat/candidate-source/SOURCE-MANIFEST.json')
def archive(name,files):
 target=out/name;assert not target.exists()
 manifest={key:{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for key,p in sorted(files.items())}
 with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for key,p in sorted(files.items()):z.write(p,key)
  z.writestr('ARCHIVE-MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
 with zipfile.ZipFile(target) as z:
  assert len(z.infolist())==len(manifest)+1
  for key,value in manifest.items():
   raw=z.read(key);assert len(raw)==value['bytes'] and sha(raw)==value['sha256']
 receipt={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'file':name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'originalFileCount':len(files),'expandedOriginalBytes':sum(v['bytes'] for v in manifest.values()),'everyMemberReadbackExact':True,'sourceInputs':392,'fullGoalComplete':False,'LibraryStatus':'NOT_RUN'}
 assert receipt['bytes']<30*1024*1024
 (out/(name+'.RECEIPT.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
archive('ROOT21-SOURCE-AND-BUILD.zip',source)
archive('ROOT21-ORIGINAL-VALIDATION.zip',original)
assert all(sha((repo/p).read_bytes())==h for p,h in functional.items())

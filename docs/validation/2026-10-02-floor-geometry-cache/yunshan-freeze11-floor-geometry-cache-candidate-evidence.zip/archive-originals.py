from pathlib import Path
import hashlib,json,gzip,re,zipfile,datetime
root=Path('/tmp/yunshan-floor-geometry-cache-candidate-01');out=root/'deliverables';out.mkdir(exist_ok=False)
sha=lambda v:hashlib.sha256(v).hexdigest()
base=json.loads((root/'evidence/baseline-manifest.json').read_text())['hashes'];candidate=json.loads((root/'evidence/candidate-manifest-pre-run.json').read_text())['hashes']
files={}
for side,manifest in [('before',base),('candidate',candidate)]:
 for rel,expected in manifest.items():
  p=root/side/rel;assert p.is_file() and sha(p.read_bytes())==expected;files[side+'/'+rel]=p
for name in ['candidate.patch','README-final.md','query-differential.mts','save-exact.mts','startup-perf.mts','run-pure.py','run-save-exact.py','run-startup-perf.py','archive-originals.py']:files[name]=root/name
for p in sorted((root/'evidence').rglob('*')):
 if p.is_file():files['evidence/'+str(p.relative_to(root/'evidence'))]=p
actual=Path('/tmp/yunshan-npc-public-rest-coherent11-actual-01/actual')
for name in ['actual-final-save.json.gz','after-24-actual-save.json.gz']:files['original-inputs/actual11-'+name]=actual/name
patterns={
 'private-key':rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
 'openai-secret':rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}',
 'aws-access-key':rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
 'bearer-secret':rb'(?i)authorization["\s:]+bearer\s+[A-Za-z0-9._~+/=-]{16,}',
 'github-token':rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b',
 'signed-aws-url':rb'(?i)[?&]X-Amz-(?:Signature|Credential|Security-Token)=',
 'signed-provider-url':rb'(?i)https?://[^\s"<>]{0,1500}[?&](?:signature|sig|access_token|security_token)=[A-Za-z0-9_%+./=-]{16,}',
}
counts={k:0 for k in patterns};totalBytes=0;records=[]
for name,p in sorted(files.items()):
 data=p.read_bytes();totalBytes+=len(data);records.append({'name':name,'bytes':len(data),'sha256':sha(data),'originalPath':str(p)})
 scan=gzip.decompress(data) if p.name.endswith('.gz') else data
 # The scan specification file contains regex examples, not credentials.
 if name=='archive-originals.py':continue
 for key,pattern in patterns.items():counts[key]+=len(re.findall(pattern,scan))
assert all(v==0 for v in counts.values()),counts
manifest={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'payloadCount':len(files),'payloadBytes':totalBytes,'sourceCounts':{'before':len(base),'candidate':len(candidate)},'scope':'Complete independent before105/candidate106, final patch/test, all actual failed and successful evidence/runner/save/performance originals. Library metadata helper/private receipts are outside this artifact. No node_modules/browser userdata/Git/env/credentials/signed URL. No source mutations during archived functional/benchmark runs.','sensitivePatternCounts':counts,'scanException':'archive-originals.py regex specification itself excluded from secret-pattern counting; every payload including gzip decompressed JSON was scanned otherwise.','records':records}
manifestBytes=(json.dumps(manifest,indent=2)+'\n').encode();(out/'archive-manifest.json').write_bytes(manifestBytes)
archive=out/'yunshan-freeze11-floor-geometry-cache-candidate-evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for name,p in sorted(files.items()):z.writestr(name,p.read_bytes())
 z.writestr('archive-manifest.json',manifestBytes)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None;assert len(z.namelist())==len(files)+1;assert len(set(z.namelist()))==len(z.namelist())
 for name,p in files.items():assert z.read(name)==p.read_bytes(),name
 assert z.read('archive-manifest.json')==manifestBytes
status={'status':'PASS','archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'memberCount':len(files)+1,'payloadCount':len(files),'payloadBytes':totalBytes,'crcAllMembersPass':True,'everyMemberDirectOriginalBytesEqual':True,'beforeSourceCount':len(base),'candidateSourceCount':len(candidate),'sensitivePatternCounts':counts,'createdAfterBenchmarkExited':True,'libraryStatus':'NOT_ATTEMPTED','manifestSha256':sha(manifestBytes)}
(out/'archive-integrity-status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))

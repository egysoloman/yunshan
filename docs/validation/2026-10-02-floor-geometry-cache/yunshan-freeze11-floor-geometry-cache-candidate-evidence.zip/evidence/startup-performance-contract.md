# Node 冷进程启动性能验证准备（尚未运行，等待 Root GO）

每个独立 fresh Node 进程运行 `startup-perf.mts <before|candidate> <runId>`。固定 seed20261001、完整current-v4/612楼/616居民、默认1×、08:00、不暂停，new Simulation后仅4次真实 `.25` step到tick4/08:01。不setFocus、不改settings/人口/速度/十阶段/权限/路线/体素；不Renderer/GPU、无CDP/Node CPUprofile。两边初始与最终World及full export SHA必须相同，且每轮World不变。源码105/106与runner start/end逐SHA守卫。

拟顺序：before-01 → candidate-01 → candidate-02 → before-02，各为fresh Node，且一次只有一个性能进程；此前功能/原存档测试全部结束才启动，不并发GPU或其他Sim。每个进程同样包含createWorld造成的原descriptor预热和首次真实tick的派生cache创建；不单给candidate预热或比较warm candidate与cold before。

记录完整进程墙钟（launcher）、脚本入口后的总wall/CPU、resourceUsage.maxRSS与末RSS；另逐阶段记录模块导入、World生成、Simulation构造、每一tick和只读integrity/export序列化的wall/CPU/RSS。导入与SHA/JSON观察开销清楚单列，不能将总值全部归geometry。该阶段计时不产生新的采样profile。

若两pair任一源码/World/export不一致或程序失败，则立即fail-stop、保原件；不输出收益。四轮相同最终SHA后再给每pair及整体总CPU/墙钟/真实4tick阶段比较，不把Linux Node转成browser/FPS/GPU/Mac数字。只有2轮/侧，偏差与JIT/OS调度/导入差异保留。

时长预估待当前保存验证完成再给Root：World/Sim构造及首次route是主成本，4fresh轮可能接近4分钟；如当前default24段显示更长，建议先1pair（before→candidate）确认收益和哈希，再由Root决定反序第2pair，不自动扩大。当前只有脚本准备，未运行任何性能程序。

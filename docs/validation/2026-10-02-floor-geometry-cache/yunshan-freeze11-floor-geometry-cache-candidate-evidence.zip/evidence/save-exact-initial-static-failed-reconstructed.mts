import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { Simulation as OldSimulation } from './before/src/simulation.ts';
import { Simulation as NextSimulation } from './candidate/src/simulation.ts';
import { createWorld as oldWorld } from './before/src/world.ts';
import { createWorld as nextWorld } from './candidate/src/world.ts';
import { selectSavedWorld as oldSelect } from './before/src/persistence/world-layout.ts';
import { selectSavedWorld as nextSelect } from './candidate/src/persistence/world-layout.ts';
import * as oldGeometry from './before/src/architecture-floor-plan.ts';
import * as nextGeometry from './candidate/src/architecture-floor-plan.ts';

const startedAt=new Date().toISOString(),sha=(s:string|Buffer)=>createHash('sha256').update(s).digest('hex'),evidence:any[]=[];
function sourceHashes(side:'before'|'candidate'){
  const baseline=JSON.parse(readFileSync(new URL('./evidence/baseline-manifest.json',import.meta.url),'utf8')).hashes;
  const names=Object.keys(baseline);if(side==='candidate')names.push('tests/floor-plan-derived-cache.test.ts');
  return Object.fromEntries(names.map(name=>[name,sha(readFileSync(new URL(`./${side}/${name}`,import.meta.url)))]));
}
const sourcesBefore={before:sourceHashes('before'),candidate:sourceHashes('candidate')};
for(const mode of ['native-r5','current-v4'] as const){
  const native=mode==='native-r5'?gunzipSync(readFileSync(new URL('./before/tests/fixtures/world-layout/r5-native-ui-export-coherent02.json.gz',import.meta.url))).toString('utf8'):null;
  if(native){assert.equal(Buffer.byteLength(native),1798521);assert.equal(sha(native),'7ba76f550f9f5413cd712022b751599340cc24e9e48327674f88b2c122af6fe9');}
  const a=native?oldSelect(native).world:oldWorld(20261001,'current-v4'),b=native?nextSelect(native).world:nextWorld(20261001,'current-v4');assert.deepEqual(a,b);
  const worldBefore=sha(JSON.stringify(a)),left=new OldSimulation(a),right=new NextSimulation(b);
  if(native)for(const sim of [left,right]){const result=sim.importSave(native);assert(result.ok,result.message);assert.equal(sim.exportSave(),native);}
  const original=left.exportSave();assert.equal(right.exportSave(),original);writeFileSync(new URL(`./evidence/${mode}-initial-save.json`,import.meta.url),original);
  const beforeQuery=left.exportSave();
  for(let i=0;i<a.buildings.length;i+=61){const oldBody=oldGeometry.getBuildingBody(a.buildings[i]),newBody=nextGeometry.getBuildingBody(b.buildings[i]);assert.deepEqual(oldBody,newBody);if(!oldBody||!newBody)continue;for(const p of oldBody.floorPlans){const q=newBody.floorPlans.find(q=>q.floor===p.floor)!,from=oldGeometry.buildingWorldPosition(a.buildings[i],{...p.usePoint,y:p.y}),to=nextGeometry.buildingWorldPosition(b.buildings[i],{...q.usePoint,y:q.y});assert.deepEqual(oldGeometry.floorPlanSupport(a.buildings[i],p.floor,from),nextGeometry.floorPlanSupport(b.buildings[i],q.floor,to));}}
  assert.equal(left.exportSave(),beforeQuery);assert.equal(right.exportSave(),beforeQuery,'geometry reads do not mutate native save state');
  // Public pause command only resumes the actual imported paused native game.
  // Clock, speed, actor needs, funds, routes, beds and voxels are never edited.
  if(native)for(const sim of [left,right])assert(sim.command({type:'pause',value:0}).ok);
  const startTick=left.state.tick,ticks=[];
  for(let i=0;i<24;i++){left.step(.25);right.step(.25);const actual=left.exportSave();assert.equal(right.exportSave(),actual,`${mode}: actual tick ${i+1} full export`);assert.equal(left.state.tick,startTick+i+1);ticks.push({tick:left.state.tick,sha256:sha(actual)});}
  const final=left.exportSave();writeFileSync(new URL(`./evidence/${mode}-final-save.json`,import.meta.url),final);assert.equal(sha(JSON.stringify(a)),worldBefore);assert.equal(sha(JSON.stringify(b)),worldBefore);
  evidence.push({mode,scope:'two actual CPU Simulation instances; native import and geometry reads before 24 serial .25 steps each; no profile/GPU/night audit/performance claim',initialSaveSha256:sha(original),finalSaveSha256:sha(final),worldSha256:worldBefore,initialTick:startTick,finalTick:left.state.tick,ticks});console.log(JSON.stringify({mode,status:'PASS',stepsEach:24,finalTick:left.state.tick}));
}
const sourcesAfter={before:sourceHashes('before'),candidate:sourceHashes('candidate')};assert.deepEqual(sourcesAfter,sourcesBefore);
writeFileSync(new URL('./evidence/save-exact-result.json',import.meta.url),JSON.stringify({status:'PASS',startedAt,endedAt:new Date().toISOString(),sourcesBefore,sourcesAfter,evidence},null,2)+'\n');

# 隔离几何派生缓存候选（尚未运行）

基线是冻结 11 的全部 105 输入逐 SHA 相同复制。candidate 仅修改 `src/architecture-floor-plan.ts` 并新增正式 `tests/floor-plan-derived-cache.test.ts`，共 106 输入。共享仓库、冻结 11、旧证据不改。

## 依赖及既有语义

邻层列表每次查询扫描当前 body.floorPlans，按原 filter 条件和顺序核对当前成员；floor 数值、成员、顺序、增删/替换/稀疏槽均可见。踏步/转台列表核对当前近层展开成员，保 live StairSurface 对象引用。内部 solid 包装逐项核对旧 wallPanels 返回数组、live fixtures、stair surface 和旧 slabRegions 返回数组的 rect 引用、实际 bottom/top/steppable；nested rect 数值直接共享，替换 rect 或 copied height 变化重建。异常 sparse stairs/upper slabs 回退原 localSolids 的派生过程，保 priming 和消费短路。

支撑 footprint 边界缓存独立于 canStand 的既有 supportCache.boundaries。只快照旧 getFloorPlanSlabRegions 当前返回 rect 的坐标及成员/槽、当前 stair rect 坐标/top、p.y。变化清空 byTop；因此地图只含当前 p.y 和当前 stair tops，不积累旧动态高度。点、radius、床预约/可用、权限、动态 voxels、费用均不缓存。radius zero 仍按中心支撑判断，不提前计算边界；旧 wall/slab/body/roof/routeGrid 的生命周期未重算。

## 静态成本

未变化 dense 查询需要一次 F 楼层成员扫描、一次 S 踏步成员扫描、一次 D solid 引用/height扫描；支撑第一次 disk 判定再做 B 楼板和 S 踏步坐标核对。当前可避免原 localSolids 内三次邻层列表分配、多次 spread/flatMap/map，以及每个 point/top 重建完整 boundaryLoops。warm cache 路径不分配 O(F+S+D) 数组或 solid 对象，仅保原 supportedAt Map 和一个 O(1) check closure。第一次/真实 mutable 变化仍构建派生数组和必要边界，旧程序的实际碰撞/支撑计算逐次执行。按当前 FloorPlan 对象有界的 WeakMap 不代表已测内存收益；依赖扫描的实际净性能待独占同条件运行。

## 拟执行范围，等待 Root GO

1. `node --import tsx --test tests/floor-plan-derived-cache.test.ts`：5 项具体 fixture/wall-panel/slab/stairs/near-floor mutable 前后碰撞和支撑断言，含 .35/0、+.22/-.42/1.72、nested rect 替换、旧描述缓存寿命和稀疏槽。无 Simulation。
2. 根目录 `node --import ./candidate/node_modules/tsx/dist/loader.mjs query-differential.mts`：八用途楼体选择，真实多个楼层/人工 basement+旋转 clone，真实上下 tread 点、支撑边、孔、fixture 顶、功能点、实际路由；33 顺序 mutable probe 和 sparse 异常；四旧 recipe World/未标记几何；两完整生成 World 查询前后字节相同。baseline/candidate 查询完整返回对象与异常 name/message 严格相同。无 Simulation。
3. 根目录 `node --import ./candidate/node_modules/tsx/dist/loader.mjs save-exact.mts`：原 native r5 gzip/hash/1798521B import/export、当前 v4 默认 1x 初始 full-save、只读 geometry 后状态不变、两实例各 24 个真实 .25 step，每步 full export 逐字；完整 source 与 World 前后同。不是自然夜审计。
4. 原相关 provider/controller/world test 文件是否加入本次范围由 Root 明确选择；未自行 npm test/大套/默认 night。所有性能测试和新的 profile/GPU 等待单独 GO。

## 当前验证边界

首次和最终 candidate 严格 `tsc --noEmit` 已 exit 0；运行测试、Simulation、性能、build/browser 仍 NOT_RUN。11 的既有相关49/native105+24、09 full496、10 browser0/11/首夜FAIL不迁给候选。合并后仍需新冻结12/同源 build、规则及原default存档/串行GPU验证。候选不解决粮食覆盖、通用 NPC 动态途中碰撞、城市美术、默认稳态或 Mac 性能。

# 楼层派生结构缓存：只读静态可变契约审查

本报告主体为静态分析，末尾另记录已存在的父任务运行回执读回。本审查没有运行测试、Simulation、GPU、profile 或性能测量，没有编辑共享源码、冻结 before 或候选源码。唯一写入是本报告。独立只读子代理检查了相关测试，未执行测试。

已读 `/workspace/yunshan/AGENTS.md`、`提示词.md`、`开发备忘录.md` 的 2026-10-02 16:04 最新入口与既有 provider 优化记录。`/workspace/.agents` 为空；仓库没有 `.agents/skills` 或更下层 AGENTS。现有分支为 `takeover-city-life`，共享工作树本来有未提交改动，本审查未动它们。

冻结 before provider SHA256：`0a7d728e2714b2465002f509ff7ce8f389c4505cd3ff05070961336bd3a9ba78`。

本轮最终已静态检查候选 SHA256：`b4d0c35fb868deedfb10e14128c2f3255a1f3a5f3b54f2f853afb0d2656a4d42`。此 SHA 版本已修复 `nearPlans` 的 sparse floorPlans、footprint base 的 sparse presence 检查、localSolids 的 sparse upper slabs/stairs 旧派生 fallback，以及 mixed valid-stair+hole 的异常读取字段顺序。后续版本须重新读取，不能把此版本审查冒称未来版本已通过。此前 `13500d7c` 的两个 localSolids 差异与 `95eb4b04` 的 mixed-stair 错误文本差异作为简短失败事实保留。

本轮最后静态读核新增测试 SHA256：`1d87502fa01a13a00514937530bce88008f8f7d866ac27d155d3c9bd53907963`。该版本已补 cold cloned FloorPlans 的 radius-zero descriptor lifetime 和直接 p.y/position/radius 修改后恢复回归。

## 既有缓存的语义，必须原样保留

| 缓存 | 当前生命周期与可变行为 | 既有风险，不能在本次偷偷改变 |
| --- | --- | --- |
| `wallPanels` / `panelCache`，before 243–261 | 以 FloorPlan 身份缓存第一次生成的 WallPanel 数组；以后返回同一公开数组。raw `walls`、端点、opening/windows 的修改或源数组替换不会重建已缓存面板。直接修改返回数组、panel.top/bottom 或 panel.rect 会被后续消费者读取。 | raw 墙描述与面板可以不一致；render/collision 使用同一面板缓存，而 routeGrid 已计算的布尔 walkability 仍有自己的旧生命周期。新增 solid 缓存应读取当前 panel 缓存返回值，不能重新从 raw walls 推导。 |
| `supportCache`，before 262–273 | 首次从 interior/circulation/courtyard 与 hole/landing 生成 regions 和 boundaries；返回同一个公开 regions 数组，boundaries 私有且不重建。无 hole 时 regions 是源 rect 引用的浅合并；有 hole 时 rectangleCover 产生新 rect，另保留 stairLanding 引用。 | 无 hole 的源 nested rect 修改可以影响 live regions；有 hole 时被 cover 拷贝的源 rect 修改一般不影响旧 regions。直接 regions push/splice 或 rect 坐标修改影响 slab/contains 查询，但旧 `canStandInFloorPlan` 的 cached boundaries 不更新。`floorPlanSupport` 现有 footprint 边界却从 live regions 重新派生；不能改用旧 supportCache.boundaries 代替。 |
| `bodies` / BodyCache，before 209–224 | Building 身份 WeakMap；每次检查 13 primitive 值和 floorFootprints/floorUses/floorPermissions 三个引用。命中时返回同一公开 BuildingBody；body.floorPlans、plan 数组和 nested 对象均可直接修改。 | 在原数组内修改 footprint width/depth、uses 或 permissions 不使 body 重建；普通 id、door、basementUses 也不在旧失效键中。marker/core/pavilion 为每次门控。新增缓存必须先从原 getBuildingBody 得到当前 body，不能增加 raw Building 深度失效来改变旧 body 身份/生成行为。 |
| `routeGrids`，before 362–368 | FloorPlan 身份 → 按精确 number radius 的 Map；x0/z0/nx/nz/.8 step/walkable 首次生成后不失效。网格点的 y 在路线查询时仍读当前 p.y。 | broadphase/slab/panel/fixture 修改不会更新既有 walkable；每条边仍通过 live localSegmentClear 与外部 segmentBlocked 校验，不能把 grid 命中当动态通行批准，也不能本次顺手刷新旧 grid。原 radius Map 可能被任意输入扩展，属于既有范围。 |

`roofCache` 同样是旧 BuildingBody 身份生命周期缓存；公开 RoofRegion 返回值可变。它未被候选改动，应保持原行为。

半径零查询也有既有副作用：before 312–317 明确在不分配 solids 时仍按邻层顺序调用 `wallPanels`，并对上层调用 `getFloorPlanSlabRegions`。冷 cloned floorPlans 的 radius-zero 查询之后追加 raw wall，旧面板缓存必须继续忽略该 wall；直接往返回的 panel 数组追加同位置障碍则必须影响后续身体查询。原 `/tmp/yunshan-v4-provider-perf-01/cold-cache-check.mjs` 与已归档 `cold-cache-result.json` 就是这一契约的历史证据，本审查只读取它们。

## 新派生缓存的精确依赖与静态结论

| 派生结构 | 必须保持的依赖与顺序 | 本轮静态判断 |
| --- | --- | --- |
| `nearPlans` | 当前 getBuildingBody 返回体的 floorPlans；逐个读取 f.floor 与 p.floor，保持 `abs(f.floor-p.floor)<=1` 的成员序列、重复项及 filter skip-hole 语义。选中成员序列相同即可复用；仅因 source array 引用不同而强制重建不是必要条件。 | 修订版以 index/in 验证当前选中序列，每次仍取 getBuildingBody。p.floor/f.floor 修改和 push/splice/reorder/replace 都会重新计算选择；即使数组引用变但选中序列完全相同，复用值仍等价。 |
| `stairSurfaces` | 邻层顺序 → 各层 stairTreads 再 stairLandings 的原成员序列；保留原 StairSurface 对象引用。 | 成员引用序列校验足够，因为 top/bottom/fromFloor/toFloor/rect 等 nested 字段继续从同一对象读取。不能把这些对象深拷贝后仅按数组长度失效。当前实现符合 dense typed 数据的引用语义；sparse 的 flattened undefined 必须由 localSolids 的旧 object-spread 语义处理。 |
| `localSolids` | 先各邻层 wallPanels 返回值再 live fixtures；再所有 stair surfaces；最后 f.floor>p.floor 的旧 slab cache 返回值。wall/fixture 复制高度为 f.y+bottom/top；stair 复制绝对 bottom/top；ceiling slab 为 f.y-.2/f.y。rect 保留引用。 | 候选逐项检查 rect 引用、复制后的 bottom/top、steppable 和总项数，且读取旧 wall/slab 缓存，覆盖 dense 数据的 observable geometry。nested rect 坐标不必使包装数组重建，因原 rect 引用仍 live；rect 被替换和 copied 高度变化会重建。stair id/kind/from/to 未放进 LocalSolid，但碰撞消费者从不读取这些 extra fields；support/link 仍读 live surfaces。当前新增 uncachedLocalSolids 在 sparse surfaces/upper slabs 回退到旧 map/flatMap/spread，保密化、消费短路和 descriptor priming。 |
| support footprint / boundary | live base regions 的完整成员顺序、每个 rect 引用与四个原始坐标；live surfaces 的成员几何顺序、top、rect 引用及四坐标；p.y。每个查询 top 按原 +.22/-.42/eps 选 steps；local x/z/radius/feet 的 supported bool 每次重新计算。 | 坐标快照保留 raw 数字，未按 q/snapped 值替代；nested 坐标、surface top 与 p.y 变化会清空当前 byTop。边界私有，不改变公开 `boundaryLoops` 每次新返回 nested arrays 的行为。radius===0 短路不求边界、later nonzero lazily 求边界，原比较和 footprint 包含顺序保持。修订版已比较 base 的 index presence，避免 every 跳过 deleted hole 而误命中。 |
| `byTop` 有界性 | 只能出现当前 p.y 和当前 surface.top 的 queried 高度；有关几何或高度变化时丢弃整 Map，不能无限积累历史高度。 | 静态调用点只将 p.y 或 surface.top 送入 diskSupportedAt，fixtures top 不送入。缓存替换时新建 Map，因此每个当前几何版本最多 1+当前 surfaces.length 个不同 top，WeakMap 生命周期随 FloorPlan。 |

新增 `supportFootprints` 不缓存“可以休息/可达/已到场”或 diskSupported bool，不涉及身份、权限、NPC 预约、需求、现金、时间/phase 或动态体素。路线 callback 与屋顶碰撞仍走原路径。所有性能收益与真实保存等价均未在本审查执行验证。

## 本轮发现与具体回归序列

1. **最初 nearPlans sparse 差异已静态修复。** 取三层 dense body，查询 floor0，再 `delete body.floorPlans[2]`。旧 floor0 find 在首项命中、near filter 跳过末项孔；最初候选 for-of 会读取 undefined.floor 而抛错。当前 index/in 版本保留 filter skip-hole。

2. **最初 footprint sparse base 差异已静态修复。** 在一个 clean room 点以 .35 查询、prime byTop 与 boundaries；保留能包含该点的早期 base rect，只 delete slabRegions 中一个不含此点的后部元素，length 不变。旧 disk footprint spread 会把孔密化为 undefined，非零半径 boundary validation 抛错；最初候选 base.every 跳过孔而复用旧 dense regions。当前 presence 比较会失效，base.map 仍保 hole，随后 spread 保持原密化和边界错误。

3. **早先 sparse upper slab 差异已静态修复。** 取正常有上层的 floor0 clean support 点，prime 上层 slab，然后 delete `getFloorPlanSlabRegions(upper)[k]` 的一个末部元素。旧 localSolids 的 `push(...regions.map(...))` 使 hole 在 result 中成为显式 undefined；后续 solids.some 到该项会访问 undefined.top 而抛错。早先候选 for-of 为孔生成 `{rect:undefined,bottom:f.y-.2,top:f.y}`，该 ceiling 可以因高度跳过而不抛错。当前 `uncachedLocalSolids` 保持旧 map+spread 的原密化语义；没有整体提前抛错，旧 .some 也可能因之前的障碍短路。

4. **早先 sparse stair/landing 的 priming 顺序差异已静态修复。** 对 fresh cloned plan 删除 stairTreads/landings 一个元素，直接调用 blocksFloorPlanMovement。旧 flattened undefined 经 `{...undefined,steppable:true}` 成为只有 steppable 的对象，localSolids 仍先完成 upper slab priming，消费时才因 rect 缺失抛错。早先候选先读取 s.rect，在 slab priming 前抛错。当前 `uncachedLocalSolids` 回退保原 priming 顺序。floorPlanSupport 在 surfaces.some 处两版都先抛错，所以必须有直接 movement fixture，并在捕获错误后修改 raw upper interior/hole 再读 slab，才能检查缓存 lifetime。

5. **建议 dense 修改矩阵。** 每个 API cold→warm→mutation→warm→restore；分别覆盖 fixture push/splice/reorder/array replace、member top/bottom/rect replacement/rect coordinate change；returned panels 同项；returned slab regions 同项；floorPlans 替换/成员 reorder/f.floor 改变；stairs/landings top/bottom/fromFloor/toFloor/rect 与数组修改；p.y 修改；足量上层 ceiling slab。每步比较完整 support 值、movement bool 与 route 数组或完整错误，且保旧 raw wall/slab 不重建行为。

6. **建议 footprint 高度边界。** 以真实 p.y、每个 stair.top 和 `.22/.42` 窗口端点 ±eps 的 world feet 查询；radius 0→.35→0 与 .35→0→.35；同 top 改 raw rect 四坐标后恢复；相同 snapped cuts、不同 raw 坐标也要比较。private boundary cache 不得只按 top 或 snapped shape 命中。修改 surface top 多次后检查仅当前 byTop 可达，不以 radius 或任意 query local.y 扩 Map。

7. **建议 route 独立顺序。** 同 from/to 在全新 FloorPlan、radius0 priming 后、positive support priming 后、重复 path 查询后比较完整 Vec3[]；同输入切换 live segmentBlocked callback，仍应拒绝当前障碍；原 routeGrid stale 的 mutation 行为须 baseline/candidate 一致，不能要求它突然刷新。

8. **mixed valid stair + hole 的异常读取字段差异已静态修复。** 用 `[有效 tread, hole]`，让查询点落在有效 tread 上，两个 surfaces.some 在首项短路，然后进入 diskSupportedAt。旧 nearStepRects.filter 在 hole 读取 undefined.top；95eb4b04 的 surfaces.map 快照先读取 undefined.rect，Error.message 不同。当前将 stair snapshot 的 top 读取置于 rect snapshot 之前，冷/rebuilt snapshot 和 warm validation 遇到孔都先读取 top，保旧字段错误。外部 probe 已补 `stairs-mixed-hole`，准备完整捕获 name/message 比较；此回归尚未由本审查运行。

9. **此前建议的两个回归范围现已补入正式测试。** 当前 test 39–42 行先 `body.floorPlans=structuredClone(body.floorPlans)`，清 raw walls/hole，再 radius0 prime→raw wall push/upper.interior 数组替换→检查已缓存 panel/slab 与 .35 support，明确把 descriptor lazy lifetime 与 makeBody 已预热区别开。49 行直接令 queried p.y=.2，配合 world feet=.2 查询，再对未变 footprint 改 position/radius，最后恢复 p.y=0 并查支撑。它们现在是现有覆盖，不再列为未补缺口。

## 当前测试覆盖与缺口

- `tests/architecture-floor-plan.test.ts:6–18` 有原真实门、用途点 room 支撑、踏步薄度/量化/包络和 hole/platform slab；21–27 有门与玻璃；30–38 有 roof 支撑/碰撞。它没有 prime→nested mutation 的系统性断言。
- `tests/home-rest.test.ts:158–163` 明确先取得床点再 push public fixtures 障碍，要求 restPoint null、command 拒绝且 save 不变。这是现有最直接的 cache 后 mutable array 回归。
- `tests/world-v4.test.ts:123–126` 直接改 opening.height、interior[0].x0、courtyard[0].x0、stair.x，要求 fingerprint 变化并可恢复；这是 public nested mutation 合法的直接证据，但只检查 fingerprint，不能理解成所有旧描述缓存都刷新。
- `tests/controller-v4.test.ts:60–82` 与 110–118、`tests/v4-simulation.test.ts:72` 覆盖真实 stairs、headroom、hole、途中重规划和 fixture 碰撞；`tests/architecture-bodies.test.ts:34/68/94` 覆盖 near/far roofs、open courts、上层空间净空。没有发现同一线路在不同 priming 顺序/冷热缓存后的严格路线数组相等断言。
- 历史 provider cold-cache probe 明确保留 public wall cache lifetime；它不能替代本候选每类新增 private cache 的 mutation 检查。
- 当前候选另有 `tests/floor-plan-derived-cache.test.ts` 五项实质 CPU 几何 fixture 和外部 `query-differential.mts`；本审查已静态阅读，未执行。新五项覆盖 fixture/panel/slab/upper-membership/stairs 的主要 nested 修改，并已补上述 cold clone、p.y 与 live query 参数回归。外部 probe 比较 baseline/candidate 的真实族、多层/旋转/孔/双跑、radius0/.35、旧四配方与顺序 mutable/sparse 查询。已有父任务真实运行回执另见下一节，不能归为本只读审查亲自运行。

## 已有父任务运行回执读回，保留首次失败

本审查只读取 `evidence/attempt01/new-mutable-tests.log`、当前 `new-mutable-tests.log`、`original-related-tests.log`、`query-differential.log`、`query-differential-result.json` 和 `pure-run-status.json`，没有重新执行其命令。

- 首次新五项实际为 3/5，原件保留在 `evidence/attempt01/`。两个失败是 fixture 误解旧合同：无 stairHole 时旧 slab cache 浅引用原 Rect，所以 `coldUpper.interior[0].x1=.2` 本来就会把 returned slab x1 改为 .2；以及 stair.x1=.1 被原 .2 lattice boundary 切分/占用采样视为无该期望 gap。最终只把 test 改为替换 upper.interior 数组与 stair.x1=0 的真实 lattice gap；provider SHA 未变。静态 diff 只见这两处测试修订，原完整身体半径、阈值与预期拒绝保持。
- 当前新五项日志为 tests 5/pass 5/fail 0；原相关日志为 tests 37/pass 37/fail 0；差分日志为 PASS、2662 queries、17 matchingErrorQueries、49 cases。`pure-run-status.json` 记录三程序按序 exitCode 0，开始 2026-10-02T16:28:10.445413+00:00，结束 16:29:18.938484+00:00，`sourceUnchanged: true`。其 provider/test SHA 与本轮读核版本相同。
- 这仅是父任务已有 CPU 几何与相关规则证据，不能扩成完整全套、native save、Simulation 长期经济、GPU、美术、性能收益或 macOS 结论；正在另行执行的 native save 不属于本审查范围。

## 限制与当前结论

对 dense、合法 typed 几何和普通 data-property 对象，本 SHA 候选新缓存的依赖与 nested mutation 处理静态上完整，旧 descriptor/cache 生命周期与 radius-zero priming 未被主动改写。此前发现的 sparse filter/base-presence/localSolids 及 mixed valid-stair+hole 异常字段差异均已静态确认修复；当前无剩余静态阻碍。cold cloned descriptor radius-zero 与直接 p.y/live position/radius 回归已补，已有父任务受限验证回执读回如上；本审查没有自行运行验证，不能据此声称完整实现等价或性能收益。

静态性能/空间限制：nearPlans 仍扫描当前完整 floor list，localSolids 仍逐项比较当前 solids，footprint 每次首次使用仍验证 base/stairs 的全部原坐标；因此这里只减少重建与边界计算，不能从代码结构直接断言 CPU 收益。新增弱缓存随 FloorPlan 保留 private 数组和当前 byTop 边界；Map 条数有界，但每个条目重复持有 base/near-step 引用并保存自己的 loops，仍有空间成本。应由实现方在既有授权范围内实际测量，不能把静态有界性当作 macOS 或整城性能结论。

本分析不将 JS accessor/proxy 的重入副作用视为项目已有数据契约；如果外部刻意用 getters 在读取过程中改 body/arrays，减少 nearPlans/getBuildingBody 重复读取可改变该副作用的时序。普通公开数组/nested mutation（包括 delete 形成孔）已明确纳入本轮检查，不因性能理由把它们忽略。

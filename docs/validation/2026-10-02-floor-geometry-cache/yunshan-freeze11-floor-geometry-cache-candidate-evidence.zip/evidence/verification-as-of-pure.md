# 截至 2026-10-02 16:29:18 UTC 的实际状态

provider SHA `b4d0c35fb868deedfb10e14128c2f3255a1f3a5f3b54f2f853afb0d2656a4d42`；新 test SHA `1d87502fa01a13a00514937530bce88008f8f7d866ac27d155d3c9bd53907963`；apply-ready patch SHA `b6b28a748e3c3bc4b0d5f8623fb018a7ebd1c70db5040698bf8a79152936197a`。

实际两轮均各自固定基线105/候选106输入，source 首尾无变化；第二轮仅修新增 fixture，provider不改。

第一次新5项实际3PASS/2FAIL、exit1，16:24:53.004263→16:25:12.798530 UTC。顺序立即停止，原相关/外query未跑。完整测试源码、patch、日志、status和manifest保存在 `attempt01/`。两失败不是候选运行等价证明：cold no-hole slab保原interior rect引用，nested edit本就live；tread边.1按原.2格切割量化到.2后仍闭合。只改测试为array replacement与真实格点gap=0，未改规则。外query另保两个原失败输入，硬断言old与candidate实际同result。

第二次顺序实际16:28:10.445413→16:29:18.938484 UTC、exit0：新5/5；原 architecture-floor-plan/controller-v4/home-rest/npc-home-rest-voxels 四文件37/37；外部完整返回对象差分2662query、17同异常、49case PASS。两完整生成 World查询前后字节同，四旧recipe和实际多族楼体/多层/上下梯/孔/旋转/mutable/sparse覆盖详见 query-differential-result.json。这些计数不是完整suite，不挪用冻结11/09/10的既有结果。

三次 candidate严格 tsc及external最终tsc均exit0。首次external tsc因runner的find变量q隐式any失败，原日志 `runner-static-tsc.log` 保留，只修runner局部类型注解后pass。

独立静态review最终已核b4d0；报告保先前 sparse 与错误字段差异发现和修订事实。所有新缓存只为内部纯派生结构；既有wall/slab/body/roof/routeGrid生命周期不变。缓存验证每query仍有线性扫描，byTop虽按当前geometry有界但会保留边界对象，实际CPU/内存净收益尚未测。

完整 native baseline→candidate import/export+24真实step runner已准备，当前尚未运行，等待Root具体GO。无新GPU、profile、性能、默认night、大套、build、commit/push/Library；共享源码和冻结11/原证据未修改。合并后需新冻结12同源验证。

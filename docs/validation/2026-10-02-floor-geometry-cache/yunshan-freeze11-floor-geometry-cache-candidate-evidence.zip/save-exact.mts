import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { Simulation as OldSimulation } from './before/src/simulation.ts';
import { Simulation as NextSimulation } from './candidate/src/simulation.ts';
import { createWorld as oldWorld } from './before/src/world.ts';
import { createWorld as nextWorld } from './candidate/src/world.ts';
import { selectSavedWorld as oldSelect } from './before/src/persistence/world-layout.ts';
import { selectSavedWorld as nextSelect } from './candidate/src/persistence/world-layout.ts';
import * as oldGeometry from './before/src/architecture-floor-plan.ts';
import * as nextGeometry from './candidate/src/architecture-floor-plan.ts';
import type { FloorPlan } from './candidate/src/architecture-floor-plan.ts';

const startedAt=new Date().toISOString(),sha=(s:string|Buffer)=>createHash('sha256').update(s).digest('hex'),evidence:any[]=[];
const actualRoot='/tmp/yunshan-npc-public-rest-coherent11-actual-01/actual/',actualOriginalPath=actualRoot+'actual-final-save.json.gz',actualAfter24Path=actualRoot+'after-24-actual-save.json.gz';
const nativePath=new URL('./before/tests/fixtures/world-layout/r5-native-ui-export-coherent02.json.gz',import.meta.url);
const inputs=[['native-r5',nativePath],['actual07-original',actualOriginalPath],['actual07-after24',actualAfter24Path]] as const;
const inputHashes=()=>Object.fromEntries(inputs.map(([name,path])=>{const gzip=readFileSync(path),raw=gunzipSync(gzip);return [name,{gzipSha256:sha(gzip),rawSha256:sha(raw),gzipBytes:gzip.length,rawBytes:raw.length}];}));
const inputsBefore=inputHashes(),runnerShaBefore=sha(readFileSync(new URL('./save-exact.mts',import.meta.url)));
assert.equal(inputsBefore['actual07-original'].rawSha256,'03e7155cdaddce72a3e09fdb8dda49017f6b4d03771976d7356781fbf38f79f6');
function sourceHashes(side:'before'|'candidate'){
  const baseline=JSON.parse(readFileSync(new URL('./evidence/baseline-manifest.json',import.meta.url),'utf8')).hashes;
  const names=Object.keys(baseline);if(side==='candidate')names.push('tests/floor-plan-derived-cache.test.ts');
  return Object.fromEntries(names.map(name=>[name,sha(readFileSync(new URL(`./${side}/${name}`,import.meta.url)))]));
}
const sourcesBefore={before:sourceHashes('before'),candidate:sourceHashes('candidate')};
assert.deepEqual(sourcesBefore.before,JSON.parse(readFileSync(new URL('./evidence/baseline-manifest.json',import.meta.url),'utf8')).hashes);
assert.deepEqual(sourcesBefore.candidate,JSON.parse(readFileSync(new URL('./evidence/candidate-manifest-pre-run.json',import.meta.url),'utf8')).hashes);
for(const mode of ['native-r5','current-v4','actual07'] as const){
  const native=mode==='native-r5'?gunzipSync(readFileSync(nativePath)).toString('utf8'):mode==='actual07'?gunzipSync(readFileSync(actualOriginalPath)).toString('utf8'):null;
  if(mode==='native-r5'){assert.equal(Buffer.byteLength(native!),1798521);assert.equal(sha(native!),'7ba76f550f9f5413cd712022b751599340cc24e9e48327674f88b2c122af6fe9');}
  const a=native?oldSelect(native).world:oldWorld(20261001,'current-v4'),b=native?nextSelect(native).world:nextWorld(20261001,'current-v4');assert.deepEqual(a,b);
  const worldBefore=sha(JSON.stringify(a)),left=new OldSimulation(a),right=new NextSimulation(b);
  if(native)for(const sim of [left,right]){const result=sim.importSave(native);assert(result.ok,result.message);assert.equal(sim.exportSave(),native);}
  if(mode==='current-v4')for(const sim of [left,right]){assert.equal(sim.state.tick,0);assert.equal(sim.state.day,0);assert.equal(sim.state.hour,8);assert.equal(sim.state.speed,1);assert.equal(sim.state.paused,false);}
  if(mode==='actual07')for(const sim of [left,right]){assert.equal(sim.state.speed,16);assert.equal(sim.state.paused,false);}
  const original=left.exportSave();assert.equal(right.exportSave(),original);writeFileSync(new URL(`./evidence/${mode}-initial-save.json`,import.meta.url),original);
  const beforeQuery=left.exportSave();
  for(let i=0;i<a.buildings.length;i+=61){const oldBody=oldGeometry.getBuildingBody(a.buildings[i]),newBody=nextGeometry.getBuildingBody(b.buildings[i]);assert.deepEqual(oldBody,newBody);if(!oldBody||!newBody)continue;for(const p of oldBody.floorPlans){const nextPlan:FloorPlan=newBody.floorPlans.find(plan=>plan.floor===p.floor)!,from=oldGeometry.buildingWorldPosition(a.buildings[i],{...p.usePoint,y:p.y}),to=nextGeometry.buildingWorldPosition(b.buildings[i],{...nextPlan.usePoint,y:nextPlan.y});assert.deepEqual(oldGeometry.floorPlanSupport(a.buildings[i],p.floor,from),nextGeometry.floorPlanSupport(b.buildings[i],nextPlan.floor,to));}}
  assert.equal(left.exportSave(),beforeQuery);assert.equal(right.exportSave(),beforeQuery,'geometry reads do not mutate native save state');
  // Public pause command only resumes the actual imported paused native game.
  // Clock, speed, actor needs, funds, routes, beds and voxels are never edited.
  if(mode==='native-r5')for(const sim of [left,right])assert(sim.command({type:'pause',value:0}).ok);
  const startTick=left.state.tick,ticks=[];
  for(let i=0;i<24;i++){left.step(.25);right.step(.25);const actual=left.exportSave();assert.equal(right.exportSave(),actual,`${mode}: actual tick ${i+1} full export`);assert.equal(left.state.tick,startTick+i+1);ticks.push({tick:left.state.tick,sha256:sha(actual)});}
  const final=left.exportSave();writeFileSync(new URL(`./evidence/${mode}-final-save.json`,import.meta.url),final);assert.equal(sha(JSON.stringify(a)),worldBefore);assert.equal(sha(JSON.stringify(b)),worldBefore);
  if(mode==='actual07'){const expected=gunzipSync(readFileSync(actualAfter24Path)).toString('utf8');assert.equal(final,expected,'baseline final matches original 11 actual 24-tick continuation');assert.equal(right.exportSave(),expected,'candidate final matches original 11 actual 24-tick continuation');}
  evidence.push({mode,scope:'two actual CPU Simulation instances; exact import and geometry reads before 24 serial .25 steps each; native r5 only resumes via public pause0; actual07 preserves speed16 and unpaused state; no profile/GPU/new-night audit/performance claim',initialSaveSha256:sha(original),finalSaveSha256:sha(final),worldSha256:worldBefore,initialTick:startTick,finalTick:left.state.tick,finalDay:left.state.day,finalHour:left.state.hour,speed:left.state.speed,original11After24Exact:mode==='actual07',ticks});console.log(JSON.stringify({mode,status:'PASS',stepsEach:24,finalTick:left.state.tick}));
}
const sourcesAfter={before:sourceHashes('before'),candidate:sourceHashes('candidate')};assert.deepEqual(sourcesAfter,sourcesBefore);
const inputsAfter=inputHashes();assert.deepEqual(inputsAfter,inputsBefore);assert.equal(sha(readFileSync(new URL('./save-exact.mts',import.meta.url))),runnerShaBefore);
writeFileSync(new URL('./evidence/save-exact-result.json',import.meta.url),JSON.stringify({status:'PASS',startedAt,endedAt:new Date().toISOString(),runnerSha256:runnerShaBefore,inputsBefore,inputsAfter,sourcesBefore,sourcesAfter,evidence},null,2)+'\n');

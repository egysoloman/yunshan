from pathlib import Path
import hashlib,json,subprocess,datetime,os,sys
root=Path('/tmp/yunshan-floor-geometry-cache-candidate-01')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def hashes(side):
 baseline=json.loads((root/'evidence'/'baseline-manifest.json').read_text())['hashes'];names=list(baseline)
 if side=='candidate':names.append('tests/floor-plan-derived-cache.test.ts')
 return {name:hashlib.sha256((root/side/name).read_bytes()).hexdigest() for name in sorted(names)}
start={side:hashes(side) for side in ('before','candidate')}
assert start['before']==json.loads((root/'evidence'/'baseline-manifest.json').read_text())['hashes']
assert start['candidate']==json.loads((root/'evidence'/'candidate-manifest-pre-run.json').read_text())['hashes']
status={'status':'RUNNING','startedAt':now(),'launcherPid':os.getpid(),'sourceStart':start,'steps':[],'scope':'Only Root-authorized five new geometry tests, four original related test files, then geometry-only query differential. No standalone save runner, benchmark, profile, GPU, default-night or whole suite.'}
target=root/'evidence'/'pure-run-status.json'
def save():target.write_text(json.dumps(status,indent=2)+'\n')
save();print(json.dumps({'startedAt':status['startedAt'],'launcherPid':os.getpid()}),flush=True)
commands=[('new-mutable-tests',['node','--import','tsx','--test','tests/floor-plan-derived-cache.test.ts']),('original-related-tests',['node','--import','tsx','--test','--test-isolation=none','tests/architecture-floor-plan.test.ts','tests/controller-v4.test.ts','tests/home-rest.test.ts','tests/npc-home-rest-voxels.test.ts']),('query-differential',['node','--import','tsx','../query-differential.mts'])]
for name,cmd in commands:
 step={'name':name,'command':cmd,'startedAt':now(),'log':str(root/'evidence'/f'{name}.log')};status['steps'].append(step)
 with open(step['log'],'wb') as output:
  p=subprocess.Popen(cmd,cwd=root/'candidate',stdout=output,stderr=subprocess.STDOUT);step['pid']=p.pid;save();print(json.dumps({'name':name,'pid':p.pid,'startedAt':step['startedAt'],'log':step['log']}),flush=True);code=p.wait()
 step['endedAt']=now();step['exitCode']=code;save();print(json.dumps({'name':name,'exitCode':code,'endedAt':step['endedAt']}),flush=True)
 if code:status['status']='FAIL';break
else:status['status']='PASS'
status['sourceEnd']={side:hashes(side) for side in ('before','candidate')};status['sourceUnchanged']=status['sourceEnd']==start
if not status['sourceUnchanged']:status['status']='FAIL_SOURCE_CHANGED'
status['endedAt']=now();save();print(json.dumps({'status':status['status'],'sourceUnchanged':status['sourceUnchanged'],'endedAt':status['endedAt']}),flush=True)
sys.exit(0 if status['status']=='PASS' else 1)

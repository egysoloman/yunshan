from pathlib import Path
import hashlib,json,subprocess,datetime,os,sys,time
root=Path('/tmp/yunshan-floor-geometry-cache-candidate-01')
# This launcher is preparation only until Root explicitly authorizes execution.
assert len(sys.argv)==2 and sys.argv[1] in ('one-pair','abba')
order=['before','candidate'] if sys.argv[1]=='one-pair' else ['before','candidate','candidate','before']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(v):return hashlib.sha256(v).hexdigest()
def sources():
 baseline=json.loads((root/'evidence'/'baseline-manifest.json').read_text())['hashes'];result={}
 for side in ('before','candidate'):
  names=list(baseline)+(['tests/floor-plan-derived-cache.test.ts'] if side=='candidate' else [])
  result[side]={name:sha((root/side/name).read_bytes()) for name in sorted(names)}
 return result
sourceStart=sources();assert sourceStart['before']==json.loads((root/'evidence'/'baseline-manifest.json').read_text())['hashes'];assert sourceStart['candidate']==json.loads((root/'evidence'/'candidate-manifest-pre-run.json').read_text())['hashes']
status={'status':'RUNNING','mode':sys.argv[1],'order':order,'startedAt':now(),'launcherPid':os.getpid(),'sourceStart':sourceStart,'runnerSha256':sha((root/'startup-perf.mts').read_bytes()),'runs':[],'scope':'One fresh Node process at a time, full unchanged default current-v4 startup and 4 actual .25 ticks. No GPU/CPU sampling profile; no concurrent functional Simulation validation. End-to-end wall/child resource usage includes Node bootstrap/tsx and integrity serialization; Node result separates phases.'}
target=root/'evidence'/('startup-perf-'+sys.argv[1]+'-status.json')
def save():target.write_text(json.dumps(status,indent=2)+'\n')
save();print(json.dumps({'startedAt':status['startedAt'],'launcherPid':os.getpid(),'mode':sys.argv[1],'order':order}),flush=True)
for index,side in enumerate(order):
 runId=f'{sys.argv[1]}-{index+1}-{side}';log=root/'evidence'/f'startup-perf-{runId}.log';run={'runId':runId,'side':side,'startedAt':now(),'log':str(log),'command':['node','--import','tsx','../startup-perf.mts',side,runId]};status['runs'].append(run)
 start=time.perf_counter()
 with open(log,'wb') as output:
  p=subprocess.Popen(run['command'],cwd=root/'candidate',stdout=output,stderr=subprocess.STDOUT);run['pid']=p.pid;save();print(json.dumps({'runId':runId,'pid':p.pid,'startedAt':run['startedAt'],'log':str(log)}),flush=True)
  _,waitStatus,usage=os.wait4(p.pid,0);code=os.waitstatus_to_exitcode(waitStatus);p.returncode=code
 run.update({'endedAt':now(),'exitCode':code,'endToEndWallMs':(time.perf_counter()-start)*1000,'childUserCpuSeconds':usage.ru_utime,'childSystemCpuSeconds':usage.ru_stime,'childMaxRssKiB':usage.ru_maxrss});save()
 if code:status['status']='FAIL';break
 result=json.loads((root/'evidence'/f'startup-perf-{runId}.json').read_text());run['result']=result
 if index:
  first=status['runs'][0]['result'];matched=all(result[k]==first[k] for k in ('worldBefore','final','state'))
  if not matched:status['status']='FAIL_OUTPUT_MISMATCH';run['matchedInitialFinalWorldExportAndState']=False;save();break
 if sources()!=sourceStart:status['status']='FAIL_SOURCE_CHANGED';break
 save();print(json.dumps({'runId':runId,'exitCode':code,'endToEndWallMs':run['endToEndWallMs'],'finalSaveSha256':result['final']['saveSha256']}),flush=True)
else:status['status']='PASS'
status.update({'endedAt':now(),'sourceEnd':sources(),'runnerSha256End':sha((root/'startup-perf.mts').read_bytes())});status['sourceUnchanged']=status['sourceEnd']==sourceStart;status['runnerUnchanged']=status['runnerSha256End']==status['runnerSha256']
if not status['sourceUnchanged'] or not status['runnerUnchanged']:status['status']='FAIL_INPUT_CHANGED'
save();print(json.dumps({k:status[k] for k in ('status','sourceUnchanged','runnerUnchanged','endedAt')}),flush=True);sys.exit(0 if status['status']=='PASS' else 1)

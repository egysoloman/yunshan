from pathlib import Path
import hashlib,json,subprocess,datetime,os,sys,gzip
root=Path('/tmp/yunshan-floor-geometry-cache-candidate-01')
actual=Path('/tmp/yunshan-npc-public-rest-coherent11-actual-01/actual')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(v):return hashlib.sha256(v).hexdigest()
def hashes(side):
 baseline=json.loads((root/'evidence'/'baseline-manifest.json').read_text())['hashes'];names=list(baseline)
 if side=='candidate':names.append('tests/floor-plan-derived-cache.test.ts')
 return {name:sha((root/side/name).read_bytes()) for name in sorted(names)}
def inputs():
 paths=[root/'before/tests/fixtures/world-layout/r5-native-ui-export-coherent02.json.gz',actual/'actual-final-save.json.gz',actual/'after-24-actual-save.json.gz']
 return {str(p):{'gzipSha256':sha(p.read_bytes()),'rawSha256':sha(gzip.decompress(p.read_bytes()))} for p in paths}
status={'status':'RUNNING','startedAt':now(),'launcherPid':os.getpid(),'sourceStart':{s:hashes(s) for s in ('before','candidate')},'inputStart':inputs(),'runnerSha256':sha((root/'save-exact.mts').read_bytes()),'scope':'Root GO: native-r5, default-v4, existing actual07 checkpoint; two actual instances per mode, 24*.25 steps each, 144 serial steps total if all pass. Exact full export per step and actual07 matches original11 after24. No benchmark/profile/GPU/new-night audit.'}
target=root/'evidence'/'save-exact-run-status.json';log=root/'evidence'/'save-exact.log'
def save():target.write_text(json.dumps(status,indent=2)+'\n')
save();print(json.dumps({'startedAt':status['startedAt'],'launcherPid':os.getpid(),'runnerSha256':status['runnerSha256']}),flush=True)
with open(log,'wb') as output:
 p=subprocess.Popen(['node','--import','tsx','../save-exact.mts'],cwd=root/'candidate',stdout=output,stderr=subprocess.STDOUT);status['pid']=p.pid;save();print(json.dumps({'pid':p.pid,'log':str(log)}),flush=True);code=p.wait()
status.update({'status':'PASS' if code==0 else 'FAIL','exitCode':code,'endedAt':now(),'sourceEnd':{s:hashes(s) for s in ('before','candidate')},'inputEnd':inputs(),'runnerSha256End':sha((root/'save-exact.mts').read_bytes())})
status['sourceUnchanged']=status['sourceStart']==status['sourceEnd'];status['inputsUnchanged']=status['inputStart']==status['inputEnd'];status['runnerUnchanged']=status['runnerSha256']==status['runnerSha256End']
if not all(status[k] for k in ('sourceUnchanged','inputsUnchanged','runnerUnchanged')):status['status']='FAIL_INPUT_CHANGED'
save();print(json.dumps({k:status[k] for k in ('status','exitCode','sourceUnchanged','inputsUnchanged','runnerUnchanged','endedAt')}),flush=True);sys.exit(0 if status['status']=='PASS' else 1)

import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';

// READY ONLY. Root must authorize the launcher separately from correctness runs.
// Each invocation is a fresh Node process and does exactly four default ticks.
const side=process.argv[2],runId=process.argv[3];assert(side==='before'||side==='candidate');assert(/^[a-z0-9-]+$/.test(runId??''));
const sha=(v:string|Buffer)=>createHash('sha256').update(v).digest('hex'),startedAt=new Date().toISOString();
const totalStart=process.hrtime.bigint(),totalCpuStart=process.cpuUsage();
const phases:any[]=[];
async function phase<T>(name:string,fn:()=>T|Promise<T>):Promise<T>{const start=process.hrtime.bigint(),cpu=process.cpuUsage(),value=await fn();phases.push({name,wallMs:Number(process.hrtime.bigint()-start)/1e6,cpuMicroseconds:process.cpuUsage(cpu),rssBytes:process.memoryUsage().rss});return value;}
const modules=await phase('dynamic-module-import',async()=>({world:await import(new URL(`./${side}/src/world.ts`,import.meta.url).href),simulation:await import(new URL(`./${side}/src/simulation.ts`,import.meta.url).href)}));
const world=await phase('createWorld-default-current-v4',()=>modules.world.createWorld(20261001,'current-v4'));
const sim=await phase('Simulation-constructor-default',()=>new modules.simulation.Simulation(world));
assert.equal(world.buildings.length,612);assert.equal(sim.state.citizens.length,616);assert.equal(sim.state.speed,1);assert.equal(sim.state.hour,8);assert.equal(sim.state.day,0);assert.equal(sim.state.tick,0);assert.equal(sim.state.paused,false);
const worldBefore=await phase('read-only-initial-world-and-export-guards',()=>({worldSha256:sha(JSON.stringify(world)),saveSha256:sha(sim.exportSave())}));
for(let index=0;index<4;index++)await phase(`actual-default-step-${index+1}`,()=>sim.step(.25));
assert.equal(sim.state.tick,4);assert.equal(sim.state.speed,1);assert.equal(sim.state.day,0);assert(Math.abs(sim.state.hour-(8+1/60))<1e-9);assert.equal(sim.state.citizens.length,616);
const final=await phase('read-only-final-world-and-export-guards',()=>({worldSha256:sha(JSON.stringify(world)),saveSha256:sha(sim.exportSave())}));assert.equal(final.worldSha256,worldBefore.worldSha256);
const totalWallMs=Number(process.hrtime.bigint()-totalStart)/1e6,totalCpu=process.cpuUsage(totalCpuStart),usage=process.resourceUsage(),memory=process.memoryUsage();
const result={status:'PASS',side,runId,pid:process.pid,startedAt,endedAt:new Date().toISOString(),node:process.version,platform:process.platform,scope:'Fresh Node CPU startup only. Includes TS/module import, full 612-building/616-resident current-v4 generation, unchanged default Simulation construction, exactly four .25 actual ticks at speed1, and separately labeled integrity serialization. No Renderer/GPU/profile/sleep/setFocus/settings/phase/actor/funds/route changes. Wall timing excludes process creation before script entry; launcher records end-to-end separately. RSS/maxRSS are process observations, not isolated geometry cache size or macOS metrics.',phases,totalScriptWallMs:totalWallMs,totalScriptCpuMicroseconds:totalCpu,processCpuUsageMicroseconds:process.cpuUsage(),maxRssKiB:usage.maxRSS,finalMemory:memory,worldBefore,final,state:{tick:sim.state.tick,day:sim.state.day,hour:sim.state.hour,speed:sim.state.speed,citizens:sim.state.citizens.length}};
writeFileSync(new URL(`./evidence/startup-perf-${runId}.json`,import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({status:result.status,side,runId,pid:process.pid,totalScriptWallMs:totalWallMs,finalSaveSha256:final.saveSha256}));

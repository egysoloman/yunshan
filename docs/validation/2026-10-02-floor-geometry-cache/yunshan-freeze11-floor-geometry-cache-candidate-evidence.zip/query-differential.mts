import assert from 'node:assert/strict';
import { writeFileSync,readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import * as old from './before/src/architecture-floor-plan.ts';
import * as next from './candidate/src/architecture-floor-plan.ts';
import { createWorld as oldWorld } from './before/src/world.ts';
import { createWorld as nextWorld } from './candidate/src/world.ts';
import type { Building,Vec3 } from './candidate/src/types.ts';
import type { FloorPlan,BuildingBody,Rect } from './candidate/src/architecture-floor-plan.ts';

const startedAt=new Date().toISOString(),evidence:any[]=[];
let queries=0,errors=0;
const sha=(s:string|Buffer)=>createHash('sha256').update(s).digest('hex');
function capture(fn:()=>unknown){try{return {ok:true,value:fn()};}catch(error){const e=error as Error;return {ok:false,name:e.name,message:e.message};}}
function equal(label:string,a:()=>unknown,b:()=>unknown){const left=capture(a),right=capture(b);assert.deepEqual(right,left,label);queries++;if(!left.ok)errors++;return left;}
function pairQuery(label:string,api:typeof old,b:Building,p:FloorPlan,point:Vec3,radius:number){
  const world=api.buildingWorldPosition(b,point),end=api.buildingWorldPosition(b,{...point,x:point.x+.4,z:point.z+.2});
  return {support:api.floorPlanSupport(b,p.floor,world,radius),stand:api.canStandInFloorPlan(p,point.x,point.z,radius),blocked:api.blocksFloorPlanMovement(b,p.floor,world,end,radius)};
}
const leftWorld=oldWorld(20261001,'current-v4'),rightWorld=nextWorld(20261001,'current-v4');
const worldBefore=[sha(JSON.stringify(leftWorld)),sha(JSON.stringify(rightWorld))];assert.equal(worldBefore[1],worldBefore[0]);
const selected:Building[]=[];
for(const kind of ['home','market','workshop','hall','bank','clinic','station','dock'] as const){const b=leftWorld.buildings.find(b=>b.kind===kind&&old.getBuildingBody(b)&&b.floors>=2);if(b)selected.push(b);}
assert(selected.length>=6);
for(const original of selected){
  const a=structuredClone(original),b=structuredClone(original);if(a.kind==='home'){a.basements=1;b.basements=1;a.rotation=.73;b.rotation=.73;}
  const bodyA=old.getBuildingBody(a)!,bodyB=next.getBuildingBody(b)!;equal(`${a.id}:body-before`,()=>bodyA,()=>bodyB);
  const floors=[...new Set([bodyA.floorPlans[0].floor,0,1,a.floors-1])];
  for(const floor of floors){
    const p=old.getBuildingFloorPlan(a,floor)!,q=next.getBuildingFloorPlan(b,floor)!;
    const points:Vec3[]=[{...p.stair,y:p.y},{...p.usePoint,y:p.y},...p.usePoints.map(t=>({x:t.x,y:p.y,z:t.z}))];
    for(const r of p.interior.slice(0,2))for(const x of [r.x0+.35-2e-7,r.x0+.35,r.x0+.35+2e-7,(r.x0+r.x1)/2])points.push({x,y:p.y,z:(r.z0+r.z1)/2});
    if(p.stairHole)for(const x of [(p.stairHole.x0+p.stairHole.x1)/2,p.stairHole.x0-.35,p.stairHole.x0-.35-2e-7])points.push({x,y:p.y,z:(p.stairHole.z0+p.stairHole.z1)/2});
    for(const f of p.fixtures)points.push({x:(f.rect.x0+f.rect.x1)/2,y:p.y+f.top,z:(f.rect.z0+f.rect.z1)/2});
    for(const point of points)for(const radius of [0,.35])equal(`${a.id}/${floor}:point:${JSON.stringify(point)}:r${radius}`,()=>pairQuery('',old,a,p,point,radius),()=>pairQuery('',next,b,q,point,radius));
    const routeA=old.getFloorPlanStairRoute(a,floor,floor+1),routeB=next.getFloorPlanStairRoute(b,floor,floor+1);assert.deepEqual(routeB,routeA);queries++;
    if(routeA)for(const position of [...routeA,...routeA.slice().reverse()])for(const radius of [0,.35])equal(`${a.id}/${floor}:stair:r${radius}`,()=>old.floorPlanSupport(a,floor,position,radius),()=>next.floorPlanSupport(b,floor,position,radius));
    const from=old.buildingWorldPosition(a,{...p.usePoint,y:p.y}),to=old.getFloorPlanStairPosition(a,floor);
    equal(`${a.id}/${floor}:route`,()=>old.findFloorPlanRoute(a,floor,from,to),()=>next.findFloorPlanRoute(b,floor,from,to));
  }
  equal(`${a.id}:body-after`,()=>bodyA,()=>bodyB);assert.deepEqual(a,b);evidence.push({check:'real-family-floor-stair-route',building:a.id,kind:a.kind,floors,rotation:a.rotation,basements:a.basements??0});
}

function controlled(api:typeof old){
  const source=selected[0],b={...structuredClone(source),width:24,depth:24,height:12,floors:3,basements:1,position:{x:0,y:0,z:0},rotation:.73,floorFootprints:undefined};
  const body=api.getBuildingBody(b)!;const r=():Rect=>({x0:-5,x1:5,z0:-5,z1:5});
  for(const p of body.floorPlans){p.y=p.floor*4;p.ceilingY=p.y+4;p.interior=[r()];p.circulation=[];p.courtyard=[];p.stairLanding={x0:-4,x1:-3,z0:-4,z1:-3};p.fixtures=[];p.stairTreads=[];p.stairLandings=[];api.wallPanels(p).splice(0);api.getFloorPlanSlabRegions(p).splice(0,Infinity,r());}
  api.getFloorPlanRoofRegions(body).splice(0);return {b,body,p:body.floorPlans.find(p=>p.floor===0)!,upper:body.floorPlans.find(p=>p.floor===1)!};
}
type Context=ReturnType<typeof controlled>;
const block=()=>({id:'fixture',kind:'table' as const,rect:{x0:-.5,x1:.5,z0:-.5,z1:.5},bottom:0,top:1.5});
// Retain the exact first-run failed expectations as old/candidate probes. These
// inputs have known existing reference/lattice behavior; no geometry is changed.
for(const kind of ['original-cold-nested-slab','original-tread-point-one'] as const){
  const contexts=[controlled(old),controlled(next)],apis=[old,next] as const;
  const values=contexts.map((c,index)=>{const api=apis[index];if(kind==='original-cold-nested-slab'){
    c.body.floorPlans=structuredClone(c.body.floorPlans);for(const p of c.body.floorPlans){p.walls=[];p.stairHole=null;}
    const p=c.body.floorPlans.find(p=>p.floor===0)!,upper=c.body.floorPlans.find(p=>p.floor===1)!;
    assert(api.floorPlanSupport(c.b,0,api.buildingWorldPosition(c.b,{x:0,y:0,z:0}),0));upper.interior[0].x1=.2;
    return api.getFloorPlanSlabRegions(upper)[0].x1;
  }
  api.getFloorPlanSlabRegions(c.p).splice(0,Infinity,{x0:-5,x1:-.2,z0:-5,z1:5},{x0:.2,x1:5,z0:-5,z1:5});
  c.p.stairTreads.push({id:'up-original',rect:{x0:-1,x1:.1,z0:-1,z1:1},bottom:0,top:.2,fromFloor:0,toFloor:1,kind:'tread'});
  return api.floorPlanSupport(c.b,0,api.buildingWorldPosition(c.b,{x:0,y:0,z:0}),.35);
  });
  assert.deepEqual(values[1],values[0],kind);if(kind==='original-cold-nested-slab')assert.equal(values[0],.2);else assert(values[0]);queries++;evidence.push({check:'preserved-first-attempt-failed-fixture-old-candidate-result',kind,result:values[0]});
}
const mutations:[string,(api:typeof old,c:Context)=>void][]=[
 ['fixture-push',(_,c)=>c.p.fixtures.push(block())],['fixture-nested-rect',(_,c)=>{c.p.fixtures[0].rect.x0=3;c.p.fixtures[0].rect.x1=4;}],['fixture-replace-rect',(_,c)=>{c.p.fixtures[0].rect=block().rect;}],['fixture-height',(_,c)=>{c.p.fixtures[0].bottom=2;c.p.fixtures[0].top=3;}],['fixture-array-replace',(_,c)=>{c.p.fixtures=[block()];}],['fixture-remove',(_,c)=>{c.p.fixtures.splice(0);}],
 ['wallpanels-push',(api,c)=>api.wallPanels(c.p).push({...block(),kind:'solid'})],['wallpanels-nested-rect',(api,c)=>{api.wallPanels(c.p)[0].rect.z0=3;api.wallPanels(c.p)[0].rect.z1=4;}],['wallpanels-replace-member',(api,c)=>{api.wallPanels(c.p)[0]={...block(),kind:'glass'};}],['wallpanels-height',(api,c)=>{api.wallPanels(c.p)[0].bottom=2;}],['wallpanels-remove',(api,c)=>api.wallPanels(c.p).splice(0)],
 ['slab-nested-rect',(api,c)=>{api.getFloorPlanSlabRegions(c.p)[0].x1=.2;}],['slab-replace-member',(api,c)=>{api.getFloorPlanSlabRegions(c.p)[0]={x0:-5,x1:5,z0:-5,z1:5};}],['upper-y',(_,c)=>{c.upper.y=1;}],['upper-slab-nested-rect',(api,c)=>{api.getFloorPlanSlabRegions(c.upper)[0].x0=3;api.getFloorPlanSlabRegions(c.upper)[0].x1=4;}],['upper-slab-replace-member',(api,c)=>{api.getFloorPlanSlabRegions(c.upper)[0]={x0:-5,x1:5,z0:-5,z1:5};}],['upper-floor',(_,c)=>{c.upper.floor=10;}],['upper-membership',(_,c)=>{c.body.floorPlans=c.body.floorPlans.filter(p=>p!==c.upper);}],['upper-reinsert',(_,c)=>{c.upper.floor=1;c.upper.y=4;c.body.floorPlans.push(c.upper);}],['member-reorder',(_,c)=>c.body.floorPlans.reverse()],
 ['stairs-push',(_,c)=>{c.p.stairTreads.push({id:'up-live',rect:{x0:-1,x1:1,z0:-1,z1:1},bottom:0,top:.2,fromFloor:0,toFloor:1,kind:'tread'});} ],['stairs-top',(_,c)=>{c.p.stairTreads[0].top=.2200002;}],['stairs-bottom',(_,c)=>{c.p.stairTreads[0].bottom=-.1;}],['stairs-nested-rect',(_,c)=>{c.p.stairTreads[0].rect.x1=.1;}],['stairs-replace-rect',(_,c)=>{c.p.stairTreads[0].rect={x0:-1,x1:1,z0:-1,z1:1};}],['stairs-replace-array',(_,c)=>{c.p.stairLandings=[{...c.p.stairTreads[0],top:.2,kind:'landing'}];c.p.stairTreads=[];}],['stairs-link',(_,c)=>{c.p.stairLandings[0].fromFloor=-1;c.p.stairLandings[0].toFloor=2;}],['stairs-remove',(_,c)=>{c.p.stairLandings.splice(0);} ],
 ['raw-wall-cached',(api,c)=>{c.p.walls=[{a:[-1,0],b:[1,0],height:2,thickness:1}];assert.equal(api.wallPanels(c.p).length,0);} ],['raw-slab-cached',(api,c)=>{c.p.interior[0].x0=10;c.p.interior[0].x1=20;c.p.stairHole={x0:-1,x1:1,z0:-1,z1:1};assert.equal(api.getFloorPlanSlabRegions(c.p)[0].x0,-5);} ],
 ['floor-array-hole',(_,c)=>{delete c.body.floorPlans[c.body.floorPlans.indexOf(c.upper)];}],
];
const a=controlled(old),b=controlled(next);
function mutationQueries(label:string){
  for(const y of [0,.2,.6,1.5])for(const radius of [0,.35])equal(`${label}:y${y}:r${radius}`,()=>pairQuery('',old,a.b,a.p,{x:0,y,z:0},radius),()=>pairQuery('',next,b.b,b.p,{x:0,y,z:0},radius));
}
mutationQueries('primed');for(const [label,mutate] of mutations){mutate(old,a);mutate(next,b);mutationQueries(label);evidence.push({check:'mutable-sequence',label});}
for(const target of ['base-hole','upper-hole','stairs-hole','stairs-mixed-hole'] as const){
  const a=controlled(old),b=controlled(next);equal(`${target}:prime`,()=>pairQuery('',old,a.b,a.p,{x:0,y:0,z:0},.35),()=>pairQuery('',next,b.b,b.p,{x:0,y:0,z:0},.35));
  for(const [api,c] of [[old,a],[next,b]] as const){if(target==='stairs-hole'){c.p.stairTreads.length=1;}else if(target==='stairs-mixed-hole'){c.p.stairTreads.push({id:'up-live',rect:{x0:-1,x1:1,z0:-1,z1:1},bottom:0,top:.2,fromFloor:0,toFloor:1,kind:'tread'});c.p.stairTreads.length=2;}else{const rs=api.getFloorPlanSlabRegions(target==='base-hole'?c.p:c.upper);rs.push({x0:10,x1:11,z0:10,z1:11});delete rs[1];}}
  for(const radius of [0,.35])equal(`${target}:support:r${radius}`,()=>old.floorPlanSupport(a.b,0,old.buildingWorldPosition(a.b,{x:0,y:0,z:0}),radius),()=>next.floorPlanSupport(b.b,0,next.buildingWorldPosition(b.b,{x:0,y:0,z:0}),radius));
  equal(`${target}:movement`,()=>old.blocksFloorPlanMovement(a.b,0,{x:-1,y:.6,z:0},{x:1,y:.6,z:0}),()=>next.blocksFloorPlanMovement(b.b,0,{x:-1,y:.6,z:0},{x:1,y:.6,z:0}));
  evidence.push({check:'sparse-public-array',target});
}
for(const recipe of ['legacy-ee3e7a1','current-v2','current-v2-r5','current-v3'] as const){
  const a=oldWorld(7,recipe),b=nextWorld(7,recipe);assert.deepEqual(a,b);for(let i=0;i<a.buildings.length;i++)assert.equal(next.getBuildingBody(b.buildings[i]),old.getBuildingBody(a.buildings[i]));evidence.push({check:'old-recipe-world-and-unmarked-bodies',recipe,worldSha256:sha(JSON.stringify(a))});
}
assert.equal(sha(JSON.stringify(leftWorld)),worldBefore[0]);assert.equal(sha(JSON.stringify(rightWorld)),worldBefore[1]);
writeFileSync(new URL('./evidence/query-differential-result.json',import.meta.url),JSON.stringify({status:'PASS',startedAt,endedAt:new Date().toISOString(),scope:'CPU geometry only; no Simulation, GPU, profile, clock or state mutation. Controlled mutable clones are separate from unchanged real generated World.',queries,matchingErrorQueries:errors,worldBefore,evidence},null,2)+'\n');
console.log(JSON.stringify({status:'PASS',queries,matchingErrorQueries:errors,cases:evidence.length}));

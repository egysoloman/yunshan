# Current 6785 F1 isolated candidate

Base: shared clean a1e7f05849590da2e108d05ee69f2ba46ee9ff2d. Both before and source contain the full 190 tracked runnable inputs plus the same two new test inputs, with shared node_modules linked. The production delta is only src/simulation.ts/publicBudgetSnapshot. No roads, performance, bridge, worker, types, controllers or save-validation contracts were changed.

The snapshot now uses the same monotonic standing deadline as publicWorkAllowance: while no finite schedule exists or day < standingUntilDay, protect max(forecast, signed remainder); once expired protect the signed current/future remainder. Public wage debts, accrued wages, essential operations and open approved budgets remain protected, and the full forecast is still displayed. No money, labor promise or approval is created.

Apply only the simulation hunk and the two test inputs. source-delta.patch contains the simulation hunk and full newly added test source; copy tests/fixtures/economy-original14-final.save.json.gz separately using its bound SHA. Do not copy a historical whole simulation.ts into the parent continuation source.

Nine tests are prepared, NOT_RUN. All original seven test bodies/assertions remain a byte-identical prefix. The two added tests use the genuine hash-bound 14-day artifact, verify earned-wage and signed-cap malformed inputs fail atomically, and verify normalized full saves followed by 24 original .25 ticks match byte exactly with actual complete cash conservation and read-only budget queries. Original first import is not claimed byte exact because metadata migrations are separately allowed and financial authority is checked. No roles, speed, positions, needs, money, clocks, jobs or contracts are altered in these added tests.

Suggested controlled validation: original before production + only the first genuine fourteen-day assertion as the expected F1 business negative; then strict and all nine tests against candidate source. Do not collapse the old successful read-only observation into a fix run. Preserve the first failure if any.

Original actual ROOT29 observation is referenced directly by original-F1-evidence-index.json with every file rehashed. It observed treasury 11198.788716185003, protected actual earned/signed/operation commitments 7120.736368054922, available existing cash 4078.0523481300806 by arithmetic, while original snapshot incorrectly returned available 0 with forecast reserve 14139.428644411995. The observation ran no commands or steps and did not validate this candidate.

No Node/Simulation/build/GPU was run for this preparation; shared source was not edited. Food production/access investigation is a separate next scope and is not silently implemented here.

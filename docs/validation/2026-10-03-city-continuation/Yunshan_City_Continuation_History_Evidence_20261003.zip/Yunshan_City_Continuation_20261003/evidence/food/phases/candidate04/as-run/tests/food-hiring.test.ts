import assert from 'node:assert/strict';
import test from 'node:test';
import { tradeSignals } from '../src/simulation/trade';
import { call, cash, exact24, nativeApproval, runtime, saveObservation, setup, until } from './food-hiring-fixture';

test('food shortage names an accepted worker without wages, then real owner review, walking, production and sale close the loop', () => {
  const c = setup(), { sim, shop, applicant, owner, staff } = c, beforeCash = cash(sim), originalDebts = structuredClone(runtime(sim).wageArrears);
  assert.equal(tradeSignals(sim, shop.id).sold, 0); assert.equal(shop.customers, 0);
  nativeApproval(sim, shop);
  const plan = runtime(sim).privateLabor.shifts[shop.id]; assert.equal(plan.assignments.length, staff.length); assert.equal(plan.assignments[0].citizenId, owner.id);
  // A real review with zero vacancies records this original, unfunded worker.
  // It creates no wage and no funding proof; adding zero names is not a promise.
  const idle = staff.find(person => person.id !== owner.id)!;
  assert.equal(plan.assignments.find((row: any) => row.citizenId === idle.id).minutesCap, 0, 'original zero-cash review recorded the inactive name');
  const wages: unknown[] = [], production: unknown[] = [], sales: unknown[] = [], approvals: unknown[] = [];
  sim.onEvent('wage-earned', event => { if (event.citizenId === applicant.id) wages.push(structuredClone(event)); });
  sim.onEvent('production', event => { if (event.shopId === shop.id) production.push(structuredClone(event)); });
  sim.onEvent('sale', event => { if (event.shopId === shop.id) { const trust = sim.state.relationships.find(r => r.npcId === event.citizenId)?.trust ?? 0; sales.push({ ...structuredClone(event), actualUnitPrice: shop.price * (trust > 55 ? .95 : 1) }); } });
  sim.onEvent('private-shift-authorized', event => { if (event.shopId === shop.id) approvals.push(structuredClone(event)); });
  saveObservation(sim, 'loop-premise', { applicantId: applicant.id, idleId: idle.id, ownerId: owner.id, demand: c.buyers.map(person => person.id), contribution: beforeCash - c.initialCash });
  until(sim, () => applicant.workId === shop.buildingId, 8, 'zero-sales food employer must accept a real reachable qualified applicant');
  const assignment = plan.assignments.find((a: any) => a.citizenId === applicant.id);
  assert.ok(assignment); assert.equal(assignment.minutesCap, 0); assert.equal(assignment.workedMinutes, 0); assert.equal(wages.length, 0); assert.equal(plan.reviews.length, 1);
  assert.equal(applicant.role, c.originalRole); assert.equal(applicant.homeId, c.originalHomeId); assert.deepEqual(runtime(sim).wageArrears, originalDebts);
  assert.equal(runtime(sim).publicLabor.jobs[applicant.id], c.originalWorkId); assert.equal(shop.employees, 2, 'same-tick commerce must not shrink accepted staff against the old workforce cache');
  assert.ok(plan.assignments.indexOf(assignment) < plan.assignments.findIndex((a: any) => a.citizenId === idle.id), 'accepted name precedes old zero-cap inactive names');
  exact24(sim, 'accepted-zero');
  until(sim, () => assignment.minutesCap > 0, 60, 'only original onsite employer review may sign a positive funded cap');
  assert.ok(approvals.length > 0); assert.equal(assignment.workedMinutes, 0); assert.equal(wages.length, 0); assert.ok(Number(applicant.id.slice(8)) > Number(idle.id.slice(8)));
  saveObservation(sim, 'signed', { assignment, reviews: plan.reviews });
  const arrived = () => assignment.workedMinutes > 0;
  until(sim, arrived, 900, 'new worker must physically walk the original route and accrue genuine onsite labor');
  assert.ok(wages.length > 0); assert.equal(sim.isOnDuty(applicant.id, shop.buildingId), true);
  exact24(sim, 'first-attendance');
  until(sim, () => production.length > 0 && sales.length > 0, 900, 'finite attendance must produce food and a real buyer must pay for it');
  const p = production as any[], s = sales as any[]; assert.ok(p.every(event => event.minutes > 0 && event.amount > 0)); assert.ok(s.some(event => c.buyers.some(b => b.id === event.citizenId)));
  assert.ok(s.every(event => Math.abs(event.amount - event.quantity * event.actualUnitPrice) < 1e-8 && event.quantity > 0));
  assert.ok(Math.abs(cash(sim) - beforeCash) < 1e-6, 'wallets, original supplier accounts, actual wages and tax conserve every existing coin');
  const produced = p.reduce((n, event) => n + event.amount, 0), sold = s.reduce((n, event) => n + event.quantity, 0);
  assert.ok(Math.abs(shop.inventory - (90 + produced - sold)) < 1e-7, 'food stock has only original units, actual funded production and actual sales');
  saveObservation(sim, 'loop-complete', { applicantId: applicant.id, assignment, wages, production, sales, approvals });
  exact24(sim, 'sold-loop');
});

test('food hiring demand is read-only and rechecks food, cash and current position within the same people tick', () => {
  const { sim, shop, site, buyers } = setup(); const before = sim.exportSave();
  const names = call(sim, 'foodHiringDemandIds', shop, site) as string[];
  assert.equal(names.length, 92); assert.equal(sim.exportSave(), before, 'query changes no route, permit, money, intent or clock');
  const buyer = buyers[0]; buyer.food = 1; assert.ok(!(call(sim, 'foodHiringDemandIds', shop, site) as string[]).includes(buyer.id));
  buyer.food = 0; const wallet = buyer.money; buyer.money = shop.price - .01; assert.ok(!(call(sim, 'foodHiringDemandIds', shop, site) as string[]).includes(buyer.id)); buyer.money = wallet;
  const oldTravel = call(sim, 'foodHiringSaleDistance', buyer, site) as number; buyer.position = { x: 950, y: 20.6, z: 950 };
  const moved = call(sim, 'foodHiringDemandIds', shop, site) as string[]; assert.ok(moved.includes(buyer.id), 'a long but still timely actual walk is not rejected');
  const cached = Reflect.get(sim, 'foodHiringDemand').get(shop.id).find((row: any) => row.id === buyer.id); assert.ok(cached.travel > oldTravel, 'same-tick movement recomputes the actual route');
  assert.ok(sim.command({ type: 'setTime', value: 19.75 }).ok); assert.ok(!(call(sim, 'foodHiringDemandIds', shop, site) as string[]).includes(buyer.id), 'legal near-close display time leaves insufficient walking minutes');
});

test('food shortages do not bypass reserved wages, owner presence or the materials-only business', () => {
  const c = setup(), { sim, shop, applicant, owner } = c, salary = 32 * (.7 + sim.state.districts[0].prosperity / 100);
  const original = { ...owner.position }; owner.position = { ...sim.worldDefinition.spawn }; let before = sim.exportSave();
  assert.equal(call(sim, 'foodShortageHiringOffer', shop, applicant, salary), false); assert.equal(sim.exportSave(), before);
  owner.position = original; nativeApproval(sim, shop);
  // A genuine owner amendment allocates the remaining cash to original workers.
  const required = salary * c.staff.length + 20 * 8 / 24; const returned = sim.shopFunds(shop) - required;
  assert.ok(returned >= 0); sim.transferShopFunds(shop, -returned); owner.money += returned;
  shop.employees = c.staff.length; nativeApproval(sim, shop); before = sim.exportSave();
  assert.equal(call(sim, 'foodShortageHiringOffer', shop, applicant, salary), false); assert.equal(sim.exportSave(), before); assert.ok(sim.shopProtectedFunds(shop) > 0);
  const materials = sim.state.shops.find(s => s.buildingId === 'food-materials')!; before = sim.exportSave();
  assert.equal(call(sim, 'foodShortageHiringOffer', materials, applicant, salary), false); assert.equal(sim.exportSave(), before);
});

test('the original actual-sale offer still signs only through the owner review and saves its named acceptance', () => {
  const { sim, shop, site, applicant, buyers } = setup();
  for (const buyer of buyers) buyer.needs.hunger = 70; // Explicit no-shortage boundary, never used in the walking lifecycle.
  assert.equal(call(sim, 'foodShortageHiringOffer', shop, applicant, 44.16), false);
  const stock = shop.inventory, money = sim.state.player.money, total = cash(sim);
  const bought = sim.command({ type: 'purchase', targetId: site.id, value: 1 }); assert.ok(bought.ok, bought.message);
  assert.equal(shop.inventory, stock - 1); assert.equal(sim.state.player.money, money - shop.price); assert.ok(tradeSignals(sim, shop.id).sold > 0);
  until(sim, () => applicant.workId === site.id, 8, 'existing sold-demand branch stays usable');
  const plan = runtime(sim).privateLabor.shifts[shop.id], row = plan.assignments.find((a: any) => a.citizenId === applicant.id);
  assert.equal(row.minutesCap, 0); assert.equal(row.workedMinutes, 0); assert.equal(plan.reviews.length, 0);
  exact24(sim, 'sold-acceptance'); until(sim, () => row.minutesCap > 0, 60, 'actual onsite reviewer funds original-sale hire');
  assert.ok(plan.reviews.length > 0); assert.ok(Math.abs(cash(sim) - total) < 1e-6); exact24(sim, 'sold-funded');
});

test('original two-official review creates a real future promise which food hiring cannot borrow', () => {
  const { sim, shop, applicant } = setup(true), hall = sim.worldDefinition.buildings.find(b => b.kind === 'hall')!;
  const officials = sim.state.citizens.filter(c => c.workId === hall.id && c.role === '官员' && sim.state.extension!.actorProfiles[c.id].age >= 18).slice(0, 2);
  assert.equal(officials.length, 2, 'only existing generated legal officials, not supplied identities');
  const labor = runtime(sim).publicLabor; labor.standingUntilDay = 1;
  for (const official of officials) { labor.jobs[official.id] = hall.id; official.position = { ...hall.position, y: hall.position.y + .6, z: .5 }; }
  const before = cash(sim); call(sim, 'reviewPublicShifts');
  const tomorrow = labor.shifts.find((shift: any) => shift.day === 1), row = tomorrow?.assignments.find((a: any) => a.citizenId === applicant.id);
  assert.ok(row?.minutesCap > 0); assert.equal(row.workedMinutes, 0); assert.equal(labor.shifts.some((shift: any) => shift.day === 0), false);
  const snapshot = sim.exportSave(); assert.equal(call(sim, 'foodHiringApplicantAvailable', applicant), false); assert.equal(sim.exportSave(), snapshot); assert.equal(cash(sim), before);
  assert.equal(call(sim, 'foodShortageHiringOffer', shop, applicant, 44.16), false); exact24(sim, 'future-public-promise');
});

test('after natural day rollover new private acceptance preserves old named staff and public review never resigns their old office', () => {
  const { sim, shop, applicant, owner, staff, originalWorkId } = setup(true);
  nativeApproval(sim, shop); until(sim, () => applicant.workId === shop.buildingId, 8, 'first actual food hire accepted');
  until(sim, () => runtime(sim).privateLabor.shifts[shop.id].assignments.find((a: any) => a.citizenId === applicant.id)?.minutesCap > 0, 60, 'first name gets real current-day cap');
  const prior = structuredClone(runtime(sim).privateLabor.shifts[shop.id]); assert.ok(prior.assignments.find((a: any) => a.citizenId === applicant.id).minutesCap > 0);
  assert.ok(sim.command({ type: 'speed', value: 8 }).ok);
  until(sim, () => sim.state.extension!.lastUpdate >= 1440, 600, 'natural monotonic next day, not setTime');
  assert.equal(Math.floor(sim.state.extension!.lastUpdate / 1440), 1);
  // The next acceptance is a boundary fixture at the real next-day clock. Only
  // its decision is requested; no role, wallet, position, minute or old debt is changed.
  const second = sim.state.citizens.find(c => c.role === '老师' && c.workId !== shop.buildingId && (c.skills?.craft ?? 0) >= 20 && (c.education ?? 0) >= 2 && c.needs.hunger >= 45 && c.needs.fatigue >= 40 && sim.state.extension!.actorProfiles[c.id].age >= 18)!;
  assert.ok(second);
  const labor = runtime(sim).publicLabor; labor.jobs[second.id] = second.workId;
  const hall = sim.worldDefinition.buildings.find(b => b.kind === 'hall')!, officials = sim.state.citizens.filter(c => c.workId === hall.id && c.role === '官员').slice(0, 2);
  // Move neither actor nor clock. Testing the narrow new-signing predicate uses
  // the original reviewer once its native office actors arrive during daytime.
  for (const official of officials) labor.jobs[official.id] = hall.id;
  assert.equal(labor.jobs[applicant.id], originalWorkId, 'historical occupation registry remains');
  const history = structuredClone(labor.shifts), debt = structuredClone(runtime(sim).wageArrears);
  assert.ok(sim.command({ type: 'speed', value: 8 }).ok);
  until(sim, () => sim.state.hour >= 8 && labor.shifts.some((shift: any) => shift.day === 1), 300, 'native next-day officials physically review finite public payroll');
  const current = labor.shifts.find((shift: any) => shift.day === 1); assert.ok(current);
  assert.ok(!current.assignments.some((row: any) => row.citizenId === applicant.id), 'past public job cannot create another employer promise');
  for (const shift of history) assert.deepEqual(labor.shifts.find((now: any) => now.id === shift.id), shift, 'new approval cannot rewrite old signed records');
  assert.equal(labor.jobs[applicant.id], originalWorkId); assert.ok(debt.every((row: any) => row.amount >= 0));
  const plan = runtime(sim).privateLabor.shifts[shop.id];
  assert.ok(plan.assignments.some((a: any) => a.citizenId === applicant.id), 'previous named worker survives rollover rather than losing slot to inactive original index');
  assert.ok(plan.assignments.some((a: any) => a.citizenId === owner.id)); assert.equal(applicant.role, '老师'); assert.equal(applicant.homeId, 'food-home');
  saveObservation(sim, 'next-day-public-review', { prior, current, plan, originalDebts: debt, currentDebts: runtime(sim).wageArrears, idle: staff.find(c => c.id !== owner.id)?.id });
  exact24(sim, 'next-day');
});

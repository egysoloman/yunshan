import assert from 'node:assert/strict';
import test from 'node:test';
import { tradeSignals } from '../src/simulation/trade';
import { call, cash, exact24, nativeApproval, runtime, saveObservation, setup, until } from './food-hiring-fixture';

test('food shortage names an accepted worker without wages, then real owner review, walking, production and sale close the loop', () => {
  const c = setup(), { sim, shop, applicant, owner, staff } = c, beforeCash = cash(sim), originalDebts = structuredClone(runtime(sim).wageArrears);
  assert.equal(tradeSignals(sim, shop.id).sold, 0); assert.equal(shop.customers, 0);
  nativeApproval(sim, shop);
  const plan = runtime(sim).privateLabor.shifts[shop.id]; assert.equal(plan.assignments.length, staff.length); assert.equal(plan.assignments[0].citizenId, owner.id);
  // A real review with zero vacancies records this original, unfunded worker.
  // It creates no wage and no funding proof; adding zero names is not a promise.
  const idle = staff.find(person => person.id !== owner.id)!;
  assert.equal(plan.assignments.find((row: any) => row.citizenId === idle.id).minutesCap, 0, 'original zero-cash review recorded the inactive name');
  const wages: unknown[] = [], production: unknown[] = [], sales: unknown[] = [], approvals: unknown[] = [];
  sim.onEvent('wage-earned', event => { if (event.citizenId === applicant.id) wages.push(structuredClone(event)); });
  sim.onEvent('production', event => { if (event.shopId === shop.id) production.push(structuredClone(event)); });
  sim.onEvent('sale', event => { if (event.shopId === shop.id) sales.push(structuredClone(event)); });
  sim.onEvent('private-shift-authorized', event => { if (event.shopId === shop.id) approvals.push(structuredClone(event)); });
  saveObservation(sim, 'loop-premise', { applicantId: applicant.id, idleId: idle.id, ownerId: owner.id, demand: c.buyers.map(person => person.id), contribution: beforeCash - c.initialCash });
  until(sim, () => applicant.workId === shop.buildingId, 8, 'zero-sales food employer must accept a real reachable qualified applicant');
  const assignment = plan.assignments.find((a: any) => a.citizenId === applicant.id);
  assert.ok(assignment); assert.equal(assignment.minutesCap, 0); assert.equal(assignment.workedMinutes, 0); assert.equal(wages.length, 0); assert.equal(plan.reviews.length, 1);
  assert.equal(applicant.role, c.originalRole); assert.equal(applicant.homeId, c.originalHomeId); assert.deepEqual(runtime(sim).wageArrears, originalDebts);
  assert.equal(runtime(sim).publicLabor.jobs[applicant.id], c.originalWorkId); assert.equal(shop.employees, 2, 'same-tick commerce must not shrink accepted staff against the old workforce cache');
  assert.ok(plan.assignments.indexOf(assignment) < plan.assignments.findIndex((a: any) => a.citizenId === idle.id), 'accepted name precedes old zero-cap inactive names');
  exact24(sim, 'accepted-zero');
  until(sim, () => assignment.minutesCap > 0, 60, 'only original onsite employer review may sign a positive funded cap');
  assert.ok(approvals.length > 0); assert.equal(assignment.workedMinutes, 0); assert.equal(wages.length, 0); assert.ok(Number(applicant.id.slice(8)) > Number(idle.id.slice(8)));
  saveObservation(sim, 'signed', { assignment, reviews: plan.reviews });
  const arrived = () => assignment.workedMinutes > 0;
  until(sim, arrived, 900, 'new worker must physically walk the original route and accrue genuine onsite labor');
  assert.ok(wages.length > 0); assert.equal(sim.isOnDuty(applicant.id, shop.buildingId), true);
  exact24(sim, 'first-attendance');
  until(sim, () => production.length > 0 && sales.length > 0, 900, 'finite attendance must produce food and a real buyer must pay for it');
  const p = production as any[], s = sales as any[]; assert.ok(p.every(event => event.minutes > 0 && event.amount > 0)); assert.ok(s.some(event => c.buyers.some(b => b.id === event.citizenId)));
  assert.ok(s.every(event => event.amount === event.quantity * shop.price && event.quantity > 0));
  assert.ok(Math.abs(cash(sim) - beforeCash) < 1e-6, 'wallets, original supplier accounts, actual wages and tax conserve every existing coin');
  const produced = p.reduce((n, event) => n + event.amount, 0), sold = s.reduce((n, event) => n + event.quantity, 0);
  assert.ok(Math.abs(shop.inventory - (90 + produced - sold)) < 1e-7, 'food stock has only original units, actual funded production and actual sales');
  saveObservation(sim, 'loop-complete', { applicantId: applicant.id, assignment, wages, production, sales, approvals });
  exact24(sim, 'sold-loop');
});

test('food hiring demand is read-only and rechecks food, cash and current position within the same people tick', () => {
  const { sim, shop, site, buyers } = setup(); const before = sim.exportSave();
  const names = call(sim, 'foodHiringDemandIds', shop, site) as string[];
  assert.equal(names.length, 92); assert.equal(sim.exportSave(), before, 'query changes no route, permit, money, intent or clock');
  const buyer = buyers[0]; buyer.food = 1; assert.ok(!(call(sim, 'foodHiringDemandIds', shop, site) as string[]).includes(buyer.id));
  buyer.food = 0; const wallet = buyer.money; buyer.money = shop.price - .01; assert.ok(!(call(sim, 'foodHiringDemandIds', shop, site) as string[]).includes(buyer.id)); buyer.money = wallet;
  buyer.position = { x: 950, y: 20.6, z: 950 }; assert.ok(!(call(sim, 'foodHiringDemandIds', shop, site) as string[]).includes(buyer.id), 'same-tick movement must recheck actual ETA before 20:00');
});

test('food shortages do not bypass reserved wages, owner presence or the materials-only business', () => {
  const c = setup(), { sim, shop, applicant, owner } = c, salary = 32 * (.7 + sim.state.districts[0].prosperity / 100);
  const original = { ...owner.position }; owner.position = { ...sim.worldDefinition.spawn }; let before = sim.exportSave();
  assert.equal(call(sim, 'foodShortageHiringOffer', shop, applicant, salary), false); assert.equal(sim.exportSave(), before);
  owner.position = original; nativeApproval(sim, shop);
  // A genuine owner amendment allocates the remaining cash to original workers.
  const required = salary * c.staff.length + 20 * 8 / 24; const returned = sim.shopFunds(shop) - required;
  assert.ok(returned >= 0); sim.transferShopFunds(shop, -returned); owner.money += returned;
  shop.employees = c.staff.length; nativeApproval(sim, shop); before = sim.exportSave();
  assert.equal(call(sim, 'foodShortageHiringOffer', shop, applicant, salary), false); assert.equal(sim.exportSave(), before); assert.ok(sim.shopProtectedFunds(shop) > 0);
  const materials = sim.state.shops.find(s => s.buildingId === 'food-materials')!; before = sim.exportSave();
  assert.equal(call(sim, 'foodShortageHiringOffer', materials, applicant, salary), false); assert.equal(sim.exportSave(), before);
});

"""Bounded root-owned validation with immutable input and raw-output receipts."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import sys

source = Path(sys.argv[1]).resolve()
run = Path(sys.argv[2]).resolve()
argv = json.loads(sys.argv[3])
timeout = int(sys.argv[4]) if len(sys.argv) > 4 else 1200
assert source.is_dir() and isinstance(argv, list) and argv
assert all(isinstance(arg, str) for arg in argv)
assert 1 <= timeout <= 7200
run.mkdir(exist_ok=False)

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def inputs():
    result = {}
    for name in ['src', 'tests', 'scripts', 'public']:
        for path in sorted((source / name).rglob('*')):
            if path.is_file() and not path.is_symlink():
                result[path.relative_to(source).as_posix()] = digest(path)
    for name in ['package.json', 'package-lock.json', 'tsconfig.json', 'index.html', 'vite.config.ts']:
        path = source / name
        if path.is_file() and not path.is_symlink():
            result[name] = digest(path)
    return result

def save(name, data):
    (run / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

first = inputs()
save('inputs-first.json', first)
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
timed_out = False
with (run / 'raw.log').open('wb') as log:
    child = subprocess.Popen(argv, cwd=source, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    proc = Path('/proc') / str(child.pid)
    stat = (proc / 'stat').read_text().split(') ', 1)[1].split()
    save('owned-process.json', {'pid': child.pid, 'parentPid': os.getpid(), 'startTicks': stat[19], 'start': start, 'argv': argv, 'timeoutSeconds': timeout})
    print(json.dumps({'started': run.name, 'pid': child.pid, 'start': start}), flush=True)
    try:
        code = child.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(child.pid, signal.SIGTERM)
        try:
            code = child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait(timeout=10)

last = inputs()
save('inputs-last.json', last)
receipt = {'phase': run.name, 'start': start, 'end': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'exit': code, 'timedOut': timed_out, 'inputCount': len(first), 'sourceStable': first == last,
           'ownedPidGone': not proc.exists(), 'rawSha256': digest(run / 'raw.log'), 'wrapperSha256': digest(Path(__file__))}
if argv == ['npm', 'run', 'build'] and code == 0:
    receipt['distHashes'] = {p.relative_to(source / 'dist').as_posix(): digest(p)
                             for p in sorted((source / 'dist').rglob('*')) if p.is_file() and not p.is_symlink()}
save('receipt.json', receipt)
print(json.dumps(receipt), flush=True)
sys.exit(97 if first != last else 124 if timed_out else code)

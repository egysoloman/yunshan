# 公共诊疗用后物料与真实护理接入

状态：隔离候选已完成定向功能验证，等待 root 独立接合和统一验证；没有写共享源码，没有提交、推送、GPU、Library 或性能测量。

## 修复

原公共医疗订单实际采购材料、共享医患到场窗口、完成20分钟护理并耗用1份材料，却未进入原卫生来源或既有病理护理账。现在每次真实公共耗用保存具名、固定站点及时间的不可变回执，并发出内部认证事件；卫生保管这份用后用品，现有具名YV1病例获得原护理缓解。

只有真实服务分支能登记内部事件认证。伪造 emitEvent、复制或重播事件、普通健康变化及教育/交通事件不能生成污染物或护理。公共来源与原 clinical-* 消耗严格分开：不改变付费临床库存计数/迁移水位，不合并或覆盖原YV1污染时刻。保存要求来源、患者、公共服务站、耗用序号、20分钟、数量1与垃圾批次相互对账，坏引用原子拒绝。

第一次新耗用才给公共订单增加三项optional字段；旧未标订单不在load时回填历史。文化原请愿/订单容量均16，没有淘汰完成订单；每单至多6份原件，总96份。公共源不得以临床聚合归档占位符替代。未处置污染用品和消毒后两份封存物仍保留。

没有新增资金、材料、药物、角色、设施、默认病原来源、感染治愈、终端处置、自动卫生审批。原20分钟诊疗、两并发医生槽、30付费诊疗费用、有限公共额度、原20消毒预算/1清洁物料/10已付医生分钟及共享时间池保持。

## 实际验证

以下是不同定向scope，不能相加称全项目测试通过：

| scope | 实际结果 | 原件 |
|---|---|---|
| 原runtime causal | 0/1，真实业务FAIL：公共耗用后无垃圾 | `../yunshan-public-health-hygiene-candidate-20261003-01/before-causal01/` |
| 原runtime旧公共消费writer | 1/1 PASS，真实旧保存 | `../yunshan-public-health-hygiene-candidate-20261003-01/before-writer01/` |
| 最终候选strict | exit0 | `strict01/` |
| 新功能 | 8 PASS，2个显式writer/reader默认SKIP | `public-health01/` |
| 实际旧公共保存reader | 1 PASS；即时full-save exact，只新未来消费激活垃圾，再+24 exact | `old-reader01/` |
| 原卫生/M1/文化相关 | 45/45 PASS | `related01/` |
| 实际旧公共+付费临床/H2 writer | exit0，公共consumed1、付费worked20、旧clinical垃圾与病理支持 | `joint-old-writer01/` + `actual-old-public-h2-01/` |
| 最终旧联合保存reader | exit0：即时full bytes exact、原旧联合+24、新未来公共消费+24、旧临床垃圾及病理支持逐字保留 | `joint-old-reader01/` |

最后reader于2026-10-03 18:59:53.458739—18:59:55.248104 UTC完成，owned PID256785/startTicks18995059已退出。所有8次运行原raw、receipt、owned-process及inputs-first/last已校验；source首尾稳定、实际PID均不存在。外部联合driver首尾SHA亦一致。最终168个执行输入与strict/新功能/旧reader/相关/联合reader完全同版。

这些测试明确使用原九建筑/384居民的受控审批期限与站位夹具；实际采购、工资、业务窗口与数量执行原规则。YV1只来自显式controlled-validation seed，不能称默认自然疫情、原生长期治理或居民自主卫生响应。此次未运行build/全套/长审计；统一接合build由root完成。

## 最窄接合文件

只复制下面4文件；其它基线文件与root02相同，无core/type/世界/命令变更：

| 文件 | SHA256 |
|---|---|
| `source/src/simulation/culture.ts` | `08cc2f50a188cd137796d50c7704d28c647c602fca997f7ed701c11a41ace76f` |
| `source/src/simulation/hygiene.ts` | `0bce38b7a7e4205d0970dbbac80b449c66ed1a75cad8a862a9bddd637498eb64` |
| `source/src/simulation/pathology.ts` | `506ab47b6898f40e968f4561261a7958f8a2774e6cd3cf90aa008798fa5f25c5` |
| `source/tests/public-health-hygiene.test.ts` | `933feba6dbfde025396f6adc62f9eb10b4270a42681a3ef0709b096aa4645490` |

`public-health-hygiene-final.patch`: `36dc62260a57e4071b332d563cb8a679e214ee2dfc0fe66d00938c23f4246332`。
`execution-manifest.json`逐项列原件路径、时间、argv、PID、source/raw/receipt SHA及scope。
旧联合full-save SHA: `9fae8f06619470d47efcee80ce80e3e0ba4473bd7d4bfc0a46a3453e3a6fafad`；最终联合result SHA: `28d65cf6f261bb2d4dce153cdc8fbac57b2dcbd0241f0febb59b25f59b7deb2c`。

初版目录、原始NOT_RUN manifest、before真实FAIL/writer和每个原件保持原字节；最终卫生独立一行约束关闭公共来源被伪装成临床归档的静态缺口，强负例保留。新test与before test不是整文件同SHA，增加该坏档负例；causal首案业务断言保持。

## 后续仍缺

默认自然病原输入、居民/医院自主卫生申请、公共卫生自动有限采购审批、持有污染物的真实转运/终端处置及城市其他垃圾来源仍未实现。本次只补已发生公共诊疗的真实来源漏项，完整城市目标未完成。

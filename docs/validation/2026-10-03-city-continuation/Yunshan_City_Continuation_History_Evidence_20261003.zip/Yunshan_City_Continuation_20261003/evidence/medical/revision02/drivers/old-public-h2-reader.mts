import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { Simulation } from '/tmp/yunshan-public-health-hygiene-candidate-revision02-20261003-01/source/src/simulation.ts';
import { advance, attachControls, fixture, pin, station, type Controls } from '/tmp/yunshan-public-health-hygiene-candidate-revision02-20261003-01/source/tests/clinical-presence-fixture.ts';
const directory = process.argv[2], output = process.argv[3]; assert.ok(directory && output);
const saved = readFileSync(join(directory, 'old-public-h2-save.json'), 'utf8'), sim = new Simulation(fixture());
const loaded = sim.importSave(saved); assert.equal(loaded.ok, true, loaded.message); assert.equal(sim.exportSave(), saved);
const controls: Controls = new Map(JSON.parse(readFileSync(join(directory, 'old-public-h2-controls.json'), 'utf8'))); attachControls(sim, controls);
const order = sim.state.culture!.orders[0]; assert.equal(order.healthWasteVersion, undefined); assert.equal(order.consumedUnits, 1);
const oldBatch = JSON.stringify(sim.state.hygiene!.batches[0]), oldSupport = JSON.stringify(sim.state.pathology!.episodes.player.supportReceipts[0]);
function exact24() {
  const snapshot = sim.exportSave(), copy = new Simulation(sim.worldDefinition), result = copy.importSave(snapshot); assert.equal(result.ok, true, result.message); assert.equal(copy.exportSave(), snapshot); attachControls(copy, controls);
  for (let tick = 0; tick < 24; tick++) { sim.step(.25); copy.step(.25); assert.equal(copy.exportSave(), sim.exportSave(), `joint original full-save continuation ${tick + 1}`); }
}
exact24(); assert.equal(order.healthWasteVersion, undefined); assert.equal(sim.state.hygiene!.batches.length, 1);
const site = sim.worldDefinition.buildings.find(site => site.id === order.siteId)!;
const person = sim.state.citizens.find(person => !['官员', '医生'].includes(person.role) && sim.state.extension!.actorProfiles[person.id].age >= 18)!;
assert.ok(person); pin(sim, controls, person.id, site, station(site, 0)); sim.state.extension!.actorProfiles[person.id].health = 70;
advance(sim, 20); assert.equal(order.consumedUnits, 2); assert.equal(order.healthConsumptionBaseline, 1); assert.equal(order.healthConsumptions!.length, 1); assert.equal(order.healthConsumptions![0].patientId, person.id);
assert.equal(sim.state.hygiene!.batches.length, 2); assert.equal(sim.state.hygiene!.batches[1].sourceKind, 'public-health'); assert.equal(sim.state.hygiene!.batches[1].generatedUnits, 1);
assert.equal(JSON.stringify(sim.state.hygiene!.batches[0]), oldBatch); assert.equal(JSON.stringify(sim.state.pathology!.episodes.player.supportReceipts[0]), oldSupport);
exact24();
writeFileSync(join(output, 'result.json'), JSON.stringify({ status: 'PASS', immediateFullBytesExact: true, originalJointFullSave24: true, futurePublicConsumptionOnly: true, oldClinicalSourceBytesUnchanged: true, oldPathologySupportBytesUnchanged: true, newJointFullSave24: true, scope: 'controlled original native-employment fixture; not natural outbreak or default governance' }, null, 2) + '\n');
writeFileSync(join(output, 'final-save.json'), sim.exportSave()); console.log('PASS original public + H2 full save immediate exact and 24, future public + 24');

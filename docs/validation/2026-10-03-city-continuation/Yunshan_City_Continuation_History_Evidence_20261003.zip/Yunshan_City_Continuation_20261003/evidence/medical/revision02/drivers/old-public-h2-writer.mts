import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { advance, at, begin, publicCare, setup } from '/tmp/yunshan-public-health-hygiene-candidate-20261003-01/before/source/tests/clinical-presence-fixture.ts';
import { seedControlledYV1Source } from '/tmp/yunshan-public-health-hygiene-candidate-20261003-01/before/source/src/simulation/pathology.ts';
const directory = process.argv[2]; assert.ok(directory);
const context = setup(), { sim } = context, order = publicCare(context);
seedControlledYV1Source(sim, 'player', 'controlled original runtime joint public/H2 compatibility source');
assert.equal(sim.command({ type: 'attendService', targetId: order.id }).ok, true); advance(sim, 20);
assert.equal(order.consumedUnits, 1); assert.equal(order.serviceMinutes.player, 20); assert.equal(Reflect.get(order, 'healthWasteVersion'), undefined); assert.equal(sim.state.hygiene, undefined);
// Observe the original cooldown and real passage of time; never replace it.
advance(sim, sim.state.clinical!.nextVisitAt.player - at(sim));
const paid = begin(sim, context.site); for (let tick = 0; paid.state !== 'completed' && tick < 30; tick++) sim.step(.25);
assert.equal(paid.state, 'completed', paid.lastReason); assert.equal(paid.workedMinutes, 20); assert.equal(paid.consumedUnits, 1);
const batch = sim.state.hygiene!.batches[0]; assert.equal(batch.generatedUnits, 1); assert.equal(batch.sourceReceipts[0].orderId, paid.id); assert.equal(Reflect.get(batch.sourceReceipts[0], 'kind'), undefined);
assert.equal(sim.state.pathology!.episodes.player.supportReceipts[0].orderId, paid.id); assert.equal(Reflect.get(sim.state.pathology!.episodes.player.supportReceipts[0], 'kind'), undefined);
mkdirSync(directory, { recursive: true }); writeFileSync(join(directory, 'old-public-h2-save.json'), sim.exportSave()); writeFileSync(join(directory, 'old-public-h2-controls.json'), JSON.stringify([...context.controls]));
writeFileSync(join(directory, 'result.json'), JSON.stringify({ status: 'PASS', scope: 'controlled original runtime writer; actual public + paid care, YV1 controlled only', publicOrderId: order.id, oldPublicConsumed: order.consumedUnits, paidOrderId: paid.id, paidWorked: paid.workedMinutes, clinicalWaste: batch.id, clock: at(sim) }, null, 2) + '\n');
console.log('PASS actual original public + clinical H2 full-save writer');

# 公共护理历史时间守卫 REV03

最终候选已冻结，READY_FOR_ROOT_INTEGRATION。REV02 原件、真实旧公共/临床联合保存续演及45相关测试保持原字节；本轮不复跑或改称REV03结果。

相对REV02，运行代码仅 pathology.ts public-health 支持回执分支新增直接半开时间界限：`completedAt >= episode.infectiousFrom && completedAt < episode.recoveryAt`。不调用读取当前alive的phaseAt校验历史，因此后来死亡不会剥夺真实护理记录。原 clinical-* schema/校验分支、费用、阶段、默认种源、文化/卫生运行文件均不改。

## 真实因果及运行

外部同一driver SHA `e9e71751bafedc6e99b5fbfba3af13a53202b2cbb5e912a4b31c4c124b7193af`，内容未改，只用argv换runtime。原医生citizen-4通过两个真实10已付薪分钟的YV1用品处理任务累积dose5，实际产生waste-contact潜伏病例；原第二医生citizen-12给其20分钟公共护理，真实耗用source `public-health:service-1:2`，耗用2074、暴露2054、infectiousFrom2294、recoveryAt3494。原公共护理不产生症状支持；负例只在save边界伪加support+relief15。

- before REV02：19:09:38.680689—19:09:39.877704，exit1、PID258502 gone，import真实接受坏档、atomic=false，强拒绝断言FAIL。前置均真成功，非fixture失败。raw `ea15468a9c7c6ce1dbe242f638189f2a45370846067da0071de8ead1d1f9223e`。
- strict REV03：19:11:57.533390—19:12:06.064723，exit0、PID258662 gone。
- after REV03：19:12:40.336629—19:12:41.833873，exit0、PID258744 gone，import拒绝并atomic=true；raw `8d03ab185d66d280b930bb4ac8ff26bfb5d04c7f8b4e4bced556952e16f66934`。
- 新两案：19:12:55.559446—19:12:58.104245，2/2 PASS、0skip、exit0、PID258792 gone；raw `2aa0be65ba32e17a55f15a0bb35f2101781778c6a6054efa015c942c481b7dd9`。包括真潜伏公共源坏档原子拒绝及合法护理后health-zero入口触发原生命规则死亡、历史支持/+24全save保持。

所有scope输入168首尾stable；strict/after/newcases同版。before/after的实际原始存档和伪造坏档分别逐字相同。四owned PID均不存在，driver输入首尾一致，REV02四原输入首尾一致。未执行build、45相关重跑、旧reader重跑、全suite、GPU、性能测量或Library。

## 接合4文件

- `source/src/simulation/culture.ts`: `08cc2f50a188cd137796d50c7704d28c647c602fca997f7ed701c11a41ace76f`
- `source/src/simulation/hygiene.ts`: `0bce38b7a7e4205d0970dbbac80b449c66ed1a75cad8a862a9bddd637498eb64`
- `source/src/simulation/pathology.ts`: `8f76ef5e18f1b3a5ff042857a77547a566b5bbfb9e2c4400a1d9632398063005`
- `source/tests/public-health-hygiene.test.ts`: `17a3506e02eb6de0eaaaa2c2dd1d28e05eb9505d7be9890eb84e4c7d60a6cd1e`

全patch对原root02：`public-health-hygiene-final.patch` SHA `32d7088cb9b9d32eb0d006014b6c542c2310c0c402c0f68680eb526b2694fc48`。
仅REV02→REV03 patch：`revision03.patch` SHA `5081f9b3701b872daaeff85b8e22a5a7dc32c7d59874b2fb5f63ce868ef2bb74`。
完整路径、argv、PID/startTicks、source/raw/receipt SHA和实际before/after结果见execution-manifest.json。

受控站位、原审批期限及显式controlled YV1种源保持明确；实际接触感染、出勤、护理耗用和生命周期执行原业务。这不是默认自然疫情、自然死亡或居民自主卫生的验证。下一步由root统一接合/验证，producer不写共享、不上传。

import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
const source = process.argv[2], output = process.argv[3]; assert.ok(source && output);
const { advance, at, begin, pin, publicCare, setup, station } = await import(`${source}/tests/clinical-presence-fixture.ts`);
const { seedControlledYV1Source } = await import(`${source}/src/simulation/pathology.ts`);
// Controlled original standing/deadline fixture, existing doctor roles and
// money. Infection itself requires two real ten-paid-minute handling jobs;
// public care is a genuine20-minute source while the new episode incubates.
const context = setup(), { sim, site, doctor, controls } = context, order = publicCare(context);
assert.ok(seedControlledYV1Source(sim, 'player', 'controlled primary source for true incubating public-care negative'));
assert.equal(sim.command({ type: 'attendService', targetId: order.id }).ok, true); advance(sim, 20);
assert.equal(order.consumedUnits, 1);
advance(sim, sim.state.clinical.nextVisitAt.player - at(sim));
const paid = begin(sim, site); for (let tick = 0; paid.state !== 'completed' && tick < 30; tick++) sim.step(.25);
assert.equal(paid.state, 'completed', paid.lastReason);
const sources = sim.state.hygiene.batches.slice(); assert.equal(sources.length, 2); assert.ok(sources.every((batch: any) => batch.hazard === 'YV1'));
for (const batch of sources) {
  const result = sim.command({ type: 'disinfectWaste', targetId: batch.id }); assert.equal(result.ok, true, result.message);
  const job = sim.state.hygiene.jobs.at(-1); for (let tick = 0; job.completedAt === null && tick < 30; tick++) sim.step(.25);
  assert.equal(job.state, 'completed', job.reason); assert.equal(job.workedMinutes, 10); assert.equal(job.staffMinutes[doctor.id], 10);
}
const episode = sim.state.pathology.episodes[doctor.id]; assert.ok(episode); assert.equal(episode.origin, 'waste-contact'); assert.equal(episode.phase, 'incubating'); assert.equal(episode.exposureReceipts.reduce((sum: number, receipt: any) => sum + receipt.effectiveDose, 0), 5);
const second = sim.state.citizens.find((person: any) => person.id !== doctor.id && person.workId === site.id && ['医生', 'doctor'].includes(person.role) && sim.state.extension.actorProfiles[person.id].alive && sim.state.extension.actorProfiles[person.id].age >= 18 && sim.state.extension.actorProfiles[person.id].health >= 45);
assert.ok(second, 'the original constructor must supply the second adult doctor');
assert.ok(sim.state.extension.actorProfiles[doctor.id].health < 95, 'the incubating patient must have a real generic public-care need');
pin(sim, controls, doctor.id, site, station(site, 0), 'social'); pin(sim, controls, second.id, site, station(site, 0), 'work');
advance(sim, 20); assert.ok(order.servedIds.includes(doctor.id)); assert.equal(order.serviceMinutes[doctor.id], 20);
const receipt = order.healthConsumptions.find((receipt: any) => receipt.patientId === doctor.id); assert.ok(receipt);
assert.ok(receipt.consumedAt >= episode.exposedAt && receipt.consumedAt < episode.infectiousFrom);
assert.equal(episode.phase, 'incubating'); assert.equal(episode.supportReceipts.length, 0); assert.equal(episode.symptomRelief, 0);
const original = sim.exportSave(), data = JSON.parse(original), e = data.state.pathology.episodes[doctor.id];
e.supportReceipts.push({ kind: 'public-health', sourceId: receipt.id, orderId: receipt.orderId, siteId: receipt.siteId, completedAt: receipt.consumedAt, publicConsumptionIndex: receipt.consumptionIndex, consumedUnits: 1, minutes: 20, relief: 15 }); e.symptomRelief = 15;
const bad = JSON.stringify(data); mkdirSync(output, { recursive: true }); writeFileSync(join(output, 'actual-incubating-source-save.json'), original); writeFileSync(join(output, 'forged-incubating-support-save.json'), bad);
const result = sim.importSave(bad);
writeFileSync(join(output, 'result.json'), JSON.stringify({ scope: 'controlled source and standing fixture; actual handling-induced incubation and actual public consumption; deliberate save mutation only at the negative boundary', causalPreconditions: true, actorId: doctor.id, otherDoctorId: second.id, publicSourceId: receipt.id, exposedAt: episode.exposedAt, publicConsumedAt: receipt.consumedAt, infectiousFrom: episode.infectiousFrom, recoveryAt: episode.recoveryAt, imported: result, atomic: sim.exportSave() === original }, null, 2) + '\n');
console.log(JSON.stringify({ actorId: doctor.id, sourceId: receipt.id, consumedAt: receipt.consumedAt, infectiousFrom: episode.infectiousFrom, imported: result, atomic: sim.exportSave() === original }));
assert.equal(result.ok, false, 'a true incubating public-care source cannot invent symptomatic/recovery nursing'); assert.equal(sim.exportSave(), original, 'rejected support is atomic');

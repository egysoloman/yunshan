云山城市生活阶段交付，2026-10-03。完整城市目标仍未完成。

两个ZIP一起解压到同一个目录，均使用 Yunshan_City_Continuation_20261003/ 前缀。Runtime包包含ROOT05冻结源码、真实生产dist、最终文档、全部本轮原生动态存档和诊断；History包保留ROOT04及更早范围、食品招聘23轮和原始失败。每个原始路径只分配到一个ZIP，全部文件SHA在全局清单，实际ZIP校验结果另附receipt。

先读 FINALREPORT.md、FINALMEMO.md、FINALMATRIX.md 和 final-docs/validation/NEXT-ENTRY.md。FINALMEMO是已冻结的原备忘录；后续Library/Git结果单独记录，不改这些已冻结字节。

source-ROOT05/是实际运行时175输入的历史快照。最终shared只修一份公共休息测试的依赖夹具，位于 fixture-overlay-ROOT05/tests/npc-public-rest.test.ts；另174输入、运行源码和经济driver均相同。若复现最终工作树，在新副本应用该overlay或 evidence/public-rest-fix/public-rest-fixture.patch，保留历史目录原件。安装和构建使用该副本的package-lock与package.json；dist-ROOT05/保存实际已验生产构建七件原文件。需要HTTP服务器打开dist。

真实独立范围：ROOT05 build exit0、DOM35/35、WebGL11/11/errors[]；原完整测试90分钟TIMEOUT_PARTIAL，原日志顶层702通过、6失败、4跳过，另83缩进子项，没有runner最终总计；公共休息夹具原8/2FAIL、候选原10/10PASS只是独立范围。原14日10080tick完成但死亡守卫FAIL（2名NPC死亡）；终局完整保存、即时读档和后续24tick相等通过。以上计数不能相加称项目总数或冒全套通过。Linux软件GPU不证明Mac性能，原截图仍ART FAIL。

原真实失败、原终局3,031,686字节存档、所有78个ROOT05原生artifact、阶梯支持/同高复路失联纯诊断、原产权守卫拒绝及只读现金/警务/物料归因都保留。归因中静态NO_GO、未运行探针和原agent等待GO文字保持原件；root NEXT-ENTRY说明现有用户授权，正常实现无需逐条再确认。

本包没有安装依赖目录、凭据、私有Library辅助程序或官方私有MZ美术。没有宣告经济稳态、参考美术完成、任意地图导入完成或全部游戏完成。

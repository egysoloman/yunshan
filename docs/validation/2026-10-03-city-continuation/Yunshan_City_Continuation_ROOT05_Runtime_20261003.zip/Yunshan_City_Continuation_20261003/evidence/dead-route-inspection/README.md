# ROOT05 两居民真实失联：零步存档与纯几何诊断

本目录只读诊断生产输入；没有编辑 shared/as-run/生产源码，没有复活、迁位置、补钱、改需求或模拟步进。原14日审计死亡守卫仍为 FAIL；reader 即刻与后续24步 PASS 是原审计结果，不等于死亡问题已解决。

## 实际输入与验证边界

- ROOT05 core SHA256：`a361bf6857af3d7f6ab1c22e91897ee8f43def4825c0d16740138074aefb74c4`。
- ROOT05 architecture SHA256：`27431000d8f47ad5c5ece0e8c9319362c0610efda53559854a317995f1fc5f08`。
- a1 HEAD architecture SHA256：`b4d0c35fb868deedfb10e14128c2f3255a1f3a5f3b54f2f853afb0d2656a4d42`，旧代码来自独立 git archive `a1e7f05849590da2e108d05ee69f2ba46ee9ff2d`。
- 真实存档：`/tmp/yunshan-continuation-20261003-05/source/artifacts/economy-root05-14-final.save.json`，3,031,686字节，SHA256 `933329dc11b36cb549c91239149ac7df2f44e07fabb64e708513d9d0dac2edd8`。
- `inspect.ts` 使用原 ROOT05 `createWorld(20261001)` 与真实 `Simulation.importSave`；worldFingerprint `80cd31e2`。导入后及全部纯查询后 `exportSave()` 均与原存档完整字符串相等，实际文件首尾亦相等。没有调用 step/command。
- 终局为 day14/hour8/tick10080，两居民已死亡。因此此查询证明实际位置与几何合同，不能重演死亡前的决定、占床情况、即时供粮或生命结算。`deaths.before` 是原审计真实生前 observer 记录；它已记下相同坐标、`unreachable`、`destinationId=null`、hunger/fatigue0。

## 两个最小真实病例

### citizen-228 / 沈澄1

住宅 `east-b42`，工作 `east-b2`（market）。原生住宅12层，所有地上层权限可用，每层1张床、2个合法床侧，共24侧；全部床侧与入口双向路由存在。终局也有24个可用床侧，不能据此证明死亡前的占床情况。

实际位置 `(1389.9520000000002,220.20000000000002,-243.62698100608847)`，只被自己住宅识别为室内。真实 presence 为 floor1、stairs、link1→2；local `(-12.64799999999991,3.4,-7.026981006088448)`，是 lower-link 平台；整个 `.35m` 身体支撑存在且 stationary collision 为 false。

但是 `canStandInFloorPlan(plan1,local.x,local.z,.35)` 为 false：该函数只认楼层平面，lower-link 伸入 stairHole。`findBuildingFloorPlanRoute:487` 只在 link 存在且脚高与 floor plane 相差 `>.01` 时恢复楼梯；这里高度差恰为0，所以跳到平面路径。`findFloorPlanRoute:443` 的 endpoint 对非0层、平面不可站立点返回 null。因此实际位置到门、同层床、下一层床全部 null。canonical shaft centre 到门仍有28个真实路点，证明并非整栋楼梯或床位不存在。

### citizen-289 / 云溪2

住宅 `west-b34`，工作 `west-b38`（market）。原生住宅13层，共26个合法床侧，所有层权限可用，全部床侧与入口双向可达；终局26侧可用，仍仅是终局占用情况。

实际位置 `(-1019.76,281.6,-754.5963915022352)`，local `(-13.159999999999968,5.000000000000023,-3.396391502235133)`。`floorPlanPresence` 初始 queryFloor1 得 null，fallback queryFloor0 返回 stairs/floor1/link1→2。实际 `findBuildingFloorPlanRoute(home,1,0,pos,door)` 再查询1层得 null，无法恢复 link；平面 endpoint 亦拒绝。

更深的真实支撑问题已记录于 `support-gap.json`：floor1 `up-8` 的 z区间是 `[-3.6,-3.2]`，同高 `half-turn` 平台是 `[-3.0,-1.4]`，两者之间有 `0.20000000000000018m` 空缝。真实 `.35m` 身体前缘达 `-3.046391502235133`，跨入空缝。queryFloor1/2 在 radius0、.1 下有支撑，radius.2、.25、.3、.35 下均为 null。

queryFloor0 却对所有这些半径给出高处支撑，是 `diskSupportedAt:346` 把当前 query plan 的完整 ground slab 无条件放入高处 footprint，填掉了实际楼梯缝。它不能作为合法身体支撑来绕过拒绝。真实 canonical 楼梯第10点自身在所属1层的身体支撑也为 null，虽然 `blocksFloorPlanMovement` 为 false；碰撞未阻挡不等于身体有连续承托。

## 对新旧版本的实际比较

`compare-head.ts` 在同一真实生成世界与两个实际终坐标上，调用 ROOT05 和 a1 的实际 floor geometry，以及各自真实 `Simulation.prototype.floorPlanPresence`。比较包括各 queryFloor/半径、canonical梯点支撑、逐段碰撞和入口路由。输出 `semanticEqual=true`，两个病例完全一致。新旧 worldFingerprint 均 `80cd31e2`。

architecture 唯一 delta 是 choices为空时的提前 return/cache priming，未造成这两个合法/非法支撑病例的行为变化；这两个失联入口原 a1 已有。

## 与食物及死亡记录的关系

实际 terminal 无 roadNetwork、无 closed edge、无放置 voxel。两人的 `walkingAnchors` 都为空，因此从当前位置到所有食品店与 public rest 的 travel 都为 Infinity。

真实 terminal 全城仍有63家开门有粮的食品店，库存总量7348.621224516196；整个14日实际成交8045次、储粮消费3076次、生产7231.368197087968。它们证明“终局全城无粮”不成立，不能回填死亡前的供应。

228 原生前钱包199.29706620239858，终局相同；终局 east 无开门有粮店，最近跨区有粮门距1644.61m，超过原 cross-district 1200m 选择过滤。楼梯修复后仍须沿真实生前局部食品供应/物流追踪，不保证能吃到粮。

289 原生前钱包424.06032995346237；终局0包含死亡后的资金转移，不能当作生前缺钱。终局 west 有3家开门有粮店，最近门距447.737m；是否死亡前也有相同库存，需要生前存档或观察，不能靠终局推断。

`walkingAnchors:939–944` 在室内出口 null 时直接返回 []；`chooseFacility:1193/1237` 剔除所有非有限旅行候选后默认 home/rest；`routeFromCitizen:964` 返回单点；`setDestination:1037` 标 unreachable；`people:1395` 清空 destination。这个真实几何查询足以重现失联路径，但不证明首次进入失联的 tick，也不能区分所有过去到达校验失败；下一死亡前 observer 应捕获首次 anchors为空及其 prior route/activity/position。

## 下一个可独立复现入口与保守修复要求

不必重新跑14日：使用 seed20261001 的实际 home 和上述位置，运行 `geometry-entry.ts` 或 `compare-head.ts` 即可纯几何复现两项 route null。它们只读本目录 `result.json` 的真实输入；原执行 raw 均在目录中。`geometry-raw.log` 是第一次探针错误地假设 returned floor 必有 support 的失败，保留；修正探针后的 `geometry-raw02.log` 为实际完整输出。

下一实现应先保证真实末踏板与 half-turn/landing 共用量化边界，避免同一个名义相邻边被浮点/重复取整分成两条。用完整 `.35m` 身体与1.72m净空沿真实梯段连续验证，保留 `.2m` 升高、真实去向和反向合法性；不能放宽支持半径、借低楼层 slab 填洞、迁人或跳到 landing。

同时，lower-link 与层平面同高仍是实际楼梯点，两个路由入口都须识别真实有效 link 并通过 canonical 梯段复路；处理 stair endpoints 时须保守防止递归重复、越级楼层、身体穿越、权限失效或路障绕过。先让真实梯段几何合法，再使 presence/route 共享该有效支撑合同，不能只接受 floor0 的假阳性。

本轮没有实施任何生产修复。完整目标、局部食品物流、有限公共财政、自然学习与新14日存活验证、ARTFAIL和 macOS 硬件验证仍未完成。

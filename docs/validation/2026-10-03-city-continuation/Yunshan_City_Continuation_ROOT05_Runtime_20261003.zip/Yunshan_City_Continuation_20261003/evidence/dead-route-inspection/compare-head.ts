import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createWorld } from '/tmp/yunshan-continuation-20261003-05/source/src/world.ts';
import { savedWorldFingerprint } from '/tmp/yunshan-continuation-20261003-05/source/src/persistence/world-layout.ts';
import * as current from '/tmp/yunshan-continuation-20261003-05/source/src/architecture-floor-plan.ts';
import * as original from '/tmp/yunshan-public-rest-fix-20261003-01/original-head/src/architecture-floor-plan.ts';
import { Simulation as CurrentSimulation } from '/tmp/yunshan-continuation-20261003-05/source/src/simulation.ts';
import { Simulation as OriginalSimulation } from '/tmp/yunshan-public-rest-fix-20261003-01/original-head/src/simulation.ts';
const root='/tmp/yunshan-dead-route-inspect-20261003-01', prior=JSON.parse(readFileSync(`${root}/result.json`,'utf8'));
const sha=(p:string)=>createHash('sha256').update(readFileSync(p)).digest('hex');
const len=(r:any)=>r?.length??null;
const versions=[['root05',current,CurrentSimulation,'/tmp/yunshan-continuation-20261003-05/source/src/architecture-floor-plan.ts'],['head-a1',original,OriginalSimulation,'/tmp/yunshan-public-rest-fix-20261003-01/original-head/src/architecture-floor-plan.ts']] as const;
const rows=versions.map(([version,g,Simulation,archPath])=>{
 const world=createWorld(20261001);
 const presence=Reflect.get(Simulation.prototype,'floorPlanPresence');
 return {version,archSha256:sha(archPath),worldFingerprint:savedWorldFingerprint(world),cases:prior.rows.map((r:any)=>{
   const b=world.buildings.find(b=>b.id===r.home.id)!,pos=r.actor.position,pres=presence.call({},b,pos),floor=pres.floor;
   const plan=g.getBuildingFloorPlan(b,floor)!,local=g.buildingLocalPosition(b,pos),stair=g.getFloorPlanStairPosition(b,floor),whole=g.getFloorPlanStairRoute(b,1,2)!;
   return {id:r.actor.id,home:b.id,position:pos,presence:pres,floorQueries:[0,1,2].map(f=>({floor:f,support:g.floorPlanSupport(b,f,pos),radiusSweep:[0,.1,.2,.25,.3,.35].map(radius=>({radius,support:g.floorPlanSupport(b,f,pos,radius)}))})),startCanStand:g.canStandInFloorPlan(plan,local.x,local.z),startSelfBlocked:g.blocksFloorPlanMovement(b,floor,pos,pos),currentToDoor:len(g.findBuildingFloorPlanRoute(b,floor,0,pos,b.door)),stairToDoor:len(g.findBuildingFloorPlanRoute(b,floor,0,stair,b.door)),canonicalStairPoints:whole.map((p,i)=>({index:i,position:p,supportAtOwnerFloor:g.floorPlanSupport(b,1,p),movementFromPreviousBlocked:i>0?g.blocksFloorPlanMovement(b,1,whole[i-1],p):false})),landings:plan.stairLandings};
 })};
});
const semanticEqual=JSON.stringify(rows[0].cases)===JSON.stringify(rows[1].cases);
writeFileSync(`${root}/compare-head.json`,JSON.stringify({scope:'Pure geometry comparison on exact terminal positions; no Simulation construction, import, step, revival, teleport, or resource injection.',semanticEqual,rows},null,2)+'\n');
console.log(JSON.stringify({semanticEqual,rows:rows.map(r=>({...r,cases:r.cases.map(({floorQueries,canonicalStairPoints,landings,...c})=>c)}))},null,2));

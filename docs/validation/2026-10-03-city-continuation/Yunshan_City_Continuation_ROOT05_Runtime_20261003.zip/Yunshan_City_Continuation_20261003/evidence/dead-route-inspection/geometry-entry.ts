import { readFileSync, writeFileSync } from 'node:fs';
import { createWorld } from '/tmp/yunshan-continuation-20261003-05/source/src/world.ts';
import { homeRestPoints } from '/tmp/yunshan-continuation-20261003-05/source/src/simulation/home-rest.ts';
import { buildingLocalPosition, getBuildingFloorPlan, floorPlanSupport, getFloorPlanStairPosition, getFloorPlanStairRoute, canStandInFloorPlan, findFloorPlanRoute, findBuildingFloorPlanRoute } from '/tmp/yunshan-continuation-20261003-05/source/src/architecture-floor-plan.ts';
const prior=JSON.parse(readFileSync('/tmp/yunshan-dead-route-inspect-20261003-01/result.json','utf8')), world=createWorld(20261001);
const len=(r:any)=>r?.length??null;
const results=prior.rows.map((r:any)=>{
 const b=world.buildings.find(b=>b.id===r.home.id)!, pos=r.actor.position, floor=r.interiors[0].presence.floor;
 const plan=getBuildingFloorPlan(b,floor)!, stair=getFloorPlanStairPosition(b,floor);
 const supportQueries=[floor,floor-1,floor+1].map(queryFloor=>({queryFloor,support:floorPlanSupport(b,queryFloor,pos)}));
 const support=supportQueries.find(q=>q.support&&Math.abs(q.support.y-pos.y)<=.26)!.support!, link=support.link!, whole=getFloorPlanStairRoute(b,link.fromFloor,link.toFloor)!;
 let index=0,best=Infinity;whole.forEach((p,i)=>{const d=Math.hypot(p.x-pos.x,p.y-pos.y,p.z-pos.z);if(d<best){best=d;index=i;}});
 const exit=whole[0], exitLocal=buildingLocalPosition(b,exit), point=(target:number)=>homeRestPoints(b,target)[0];
 return {id:r.actor.id,building:b.id,position:pos,supportQueries,support,planeHeight:b.position.y+.6+plan.y,heightDifference:pos.y-(b.position.y+.6+plan.y),stairLocal:buildingLocalPosition(b,stair),stairCanStand:canStandInFloorPlan(plan,buildingLocalPosition(b,stair).x,buildingLocalPosition(b,stair).z),nearestWholeIndex:index,nearestWholePoint:whole[index],distanceToNearestWholePoint:best,wholeStart:exit,wholeStartSupport:floorPlanSupport(b,floor,exit),wholeStartCanStand:canStandInFloorPlan(plan,exitLocal.x,exitLocal.z),tailStartToDoor:len(findBuildingFloorPlanRoute(b,link.fromFloor,0,exit,b.door)),currentToDoor:len(findBuildingFloorPlanRoute(b,floor,0,pos,b.door)),stairToDoor:len(findBuildingFloorPlanRoute(b,floor,0,stair,b.door)),currentToSameFloorBed:len(findBuildingFloorPlanRoute(b,floor,floor,pos,point(floor).position)),currentToNextFloorBed:len(findBuildingFloorPlanRoute(b,floor,link.toFloor,pos,point(link.toFloor).position)),whole,stairLandings:plan.stairLandings,slabSupportAtCurrent:floorPlanSupport(b,floor,pos)};
});
writeFileSync('/tmp/yunshan-dead-route-inspect-20261003-01/geometry-entry.json',JSON.stringify(results,null,2)+'\n');
console.log(JSON.stringify(results.map(({whole,stairLandings,...r}:any)=>r),null,2));

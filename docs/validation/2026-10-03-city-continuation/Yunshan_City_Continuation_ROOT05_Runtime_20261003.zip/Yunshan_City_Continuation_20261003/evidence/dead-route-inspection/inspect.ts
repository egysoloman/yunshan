import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { createWorld } from '/tmp/yunshan-continuation-20261003-05/source/src/world.ts';
import { Simulation } from '/tmp/yunshan-continuation-20261003-05/source/src/simulation.ts';
import { homeRestPoints } from '/tmp/yunshan-continuation-20261003-05/source/src/simulation/home-rest.ts';
import { buildingLocalPosition, floorPlanSupport, getBuildingFloorPlan, getFloorPlanStairPosition, canStandInFloorPlan, blocksFloorPlanMovement, findFloorPlanRoute } from '/tmp/yunshan-continuation-20261003-05/source/src/architecture-floor-plan.ts';
import { canAccessFloor } from '/tmp/yunshan-continuation-20261003-05/source/src/access.ts';
import { isRoadOpen } from '/tmp/yunshan-continuation-20261003-05/source/src/roads.ts';

const source = '/tmp/yunshan-continuation-20261003-05/source';
const savePath = `${source}/artifacts/economy-root05-14-final.save.json`;
const raw = readFileSync(savePath, 'utf8'), report = JSON.parse(readFileSync(`${source}/artifacts/economy-root05-14.json`, 'utf8'));
const hash = (text: string) => createHash('sha256').update(text).digest('hex');
assert.equal(hash(raw), report.finalSave.sha256);
const world = createWorld(report.seed), sim = new Simulation(world);
assert.equal(sim.importSave(raw).ok, true);
assert.equal(sim.exportSave(), raw);
const allowed = new Set(['citizenIdentity', 'floorPlanPresence', 'floorPlanRoute', 'availableHomeRestPoints', 'walkingAnchors', 'walkingTree', 'buildingNode', 'routeFromCitizen', 'shopCommodity']);
const call = (name: string, ...args: any[]): any => { assert(allowed.has(name)); return Reflect.get(sim, name).call(sim, ...args); };
const distance = (a: any, b: any) => Math.hypot(a.x-b.x, a.y-b.y, a.z-b.z);
const length = (route: any[] | null) => route?.length ?? null;
const buildingSummary = (b: any) => ({ id: b.id, kind: b.kind, name: b.name, floorPlanProfile: b.floorPlanProfile, districtId: b.districtId, floors: b.floors, height: b.height, position: b.position, rotation: b.rotation, door: b.door, publicFloors: b.publicFloors, requiredPermission: b.requiredPermission, floorPermissions: b.floorPermissions, floorUses: b.floorUses });
const food = sim.state.shops.filter(shop => call('shopCommodity', shop) === 'food');
const supply = { totalShops: food.length, openStockedShops: food.filter(s => s.open && s.inventory >= 1).length, foodInventory: food.reduce((sum, s) => sum+s.inventory, 0), saleCount: report.totals.saleCount, storedMeals: report.totals.storedMeals, production: report.totals.production };
const rows = ['citizen-228', 'citizen-289'].map(id => {
  const actor = sim.state.citizens.find(c => c.id === id)!;
  const home = world.buildings.find(b => b.id === actor.homeId)!, work = world.buildings.find(b => b.id === actor.workId)!;
  const role = call('citizenIdentity', actor), person = { role, identities: [role] };
  const anchors = call('walkingAnchors', actor) as any[];
  const travel = (b: any) => { const target = call('buildingNode', b); return Math.min(...anchors.map(a => a.cost+(call('walkingTree', a.node).costs.get(target.id) ?? Infinity))); };
  const interiors = world.buildings.flatMap(b => {
    const presence = call('floorPlanPresence', b, actor.position);
    if (!presence) return [];
    const plan = getBuildingFloorPlan(b, presence.floor), local = buildingLocalPosition(b, actor.position), stair = getFloorPlanStairPosition(b, presence.floor);
    return [{ building: buildingSummary(b), presence, local, startCanStand: plan && canStandInFloorPlan(plan, local.x, local.z), selfBlocked: blocksFloorPlanMovement(b, presence.floor, actor.position, actor.position), routeToStair: length(findFloorPlanRoute(b, presence.floor, actor.position, stair)), routeFromStair: length(findFloorPlanRoute(b, presence.floor, stair, actor.position)), routeToDoor: length(call('floorPlanRoute', b, presence.floor, 0, actor.position, b.door)), stair, stairSupport: floorPlanSupport(b, presence.floor, stair), stairSelfBlocked: blocksFloorPlanMovement(b, presence.floor, stair, stair), fixtures: plan?.fixtures, walls: plan?.walls }];
  });
  const beds = Array.from({ length: home.floors }, (_, floor) => {
    const points = homeRestPoints(home, floor), plan = getBuildingFloorPlan(home, floor);
    return { floor, access: Array.from({ length: floor+1 }, (_, f) => f).every(f => canAccessFloor(home, f, person)), fixtures: plan?.fixtures.filter(f => f.kind === 'bed').length, stairTreads: plan?.stairTreads.length, points: points.map(p => ({ ...p, support: floorPlanSupport(home, floor, p.position), entranceRoute: length(call('floorPlanRoute', home, 0, floor, home.door, p.position)), exitRoute: length(call('floorPlanRoute', home, floor, 0, p.position, home.door)) })) };
  });
  const stocked = food.filter(s => s.open && s.inventory >= 1);
  const publicRest = world.buildings.filter(b => ['pavilion', 'station', 'clinic'].includes(b.kind)).map(b => ({ id: b.id, districtId: b.districtId, kind: b.kind, travel: travel(b), routeLength: call('routeFromCitizen', actor, b, anchors).length }));
  return { actor, beforeDeath: report.deaths.find((d: any) => d.id === id), profile: sim.state.extension?.actorProfiles[id], role, activity: Reflect.get(sim, 'runtime').activities[id], home: buildingSummary(home), work: buildingSummary(work), interiors, anchors, homeTravel: travel(home), workTravel: travel(work), homeOutsideRouteLength: call('routeFromCitizen', actor, home, anchors).length, bedFloors: beds, terminalAvailableBedSides: call('availableHomeRestPoints', actor, home).length, food: { openStockedCity: stocked.length, openStockedSameDistrict: stocked.filter(s => s.districtId===actor.districtId).length, affordableTerminal: stocked.filter(s => actor.money>=s.price).length, finiteTravel: stocked.filter(s => Number.isFinite(travel(world.buildings.find(b => b.id===s.buildingId)!))).length, closestDoor: [...stocked].map(s => ({ shopId:s.id, price:s.price, inventory:s.inventory, buildingId:s.buildingId, distance:distance(actor.position, world.buildings.find(b => b.id===s.buildingId)!.door) })).sort((a,b)=>a.distance-b.distance).slice(0,3) }, publicRest };
});
const after = sim.exportSave(); assert.equal(after, raw); assert.equal(readFileSync(savePath,'utf8'), raw);
const output = { scope: 'Terminal actual save, zero simulation steps. Geometry queries retain terminal dead actors; this does not replay their pre-death decision or occupation state.', exactSaveBeforeAfter: true, saveSha256: hash(raw), tick: sim.state.tick, day: sim.state.day, hour: sim.state.hour, layout: world.layoutVersion, fingerprint: JSON.parse(after).worldFingerprint, coreSha256: hash(readFileSync(`${source}/src/simulation.ts`,'utf8')), roadNetwork: sim.state.roadNetwork ?? null, closedEdges: world.edges.filter(e=>!isRoadOpen(sim.state,e.id)).map(e=>e.id), voxelCount: sim.state.voxels.length, supply, rows };
writeFileSync('/tmp/yunshan-dead-route-inspect-20261003-01/result.json', JSON.stringify(output, null, 2)+'\n');
console.log(JSON.stringify({ exactSaveBeforeAfter: output.exactSaveBeforeAfter, saveSha256: output.saveSha256, coreSha256:output.coreSha256, supply, closedEdges:output.closedEdges, rows:rows.map(r=>({id:r.actor.id,home:r.home.id,work:r.work.id,interiors:r.interiors.map(p=>({building:p.building.id,presence:p.presence,startCanStand:p.startCanStand,selfBlocked:p.selfBlocked,routeToStair:p.routeToStair,routeToDoor:p.routeToDoor,stairSelfBlocked:p.stairSelfBlocked})),anchors:r.anchors,terminalAvailableBedSides:r.terminalAvailableBedSides,homeBedSides:r.bedFloors.reduce((n,f)=>n+f.points.length,0),food:r.food,finitePublicRest:r.publicRest.filter(b=>Number.isFinite(b.travel)).length})) },null,2));

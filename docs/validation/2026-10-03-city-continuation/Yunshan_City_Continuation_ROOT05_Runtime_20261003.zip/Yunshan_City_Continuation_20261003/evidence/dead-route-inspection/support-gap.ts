import { writeFileSync } from 'node:fs';
import { createWorld } from '/tmp/yunshan-continuation-20261003-05/source/src/world.ts';
import { getBuildingFloorPlan, floorPlanSupport } from '/tmp/yunshan-continuation-20261003-05/source/src/architecture-floor-plan.ts';
const b=createWorld(20261001).buildings.find(b=>b.id==='west-b34')!, p=getBuildingFloorPlan(b,1)!;
const pos={x:-1019.76,y:281.6,z:-754.5963915022352},up=p.stairTreads.find(t=>t.id==='up-8')!,turn=p.stairLandings.find(t=>t.id==='half-turn')!;
const result={building:b.id,floor:1,planeHeight:p.y,stairHole:p.stairHole,lastUpTreads:p.stairTreads.filter(t=>['up-6','up-7','up-8'].includes(t.id)),halfTurn:turn,localY:pos.y-b.position.y-.6,localZ:pos.z-b.position.z,gap:turn.rect.z0-up.rect.z1,bodyRadius:.35,frontEdgeLocalZ:pos.z-b.position.z+.35,queries:[0,1,2].map(f=>({floor:f,support:floorPlanSupport(b,f,pos)}))};
writeFileSync('/tmp/yunshan-dead-route-inspect-20261003-01/support-gap.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));

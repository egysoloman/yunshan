ROOT05 food-contract terminal handoff — read only, frozen 2026-10-03

JSON: terminal-food-contracts.json
JSON SHA256: 2c2a8e7698e13a5bbb78b9e6721527fb3788229d9fab946aa890df4198a8894c
Original save: /tmp/yunshan-continuation-20261003-05/source/artifacts/economy-root05-14-final.save.json
Original save SHA256: 933329dc11b36cb549c91239149ac7df2f44e07fabb64e708513d9d0dac2edd8
ROOT05 src/simulation.ts SHA256: a361bf6857af3d7f6ab1c22e91897ee8f43def4825c0d16740138074aefb74c4
ROOT05 src/world.ts SHA256: 8fd12c086d9953486b24bb14a287cc72c232d520d80a9fc845f68cd17367e843

Only Python read the original JSON and frozen source literals/formulas. No Node, simulation, trusted world generation, tests, build, GPU or new route/geometry query was run. Production shared and ROOT05 source were not modified.

Actual terminal facts: raw day14/hour8/tick10080/monotonicTime20640. There are 15 acceptance tags and privateMoves15. Their final work kinds are market10/workshop5, classified from frozen world literals; this is a final-work fact and does not identify their historical acceptance branch. All15 have no day14 private cap. Seven retained day12 plans have zero cap/no review: citizen-218/254/262/273/284/419/471; this does not prove earlier overwritten private plans never had a signature.

All273 historical-public-job actors still in nonprivate jobs have hunger<45, so the terminal recruitment entry gate has no applicant. Public retained shifts are days8/9/10/11, and day12 is the first missing public plan within the retained day8–14 horizon. This proves missing retained coverage, not the entire causal trajectory.

All47 farm/dock shops are listed with actual main-job and source-order private rosters, owner needs/health, authoritative funds, payroll debt and protected commitments. Only river-b19/citizen-33 has a day14 positive private cap480/worked0, reviewed at20612. Owner presence, legal work/sale routes, <=500 home travel, voxel permission checks, and before17/before20 ETA remain NOT_QUERIED for all47 shops. Recorded roster is not evidence of actual on-duty presence.

No material→energy→capacity diagnosis is added. No further work is pending in this delegated scope.

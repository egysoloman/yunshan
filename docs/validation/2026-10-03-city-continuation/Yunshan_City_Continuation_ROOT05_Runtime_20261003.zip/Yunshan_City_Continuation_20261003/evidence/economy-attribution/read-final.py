"""Read-only analysis of immutable ROOT05 evidence. Does not run Simulation."""
import collections
import hashlib
import json
import pathlib
import re

OUT = pathlib.Path(__file__).parent
ROOT = pathlib.Path('/tmp/yunshan-continuation-20261003-05')
SOURCE = ROOT / 'source'
AUDIT = SOURCE / 'artifacts/economy-root05-14.json'
SAVE = SOURCE / 'artifacts/economy-root05-14-final.save.json'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

before_save = sha(SAVE)
audit = json.loads(AUDIT.read_text())
saved = json.loads(SAVE.read_text())
state, runtime = saved['state'], saved['runtime']
profiles = state['extension']['actorProfiles']
citizens = {c['id']: c for c in state['citizens']}
companies = {c['buildingId']: c for c in state['extension']['companies']}
districts = {d['id']: d for d in state['districts']}
now = state['extension']['lastUpdate']
day = int(now // 1440)

# This reproduces only the kind/ID selection in world.ts, not its positions,
# floors, legal routes or support/ACL. Those require the NOT_RUN native driver.
world_source = (SOURCE / 'src/world.ts').read_text()
plans = {}
for district, count, kinds in re.findall(r"\{ id: '([^']+)'[^\n]+?count: (\d+), kinds: \[([^\]]+)\]", world_source):
    plans[district] = (int(count), re.findall(r"'([^']+)'", kinds))
assert len(plans) == 11
core_ids = ['core-main', 'core-admin-east', 'core-data-west', 'core-energy-south',
            'core-security-north', 'core-council', 'core-embassy', 'core-archives',
            'core-treasury', 'core-interchange', 'core-clinic', 'core-dock-building']
core_kinds = ['core', 'hall', 'workshop', 'workshop', 'police', 'hall', 'hall', 'hall', 'bank', 'station', 'clinic', 'dock']
kind_by_id = dict(zip(core_ids, core_kinds))
for district, (count, kinds) in plans.items():
    for i in range(count):
        if district == 'core' and i < len(core_ids):
            continue
        local = i - len(core_ids) if district == 'core' else i
        kind = kinds[(local // 4 + local % 4) % len(kinds)]
        if i == 0 and district in ['summit', 'airport', 'starport']:
            kind = {'summit': 'pavilion', 'airport': 'airport', 'starport': 'starport'}[district]
        kind_by_id[f'{district}-b{i}'] = kind

shop_rows = []
for shop in state['shops']:
    kind = kind_by_id[shop['buildingId']]
    assert kind in ['market', 'farm', 'dock', 'workshop']
    company = companies.get(shop['buildingId'])
    owner_id = company['ownerId'] if company else shop.get('ownerId')
    owner = state['player'] if owner_id == 'player' else citizens.get(owner_id)
    profile = profiles.get(owner_id, {})
    funds = company['capital'] if company else shop.get('cash', 0)
    owed = sum(w['amount'] for key in ['wageArrears', 'wageAccruals', 'wages'] for w in runtime.get(key, []) if w.get('shopId') == shop['id'])
    plan = runtime.get('privateLabor', {}).get('shifts', {}).get(shop['id'])
    commitment = sum((a['minutesCap'] - a['workedMinutes']) * a['ratePerMinute'] for a in plan['assignments']) if plan and plan['day'] == day else 0
    shop_rows.append({'id': shop['id'], 'buildingId': shop['buildingId'], 'districtId': shop['districtId'],
        'kind': kind, 'commodity': 'materials' if kind == 'workshop' else 'food',
        'inventory': shop['inventory'], 'open': shop['open'], 'employees': shop['employees'],
        'price': shop['price'], 'funds': funds, 'owed': owed, 'currentCommitment': commitment,
        'cashAfterDebtAndCommitment': funds - owed - commitment,
        'ownerId': owner_id, 'ownerAlive': profile.get('alive'), 'ownerHealth': profile.get('health'),
        'ownerNeeds': owner.get('needs') if owner else None,
        'ownerPose': owner.get('position') if owner else None,
        'privateShift': plan, 'presenceACLCurrentRoute': 'NOT_QUERIED'})

by_kind = {}
for kind in ['market', 'farm', 'dock', 'workshop']:
    rows = [x for x in shop_rows if x['kind'] == kind]
    by_kind[kind] = {'shops': len(rows), 'inventory': sum(x['inventory'] for x in rows),
        'open': sum(x['open'] for x in rows), 'employees': sum(x['employees'] for x in rows),
        'inventoryAtLeast120': sum(x['inventory'] >= 120 for x in rows)}

district_rows = []
for district in state['districts']:
    actors = [c for c in state['citizens'] if c['districtId'] == district['id'] and profiles[c['id']]['alive']]
    food = [x for x in shop_rows if x['districtId'] == district['id'] and x['commodity'] == 'food']
    district_rows.append({'id': district['id'], 'energy': district['energy'], 'pollution': district['pollution'],
        'foodShopCount': len(food), 'foodShopStock': sum(x['inventory'] for x in food),
        'openStockedFoodShops': sum(x['open'] and x['inventory'] >= 1 for x in food),
        'unlocatedFreight': runtime['freight'].get(district['id'], 0), 'alive': len(actors),
        'hungryBelow20WithMoneyAtLeast15': sum(c['needs']['hunger'] < 20 and c['money'] >= 15 for c in actors),
        'meanHunger': sum(c['needs']['hunger'] for c in actors) / max(1, len(actors))})

names = collections.defaultdict(list)
for citizen in state['citizens']:
    names[citizen['name']].append(citizen['id'])
exits = []
for event in state['events']:
    if event.get('type') != 'dispatch':
        continue
    name = event['text'].split('因补给')[0]
    exits.append({**event, 'actorName': name, 'matchingActorIds': names[name],
        'derivedClock': 480 + event['tick'] * 2, 'derivedDay': int((480 + event['tick'] * 2) // 1440)})

snapshots = [x for x in audit['snapshots'] if x['tick'] % 720 == 0]
deltas = []
for previous, current in zip(snapshots, snapshots[1:]):
    totals = {k: current['wages'][k] - previous['wages'][k] for k in ['sales', 'saleCount', 'storedMeals', 'production', 'publicSupplies', 'security', 'operations', 'payrollPrivateRequested']}
    deltas.append({'fromTick': previous['tick'], 'toTick': current['tick'], 'toDay': current['day'],
        'actualCumulativeDifference': totals, 'openAtSample': current['shops']['open'],
        'aliveAtSample': current['npc']['alive'], 'storedFoodAtSample': current['npc']['storedFood']})

# In this audit commands are limited to speed/policy assignment. No births,
# household meal orders, construction orders, clinical or power purchases ran.
# Material stock has only native productive additions, and actual public buys.
initial_food = by_kind['market']['shops'] * 90 + by_kind['farm']['shops'] * 160 + by_kind['dock']['shops'] * 90
initial_materials = by_kind['workshop']['shops'] * 90
initial_cargo = sum(28 for v in state['vehicles'] if v['kind'] == 'road' and v['id'].endswith('-1')) + sum(60 for v in state['vehicles'] if v['kind'] == 'flight')
current_food = sum(x['inventory'] for x in shop_rows if x['commodity'] == 'food')
materials_min_produced = audit['totals']['publicSupplies'] - initial_materials
food_max_produced = audit['totals']['production'] - materials_min_produced
current_cargo = sum(v['cargo'] for v in state['vehicles'])
current_freight = sum(runtime['freight'].values())
current_carry = sum(c.get('food', 0) for c in state['citizens']) + state['player']['inventory'].get('food', 0)
implied_food_produced = current_food + current_cargo + current_freight + current_carry + audit['totals']['saleCount'] + audit['totals']['storedMeals'] - initial_food - initial_cargo
physical = {'initialFoodShopStock': initial_food, 'initialIndustrialStock': initial_materials,
    'nativeSeedCargo': initial_cargo, 'currentFoodShopStock': current_food,
    'currentIndustrialStock': by_kind['workshop']['inventory'], 'currentFreight': current_freight,
    'currentVehicleCargo': current_cargo, 'currentActorCarry': current_carry,
    'immediateRetailMeals': audit['totals']['saleCount'], 'carryMealsConsumed': audit['totals']['storedMeals'],
    'minimumIndustrialProductionFromProcurement': materials_min_produced,
    'upperBoundFoodProduction': food_max_produced, 'foodProductionImpliedByFoodStocksAndConsumption': implied_food_produced,
    'twoIndependentEquationDifference': food_max_produced - implied_food_produced,
    'foodDailyUpperBound': food_max_produced / 14, 'idealFoodMealsPerDayOriginalNeeds': 616 * 1440 * .05 / 52,
    'scope': 'Source-defined gameplay portions. No physical mass/MW claim; kinds/seed cargo reconstructed only, legal geometry NOT_QUERIED.'}

dump('final-native-observation.json', {'status': 'READ_ONLY_JSON_SOURCE_ANALYSIS',
    'auditStatus': audit['status'], 'auditFailure': audit.get('failure'), 'terminalSave': str(SAVE),
    'terminalSaveSha256': before_save, 'snapshotFinal': audit['snapshots'][-1], 'stockByKind': by_kind,
    'stockByDistrict': district_rows, 'physicalEquations': physical, 'dailyCumulativeDifferences': deltas,
    'retainedDispatchExitNotices': exits, 'allShopDetails': shop_rows,
    'absentOptionalBodies': [k for k in ['power', 'roadNetwork', 'roadworks', 'education', 'hygiene', 'pathology', 'shopLifecycle', 'roadDemands'] if k not in state],
    'nativeImportDriver': 'diagnose-final.ts STATIC / NOT_RUN',
    'limitations': ['No historical per-procurement crimeId is in the audit. Do not attribute every 7728 unit of cash to a repeated same-case purchase.',
        'Retained exit notices prove repeated exits by names, but their text conflates supply, health and wage-window causes.',
        'Current native legal route/workpoint/ACL tests remain NOT_RUN. No final pose is used as a historical pose.',
        'Original foodDistance death observation includes materials and straight distances, so is not a food-route authority.']})

inputs = json.loads((ROOT / 'frozen-inputs.json').read_text())
actual_hashes = {name: sha(SOURCE / name) for name in inputs}
audit_matches = {name: sha(SOURCE / name) for name in audit['sourceHash']}
assert actual_hashes == inputs
assert audit['sourceHash'] == audit['endSourceHash'] == audit_matches
assert sha(SAVE) == before_save == '933329dc11b36cb549c91239149ac7df2f44e07fabb64e708513d9d0dac2edd8'
dump('final-read-receipt.json', {'scope': 'Python standard library reads only; no Node/Simulation/commands/steps/tests/build.',
    'fullFrozenInputCount': len(inputs), 'auditRuntimeSourceCount': len(audit_matches),
    'all175StillMatchFreeze': True, 'auditStartEndAndActualRuntimeSourcesMatch': True,
    'originalSaveBeforeAndAfterSha256': before_save,
    'originalEvidence': {str(path): sha(path) for path in [AUDIT, SAVE, ROOT / 'economy14-01/receipt.json', ROOT / 'economy14-01/raw.log', ROOT / 'frozen-inputs.json']},
    'analysisScriptSha256': sha(pathlib.Path(__file__)),
    'observationSha256': sha(OUT / 'final-native-observation.json')})
print(json.dumps({'readOnly': True, 'inputsStable': len(inputs), 'auditRuntimeHashes': len(audit_matches),
    'physical': physical, 'dispatchExitNoticesRetained': len(exits), 'originalSaveSha256': before_save}, ensure_ascii=False))

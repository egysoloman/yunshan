// STATIC / NOT_RUN: final ROOT05 writer evidence is required before runtime GO.
// Read-only importer/query scope: no command, step, actor mutation, or fallback city.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
const bindingPath = process.argv[2]; assert.ok(bindingPath);
const binding = JSON.parse(await readFile(bindingPath, 'utf8'));
assert.equal(binding.runtimeGO, true, 'A new true GO binding must be created; the frozen false binding is not authority to run.');
const outputRoot = resolve(binding.outputRoot); assert.ok(outputRoot.startsWith('/tmp/yunshan-food-recruitment-default-diagnosis-root05-'));
await mkdir(outputRoot, { recursive: false });
const report: any = { scope: 'Single actual terminal save, trusted selector and read-only query. No historical gate timing inferred from one snapshot.', startedAt: new Date().toISOString(), bindingPath };
const sha = (text: string | Buffer) => createHash('sha256').update(text).digest('hex');
async function frozenInputs() {
  const actual: Record<string, string> = {};
  for (const [name, expected] of Object.entries(binding.copiedHashes)) {
    const bytes = await readFile(join(binding.sourceRoot, name)); actual[name] = sha(bytes); assert.equal(actual[name], expected, `frozen source changed: ${name}`);
  }
  return actual;
}
try {
  report.firstInputs = await frozenInputs();
  const auditBytes = await readFile(binding.auditPath, 'utf8'), saveBytes = await readFile(binding.savePath, 'utf8');
  const audit = JSON.parse(auditBytes), saved = JSON.parse(saveBytes);
  report.original = { auditPath: binding.auditPath, auditSha256: sha(auditBytes), savePath: binding.savePath, saveSha256: sha(saveBytes), saveBytes: Buffer.byteLength(saveBytes) };
  assert.equal(audit.finalSave.sha256, report.original.saveSha256); assert.deepEqual(audit.sourceHash, audit.endSourceHash);
  for (const [name, hash] of Object.entries(audit.sourceHash)) assert.equal(binding.copiedHashes[name], hash, `audit source mismatch: ${name}`);
  const { selectSavedWorld, savedWorldFingerprint } = await import(pathToFileURL(join(binding.sourceRoot, 'src/persistence/world-layout.ts')).href);
  const { Simulation } = await import(pathToFileURL(join(binding.sourceRoot, 'src/simulation.ts')).href);
  const { tradeSignals } = await import(pathToFileURL(join(binding.sourceRoot, 'src/simulation/trade.ts')).href);
  const { shopLifecycleAllowsNewPayroll } = await import(pathToFileURL(join(binding.sourceRoot, 'src/simulation/shop_lifecycle.ts')).href);
  const { homeRestPointBlockedByVoxels } = await import(pathToFileURL(join(binding.sourceRoot, 'src/simulation/home-rest.ts')).href);
  const selected = selectSavedWorld(saveBytes); report.selected = { layout: selected.layout, fingerprint: savedWorldFingerprint(selected.world) };
  const sim: any = new Simulation(selected.world), imported = sim.importSave(saveBytes);
  report.imported = imported; assert.ok(imported.ok, imported.message);
  const before = sim.exportSave(); assert.equal(before, saveBytes, 'Current writer/importer must preserve the actual full terminal bytes before any query.');
  const s = sim.state, r = Reflect.get(sim, 'runtime'), buildings = new Map<any, any>(selected.world.buildings.map((b: any) => [b.id, b]));
  const call = (name: string, ...args: any[]) => Reflect.get(sim, name).call(sim, ...args);
  const day = Math.floor(s.extension.lastUpdate / 1440), now = s.day * 1440 + s.hour * 60;
  const profiles = s.extension.actorProfiles, labor = r.publicLabor, shopsByBuilding = new Map<any, any>(s.shops.map((shop: any) => [shop.buildingId, shop]));
  const foodSites = s.shops.filter((shop: any) => ['farm', 'dock'].includes(buildings.get(shop.buildingId).kind));
  report.terminal = { tick: s.tick, displayedHour: s.hour, monotonicTime: s.extension.lastUpdate, day, treasury: s.treasury, auditStatus: audit.status, cashTrend: audit.economicTrend, budget: sim.publicBudgetSnapshot(), publicService: sim.publicServiceCoverage(), privateLabor: call('privateLaborCoverage') };
  report.publicEntry = { present: !!labor, standingUntilDay: labor?.standingUntilDay ?? null, standingStillActive: !labor || day < labor.standingUntilDay, historicalRegisteredIds: Object.keys(labor?.jobs ?? {}), approvedShifts: labor?.shifts ?? [], statistics: labor?.stats ?? null, firstSavedApprovalAt: labor?.shifts.length ? Math.min(...labor.shifts.map((x: any) => x.approvedAt)) : null, declaredActivationDay: labor ? labor.standingUntilDay - 1 : null, exactActivationMinutePersisted: false };
  report.snapshotHistory = audit.snapshots.map((sample: any) => ({ tick: sample.tick, day: sample.day, hour: sample.hour, treasury: sample.treasury, publicBudget: sample.publicBudget, publicService: sample.publicService, privateLabor: sample.privateLabor, npcMoney: sample.npcMoney, npc: sample.npc }));
  const applicantRows: any[] = [], structuralApplicants: any[] = [], counts: Record<string, number> = {};
  for (const c of s.citizens) {
    const profile = profiles[c.id], identity = call('citizenIdentity', c), currentShop = shopsByBuilding.get(c.workId);
    const publicPromises = (labor?.shifts ?? []).flatMap((shift: any) => shift.day >= day ? shift.assignments.filter((a: any) => a.citizenId === c.id && a.minutesCap > a.workedMinutes).map((a: any) => ({ shiftId: shift.id, day: shift.day, remaining: a.minutesCap - a.workedMinutes })) : []);
    const structuralChecks = { registeredPublicHistory: !!labor?.jobs[c.id], currentNotPrivate: !currentShop, aliveAdult: !!profile?.alive && profile.age >= 18, legalTransferIdentity: !['official', 'council', 'mayor'].includes(identity), craft20: (c.skills?.craft ?? 0) >= 20 };
    const instantChecks = { hour8to17: s.hour >= 8 && s.hour < 17, hunger45: c.needs.hunger >= 45, fatigue40: c.needs.fatigue >= 40, decisionDue: (r.decisionAt[c.id] ?? 0) <= now, publicAllowanceZero: call('publicWorkAllowance', c) <= 0, existingTasksAvailable: call('foodHiringApplicantAvailable', c), notRoadWaiting: c.state !== 'roadWaiting' };
    const firstBlock = Object.entries({ ...structuralChecks, ...instantChecks }).find(([, ok]) => !ok)?.[0] ?? 'entryEligibleNow'; counts[firstBlock] = (counts[firstBlock] ?? 0) + 1;
    const row = { id: c.id, name: c.name, role: c.role, identity, districtId: c.districtId, homeId: c.homeId, workId: c.workId, currentShopId: currentShop?.id ?? null, position: c.position, state: c.state, destinationId: c.destinationId, activity: r.activities[c.id], decisionAt: r.decisionAt[c.id] ?? null, hunger: c.needs.hunger, fatigue: c.needs.fatigue, money: c.money, food: c.food ?? 0, health: profile?.health, alive: profile?.alive, structuralChecks, instantChecks, firstBlock, publicPromises };
    Object.assign(row, { currentPrivatePromises: Object.entries(r.privateLabor?.shifts ?? {}).flatMap(([shopId, raw]: any) => raw.day === day ? raw.assignments.filter((a: any) => a.citizenId === c.id).map((a: any) => ({ shopId, day: raw.day, minutesCap: a.minutesCap, workedMinutes: a.workedMinutes, remaining: a.minutesCap - a.workedMinutes })) : []) });
    applicantRows.push(row); if (Object.values(structuralChecks).every(Boolean)) structuralApplicants.push(c);
  }
  report.applicantFirstBlockCounts = counts; report.applicants = applicantRows;
  const siteRows: any[] = [];
  for (const shop of foodSites) {
    const site = buildings.get(shop.buildingId), ownerId = sim.shopOwnerId(shop), owner = ownerId === 'player' ? s.player : s.citizens.find((c: any) => c.id === ownerId), profile = profiles[ownerId];
    const identity = owner && ownerId !== 'player' ? call('citizenIdentity', owner) : null;
    const debt = sim.shopPayrollDebt(shop), promised = sim.shopCommittedPayroll(shop), protectedFunds = sim.shopProtectedFunds(shop), cash = sim.shopFunds(shop);
    const ownerChecks = { exists: !!owner, aliveAdult: !!profile?.alive && profile.age >= 18, health45: (profile?.health ?? 0) >= 45, hunger40: (owner?.needs.hunger ?? 0) >= 40, fatigue35: (owner?.needs.fatigue ?? 0) >= 35, dynamicBodyClear: !!owner && !homeRestPointBlockedByVoxels(owner.position, s.voxels), actualNear2: !!owner && call('isNearBuilding', site, owner.position, 2), actualWorkPoint: !!owner && sim.isAtBuildingFunctionPoint(site, owner.position, 'work', ownerId === 'player' ? s.player : { role: identity, identities: [identity] }) };
    const demandIds = call('foodHiringDemandIds', shop, site), allUnaffordableOrNotHungry = s.citizens.filter((c: any) => profiles[c.id]?.alive && profiles[c.id].age >= 6 && (c.food ?? 0) < 1 && c.needs.hunger < 55 && c.money >= shop.price).map((c: any) => c.id);
    const namedDemandAds = demandIds.map((id: string) => { const c = s.citizens.find((person: any) => person.id === id); const distance = Math.hypot(c.position.x - site.door.x, c.position.y - site.door.y, c.position.z - site.door.z); return { actorId: id, distance, advertisedByOriginalChoice: distance <= 1200 || site.districtId === c.districtId }; });
    const routes = structuralApplicants.map((c: any) => {
      const homeDistance = sim.buildingTravelDistance(c.homeId, shop.buildingId), salary = 32 * (.7 + s.districts.find((d: any) => d.id === c.districtId).prosperity / 100);
      // Only the original home-distance intersection merits expensive current-route queries.
      const workDistance = homeDistance <= 500 ? call('foodHiringWorkDistance', c, site) : null;
      return { actorId: c.id, homeDistance: Number.isFinite(homeDistance) ? homeDistance : 'Infinity', currentWorkDistance: workDistance === null ? null : Number.isFinite(workDistance) ? workDistance : 'Infinity', salary, freeAfterOriginalReserve: cash - protectedFunds - 20 * 8 / 24, canFundSalary: cash - protectedFunds - 20 * 8 / 24 >= salary, workArrivalBefore17: workDistance !== null && Number.isFinite(workDistance) && s.hour * 60 + workDistance / (s.weather === '雨' ? 3.1 : 4.2) < 17 * 60, shortageOfferNow: homeDistance <= 500 ? call('foodShortageHiringOffer', shop, c, salary) : false };
    });
    siteRows.push({ id: shop.id, buildingId: site.id, districtId: site.districtId, kind: site.kind, open: shop.open, payrollAllowed: shopLifecycleAllowsNewPayroll(s, shop.id), inventory: shop.inventory, price: shop.price, employees: shop.employees, capacity: site.capacity, cash, debt, committedFutureWages: promised, otherProtectedFunds: protectedFunds - debt - promised, freeAfterOperatingReserve: cash - protectedFunds - 20 * 8 / 24, owner: { id: ownerId, workId: owner?.workId, position: owner?.position, role: owner?.role, checks: ownerChecks }, privatePlan: r.privateLabor?.shifts[shop.id] ?? null, actualRecentSold: tradeSignals(sim, shop.id).sold, need: { qualifiedBeforeRouteCount: allUnaffordableOrNotHungry.length, reachableBefore20CountCapped121: demandIds.length, ids: demandIds, advertisement: namedDemandAds, stockShortOfNamedDemand: demandIds.length > shop.inventory, originalStockBelow120: shop.inventory < 120 }, structuralPublicApplicants: routes });
  }
  report.foodSites = siteRows;
  report.deaths = (audit.deaths ?? []).map((death: any) => {
    const actor = s.citizens.find((person: any) => person.id === death.id), beforeDeath = death.before ?? {};
    const moment = audit.snapshots.find((sample: any) => sample.tick >= death.tick);
    return { originalAuditRecord: death, actualTerminalActor: actor ? { id: actor.id, districtId: actor.districtId, homeId: actor.homeId, workId: actor.workId, position: actor.position, food: actor.food ?? 0, money: actor.money, state: actor.state, health: profiles[actor.id]?.health, alive: profiles[actor.id]?.alive } : null,
      lastObservedWalletBeforeEstate: beforeDeath.money ?? null,
      originalFoodDistanceCaveat: 'Audit foodDistance at its event filtered only open/inventory/wallet, not shopCommodity: materials may be included. It is not certified edible-food reachability.',
      firstLaterAuditSnapshot: moment ? { tick: moment.tick, day: moment.day, publicBudget: moment.publicBudget, publicService: moment.publicService, storedFood: moment.npc?.storedFood } : null,
      districtRoadHistory: actor ? (s.roadNetwork?.closures ?? []).filter((closure: any) => closure.districtId === actor.districtId).map((closure: any) => ({ ...closure, proofScope: 'Persisted native closure history; exact death monotonic clock/route/food inventory is not included in audit.deaths.' })) : [],
      clinicalHistory: (s.clinical?.orders ?? []).filter((order: any) => order.patientId === death.id),
      temporalLimits: 'Terminal open shops, stock, prices, actor paths and closing state are not reconstructed as the death-tick values. No actor is resurrected or moved to a prior pose.' };
  });
  report.districts = s.districts.map((d: any) => ({ id: d.id, prosperity: d.prosperity, energy: d.energy, publicHistoricalRegistered: applicantRows.filter(c => c.districtId === d.id && c.structuralChecks.registeredPublicHistory).length, currentPrivateResidents: applicantRows.filter(c => c.districtId === d.id && !c.structuralChecks.currentNotPrivate).length, foodShopIds: s.shops.filter((shop: any) => shop.districtId === d.id && sim.shopCommodity(shop) === 'food').map((shop: any) => shop.id), stockedFoodUnits: s.shops.filter((shop: any) => shop.districtId === d.id && sim.shopCommodity(shop) === 'food').reduce((sum: number, shop: any) => sum + shop.inventory, 0), freightPoolUnits: r.freight[d.id] ?? 0, freightLots: r.freightLots?.[d.id] ?? [] }));
  report.stateObjectsUnchanged = sim.exportSave() === before; assert.equal(report.stateObjectsUnchanged, true, 'All reachability, funding and eligibility queries must leave the complete save unchanged.');
  assert.deepEqual(JSON.parse(sim.exportSave()).runtime, saved.runtime); report.lastInputs = await frozenInputs(); assert.deepEqual(report.firstInputs, report.lastInputs);
  report.status = 'read-only-inspection-passed'; report.finishedAt = new Date().toISOString();
} catch (error) {
  report.status = 'failed'; report.error = { message: String(error), stack: error instanceof Error ? error.stack : null }; report.finishedAt = new Date().toISOString();
  await writeFile(join(outputRoot, 'diagnosis.json'), JSON.stringify(report, null, 2)); throw error;
}
await writeFile(join(outputRoot, 'diagnosis.json'), JSON.stringify(report, null, 2));
console.log(JSON.stringify({ status: report.status, finalTick: report.terminal.tick, publicEntry: { present: report.publicEntry.present, standingUntilDay: report.publicEntry.standingUntilDay, firstSavedApprovalAt: report.publicEntry.firstSavedApprovalAt, privateMoves: report.publicEntry.statistics?.privateMoves }, applicantFirstBlockCounts: report.applicantFirstBlockCounts, foodSites: report.foodSites.length, stateObjectsUnchanged: report.stateObjectsUnchanged }));

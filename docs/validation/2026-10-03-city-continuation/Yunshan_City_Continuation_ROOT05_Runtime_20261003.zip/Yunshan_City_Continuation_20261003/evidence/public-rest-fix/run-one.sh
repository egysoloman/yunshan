#!/usr/bin/env bash
set -u
task_source=$1
task_output=$2
mkdir -p "$task_output"
cd "$task_source" || exit 2
rg --files src tests package.json package-lock.json tsconfig.json | LC_ALL=C sort | xargs sha256sum > "$task_output/inputs-before.sha256"
date -u +'%Y-%m-%dT%H:%M:%SZ' > "$task_output/started-at.txt"
timeout --foreground --signal=TERM --kill-after=3s 45s bash -c 'printf "%s\n" "$$" > "$1"; exec node --import tsx --test --test-isolation=none tests/npc-public-rest.test.ts' _ "$task_output/node.pid" > "$task_output/raw.log" 2>&1
task_exit=$?
printf '%s\n' "$task_exit" > "$task_output/exit-code.txt"
date -u +'%Y-%m-%dT%H:%M:%SZ' > "$task_output/ended-at.txt"
rg --files src tests package.json package-lock.json tsconfig.json | LC_ALL=C sort | xargs sha256sum > "$task_output/inputs-after.sha256"
cmp "$task_output/inputs-before.sha256" "$task_output/inputs-after.sha256" > "$task_output/input-stability.txt" 2>&1
printf '%s\n' "$?" > "$task_output/input-stability-exit-code.txt"
if kill -0 "$(cat "$task_output/node.pid")" 2>/dev/null; then
  printf 'RUNNING\n' > "$task_output/owned-process.txt"
else
  printf 'EXITED\n' > "$task_output/owned-process.txt"
fi
cat "$task_output/raw.log"
exit "$task_exit"

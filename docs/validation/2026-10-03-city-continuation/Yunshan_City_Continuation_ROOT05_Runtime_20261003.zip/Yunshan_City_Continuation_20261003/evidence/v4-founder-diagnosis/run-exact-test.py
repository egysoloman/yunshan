#!/usr/bin/env python3
"""Owned, bounded, single-name test reproduction against an unchanged clone."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'source'
ORIGINAL = Path('/tmp/yunshan-continuation-20261003-05/source')
NAME = 'v4 founding denies a supported far room and its exterior entrance before spending qualified personal cash'
ARGV = [shutil.which('node'), '--import', 'tsx', '--test', '--test-isolation=none',
        '--test-reporter=tap', '--test-name-pattern', '^' + NAME + '$',
        'tests/v4-extensions.test.ts']

def hashes(folder, first):
    return {name: hashlib.sha256((folder / name).read_bytes()).hexdigest()
            for name in sorted(first)}

first = json.loads((BASE / 'inputs-first.json').read_text())
original_first = json.loads((BASE / 'original-inputs-first.json').read_text())
assert hashes(SOURCE, first) == first
assert hashes(ORIGINAL, original_first) == original_first
started = time.monotonic()
timed_out = False
with (BASE / 'raw.log').open('wb') as raw:
    child = subprocess.Popen(ARGV, cwd=SOURCE, stdout=raw, stderr=subprocess.STDOUT,
                             start_new_session=True)
    stat = Path(f'/proc/{child.pid}/stat').read_text().rsplit(') ', 1)[1].split()
    owned = {'pid': child.pid, 'processGroup': child.pid, 'parentPid': os.getpid(),
             'startTicks': stat[19], 'startedAt': datetime.now(timezone.utc).isoformat(),
             'argv': ARGV, 'cwd': str(SOURCE), 'timeoutSeconds': 600}
    (BASE / 'owned-process.json').write_text(json.dumps(owned, indent=2) + '\n')
    print(json.dumps({'run': 'started', **owned}), flush=True)
    try:
        returncode = child.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(child.pid, signal.SIGTERM)
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait()
        returncode = child.returncode

last = hashes(SOURCE, first)
original_last = hashes(ORIGINAL, original_first)
(BASE / 'inputs-last.json').write_text(json.dumps(last, indent=2) + '\n')
(BASE / 'original-inputs-last.json').write_text(json.dumps(original_last, indent=2) + '\n')
receipt = {'finishedAt': datetime.now(timezone.utc).isoformat(),
           'wallSeconds': time.monotonic() - started, 'returncode': returncode,
           'timedOut': timed_out, 'timeoutSeconds': 600,
           'isolatedInputsUnchanged': first == last,
           'originalFrozen175InputsUnchanged': original_first == original_last,
           'copiedInputCount': len(first), 'formalFrozenInputCount': len(original_first),
           'rawLog': str(BASE / 'raw.log'),
           'rawSHA256': hashlib.sha256((BASE / 'raw.log').read_bytes()).hexdigest(),
           'ownedProcess': owned, 'testName': NAME}
(BASE / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
sys.exit(124 if timed_out else (returncode if returncode >= 0 else 1))

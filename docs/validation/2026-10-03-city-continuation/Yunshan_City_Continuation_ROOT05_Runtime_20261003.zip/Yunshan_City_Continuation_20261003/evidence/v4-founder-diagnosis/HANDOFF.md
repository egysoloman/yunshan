# ROOT05 首条 v4 创业用例失败诊断

已用原 ROOT05 源码和原测试单名复现。失败是市集产权前置条件缺失：`tests/v4-extensions.test.ts:63:117` 最后一次真实工作点 `foundCompany` 期待成功，真实返回：

> 需先依法取得原经营资产；在租经营或已有生命周期合同不得改公司壳绕过义务。

结果是 0 PASS / 1 FAIL，Node 子测试 `142391.070889 ms`，总壁钟 `146.525898 s`，退出码 1，没有触发 600 秒上限。`raw.log` SHA256 为 `3ade8474dc44a7d4eb47c35611a9e395ffe95fda9cc692bfdfde620fc06e3387`。受控 PID `266666` 已退出并由父进程回收。完整前后证据见 `result.json`、`inputs-first.json` / `inputs-last.json`、`original-inputs-first.json` / `original-inputs-last.json`；隔离 55 输入与原冻结 175 输入均零差异。

## 原始触发链

1. `fresh()` 实际新城开局玩家现金 600、仅 traveler 身份、08:00。
2. `qualify()` 调用原 `completePaidCourse()`：原在册成年教师控制配对；真实 `sim.step(.25)`，课程完成须具名教师有效出勤、60 有效分钟及 1 份真实教材。随后实际 merchant 考试。`v4-extensions.test.ts:44` 的商人身份与玩家现金 **480** 断言实际已经通过，否则栈会停在这里。
3. `places(...,'market','work', b => !companies.some(...))` 只保证未公司化和真实几何工作点，没有建立玩家经营资产权。
4. 远房间、外门的 `denied()` 以及本次条件庭院分支均未先失败；它们保持整个 `exportSave()` 字节不变。随后行 63 的真实工作点成功分支被产权守卫拒绝。
5. `src/simulation/extensions.ts:415` 对 market 调用 `shopLifecycleMayIncorporate()`；`src/simulation/shop_lifecycle.ts:129–130` 要求 `shop.ownerId === actorId`、可处分且没有生命周期 title。这些守卫在首笔资本与登记费扣款之前执行。

课程完成把 40 文全部分摊至实际教材与已赚教学服务费，没有完成后钱包退款；考试再实际扣 80 文。所以 `600 - 40 - 80 = 480` 的固定钱包预期在此次真实运行中成立。不能把本次失败归因于新课堂耗时，也没有证据证明权限守卫应放宽。

## 最小静态修复提案（未实现、未运行）

仅修测试经营权前提，沿用本仓库已接受的 `tests/extensions.test.ts:177` 的 `declareExistingCorporateFixtureEntitlement()`，对应 `scripts/ui-test.mjs:56` 与原 UI 正／反产权检查。不要移除生产守卫，不改课堂时钟、教学分钟、40／80／300／50 金额、资格或原成功／拒绝断言。

首条用例可按以下顺序补前提：

1. 保留原 `fresh()` / `qualify()` 与 480 断言，仍选真实 market 工作点、远房间、入口、庭院。
2. 在该 market 的真实工作点先补一次**没有经营权时的 `foundCompany` 拒绝与整存档不变**，证明新产权守卫还在。
3. 仅对原未纳管、无 title／租约／公司且原持有人存在的店，显式声明“受控既存经营权益开场”。按既有 helper 计算 `protectedCash` 与 `returned = max(0, shopFunds - protectedCash)`；原店实际扣 `returned`，实际原持有人加同额，再通过 `transferBusinessOwnership(shop.id,'player')` 接权。玩家现金必须不变，所有实际资金合计守恒；库存、利润、收入、寄售/FIFO、已赚工资、欠薪和未来已接受用工承诺逐字段保持。
4. 随后保留原远房间／外门／庭院拒绝及整存档相等；在真实工作点保留原创业成功、个人钱包减 350、国库加 50、实际现金守恒。

该开场是独立公司契约的受控前置条件，**不是自然市集购买证据**；没有给玩家补钱或直接注入资格。不能用裸写 `ownerId` 代替核心所有权 API，也不能先买下已有 title 的店再把 title 删掉，公司化不得抹掉已有生命周期合同义务。其他 `companyAt()` 正向分支可能有同样旧前提，但本次只执行首条名称，未扩大测试范围或声明其他失败原因。

根可据此授权并实现窄 test/helper 候选，再跑同一名称；当前没有候选 PASS。原正式全套、公共休息候选与 14 日审计未由本诊断启动或重复。

## 精确复跑命令

独占副本在 `source/`，全部文件与原冻结字节相同；只拷 `src/`、此测试、`education-fixture.ts`、package/lock/tsconfig，共 55 输入。`node_modules` 是 `/workspace/yunshan/node_modules` 的链接，只读使用。

```bash
node --import tsx --test --test-isolation=none --test-reporter=tap \
  --test-name-pattern '^v4 founding denies a supported far room and its exterior entrance before spending qualified personal cash$' \
  tests/v4-extensions.test.ts
```

本次使用 `run-exact-test.py` 为这个 Node 进程建立独立进程组、持久化 PID／startTicks／argv、600 秒有界结束与前后哈希。该 runner 是证据原件，根实施候选时宜新建一次运行目录，保留本次 FAIL 和原 raw。

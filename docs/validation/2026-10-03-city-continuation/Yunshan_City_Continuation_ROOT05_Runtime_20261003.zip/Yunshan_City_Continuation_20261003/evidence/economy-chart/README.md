# ROOT05 经济审计静态图生产者

仅在真实终局 `economy-root05-14.json` 与关联终局 save 已写完后执行一次：

```bash
python /tmp/yunshan-city-economy-chart-20261003-01/render_economy_audit.py \
  /tmp/yunshan-continuation-20261003-05/source/artifacts/economy-root05-14.json \
  --frozen-inputs /tmp/yunshan-continuation-20261003-05/frozen-inputs.json \
  --output-dir /tmp/yunshan-city-economy-chart-20261003-01/output \
  --expect-days 14 --expect-seed 20261001 --expect-input-count 175
```

成功生产两个原件：`output/economy-root05-14.png`（2520×1890，180 DPI）和 `output/economy-root05-14.manifest.json`。现有输出不会覆盖。JSON 状态为真实 failed 的完整 14 日运行可绘制，图与 manifest 会保留失败；生产成功不代表经济审计通过，更不代表宏观稳态建立。

脚本仅读取给定 JSON、对应终局 save 和指定冻结清单。它校验 JSON 无重复键/非有限数、必需 schema、8×/seed/14 日/默认政策、完整原始采样 tick 序列、JSON 两端源码哈希与冻结清单 `src/* + scripts/economy-audit.ts` 相同、终局 save 字节与哈希、状态契约及 passed 结果的核心财政/工资/生命/科研守卫。解析后的整个 JSON（包含未绘制字段与嵌套数组）递归检查有限数，`1e999` 与 `-1e999` 的解析溢出也拒绝。缺字段、未完成/旧 partial、哈希不符会退出码 2，且不生产图。不是用旧 JSON 或 raw.log 补数据。

三个内容 panel 为居民现金、财政现金和原始计数组；计数组内部四行各有自己的计数轴，共 6 个坐标轴，没有双轴或归一化。仅绘制原始 snapshot 点，不连线、不插值、不平滑。金额轴按实际观测范围展示，避免从零起淹没资源衰减。营业店只表示采样时点营业，不等于破产数。`npcMoney` 是全部 NPC 随身现金，未混入 `moneySupply` 或银行存款。

图明示 explicit 8x fast-forward、seed、actualTicks、requestedDays、auditStatus、saveValidation.status、status 与 economicTrend 的稳态标记。冻结 ROOT05 driver 固定输出 false，因此 `economicTrend.steadyStateEstablished` 必须为布尔 `False`；`True`、数值 `0`、字符串 `"false"` 都拒绝。独立宏观稳态评估始终记录 `not_assessed`；图显示 `steady state not established`。没有性能或平台宣称。

manifest 关联原 JSON SHA-256、PNG SHA-256、生产脚本 SHA-256、冻结清单 SHA-256，保留审计字段、原始采样 tick 与六条序列数值、单位/轴范围/字体/尺寸。PNG 内也写入源 JSON 哈希和审计状态元数据。

依赖：环境现有 Python 3.12、matplotlib、Noto Sans CJK Regular。若中文字体不存在，自动用清晰英文；若 matplotlib 缺失，明确失败，不自动安装。脚本不运行模拟、不修改仓库/冻结源码、不 upload、不 commit。

准备阶段只做语法、帮助与不产图的失败路径校验；ROOT05 真实 JSON 完成前不生成占位图。根代理负责执行、查看实际原件与 Library 生产者上传。

严格性复核已记录于 `preparation-receipt.json`：布尔契约负例在内存中验证，正负指数溢出通过临时 JSON 实际读取和完整 CLI 验证，均按真实失败退出、不创建输出目录、不调用 renderer；临时负例文件已删除。有限嵌套数值与非数值文本的解析也已通过。来源、绘法和 label 未在此复核中改变，PNG 数量仍为 0。

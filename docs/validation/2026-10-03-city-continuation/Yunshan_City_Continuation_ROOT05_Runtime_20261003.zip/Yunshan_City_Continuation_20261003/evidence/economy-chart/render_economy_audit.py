#!/usr/bin/env python3
"""Render one completed, provenance-checked economy audit; never resample data."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys
import tempfile


SHA256 = re.compile(r"^[0-9a-f]{64}$")
BASE_STEP_MINUTES = 0.25
SOURCE_DRIVER = "scripts/economy-audit.ts"
FIELDS = (
    ("npcMoney", ("npcMoney",)),
    ("treasury", ("treasury",)),
    ("openShops", ("shops", "open")),
    ("employees", ("shops", "employees")),
    ("zeroCapitalCompanies", ("npc", "zeroCapitalCompanies")),
    ("alive", ("npc", "alive")),
)


class InvalidAudit(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise InvalidAudit(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def reject_constant(value):
    raise InvalidAudit(f"JSON contains non-finite constant: {value}")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"JSON contains duplicate key: {key}")
        result[key] = value
    return result


def finite_json_values(value, path="$"):
    # A valid JSON exponent such as 1e999 overflows to inf without parse_constant.
    if isinstance(value, float):
        require(math.isfinite(value), f"{path}: JSON number overflowed to a non-finite value")
    elif isinstance(value, dict):
        for key, child in value.items():
            finite_json_values(child, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            finite_json_values(child, f"{path}[{index}]")


def read_json(path):
    raw = path.read_bytes()
    data = json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object,
                      parse_constant=reject_constant)
    require(isinstance(data, dict), f"{path.name}: expected a JSON object")
    finite_json_values(data)
    return data, raw


def field(obj, *path):
    value = obj
    walked = []
    for key in path:
        walked.append(str(key))
        require(isinstance(value, dict) and key in value,
                "Missing required field: " + ".".join(walked))
        value = value[key]
    return value


def number(value, name, integer=False, minimum=None, maximum=None):
    require(type(value) in (int, float) and (type(value) is int or math.isfinite(value)),
            f"{name}: expected a finite number, got {value!r}")
    if integer:
        require(int(value) == value, f"{name}: expected an integer")
    if minimum is not None:
        require(value >= minimum, f"{name}: below {minimum}")
    if maximum is not None:
        require(value <= maximum, f"{name}: above {maximum}")
    return value


def close(actual, expected, name, tolerance=1e-6):
    require(math.isclose(actual, expected, rel_tol=0, abs_tol=tolerance),
            f"{name}: {actual!r} differs from expected {expected!r}")


def hash_map(value, name):
    require(isinstance(value, dict) and value, f"{name}: expected a nonempty hash map")
    for key, digest in value.items():
        require(isinstance(key, str) and key and not Path(key).is_absolute()
                and ".." not in Path(key).parts, f"{name}: unsafe path {key!r}")
        require(isinstance(digest, str) and SHA256.fullmatch(digest),
                f"{name}.{key}: expected lowercase SHA-256")
    return value


def validate_audit(data, frozen, input_path, args):
    """Fail closed on missing fields, partial timelines, or foreign source hashes.

    A fully sampled audit whose real assertions failed may be plotted. Its
    failure remains visible in both the figure and manifest; it is never PASS.
    """
    frozen = hash_map(frozen, "frozenInputs")
    require(len(frozen) == args.expect_input_count,
            f"Frozen input count {len(frozen)} != {args.expect_input_count}")
    expected_hashes = {k: v for k, v in frozen.items()
                       if k.startswith("src/") or k == SOURCE_DRIVER}
    require(SOURCE_DRIVER in expected_hashes, "Frozen inputs omit audit driver")
    start_hashes = hash_map(field(data, "sourceHash"), "sourceHash")
    end_hashes = hash_map(field(data, "endSourceHash"), "endSourceHash")
    require(start_hashes == end_hashes, "Audit source changed during the run")
    require(start_hashes == expected_hashes,
            "Audit hashes differ from the supplied frozen src + driver inputs")

    speed = number(field(data, "speed"), "speed")
    require(speed == 8, "This audit driver must report explicit 8x fast-forward")
    seed = number(field(data, "seed"), "seed", integer=True, minimum=1,
                  maximum=4294967295)
    require(seed == args.expect_seed, f"seed {seed} != expected {args.expect_seed}")
    days = number(field(data, "requestedDays"), "requestedDays", minimum=1, maximum=120)
    close(days, args.expect_days, "requestedDays", tolerance=1e-12)
    ticks = number(field(data, "ticks"), "ticks", integer=True, minimum=1)
    expected_ticks = math.ceil(days * 1440 / (BASE_STEP_MINUTES * speed))
    require(ticks == expected_ticks,
            f"Partial timeline: actual ticks={ticks}, requested ticks={expected_ticks}")
    elapsed = number(field(data, "elapsedGameMinutes"), "elapsedGameMinutes", minimum=0)
    close(elapsed, ticks * BASE_STEP_MINUTES * speed, "elapsedGameMinutes")

    status = field(data, "status")
    audit_status = field(data, "auditStatus")
    save_status = field(data, "saveValidation", "status")
    for name, value in (("status", status), ("auditStatus", audit_status),
                        ("saveValidation.status", save_status)):
        require(value in ("passed", "failed"), f"{name}: expected passed or failed")
    require((status == "passed") == (audit_status == "passed" and save_status == "passed"),
            "Overall status contradicts auditStatus/saveValidation.status")
    if status == "failed":
        require(isinstance(field(data, "failure"), str) and bool(data["failure"]),
                "Failed audit must retain its failure text")
    else:
        require("failure" not in data, "Passed audit unexpectedly contains failure")

    validation = field(data, "saveValidation")
    if save_status == "passed":
        require(field(validation, "immediateEqual") is True,
                "Passed save validation requires immediateEqual=true")
        require(field(validation, "futureEqual") is True,
                "Passed save validation requires futureEqual=true")
        require(number(field(validation, "futureTicks"), "saveValidation.futureTicks",
                       integer=True) == 24, "Expected exactly 24 reader-validation ticks")
        require(isinstance(field(validation, "futureSaveSha256"), str)
                and SHA256.fullmatch(validation["futureSaveSha256"]),
                "Invalid saveValidation.futureSaveSha256")
    else:
        require(isinstance(field(validation, "failure"), str) and validation["failure"],
                "Failed save validation must retain failure text")

    policy = field(data, "initialPolicy")
    close(number(field(policy, "taxRate"), "initialPolicy.taxRate"),
          args.expect_tax_rate, "initialPolicy.taxRate")
    close(number(field(policy, "policeBudget"), "initialPolicy.policeBudget"),
          args.expect_police_budget, "initialPolicy.policeBudget")
    samples = field(data, "snapshots")
    require(isinstance(samples, list) and len(samples) >= 2, "At least two snapshots required")
    required_ticks = sorted({0, expected_ticks,
                             *range(720, expected_ticks + 1, 720),
                             *(t for t in (1000, 3000, 5000, 7000) if t <= expected_ticks)})
    sample_ticks = []
    series = {name: [] for name, _ in FIELDS}
    for i, sample in enumerate(samples):
        prefix = f"snapshots[{i}]"
        tick = number(field(sample, "tick"), f"{prefix}.tick", integer=True, minimum=0)
        sample_ticks.append(tick)
        number(field(sample, "day"), f"{prefix}.day", integer=True, minimum=0)
        number(field(sample, "hour"), f"{prefix}.hour", minimum=0, maximum=24)
        for name, path in FIELDS:
            series[name].append(number(field(sample, *path), f"{prefix}." + ".".join(path),
                                       integer=len(path) > 1,
                                       minimum=0 if len(path) > 1 else None))
        for group, key in (("shops", "total"), ("npc", "total"), ("npc", "companies")):
            number(field(sample, group, key), f"{prefix}.{group}.{key}", integer=True, minimum=0)
        require(sample["shops"]["open"] <= sample["shops"]["total"],
                f"{prefix}: open shops exceed total")
        require(sample["npc"]["alive"] <= sample["npc"]["total"],
                f"{prefix}: alive residents exceed total")
        require(sample["npc"]["zeroCapitalCompanies"] <= sample["npc"]["companies"],
                f"{prefix}: zero-capital companies exceed total")
        number(field(sample, "moneySupply"), f"{prefix}.moneySupply")
        for key in ("taxRate", "policeBudget"):
            close(number(field(sample, "policy", key), f"{prefix}.policy.{key}"),
                  policy[key], f"{prefix}.policy.{key}")
    require(sample_ticks == required_ticks,
            f"Incomplete/unexpected snapshot ticks: got {sample_ticks}, expected {required_ticks}")
    first, last = samples[0], samples[-1]
    close(number(field(data, "terminalTreasury"), "terminalTreasury"),
          last["treasury"], "terminalTreasury vs final snapshot")
    close(number(field(data, "initialMoneySupply"), "initialMoneySupply"),
          first["moneySupply"], "initialMoneySupply vs first snapshot")
    close(number(field(data, "finalMoneySupply"), "finalMoneySupply"),
          last["moneySupply"], "finalMoneySupply vs final snapshot")
    require(first["npcMoney"] != 0, "Initial npcMoney cannot be zero for cashChangePercent")
    trend = field(data, "economicTrend")
    require(field(trend, "steadyStateEstablished") is False,
            "Frozen ROOT05 audit driver requires economicTrend.steadyStateEstablished=false")
    close(number(field(trend, "cashChangePercent"), "economicTrend.cashChangePercent"),
          (last["npcMoney"] / first["npcMoney"] - 1) * 100, "cashChangePercent")
    unpaid = number(field(trend, "unpaidPrivateWages"), "economicTrend.unpaidPrivateWages")
    totals = field(data, "totals")
    for key in ("payrollPrivateRequested", "payrollPrivate", "payrollPublicRequested",
                "payrollPublicPaid"):
        number(field(totals, key), f"totals.{key}")
    close(unpaid, totals["payrollPrivateRequested"] - totals["payrollPrivate"],
          "economicTrend.unpaidPrivateWages")
    residuals = {key: number(field(data, key), key)
                 for key in ("reconciliationResidual", "moneyConservationResidual")}
    deaths = field(data, "deaths")
    starts = field(data, "starts")
    require(isinstance(deaths, list) and isinstance(starts, list), "deaths/starts must be arrays")
    for key in ("exactResearchDebits", "researchCompleted"):
        number(field(data, key), key, integer=True, minimum=0)
    if audit_status == "passed":
        require(not deaths and starts and data["exactResearchDebits"] > 0
                and data["researchCompleted"] > 0, "Passed audit contradicts life/research guards")
        require(all(abs(v) < 1e-6 for v in residuals.values()),
                "Passed audit contradicts reconciliation guards")
        arrears = field(last, "wageArrears")
        for kind, requested, paid in (("private", "payrollPrivateRequested", "payrollPrivate"),
                                      ("public", "payrollPublicRequested", "payrollPublicPaid")):
            owed = number(field(arrears, kind), f"wageArrears.{kind}")
            not_due = number(field(arrears, kind + "EarnedNotDue"),
                             f"wageArrears.{kind}EarnedNotDue")
            close(totals[requested], totals[paid] + owed + not_due, f"{kind} wage reconciliation")

    final_save = field(data, "finalSave")
    rel_save = field(final_save, "path")
    expected_save = "artifacts/" + input_path.stem + "-final.save.json"
    require(rel_save == expected_save,
            f"finalSave.path must be {expected_save!r}, got {rel_save!r}")
    require(input_path.parent.name == "artifacts", "Input must be an artifacts/*.json audit")
    save_path = input_path.parent.parent / rel_save
    save_raw = save_path.read_bytes()
    require(number(field(final_save, "bytes"), "finalSave.bytes", integer=True, minimum=1)
            == len(save_raw), "Terminal save byte count does not match")
    require(isinstance(field(final_save, "sha256"), str)
            and SHA256.fullmatch(final_save["sha256"]), "Invalid finalSave.sha256")
    require(sha256(save_raw) == final_save["sha256"], "Terminal save SHA-256 does not match")
    return series, [tick * BASE_STEP_MINUTES * speed / 1440 for tick in sample_ticks], {
        "status": "passed", "completeRequestedTimeline": True,
        "expectedTicks": expected_ticks, "snapshotTicks": sample_ticks,
        "sourceHashMatchesFrozenInputs": True, "sourceHashUnchanged": True,
        "frozenInputCount": len(frozen), "auditSourceHashCount": len(start_hashes),
        "terminalSaveVerified": {"path": str(save_path), "bytes": len(save_raw),
                                 "sha256": sha256(save_raw)},
    }


def axis_limits(values, counts=False):
    low, high = min(values), max(values)
    span = high - low
    padding = span * 0.13 if span else max(1 if counts else 0.01, abs(low) * 0.025)
    lower = low - padding
    if low >= 0:
        lower = max(0, lower)
    return lower, high + padding


def render_chart(data, series, x, input_path, input_sha, target, args):
    # Import after input validation. A missing/partial JSON never creates a plot.
    os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).parent / ".mpl-cache"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.font_manager import FontProperties
    from matplotlib.ticker import FuncFormatter, MaxNLocator

    font_path = Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc")
    zh = font_path.is_file()
    font = FontProperties(fname=str(font_path)) if zh else FontProperties(family="DejaVu Sans")
    font.set_size(10)
    plt.rcParams.update({"axes.unicode_minus": False, "figure.facecolor": "#f5f7fa",
                         "savefig.facecolor": "#f5f7fa", "font.size": 10})
    fig = plt.figure(figsize=(14, 10.5), dpi=args.dpi)
    grid = fig.add_gridspec(4, 2, left=0.10, right=0.94, top=0.78, bottom=0.14,
                           hspace=0.58, wspace=0.36, width_ratios=[1.15, 1])
    cash_ax = fig.add_subplot(grid[0:2, 0])
    treasury_ax = fig.add_subplot(grid[2:4, 0])
    count_axes = [fig.add_subplot(grid[i, 1]) for i in range(4)]
    axes = [cash_ax, treasury_ax, *count_axes]
    money_fmt = FuncFormatter(lambda v, _: f"{v:,.0f}")
    count_fmt = FuncFormatter(lambda v, _: f"{v:.0f}")

    def write(x_pos, y_pos, message, size=10, color="#223047", weight="normal"):
        fig.text(x_pos, y_pos, message, fontproperties=font, fontsize=size,
                 color=color, weight=weight, ha="left", va="top")

    english_label = args.label if args.label.isascii() else "City audit"
    title = (f"云山巨城｜{args.label} 默认城市 · {data['requestedDays']:g} 日经济审计"
             if zh else f"Yunshan City | {english_label} default city | {data['requestedDays']:g}-day economy audit")
    write(0.06, 0.965, title, 20, weight="bold")
    write(0.06, 0.922,
          f"explicit 8x fast-forward · seed={data['seed']} · actualTicks={data['ticks']} · "
          f"requestedDays={data['requestedDays']:g} · snapshots={len(x)}", 11)
    failed = data["status"] == "failed"
    write(0.06, 0.891,
          f"auditStatus={data['auditStatus']}  |  saveValidation.status={data['saveValidation']['status']}"
          f"  |  status={data['status']}", 11, "#ae2632" if failed else "#223047")
    steady = data["economicTrend"]["steadyStateEstablished"]
    steady_text = ("steady state not established · 未建立长期经济稳态；独立宏观稳态评估未运行"
                   if zh else "steady state not established; independent macro steady-state assessment not run")
    if steady:
        steady_text = ("audit reports steadyStateEstablished=true; independent macro assessment not run")
    write(0.06, 0.858, steady_text, 11, "#91520d")
    if failed:
        write(0.06, 0.828, "真实审计失败，图保留失败状态" if zh else "Actual audit failed; failure retained", 10, "#ae2632")

    labels = {
        "npcMoney": ("居民随身现金 · npcMoney", "Resident cash · npcMoney", "#176e94"),
        "treasury": ("财政现金 · treasury", "Treasury cash · treasury", "#b76826"),
        "openShops": ("营业商铺（家）· shops.open", "Open shops · shops.open (shops)", "#298064"),
        "employees": ("商铺员工（人）· shops.employees", "Shop employees · shops.employees (people)", "#2867af"),
        "zeroCapitalCompanies": ("零资本公司（家）· npc.zeroCapitalCompanies", "Zero-capital companies (companies)", "#b42d45"),
        "alive": ("存活居民（人）· npc.alive", "Living residents · npc.alive (people)", "#7552a1"),
    }
    for ax, (name, _) in zip(axes, FIELDS):
        values = series[name]
        label_zh, label_en, color = labels[name]
        is_count = name not in ("npcMoney", "treasury")
        # Only observed points. No connecting curve, smoothing, or interpolation.
        ax.scatter(x, values, s=22 if is_count else 30, color=color, edgecolors="white",
                   linewidths=0.5, zorder=3, label=name)
        ax.set_xlim(-0.025 * max(x), 1.025 * max(x))
        ax.set_ylim(*axis_limits(values, is_count))
        ax.set_title(label_zh if zh else label_en, loc="left", fontproperties=font,
                     fontsize=10.5, color=color, pad=12 if is_count else 14)
        ax.set_facecolor("white")
        ax.grid(axis="both", color="#d9e0e8", linewidth=0.65, alpha=0.8)
        ax.spines[["top", "right"]].set_visible(False)
        ax.spines[["left", "bottom"]].set_color("#aab7c5")
        ax.tick_params(labelsize=8, colors="#435167")
        ax.xaxis.set_major_locator(MaxNLocator(nbins=7, integer=True))
        ax.yaxis.set_major_locator(MaxNLocator(nbins=3 if is_count else 5, integer=is_count))
        ax.yaxis.set_major_formatter(count_fmt if is_count else money_fmt)
        stat = (f"首→末 {values[0]:,.0f} → {values[-1]:,.0f}；范围 {min(values):,.0f}–{max(values):,.0f}"
                if zh else f"First→last {values[0]:,.0f} → {values[-1]:,.0f}; range {min(values):,.0f}–{max(values):,.0f}")
        ax.text(0.0, 1.015, stat, transform=ax.transAxes, fontproperties=font,
                fontsize=8, color="#435167", va="bottom")
        if is_count:
            if ax is not count_axes[-1]:
                ax.tick_params(labelbottom=False)
        else:
            ax.set_ylabel("游戏货币" if zh else "Game currency", fontproperties=font)
            change = (values[-1] / values[0] - 1) * 100 if values[0] else None
            if change is not None:
                ax.text(0.985, 0.05, f"Δ {change:+.2f}%", transform=ax.transAxes,
                        ha="right", color=color, fontsize=13, fontproperties=font)
    for ax in (treasury_ax, count_axes[-1]):
        ax.set_xlabel("实际经过游戏天数（原始 tick ÷ 720）" if zh else "Elapsed game days (raw tick / 720)",
                      fontproperties=font, fontsize=9)
    cash_ax.tick_params(labelbottom=False)
    note = ("各点为本次 JSON 原始 snapshots；无插值。金额轴依观测范围显示；右侧四行各用原始计数轴。\n"
            "npcMoney 为全部 NPC 随身现金，不含银行存款或其他账户。营业店为采样时点营业状态，不能直接视为破产数。"
            if zh else
            "Only this JSON's observed snapshots; no interpolation. Money axes use observed ranges; count tracks use separate raw axes.\n"
            "npcMoney is all NPC carried cash, excluding bank deposits and other accounts. Open shops are point-in-time openings, not bankruptcies.")
    write(0.06, 0.093, note, 8.5)
    write(0.06, 0.047, f"Source JSON: {input_path.name} · SHA256: {input_sha}", 7.2)
    fig.savefig(target, dpi=args.dpi, metadata={
        "Title": title, "SourceJSON": str(input_path), "SourceJSON_SHA256": input_sha,
        "AuditStatus": data["auditStatus"], "Status": data["status"],
        "SaveValidationStatus": data["saveValidation"]["status"],
        "SteadyStateAssessment": "not independently assessed",
    })
    plt.close(fig)
    return {"backend": "Agg", "matplotlibVersion": matplotlib.__version__,
            "font": str(font_path) if zh else "DejaVu Sans", "language": "zh" if zh else "en",
            "dpi": args.dpi, "pixelDimensions": [14 * args.dpi, int(10.5 * args.dpi)],
            "contentPanels": 3, "rawAxes": 6, "dualAxes": False,
            "interpolation": "none; raw snapshot points only", "resampling": "none",
            "timeAxis": "raw snapshot tick * 0.25 * speed / 1440",
            "moneyUnits": "game currency", "countUnits": "shops, people, companies, people",
            "axisRanges": {name: list(axis_limits(series[name], len(path) > 1))
                           for name, path in FIELDS}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="Completed artifacts/*.json economy audit")
    parser.add_argument("--frozen-inputs", type=Path, required=True,
                        help="Exact frozen input SHA-256 map for this run")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--expect-days", type=float, default=14)
    parser.add_argument("--expect-seed", type=int, default=20261001)
    parser.add_argument("--expect-input-count", type=int, default=175)
    parser.add_argument("--expect-tax-rate", type=float, default=0.08)
    parser.add_argument("--expect-police-budget", type=float, default=0.3)
    parser.add_argument("--label", default="ROOT05")
    parser.add_argument("--dpi", type=int, default=180)
    args = parser.parse_args()
    require(96 <= args.dpi <= 400, "--dpi must be within 96..400")
    for name in ("expect_days", "expect_tax_rate", "expect_police_budget"):
        number(getattr(args, name), "--" + name.replace("_", "-"))
    input_path = args.input.resolve(strict=True)
    frozen_path = args.frozen_inputs.resolve(strict=True)
    data, input_raw = read_json(input_path)
    frozen, frozen_raw = read_json(frozen_path)
    series, x, integrity = validate_audit(data, frozen, input_path, args)
    output_dir = args.output_dir.resolve()
    png_path = output_dir / (input_path.stem + ".png")
    manifest_path = output_dir / (input_path.stem + ".manifest.json")
    require(not png_path.exists() and not manifest_path.exists(),
            "Outputs already exist; choose a new output directory to preserve originals")
    output_dir.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".economy-chart-", suffix=".png", dir=output_dir)
    os.close(fd)
    temporary_png = Path(temporary)
    temporary_manifest = None
    try:
        input_sha = sha256(input_raw)
        plot = render_chart(data, series, x, input_path, input_sha, temporary_png, args)
        require(input_path.read_bytes() == input_raw, "Input JSON changed while rendering")
        require(frozen_path.read_bytes() == frozen_raw, "Frozen inputs changed while rendering")
        require(sha256(Path(integrity["terminalSaveVerified"]["path"]).read_bytes())
                == integrity["terminalSaveVerified"]["sha256"], "Terminal save changed while rendering")
        png_raw = temporary_png.read_bytes()
        png_sha = sha256(png_raw)
        script_path = Path(__file__).resolve()
        steady = data["economicTrend"]["steadyStateEstablished"]
        manifest = {
            "schema": "yunshan-economy-chart-manifest/v1",
            "createdAt": datetime.now(timezone.utc).isoformat(),
            "producer": {"script": str(script_path), "sha256": sha256(script_path.read_bytes())},
            "sourceJSON": {"path": str(input_path), "bytes": len(input_raw), "sha256": input_sha},
            "png": {"path": str(png_path), "bytes": len(png_raw), "sha256": png_sha},
            "frozenInputs": {"path": str(frozen_path), "sha256": sha256(frozen_raw),
                             "count": len(frozen)},
            "validation": integrity,
            "audit": {key: data[key] for key in (
                "status", "auditStatus", "speed", "seed", "requestedDays", "ticks",
                "elapsedGameMinutes", "initialPolicy", "saveValidation", "finalSave",
                "sourceHash", "endSourceHash", "economicTrend", "terminalTreasury",
                "reconciliationResidual", "moneyConservationResidual")},
            "economicSteadyStateAssessment": {
                "auditReportedSteadyStateEstablished": steady,
                "independentlyAssessed": False, "status": "not_assessed",
                "statement": "steady state not established" if not steady else
                "audit reports established; independent macro assessment not run",
            },
            "plot": plot,
            "series": [{"name": name, "sourcePath": "snapshots[]." + ".".join(path),
                        "ticks": [s["tick"] for s in data["snapshots"]], "values": series[name],
                        "first": series[name][0], "last": series[name][-1],
                        "minimum": min(series[name]), "maximum": max(series[name])}
                       for name, path in FIELDS],
            "failure": data.get("failure"),
        }
        fd, temporary = tempfile.mkstemp(prefix=".economy-manifest-", suffix=".json", dir=output_dir)
        temporary_manifest = Path(temporary)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(manifest, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write("\n")
        # Hard links avoid silently replacing originals created by another producer.
        os.link(temporary_png, png_path)
        try:
            os.link(temporary_manifest, manifest_path)
        except Exception:
            png_path.unlink()
            raise
        print(json.dumps({"chartGeneration": "completed", "auditStatus": data["auditStatus"],
                          "saveValidationStatus": data["saveValidation"]["status"],
                          "status": data["status"], "steadyStateEstablished": steady,
                          "sourceJSON_SHA256": input_sha, "PNG_SHA256": png_sha,
                          "png": str(png_path), "manifest": str(manifest_path)}, ensure_ascii=False))
    finally:
        temporary_png.unlink(missing_ok=True)
        if temporary_manifest is not None:
            temporary_manifest.unlink(missing_ok=True)


if __name__ == "__main__":
    try:
        main()
    except (InvalidAudit, OSError, UnicodeError, json.JSONDecodeError, ImportError) as error:
        print(json.dumps({"chartGeneration": "failed", "error": str(error),
                          "outputsPublished": False}, ensure_ascii=False), file=sys.stderr)
        sys.exit(2)

Official frozen-09 DOM original evidence

Actual command: env YUNSHAN_UI_PORT=4193 npm run test:ui
Working directory: /tmp/yunshan-system-coherent-09/source
UTC: 2026-10-02T12:54:50.746870+00:00 to 2026-10-02T13:02:05.064760+00:00
Exit: 0; official ui-results.json: 35 checks, errors [].
All 102 frozen input files match copiedHashes before and after the run.

Scope: unchanged official DOM script with generated world and real Simulation.
The declared official fixtures control initial resources and table/bed positioning.
This is not a CityRenderer/WebGL, ordinary natural journey, GPU, hardware or
performance validation, and is not the parallel full-suite result.
No source, tests, assertions or default timeouts were changed for this run.

Contains all 102 as-run source inputs, all 12 newly produced UI artifacts, raw
combined stdout/stderr, full independent run receipt, source snapshot and local
receipt runner. Existing world-layout-results.json and parallel run artifacts
are intentionally outside this DOM evidence package. No node_modules or build
output is included. package-manifest.json records every other file's SHA256,
bytes and CRC32. The external dom09-package-status.json records ZIP integrity.

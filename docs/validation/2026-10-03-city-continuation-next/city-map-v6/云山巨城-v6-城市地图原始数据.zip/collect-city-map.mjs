import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, readdir, mkdir, access } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { performance } from 'node:perf_hooks';

const source='/workspace/yunshan',out='/workspace/yunshan-work/city-map-v6-20261004-01';
const sha=b=>createHash('sha256').update(b).digest('hex');
const save=(name,data)=>writeFile(join(out,name),JSON.stringify(data,null,2)+'\n');
const walk=async(dir)=>{ const entries=await readdir(join(source,dir),{withFileTypes:true}); const files=[];for(const e of entries){const p=join(dir,e.name);if(e.isDirectory())files.push(...await walk(p));else if(e.isFile())files.push(p);}return files.sort(); };
const paths=[...await walk('src'),'package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html'].sort();
const capture=async()=>{const files={},buffers={};for(const p of paths){const b=await readFile(join(source,p));buffers[p]=b;files[p]={bytes:b.length,sha256:sha(b)};}return {files,buffers};};
try{await access(join(out,'world-native.json'));throw new Error('Do not overwrite an existing native World export.');}catch(e){if(e.code!=='ENOENT')throw e;}
const startedAt=new Date().toISOString(),start=performance.now(),before=await capture();
await save('source-start.json',{at:startedAt,sourceRoot:source,files:before.files});
const load=async p=>import(pathToFileURL(join(source,p)).href);
const {createWorld,terrainHeight,getWaterfallPath}=await load('src/world.ts');
const {savedWorldFingerprint}=await load('src/persistence/world-layout.ts');
const {getBuildingBody,getBuildingFloorPlan,getFloorPlanSlabRegions,getFloorPlanRoofRegions,getBuildingEntrance,wallPanels,boundaryLoops,rectangleCover,buildingWorldPosition}=await load('src/architecture-floor-plan.ts');
const {Simulation}=await load('src/simulation.ts');
const world=createWorld(20261001,'current-v6'),native=JSON.stringify(world)+'\n';
await writeFile(join(out,'world-native.json'),native);
const fingerprint=savedWorldFingerprint(world);assert.equal(fingerprint,'b85fa6ec');
const simulation=new Simulation(world);
assert.equal(simulation.state.tick,0);
const initialNPCs={count:simulation.state.citizens.length,tick:simulation.state.tick,day:simulation.state.day,hour:simulation.state.hour,
 byDistrict:Object.fromEntries(world.districts.map(d=>[d.id,simulation.state.citizens.filter(c=>c.districtId===d.id).length])),
 byRole:Object.fromEntries([...new Set(simulation.state.citizens.map(c=>c.role))].sort().map(k=>[k,simulation.state.citizens.filter(c=>c.role===k).length])),
 claim:'Actual seed constructor census. No Simulation.step call, no claim of attendance or stable population.'};
await save('seed-npc-census.json',initialNPCs);
const toWorld=(b,loop)=>loop.map(([x,z])=>{const p=buildingWorldPosition(b,{x,y:0,z});return [p.x,p.z];});
const rectLoop=r=>[[r.x0,r.z0],[r.x1,r.z0],[r.x1,r.z1],[r.x0,r.z1]];
const footprintWarnings=[];
const buildings=world.buildings.map(b=>{
 const body=getBuildingBody(b),p=getBuildingFloorPlan(b,0);
 let loops,authority,mode='nonzero-union-boundaries';
 if(p){const regions=[...p.interior,...p.circulation,...wallPanels(p).filter(w=>w.top>0).map(w=>w.rect)];
  try{loops=boundaryLoops(regions);}catch(e){loops=rectangleCover(regions).map(rectLoop);mode='disjoint-identical-union-rectangles';footprintWarnings.push({id:b.id,message:String(e),resolution:'Exact shared rectangleCover of same occupied union; no hull or proxy.'});}
  authority='shared floor-0 interior/circulation/real wall panels union; open courtyard excluded';
 }else{const d=b.floorFootprints?.[0]??b;loops=[rectLoop({x0:-d.width/2,x1:d.width/2,z0:-d.depth/2,z1:d.depth/2})];authority='native rotated width/depth envelope fallback; specialized landmark not a shared FloorPlan footprint';mode='landmark-envelope';}
 const roofRegions=body?getFloorPlanRoofRegions(body):[];
 const roofPeakY=roofRegions.length?b.position.y+.6+Math.max(...roofRegions.map(r=>r.top)):null;
 const entrance=getBuildingEntrance(b),groundY=terrainHeight(world,b.position.x,b.position.z,false);
 return {id:b.id,name:b.name,kind:b.kind,districtId:b.districtId,position:b.position,width:b.width,depth:b.depth,rotationRad:b.rotation,
  bodyHeightM:b.height,floors:b.floors,basements:b.basements??0,floorUses:b.floorUses??null,floorPermissions:b.floorPermissions??null,
  commercialGeometryRevision:b.commercialGeometryRevision??null,commercialRouteRevision:b.commercialRouteRevision??null,
  terrainGroundY:groundY,entrance,roofPeakY,groundToSharedRoofPeakM:roofPeakY===null?null:roofPeakY-groundY,
  roofAuthority:body?'shared getFloorPlanRoofRegions peak + position.y + .6':'specialized landmark roof not measured here; body height is native recipe',
  footprintAuthority:authority,footprintMode:mode,loops:loops.map(l=>toWorld(b,l)),
  openCourtyards:p?p.courtyard.map(r=>toWorld(b,rectLoop(r))):[],
  supportLoops:p?boundaryLoops(getFloorPlanSlabRegions(p)).map(l=>toWorld(b,l)):null,
  workPoints:(b.functionPoints??[]).filter(f=>f.purpose==='work').length};
});
const count=(array,key)=>Object.fromEntries([...new Set(array.map(v=>v[key]))].sort().map(k=>[k,array.filter(v=>v[key]===k).length]));
const towers=buildings.filter(b=>b.commercialGeometryRevision===1).sort((a,b)=>b.bodyHeightM-a.bodyHeightM);
assert.equal(towers.length,5);assert.ok(towers.every(b=>b.kind==='bank'&&b.commercialRouteRevision===1));
assert.equal(world.buildings.length,612);assert.equal(initialNPCs.count,616);assert.equal(world.districts.length,11);
const districts=world.districts.map((d,i)=>({...d,number:i+1,buildings:buildings.filter(b=>b.districtId===d.id).length,seedNPCs:initialNPCs.byDistrict[d.id],maxBodyHeightM:Math.max(...buildings.filter(b=>b.districtId===d.id).map(b=>b.bodyHeightM))}));
const stats={at:startedAt,seed:world.seed,recipe:world.layoutVersion,fingerprint,voxelSizeM:world.voxelSize,worldSizeM:world.size,
 buildings:world.buildings.length,kinds:count(buildings,'kind'),districtCount:districts.length,districts,seedNPCs:initialNPCs.count,
 nodes:world.nodes.length,edges:world.edges.length,transportModes:count(world.edges,'mode'),
 towers:towers.map(({loops,openCourtyards,supportLoops,...b})=>b),commercialCount:buildings.filter(b=>['market','bank'].includes(b.kind)).length,
 commercialHighrises:buildings.filter(b=>['market','bank'].includes(b.kind)&&(b.bodyHeightM>=80||b.floors>=20)).map(b=>b.id),
 commercialSkyscrapers:buildings.filter(b=>['market','bank'].includes(b.kind)&&b.bodyHeightM>=150).map(b=>b.id),
 footprintFallbacks:buildings.filter(b=>b.footprintMode==='landmark-envelope').map(b=>b.id),footprintWarnings,
 runway:world.edges.find(e=>e.id==='road-airport-runway-strip'),waterfall:{...world.waterfall,dropM:world.waterfall.top.y-world.waterfall.bottom.y,path:getWaterfallPath(world)},
 units:'Local X/Z metres, -Z drawn upward, not latitude/longitude/true north; design radii are not title boundaries.',
 interpretation:'Static current shared World data. Height is native building height, separate from ground Y and shared roof peak. Edges do not prove routes traversable. Tick-0 NPC count does not prove attendance or economic stability.'};
await save('city-census.json',stats);await save('building-footprints.json',buildings);
const csv=v=>'"'+String(typeof v==='object'?JSON.stringify(v):v??'').replaceAll('"','""')+'"';
const bc=['id','name','kind','districtId','bodyHeightM','floors','basements','terrainGroundY','roofPeakY','groundToSharedRoofPeakM','position','width','depth','rotationRad','entrance','commercialGeometryRevision','commercialRouteRevision','workPoints','floorUses','floorPermissions','footprintAuthority'];
await writeFile(join(out,'buildings.csv'),'\uFEFF'+[bc.join(','),...buildings.map(b=>bc.map(k=>csv(b[k])).join(','))].join('\n')+'\n');
const dc=['number','id','name','kind','buildings','seedNPCs','maxBodyHeightM','center','radius'];
await writeFile(join(out,'districts.csv'),'\uFEFF'+[dc.join(','),...districts.map(d=>dc.map(k=>csv(d[k])).join(','))].join('\n')+'\n');
const ec=['id','mode','from','to','length','capacity','pointCount'];
await writeFile(join(out,'transport-edges.csv'),'\uFEFF'+[ec.join(','),...world.edges.map(e=>ec.map(k=>csv(k==='pointCount'?e.points.length:e[k])).join(','))].join('\n')+'\n');
const grid={xMin:-2300,xMax:2300,zMin:-2300,zMax:2300,stepM:40,nx:116,nz:116,sourceFunction:'terrainHeight(world,x,z,false); actual ground with geological relief, foundations and road grading; basements excluded',orientation:'row0 zMin; x increasing right; -Z drawn upward',storage:'Float64 little endian',surfaceResolutionClaimM:40};
const H=new Float64Array(grid.nx*grid.nz);let hmin=Infinity,hmax=-Infinity;
for(let j=0;j<grid.nz;j++)for(let i=0;i<grid.nx;i++){const h=terrainHeight(world,grid.xMin+i*grid.stepM,grid.zMin+j*grid.stepM,false);H[j*grid.nx+i]=h;hmin=Math.min(hmin,h);hmax=Math.max(hmax,h);}
await writeFile(join(out,'terrain-height-f64.bin'),Buffer.from(H.buffer));await save('terrain-grid.json',{...grid,samples:H.length,minHeightM:hmin,maxHeightM:hmax});
assert.equal(JSON.stringify(world)+'\n',native,'Read-only provider, terrain and tick-0 constructor queries must not mutate actual World');
const after=await capture();await save('source-end.json',{at:new Date().toISOString(),sourceRoot:source,files:after.files});
const changed=paths.filter(p=>JSON.stringify(before.files[p])!==JSON.stringify(after.files[p]));
await save('source-change-check.json',{changed,sourceUnchanged:changed.length===0});
assert.deepEqual(after.files,before.files,'Source changed during collection. Preserve original artifacts and recollect in a new namespace.');
for(const p of paths){const dest=join(out,'source-bound',p);await mkdir(dirname(dest),{recursive:true});await writeFile(dest,before.buffers[p]);}
await save('collection-manifest.json',{startedAt,endedAt:new Date().toISOString(),elapsedSeconds:(performance.now()-start)/1000,sourceRoot:source,sourceCount:paths.length,
 fingerprint,seed:world.seed,recipe:world.layoutVersion,nativeWorldSHA256:sha(native),sourceStartSHA256:sha(await readFile(join(out,'source-start.json'))),sourceEndSHA256:sha(await readFile(join(out,'source-end.json'))),
 topLevelCreateWorldCalls:1,simulationConstructors:1,simulationTicks:0,GPU:0,sourceUnchanged:true,worldUnchanged:true,terrainSamples:H.length,terrainStepM:grid.stepM,
 sourceBoundCopy:'All exact pre-collection source/config bytes, no edits. Local reproducibility only; no shared writes.'});
console.log(JSON.stringify({status:'WORLD_DATA_COLLECTED',elapsedSeconds:(performance.now()-start)/1000,fingerprint,buildings:buildings.length,seedNPCs:initialNPCs.count,districts:districts.map(d=>({name:d.name,buildings:d.buildings})),nodes:world.nodes.length,edges:world.edges.length,towers:towers.map(b=>({id:b.id,name:b.name,height:b.bodyHeightM,floors:b.floors,groundToRoof:b.groundToSharedRoofPeakM})),footprintFallbacks:stats.footprintFallbacks,footprintWarnings,sourceUnchanged:true},null,2));

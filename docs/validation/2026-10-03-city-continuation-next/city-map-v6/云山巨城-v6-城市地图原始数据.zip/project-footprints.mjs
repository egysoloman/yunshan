import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { getBuildingFloorPlan, wallPanels, boundaryLoops, rectangleCover, buildingWorldPosition } from './source-bound/src/architecture-floor-plan.ts';
const world=JSON.parse(await readFile('world-native.json','utf8'));
const before=JSON.stringify(world),buildings=JSON.parse(await readFile('building-footprints.json','utf8')),census=JSON.parse(await readFile('city-census.json','utf8'));
const corrections=[],warnings=[];
for(const b of world.buildings){const p=getBuildingFloorPlan(b,0),out=buildings.find(v=>v.id===b.id);if(!p)continue;
 const input=[...p.interior,...p.circulation,...wallPanels(p).filter(w=>w.top>0).map(w=>w.rect)];
 // Zero-area wall bands have no 2D footprint. Filter only the derived drawing
 // input; never modify the original provider, World, walls or collision data.
 const zero=input.filter(r=>r.x1<=r.x0||r.z1<=r.z0);
 const regions=input.filter(r=>r.x1>r.x0&&r.z1>r.z0);
 let loops;try{loops=boundaryLoops(regions);out.footprintMode='nonzero-union-boundaries';}
 catch(e){loops=rectangleCover(regions).map(r=>[[r.x0,r.z0],[r.x1,r.z0],[r.x1,r.z1],[r.x0,r.z1]]);out.footprintMode='disjoint-identical-union-rectangles';warnings.push({id:b.id,error:String(e),resolution:'Exact shared rectangleCover of the same occupied union.'});}
 out.loops=loops.map(l=>l.map(([x,z])=>{const w=buildingWorldPosition(b,{x,y:p.y,z});return [w.x,w.z];}));
 if(zero.length)corrections.push({id:b.id,excludedZeroAreaProjectionBands:zero.length,rectangles:zero,scope:'Derived 2D projection only; unchanged original descriptors.'});
}
assert.equal(JSON.stringify(world),before);
const sha=b=>createHash('sha256').update(b).digest('hex');
await writeFile('building-map-footprints.json',JSON.stringify(buildings,null,2)+'\n');
await writeFile('footprint-projection-receipt.json',JSON.stringify({nativeWorldSHA256:sha(await readFile('world-native.json')),worldConstructors:0,originalCollectionWarningsPreserved:census.footprintWarnings.length,excludedZeroAreaBands:corrections.reduce((n,v)=>n+v.excludedZeroAreaProjectionBands,0),buildingsWithZeroAreaProjectionBands:corrections.length,corrections,remainingWarnings:warnings,source:'Immutable source-bound shared provider; native World JSON rehydration only.',sourceProductionEdits:0,worldUnchanged:true},null,2)+'\n');
await writeFile('city-map-census.json',JSON.stringify({...census,footprintWarnings:warnings,footprintProjectionReceipt:'footprint-projection-receipt.json',originalCollectorWarningsPreserved:'city-census.json'},null,2)+'\n');
console.log(JSON.stringify({status:'PROJECTED',buildings:buildings.length,excludedZeroAreaBands:corrections.reduce((n,v)=>n+v.excludedZeroAreaProjectionBands,0),remainingWarnings:warnings}));

from pathlib import Path
import os, json, hashlib, warnings
from datetime import datetime, timezone
root=Path(__file__).resolve().parent
os.environ['MPLCONFIGDIR']=str(root/'.mpl-cache')
os.environ['XDG_CACHE_HOME']=str(root/'.font-cache')
import matplotlib
matplotlib.use('Agg')
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.ft2font import FT2Font
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.collections import LineCollection
from matplotlib.patches import Rectangle, Circle, PathPatch
from matplotlib.path import Path as MPath
from PIL import Image

fontpath='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font=FontProperties(fname=fontpath)
plt.rcParams.update({'font.family':font.get_name(),'font.size':10,'axes.unicode_minus':False,'svg.fonttype':'path','svg.hashsalt':'yunshan-v6-b85fa6ec-map','pdf.fonttype':42,'figure.facecolor':'#f7f8f1','axes.facecolor':'#f3f4e8'})
world=json.loads((root/'world-native.json').read_text())
census=json.loads((root/'city-map-census.json').read_text())
buildings=json.loads((root/'building-map-footprints.json').read_text())
grid=json.loads((root/'terrain-grid.json').read_text())
H=np.fromfile(root/'terrain-height-f64.bin',dtype='<f8').reshape(grid['nz'],grid['nx'])
xs=np.linspace(grid['xMin'],grid['xMax'],grid['nx']);zs=np.linspace(grid['zMin'],grid['zMax'],grid['nz'])
INK='#244544';MUTED='#667c75';BG='#f7f8f1'
labels={'home':'住宅','market':'市集商铺','bank':'银行','workshop':'工坊','farm':'农场','hall':'官署／议事','police':'警务','school':'学校','clinic':'医馆','station':'交通站点','dock':'码头','pavilion':'亭阁','airport':'机场','starport':'星港','core':'天枢主阁'}
colors={'home':'#408179','market':'#d39a3f','bank':'#98679b','workshop':'#936b45','farm':'#8a9b45','hall':'#856389','police':'#526daa','school':'#57a0ad','clinic':'#d57b7c','station':'#5e7075','dock':'#328ba4','pavilion':'#6c804b','airport':'#5983b0','starport':'#8776af','core':'#aa3b56'}
heightColors=['#91babb','#63959d','#417783','#ad824e','#b45a61','#81384d']
heightBins=['<15 m','15–30 m','30–60 m','60–100 m','100–150 m','≥150 m']
def hcolor(h):return heightColors[0 if h<15 else 1 if h<30 else 2 if h<60 else 3 if h<100 else 4 if h<150 else 5]
terrainMap=LinearSegmentedColormap.from_list('yunshan-ground',['#f5f3e5','#e7ebce','#c8d7b5','#a8c3aa','#90aaa0','#c4d1cd'])
terrainNorm=Normalize(0,650)
modeStyles={'road':('#69716b',.42,'solid'),'bridge':('#315762',1.10,'solid'),'maglev':('#d56844',1.55,'solid'),'lightRail':('#bf9a4d',1.2,'dashed'),'cable':('#8f629f',1.2,'dotted'),'lift':('#8a437d',1.6,'solid'),'ferry':('#1d91b2',1.6,'dashed'),'flight':('#72989c',.8,'dashdot')}
modeNames={'road':'道路','bridge':'桥梁','maglev':'磁悬浮','lightRail':'轻轨','cable':'缆索','lift':'升降井','ferry':'渡船','flight':'飞行路线'}
allText=[]
def text(ax,x,y,s,**kwargs):allText.append(s);return ax.text(x,y,s,fontproperties=font,**kwargs)
def ft(x,y,s,**kwargs):allText.append(s);return fig.text(x,y,s,fontproperties=font,**kwargs)
def footprint(ax,b,color,zorder=5,alpha=1):
    verts=[];codes=[]
    for loop in b['loops']:
        if len(loop)<3:continue
        verts.extend(loop+[loop[0]]);codes.extend([MPath.MOVETO]+[MPath.LINETO]*(len(loop)-1)+[MPath.CLOSEPOLY])
    if verts:ax.add_patch(PathPatch(MPath(verts,codes),facecolor=color,edgecolor='#314e4a' if b['commercialGeometryRevision'] else color,linewidth=.6 if b['commercialGeometryRevision'] else .16,alpha=alpha,zorder=zorder))
def basemap(ax,bounds,by='height',districts=True,detail=False):
    ax.imshow(H,extent=(grid['xMin'],grid['xMax'],grid['zMax'],grid['zMin']),cmap=terrainMap,norm=terrainNorm,interpolation='bilinear',zorder=0)
    contours=ax.contour(xs,zs,H,levels=np.arange(0,651,40),colors='#567063',alpha=.20,linewidths=.38,zorder=1)
    if not detail:ax.clabel(contours,levels=[120,240,360,480,600],inline=True,fontsize=5.8,fmt='%d m')
    for b in buildings:
        if bounds[0]-80<=b['position']['x']<=bounds[1]+80 and bounds[2]-80<=b['position']['z']<=bounds[3]+80:footprint(ax,b,hcolor(b['bodyHeightM']) if by=='height' else colors[b['kind']],alpha=.92)
    for mode in ['road','bridge','flight','maglev','lightRail','cable','ferry']:
        color,width,style=modeStyles[mode]
        lines=[[(p['x'],p['z']) for p in e['points']] for e in world['edges'] if e['mode']==mode]
        if lines:ax.add_collection(LineCollection(lines,colors=color,linewidths=width*(1.25 if detail else 1),linestyles=style,alpha=.83,zorder=6))
    for e in world['edges']:
        if e['mode']=='lift':
            ax.scatter(e['points'][0]['x'],e['points'][0]['z'],s=28,marker='D',color=modeStyles['lift'][0],zorder=7)
    river=world['river'];ax.plot([p['x'] for p in river],[p['z'] for p in river],color='#409dc3',linewidth=2.3,zorder=3)
    wf=census['waterfall'];ax.plot([p['x'] for p in wf['path']],[p['z'] for p in wf['path']],color='#167aab',linewidth=3,zorder=8)
    runway=census['runway'];ax.plot([p['x'] for p in runway['points']],[p['z'] for p in runway['points']],color='#52635e',linewidth=3.2,zorder=7)
    if districts:
        for d in census['districts']:
            x,z=d['center']['x'],d['center']['z'];ax.add_patch(Circle((x,z),d['radius'],facecolor='none',edgecolor='#729184',linestyle=(0,(4,4)),linewidth=.6,alpha=.55,zorder=2))
            text(ax,x,z,f"{d['number']:02d} {d['name']}",fontsize=9.2,ha='center',va='center',color=INK,bbox={'facecolor':BG,'edgecolor':'#b1c1b2','pad':2.6,'alpha':.93},zorder=12)
    ax.set_xlim(bounds[0],bounds[1]);ax.set_ylim(bounds[3],bounds[2]);ax.set_aspect('equal',adjustable='box');ax.tick_params(labelsize=7.5,colors=MUTED)
    for spine in ax.spines.values():spine.set_color('#9cad9e');spine.set_linewidth(.7)
    ax.grid(color='#94a78b',alpha=.15,linewidth=.5);ax.set_axisbelow(True)
    return ax
def scale(ax,x,z,length,label):
    ax.plot([x,x+length],[z,z],color=INK,lw=2,zorder=20)
    ax.plot([x,x],[z-15,z+15],color=INK,lw=1.4,zorder=20);ax.plot([x+length,x+length],[z-15,z+15],color=INK,lw=1.4,zorder=20)
    text(ax,x+length/2,z-28,label,ha='center',va='bottom',fontsize=8.5,color=INK,bbox={'facecolor':BG,'edgecolor':'none','pad':1},zorder=21)

fig=plt.figure(figsize=(24,17),facecolor=BG)
ft(.046,.956,'云山巨城 | 当前城市设计图',fontsize=23,color=INK,weight='normal')
ft(.046,.927,'current-v6 · seed 20261001 · 612 栋建筑 / 11 个城区 / 616 名初始 NPC · 674 节点 / 691 交通边',fontsize=10.8,color=MUTED)
ft(.956,.956,'真实世界数据  /  2D 城市总览',fontsize=10.5,color=MUTED,ha='right')
ft(.956,.931,'五座原银行增高，实际身份与既有街区保留',fontsize=9.5,color=MUTED,ha='right')
ax=fig.add_axes([.043,.160,.603,.744]);basemap(ax,(-2300,2300,-2300,2300))
ax.set_xlabel('本地 x / 米',fontproperties=font,fontsize=9,color=INK);ax.set_ylabel('本地 z / 米',fontproperties=font,fontsize=9,color=INK)
scale(ax,-2040,1980,500,'500 m')
ax.annotate('',xy=(2070,-1860),xytext=(2070,-1670),arrowprops={'arrowstyle':'-|>','color':INK,'lw':1.2},zorder=20)
text(ax,2010,-1640,'−Z 上方\n非地理北',fontsize=7.8,ha='right',color=INK,zorder=20)
core=next(b for b in buildings if b['id']=='core-main');cx,cz=core['position']['x'],core['position']['z'];ax.scatter(cx,cz,s=80,marker='*',color=BG,edgecolors='#84314a',linewidths=.7,zorder=18)
text(ax,cx+78,cz-130,'天枢阁 234 m / 30 层\n政务与能源主阁',fontsize=8.4,color='#7c364a',bbox={'facecolor':BG,'edgecolor':'#bba6af','pad':3,'alpha':.95},zorder=15)
text(ax,700,1590,'南岫跑道 960 × 44 m',fontsize=7.5,color=INK,bbox={'facecolor':BG,'edgecolor':'none','pad':2},zorder=12)
wf=census['waterfall'];text(ax,wf['bottom']['x']+70,wf['bottom']['z']+50,f"瀑布落差 {wf['dropM']:.0f} m",fontsize=7.8,color='#24739a',bbox={'facecolor':BG,'edgecolor':'none','pad':2},zorder=18)
marketBounds=(-670,-70,60,670)
ax.add_patch(Rectangle((marketBounds[0],marketBounds[2]),marketBounds[1]-marketBounds[0],marketBounds[3]-marketBounds[2],fill=False,edgecolor='#963c55',linestyle=(0,(4,3)),linewidth=1.1,zorder=14))
text(ax,-630,722,'商业局部 →',fontsize=8.2,color='#8b3d50',zorder=15)
for i,b in enumerate(census['towers'],1):
    x,z=b['position']['x'],b['position']['z'];ax.scatter(x,z,s=38,facecolor=hcolor(b['bodyHeightM']),edgecolors=BG,linewidths=.9,zorder=16);text(ax,x,z,str(i),fontsize=6.5,ha='center',va='center',color='white',zorder=17)

ft(.691,.884,'千灯市集 | 商业楼与真实街巷',fontsize=15,color=INK)
ft(.691,.860,'五座银行 · 137 个真实楼层 · 楼高 88–176 m',fontsize=10,color=MUTED)
zoom=fig.add_axes([.687,.523,.279,.323]);basemap(zoom,marketBounds,'use',districts=False,detail=True)
zoom.set_xticks([-600,-400,-200]);zoom.set_yticks([100,300,500,650]);zoom.tick_params(labelsize=7)
positions={'market-b6':(-180,340),'market-b38':(-120,112),'market-b44':(-631,175),'market-b41':(-612,486),'market-b35':(-172,609)}
for i,b in enumerate(census['towers'],1):
    original=next(v for v in buildings if v['id']==b['id']);footprint(zoom,original,hcolor(b['bodyHeightM']),zorder=10)
    x,z=b['position']['x'],b['position']['z'];tx,tz=positions[b['id']]
    zoom.scatter(x,z,s=42,facecolor=hcolor(b['bodyHeightM']),edgecolors=BG,linewidths=.8,zorder=12)
    short=b['name'].split('·')[-1]
    label=f"{i:02d} {short}\n{b['bodyHeightM']:g} m / {b['floors']} 层"
    allText.append(label);zoom.annotate(label,(x,z),xytext=(tx,tz),fontproperties=font,fontsize=8,color=INK,ha='left',va='center',arrowprops={'arrowstyle':'-','color':'#83526b','lw':.65},bbox={'facecolor':BG,'edgecolor':'#c6b6bd','pad':2.5,'alpha':.97},zorder=20)
scale(zoom,-632,637,100,'100 m')
ft(.691,.495,'楼层用途',fontsize=11,color=INK)
ft(.691,.474,'1F 柜台接待 · 2F 金融咨询与办事厅',fontsize=9.5,color=MUTED)
ft(.691,.454,'3F 起：结算、业务、账务复核、档案协作办公室',fontsize=9.5,color=MUTED)
ft(.691,.434,'顶层：上层办公与城市会客厅',fontsize=9.5,color=MUTED)
ft(.691,.412,'楼高仅计建筑主体；地表至共享屋顶峰为 89.8–177.8 m。',fontsize=8.6,color=MUTED)
ft(.691,.393,'开放楼层按原银行权限；地图不赋予岗位、公司或产权。',fontsize=8.6,color=MUTED)

ft(.691,.365,'用途图例 | 建筑数量',fontsize=12,color=INK)
for index,kind in enumerate(labels):
    col=index//8;row=index%8;x=.691+col*.137;y=.341-row*.023
    fig.patches.append(Rectangle((x,y-.004),.009,.009,transform=fig.transFigure,facecolor=colors[kind],edgecolor='none'))
    ft(x+.015,y,f"{labels[kind]} {census['kinds'].get(kind,0)}",fontsize=8.7,color=INK,va='center')
ft(.691,.140,'绘图范围与数据说明',fontsize=10.8,color=INK)
ft(.691,.119,'首层真平面投影保留开放庭院；天枢与六亭用原尺寸包络。',fontsize=8.5,color=MUTED)
ft(.691,.100,'虚线圈仅为原设计半径；本地米制坐标，无地理经纬或权属边界。',fontsize=8.5,color=MUTED)
ft(.691,.081,'静态网络线不证明全线可走；初始 NPC 人数不证明到岗或经济稳态。',fontsize=8.5,color=MUTED)

ft(.054,.125,'建筑楼高',fontsize=9.2,color=INK)
for i,(label,color) in enumerate(zip(heightBins,heightColors)):
    x=.107+i*.086;fig.patches.append(Rectangle((x,.121),.013,.010,transform=fig.transFigure,facecolor=color,edgecolor='none'));ft(x+.018,.126,label,fontsize=8.2,color=INK,va='center')
cax=fig.add_axes([.054,.084,.252,.009]);cb=fig.colorbar(matplotlib.cm.ScalarMappable(norm=terrainNorm,cmap=terrainMap),cax=cax,orientation='horizontal');cb.ax.tick_params(labelsize=6.8,color=MUTED);cb.outline.set_edgecolor('#9cac9a')
ft(.054,.064,'地表高程 / m · 40 m 实测网格与 40 m 等高线 · 不含地下室凹陷',fontsize=7.7,color=MUTED)
for i,mode in enumerate(modeStyles):
    col=i%4;row=i//4;x=.338+col*.074;y=.095-row*.025;color,width,style=modeStyles[mode]
    fig.lines.append(plt.Line2D([x,x+.022],[y,y],transform=fig.transFigure,color=color,lw=width*1.5,linestyle=style))
    ft(x+.027,y,f"{modeNames[mode]} {census['transportModes'][mode]}",fontsize=7.5,color=INK,va='center')
ft(.046,.029,'源绑定：current-v6 / b85fa6ec / commercialRouteRevision 1 · 源码 60 份首尾 SHA 一致 · 只读 World 与初始构造，未推进模拟',fontsize=8.2,color=MUTED)
ft(.956,.029,'YUNSHAN  |  2026.10.04',fontsize=8.3,color=MUTED,ha='right')

fontchars=FT2Font(fontpath).get_charmap();missing=sorted({c for s in allText for c in s if not c.isspace() and ord(c) not in fontchars})
assert not missing,f'Missing font glyphs: {missing}'
warningList=[]
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always')
    fig.savefig(root/'云山巨城-v6-当前城市设计图.svg',format='svg',metadata={'Title':'云山巨城 v6 真实城市设计图','Description':'Actual current-v6 World; seed 20261001; fingerprint b85fa6ec; no geographic CRS or route traversal claims.','Date':'2026-10-04'})
    fig.savefig(root/'云山巨城-v6-当前城市设计图.png',dpi=240,metadata={'Title':'云山巨城 v6 真实城市设计图','WorldFingerprint':'b85fa6ec','Seed':'20261001','Layout':'current-v6'})
    fig.savefig(root/'云山巨城-v6-当前城市设计图.pdf',metadata={'Title':'云山巨城 v6 真实城市设计图','Subject':'Actual current-v6 World; fingerprint b85fa6ec; static local X/Z metres'})
    warningList=[str(w.message) for w in caught]
plt.close(fig)
with Image.open(root/'云山巨城-v6-当前城市设计图.png') as im:
    resolution=list(im.size);im.thumbnail((1920,1360));im.save(root/'city-map-preview.png')
manifest={'at':datetime.now(timezone.utc).isoformat(),'backend':matplotlib.get_backend(),'matplotlib':matplotlib.__version__,'imageResolution':resolution,'font':fontpath,'fontSHA256':hashlib.sha256(Path(fontpath).read_bytes()).hexdigest(),'missingGlyphs':missing,'warnings':warningList,'svgTextPortableOutlines':True,'terrainGridStepM':40,'buildings':len(buildings),'nativeWorldSHA256':hashlib.sha256((root/'world-native.json').read_bytes()).hexdigest(),'worldFingerprint':census['fingerprint'],'rawSVGPNGFromSameScene':True,'GPU':0,'browser':0}
(root/'plot-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(manifest,ensure_ascii=False,indent=2))

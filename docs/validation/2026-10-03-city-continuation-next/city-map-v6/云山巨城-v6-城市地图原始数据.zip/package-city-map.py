from pathlib import Path
import json, hashlib, zipfile
from datetime import datetime, timezone
from xml.etree import ElementTree
import csv
from PIL import Image
root=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=root/'云山巨城-v6-当前城市设计图.png'
with Image.open(raw) as image:
    image.verify()
with Image.open(raw) as image:
    resolution=list(image.size)
ElementTree.parse(root/'云山巨城-v6-当前城市设计图.svg')
start=json.loads((root/'source-start.json').read_text())['files']
end=json.loads((root/'source-end.json').read_text())['files']
assert start==end
for name,expected in start.items():
    b=(root/'source-bound'/name).read_bytes()
    assert len(b)==expected['bytes'] and sha(b)==expected['sha256'],name
with (root/'buildings.csv').open(encoding='utf-8-sig',newline='') as f:
    buildings=list(csv.DictReader(f))
with (root/'districts.csv').open(encoding='utf-8-sig',newline='') as f:
    districts=list(csv.DictReader(f))
with (root/'transport-edges.csv').open(encoding='utf-8-sig',newline='') as f:
    edges=list(csv.DictReader(f))
assert len(buildings)==612 and len(districts)==11 and len(edges)==691
manifest=json.loads((root/'collection-manifest.json').read_text())
assert manifest['nativeWorldSHA256']==sha((root/'world-native.json').read_bytes())
assert manifest['fingerprint']=='b85fa6ec'
assert (root/'terrain-height-f64.bin').stat().st_size==116*116*8
skip={'.mpl-cache','.font-cache','node_modules','packaging-r1'}
excluded={'delivery-manifest.json','archive-receipt.json','云山巨城-v6-城市地图原始数据.zip','package.log'}
files=sorted(p for p in root.rglob('*') if p.is_file() and not (set(p.relative_to(root).parts)&skip) and p.name not in excluded)
fileRecords={p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files}
receipt={'at':datetime.now(timezone.utc).isoformat(),'producerNamespace':str(root),'worldFingerprint':'b85fa6ec','seed':20261001,'recipe':'current-v6','commercialRouteRevision':1,'sourceCount':len(start),'collectionSourceUnchanged':True,'sourceBoundCopiesMatch':True,'nativeWorldSHA256':manifest['nativeWorldSHA256'],'PNGOriginalResolution':resolution,'buildings':len(buildings),'districts':len(districts),'transportEdges':len(edges),'seedNPCs':616,'nativeSeedNPCCensus':'seed-npc-census.json, actual constructor tick0','checks':{'PNGDecode':'PASS','SVGXMLParse':'PASS','CSVRowCounts':'PASS','TerrainBinarySize':'PASS','SourceWindowSHAEquality':'PASS','FrozenSourceCopiesSHAEquality':'PASS','WorldExportSHAEquality':'PASS'},'files':fileRecords,'LibraryProducerCalls':0,'externalFileIDs':0,'deliveryOwner':'Root batches original PNG and ZIP; this file is not an upload receipt.'}
(root/'delivery-manifest.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
archive=root/'云山巨城-v6-城市地图原始数据.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7) as z:
    for p in [*files,root/'delivery-manifest.json']:
        z.write(p,p.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,expected in fileRecords.items():assert sha(z.read(name))==expected['sha256'],name
    assert z.read('delivery-manifest.json')==(root/'delivery-manifest.json').read_bytes()
    archiveReceipt={'at':datetime.now(timezone.utc).isoformat(),'archive':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(z.namelist()),'allMembersCRC':'PASS','eachOriginalFileSHA256':'PASS','manifestOriginalBytes':'PASS','worldFingerprint':'b85fa6ec','producerExternalIDs':0}
(root/'archive-receipt.json').write_text(json.dumps(archiveReceipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'delivery':{k:v for k,v in receipt.items() if k!='files'},'archive':archiveReceipt},ensure_ascii=False,indent=2))

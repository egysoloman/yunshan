# NEW03 evidence package

Install only candidate03.patch after baseline verification. SOURCE-INPUTS-355.json is the exact frozen source graph; source355/ has every355 path with byte-identical contents. No node_modules or historical docs archive is included.

candidate01-added/ and candidate02-added/ contain every path absent from common base351 for those exact old candidates. For an earlier full candidate, take the351 paths listed by input/SOURCE-INPUTS-351.json from source355/ and overlay its added directory. Their complete354 dictionaries and raw native receipts are included; private full candidate01-source and candidate02-source also remain at their original paths. pure03-added/ plus shared351 similarly reproduce the failed pure candidate. Do not install these superseded sources.

native01 is an original failing test assumption, native02 passes its narrower contracts but misses later reviewed protections, PURE03 has an invalid no-hole fixture, and native03/PURE04/TYPE08 are the final successful receipts. Keep original failures when reviewing the fixes. World JSON file SHA and generation authority SHA are different contracts; native-result.json names authority SHA explicitly.

This package contains no main/GUI wiring and does not prove demolition, relocation, physical construction or complete GIS parameter coverage. Text/2D hosts may use the real native transaction API only with code-owned resolvers and exclusive consumers as described in INSTALL.md.

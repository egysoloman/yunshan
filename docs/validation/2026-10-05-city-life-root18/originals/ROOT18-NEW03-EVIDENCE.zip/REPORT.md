# ROOT18 可信 World generation 事务宿主：NEW03 已验证

任务接续 `/workspace/yunshan` `e4e95d340b592ff51a6088771c741a396f2c4502`。所有实现、复制、验证和交付原件只在 `/tmp/ROOT18-dynamic-execution-20261005-01`；未改共享树、未commit/push、未调用Library、未部署。已完整读取AGENTS、提示词和备忘录顶部及相关建筑/道路/商铺/World/save合同。

## 实现和可执行范围

新增 `src/host/world-generation.ts` 与 `src/host/world-generation-binding.ts`。宿主已连接真实生产 `Simulation` 构造、完整读取器和原生存档导出；提供同几何重建、受信注册表中的完整自定义 World＋对应原生save切换，以及独立checkpoint恢复。Prepare创建新World/Building身份与新Simulation，完整验证选中原件，按原bytes恢复所有居民、路由、RNG、钱料、工资账、产权/租约/托管和公民身份历史。Commit再次核验源/目标完整原件后，用一个同步CAS发布world/simulation/consumer view；旧实例不收到新实例阶段或劳动事件。失败、取消、竞态保留当前会话，释放真正属于候选的消费者束。

World绑定包含完整definition JSON、原生baseWorldFingerprint、fullBody（楼层membership、interior/circulation/courtyard、洞口、treads/landings、fixtures、walls/openings、权限与使用点），以及独立public wallPanels/slab/roof缓存、mutable航空停机位和真实rail spans。私有近楼层/stair-surface/local-solid/support-footprint/空间/路径缓存通过新的World/Building/Simulation身份重建。当前源码没有public Ramps/SelfSolids getter；未来新增authorities必须更新该独立绑定合同。CAS不冻结共享的公开可变几何API，只拒绝已改变的源或目标。

消费者WeakSet跟踪外层bundle身份，跨active、pending、取消、退休与不同host禁止复用同对象，迟返别名不重复dispose。`stageConsumers`必须独占所有内部disposable资源；WeakSet不能自动证明fresh wrapper中的GPU/Controller内部资源所有权。undefined表示无消费者资源。

这是可供text/2D宿主调用的真实native事务执行基础；2D消费者仍须遵守独占工厂合同，现有2D/GUI产品入口未接线，**不是原城拆楼、迁居、新路、施工或合法整栋产权登记**。不同完整会话切换不是向原会话凭空添加资金、库存或身份。所有原civic origin/角色/历史及生产validator保持原合同。`main.ts`、renderer/controller/UI和product factories均未改；GUI换代接线由root单独评估。检查点不是现GUI普通导入格式，trusted resolver不从存档授予任何World几何或产权。

## 冻结与旧输入保护

源基线351字典图 `74aee7b713f03c51b9fd7427ed7fbfccdb60b451919c64c36295c75cb627c2be`。NEW03新增两host与两test，共355输入，图 `6092053e33055e3d45ac8dfe2f6b0de902034a207fa99e3ae801f5f6ca645975`。351旧输入（含229个当前tests/helper/fixture路径）逐SHA无变，所有原断言与旧原件不改。

Patch为完整 `candidate03.patch`，四项 `new file mode 100644`，SHA `f79ccee959b3707a636cb491cbd14f689a43e3223081bfd898d41746ec9d4273`；独立空private git目录 `git apply --check` PASS。INSTALL.md给出受信注册表、准备/提交/取消、恢复与GUI接线条件。

## 已运行的证据

- TYPE01/02/03/05/06/07/08严格tsc PASS；TYPE04新test引用不存在的SavePart.kind，原FAIL保留，修为实际id元数据。
- PURE04：7/7 PASS，零Simulation构造。包括SHA UTF8、检查点资源/额外字段/未知resolver拒绝、World参数及独立wall/slab缓存变动、body stair/fixtures/真实上层hole/roof/floor membership/pad/rail变化绑定。PURE03 6PASS/1FAIL保留：新夹具误选0层无孔，修为真实有孔的上层，原强断言保留。
- native02：04:53:44.858952→04:53:48.812232 UTC，3.953292s/cap180，exit0、354输入稳定、ownedActive[]。17实际Simulation构造、96普通step(.25)。7楼384人的原native3真实租约档完整读取；押金50、垫款200、原工资债、钱粮角色业务保持。Active/pending直接别名拒且不dispose，合法pause后CAS拒保最新完整save，token伪造/重复commit拒，取消/consumer异常/consumer改写候选拒。四实例未来24逐字同，5地理parts实际落盘读回；原source阶段事件0、全save与World JSON一直保持。完整custom native4与old native1 public预算原件切换/恢复也全bytes相同。
- native02源save `63670a12ece4f11c5d53d93f46fa48755bb2388522dd5b070867275823c801a2`，future24 `dbb927373c86e3fae053e9c49f8d5b80f1e915bf82816c748fff9d4a1379447a`。选中custom native4 `fa6aac005b071b7e7696b269352db27baeb606f7bd0d17a65308a1e98514dd10`；old public预算native1 `9cdfc34fc36410e683b76870979fea63e6597cd0db86716e2ae4905be47866f1`，匿名official双签、cap40/spent40及角色/legacy合同全保。

native02缺口版完整354源保存在candidate02-source，不能安装；其PASS范围不能冒NEW03异步/marked-body结果。二审查到迟返已退休consumer会重复dispose、独立wall/slab缓存未绑定，随后NEW03修复并增加实际异步与marked-body回归。

## NEW03 最终实际原生验证

`native03/START.json`、`END.json`和raw.log是本次实际运行回执。2026-10-05 05:12:03.191903→05:12:09.098905 UTC，5.907011s/cap180，exit0、timeout=false、355输入逐SHA稳定、ownedActive=[]。实际24个Simulation构造（6个可见原生构造＋18个已进入stage的host构造），144次普通step(.25)。未运行默认大城或GPU，没有body/needs/资金重置、速度修改或原断言放宽。

保留native02所有真实恢复、源保护、租约和账务断言；新增迟返退休source/取消candidate消费者的两个实际async交错，拒绝别名且不二次dispose；独立public wall/slab改写拒绝；export hash期间dispose拒绝。选中自定义参数World在首次Simulation构造前注册：4栋384人，clinic真实12×12×6、两层、continuous stair revision2，并同步真实door/node/edge三维长度。此参数城市的两个原生恢复实例各运行24普通步，每步完整save逐字相等；实际derived body/roof/wall/slab/pad/rail绑定在这些后续步中保持不变。这是显式受信参数样例，不能泛化为所有GIS或默认大城。

7栋384人的原native3源完整save SHA `63670a12ece4f11c5d53d93f46fa48755bb2388522dd5b070867275823c801a2`，source authority World SHA `2c7375b99beb355b557af93ba28ec3e10e4e76c5ca40e457137e7fb030e1b153`。Prepare和失败均保持旧source全save与World JSON，原阶段事件0；合法pause导致通知后，CAS拒绝保持该合法命令后的最新save。原租约押金50、垫款200及非零工资债和其他完整账本原字节保持，原4实例future24 SHA `dbb927373c86e3fae053e9c49f8d5b80f1e915bf82816c748fff9d4a1379447a`，实际5个physical parts读回相同。

自定义native4选中save SHA `03e75705fdd3c3d4e6a47e2df82072e3cc008504a8b696afa77d92a183212a88`，完整authority World SHA `735a310d42f0db3ac81eb626929ce8fe452d7efc6180a95cdd34bfcf11037514`；marked-body future24 SHA `b8703f881349f0108456d1451d5a3476e974f0eba46fd0c7d0ef6801cb7340f1`。原v4 civic enablement/origin对象逐字不改。old native1公共预算save SHA `9cdfc34fc36410e683b76870979fea63e6597cd0db86716e2ae4905be47866f1`，匿名original official `citizen-4`/`citizen-15`双签、cap40/spent40/506时间戳及全居民id/role完整保持，effectiveRuleset仍legacy；没有偷偷授予经营许可、整栋产权、财政权限或角色。

World authority SHA是完整definition＋当前source公开物理authority的绑定值，**不同于**只保存World JSON文件的SHA。独立checkpoint同时绑定该authority SHA、baseWorldFingerprint、完整save SHA，并由外部受信checkpoint SHA和resolver恢复。所有这些原件在native03/artifacts中；具体文件SHA见EVIDENCE-INDEX.json，不用文件JSON SHA冒充World authority SHA。

最终PURE04 7/7 PASS、TYPE08 PASS、native03 1/1 PASS。所有351旧输入和229个当前tests/helper/fixture路径逐SHA未改；最终355再次核验稳定。无需扩大native/GPU窗口，已向root释放独占slot。

## 交付原件

`candidate03.patch`、`CHANGE-MANIFEST.json`、`SOURCE-INPUTS-355.json`、`REPORT.md`、`INSTALL.md`与`ROOT18-NEW03-EVIDENCE.zip`。ZIP按字典逐项打包最终355原件，不包含node_modules、共享树或旧大型docs archive；native01/PURE03失败原日志和精确候选新增源、候选02缺口版新增源和其354字典、完整native02/03证据全保。各旧候选的351公共输入均与final一致，可由最终source355公共351＋其旧新增文件逐字重建。私有candidate01-source、candidate02-source原完整354目录仍保留。EVIDENCE-INDEX逐文件记录bytes/SHA；DELIVERABLES.json另记录ZIP整体SHA。

## 失败与剩余阻碍

- 首次整仓git archive意外包括大量旧证据ZIP，私有解包ENOSPC；仅清理本次未完成私有docs复制物，保COPY-FAILURE01回执，随后按351字典复制逐SHA核验。未删除既有原件。
- native01：04:50:30.276→31.910 UTC，1.633s/cap180，7实际构造、0step FAIL。新test错误认为合法pause/unpause通知应消失；保原raw和354输入。NEW02用独立原件reader执行合法pause，仅检查CAS拒后最新原件不变，不删通知/重置身体/削弱断言。尾esbuild156067已退出Z，不是活跃owned执行，补CLEANUP-SUPPLEMENT原件。
- 默认612/616大城、真实GIS参数全覆盖、GPU换代、完整npm、长期经济/人口/财政稳态均未由这轮窄host验证覆盖。既有大城civic-origin、全栋产权、资金材料劳动施工、搬迁/历史场所/电源分表与有效World generation/patch重放合同仍是几何执行前置；不能移除原保护或修改origin来掩盖未实现。

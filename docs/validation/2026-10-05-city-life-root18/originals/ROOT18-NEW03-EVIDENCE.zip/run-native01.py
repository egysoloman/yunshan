from pathlib import Path
import datetime,hashlib,json,os,signal,subprocess,time
r=Path('/tmp/ROOT18-dynamic-execution-20261005-01');p=r/'source';out=r/'native01';out.mkdir(exist_ok=True)
manifest=json.loads((r/'CANDIDATE01-INPUT.json').read_text())
def inputs():return {k:hashlib.sha256((p/k).read_bytes()).hexdigest() for k in manifest}
before=inputs();assert before==manifest
start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
with (out/'raw.log').open('wb') as log:
 proc=subprocess.Popen(['node','--import','tsx','--test','tests/world-generation-native.test.ts'],cwd=p,env={**os.environ,'GENERATION_ARTIFACT_DIR':str(out/'artifacts')},stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 (out/'START.json').write_text(json.dumps({'startUTC':start,'pid':proc.pid,'pgid':proc.pid,'capSeconds':180,'argv':proc.args,'inputSHA256':hashlib.sha256(json.dumps(before,separators=(',',':')).encode()).hexdigest()},indent=2)+'\n')
 timeout=False
 try:code=proc.wait(timeout=180)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(proc.pid,signal.SIGTERM)
  try:code=proc.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);code=proc.wait()
after=inputs();alive=[]
for f in Path('/proc').iterdir():
 if f.name.isdigit():
  try:
   if os.getpgid(int(f.name))==proc.pid:alive.append(int(f.name))
  except ProcessLookupError:pass
receipt={'startUTC':start,'endUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsedSeconds':time.monotonic()-clock,'pid':proc.pid,'pgid':proc.pid,'capSeconds':180,'exitCode':code,'timeout':timeout,'inputStable':before==after,'ownedActive':alive,'inputSHA256':hashlib.sha256(json.dumps(after,separators=(',',':')).encode()).hexdigest(),'rawSHA256':hashlib.sha256((out/'raw.log').read_bytes()).hexdigest()}
(out/'END.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt));print((out/'raw.log').read_text()[-6000:])

import assert from 'node:assert/strict';
import test from 'node:test';
import { createHash } from 'node:crypto';
import { WorldGenerationHost, generationSHA256, generationWorldSHA256 } from '../src/host/world-generation';
import { gridWorld } from './power-grid-fixture';

const sha = (text: string) => createHash('sha256').update(text).digest('hex');
const guard = () => {
  let calls = 0;
  return { services: { resolveWorld() { calls++; throw new Error('no trusted world registered'); },
    stageConsumers() { calls++; return undefined; }, releaseConsumers() { calls++; } }, calls: () => calls };
};
const envelope = () => {
  const save = JSON.stringify({ format: 'yunshan-save', version: 2, worldFingerprint: '1234' });
  return { format: 'yunshan-world-generation', version: 1, revision: 0, worldSHA256: 'a'.repeat(64), baseWorldFingerprint: '1234', saveSHA256: sha(save), save };
};
// These resource/envelope checks instantiate zero Simulation objects. They are
// not standalone native saves or evidence of paid work or valid city accounts.
test('generation hashes bind exact UTF-8 bytes and custom-world parameters outside the old short fingerprint', async () => {
  for (const text of ['云山世代', 'a\nb', '\u0000', '']) assert.equal(await generationSHA256(text), sha(text));
  const world = gridWorld(), before = JSON.stringify(world), original = await generationWorldSHA256(world);
  assert.equal(JSON.stringify(world), before);
  const other = structuredClone(world); other.buildings[0].capacity++;
  assert.notEqual(await generationWorldSHA256(other), original);
  other.buildings[0].capacity--; other.districts[0].population++;
  assert.notEqual(await generationWorldSHA256(other), original);
  assert.equal(await generationWorldSHA256(structuredClone(world)), original);
});
test('untrusted checkpoint digest rejects before any resolver or Simulation is called', async () => {
  const guarded = guard(), json = JSON.stringify(envelope());
  await assert.rejects(WorldGenerationHost.restore(json, 'b'.repeat(64), guarded.services), /SHA/);
  assert.equal(guarded.calls(), 0);
});
test('unknown geometry, prototype fields and invalid revisions cannot become checkpoint instructions', async () => {
  for (const alteration of [{ world: gridWorld() }, { revision: -1 }, { revision: 1e9 + 1 }, { version: 2 }, { saveSHA256: 'x' }]) {
    const guarded = guard(), json = JSON.stringify({ ...envelope(), ...alteration });
    await assert.rejects(WorldGenerationHost.restore(json, sha(json), guarded.services), /字段/);
    assert.equal(guarded.calls(), 0);
  }
  const guarded = guard(), json = JSON.stringify(envelope()).replace('"format":', '"__proto__":{},"format":');
  await assert.rejects(WorldGenerationHost.restore(json, sha(json), guarded.services), /字段/); assert.equal(guarded.calls(), 0);
});
test('business original SHA and base-world fingerprint mismatch reject without native construction', async () => {
  for (const alteration of [{ saveSHA256: 'b'.repeat(64) }, { baseWorldFingerprint: '9999' }]) {
    const guarded = guard(), json = JSON.stringify({ ...envelope(), ...alteration });
    await assert.rejects(WorldGenerationHost.restore(json, sha(json), guarded.services), /SHA|指纹/);
    assert.equal(guarded.calls(), 0);
  }
});
test('a well-shaped checkpoint still requires a trusted resolver and never falls back to a new city', async () => {
  const guarded = guard(), json = JSON.stringify(envelope());
  await assert.rejects(WorldGenerationHost.restore(json, sha(json), guarded.services), /no trusted world registered/);
  assert.equal(guarded.calls(), 1);
});

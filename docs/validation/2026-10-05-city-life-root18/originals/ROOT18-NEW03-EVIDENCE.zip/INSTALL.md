# ROOT18 World generation host installation

Candidate03 is an independent addition to base `e4e95d340b592ff51a6088771c741a396f2c4502`. It adds four files and changes none of the original 351 runtime inputs. Do not install the earlier 01/02 candidates: 01 has a failed new test assumption; 02 lacks two subsequently reviewed consistency protections.

- Patch: `candidate03.patch` (four `new file mode 100644` entries).
- Runtime input graph: `CANDIDATE03-INPUT.json`, compact JSON dictionary SHA `6092053e33055e3d45ac8dfe2f6b0de902034a207fa99e3ae801f5f6ca645975`.
- Patch SHA: `f79ccee959b3707a636cb491cbd14f689a43e3223081bfd898d41746ec9d4273`.
- Apply only after checking the parent baseline and four destination paths. `git apply --check candidate03.patch` passed in a clean private patch-check directory; no shared repository file was changed.

The API is `WorldGenerationHost.attach(existingSimulation, existingConsumers, services)` from `src/host/world-generation.ts`. A trusted host supplies `resolveWorld(worldSHA256)`, `stageConsumers(candidateWorld, candidateSimulation)` and `releaseConsumers(consumers)`. Register code-owned parameter Worlds using `generationWorldSHA256(world)`. Saves and checkpoints contain no World geometry and cannot register new geometry.

A headless host may use `undefined` for consumers and no-op staging/release. A graphical host must stage a completely new renderer, controller, navigation and associated resources against the candidate World and Simulation, then have all frame/update consumers read a single `host.current` view. The bundle and all disposable resources inside it must be exclusive. The ownership WeakSet checks outer bundle identities; it cannot infer ownership of arbitrary nested GPU/DOM objects. A fresh wrapper around an old controller/renderer violates the factory contract.

`prepareRebuild({revision, worldSHA256, sourceSaveSHA256})` reconstructs the identical World and exact native save. `prepareLoad(expectedCurrent, {worldSHA256, saveSHA256, save})` explicitly selects a different complete native session from the trusted registry. Preparation runs a new native Simulation and the complete production importer, preserves the selected save byte for byte, and stages consumers while the original session stays current. `commit(prepared)` performs a synchronous compare-and-swap of the whole view, checks the latest old/candidate bytes again, and rejects a stale or changed candidate. `cancel(prepared)` only releases that candidate.

Use `exportCheckpoint()` for a generation checkpoint. `WorldGenerationHost.restore(checkpointJSON, expectedCheckpointSHA256, services)` restores through the trusted World resolver and exact native save SHA. The ordinary existing raw save and geographic `partitionSave` format remain unchanged. The checkpoint wrapper is a separate host contract; current GUI import/load and `selectSavedWorld` do not consume it automatically.

Candidate03 verification commands, run in the private source directory:

```sh
node --import tsx --test tests/world-generation-pure.test.ts
./node_modules/.bin/tsc --noEmit
GENERATION_ARTIFACT_DIR=/absolute/new/evidence/path node --import tsx --test tests/world-generation-native.test.ts
```

The final frozen candidate03 passed its exclusive cap180 native window at 2026-10-05 05:12:03.191903–05:12:09.098905 UTC: exit0, 24 actual Simulation constructors, 144 ordinary step(.25) calls, all355 input SHAs stable and ownedActive=[]. PURE04 passed7/7; strict TYPE08 passed. The actual receipts are native03/END.json and artifacts/native-result.json. The window is released; do not repeat or expand native/GPU tests without the parent's coordination.

Text hosts can call this API directly with undefined consumers; a 2D host can supply exclusive staged consumers. Existing 2D and GUI product entrances are not wired to it. This API executes native instance/world/consumer replacement. It does not execute closure overlays, relocation, demolition, physical construction, road additions, rights registration or geometry patches in the outgoing city. Main/GUI wiring requires parent review; the shared `main.ts`, product factories, civic-origin/role contracts and validators are untouched.

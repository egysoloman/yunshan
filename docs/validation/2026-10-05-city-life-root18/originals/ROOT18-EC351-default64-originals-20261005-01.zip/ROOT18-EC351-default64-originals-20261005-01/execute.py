import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source'
EXPECTED=json.loads((ROOT/'SOURCE-INPUTS-351.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inputs(directory):
 files=[p for n in ['src','tests','scripts','adapters','public'] for p in (directory/n).rglob('*') if p.is_file()]
 files += [directory/n for n in ['package.json','package-lock.json','tsconfig.json','vite.config.ts','index.html'] if (directory/n).is_file()]
 return {str(p.relative_to(directory)):sha(p) for p in sorted(files)}
scope=ROOT/'actual01'
assert not scope.exists(),'Do not overwrite or extend a frozen phase'
frozen=json.loads((ROOT/'FROZEN-FILES.json').read_text())
origins=json.loads((ROOT/'PREPARATION-RECEIPT.json').read_text())['copied']
def external():
 return {str(p):sha(p) for p in [*(ROOT/name for name in frozen),*(Path(row['origin']) for row in origins)]}
before=external(); assert all(sha(ROOT/name)==h for name,h in frozen.items())
source_before=inputs(SOURCE); shared_before=inputs(Path('/workspace/yunshan'))
assert source_before==EXPECTED and shared_before==EXPECTED and len(source_before)==351
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
argv=['node','--import','tsx',str(ROOT/'continue-economy.mjs')]
command=[sys.executable,str(ROOT/'run-phase.py'),str(SOURCE),str(scope),json.dumps(argv),'360']
completed=subprocess.run(command,env=os.environ.copy())
after=external(); source_after=inputs(SOURCE); shared_after=inputs(Path('/workspace/yunshan'))
receipt=json.loads((scope/'receipt.json').read_text())
result={'startedAt':started,'endedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'exitCode':completed.returncode,'wrapperStatus':receipt['status'],'sourceInputCount':len(source_before),'sourceGraphSHA256':'74aee7b713f03c51b9fd7427ed7fbfccdb60b451919c64c36295c75cb627c2be','sourceMatchesFrozen351':source_before==EXPECTED,'sourceInputsStable':source_before==source_after,'sharedInputsStable':shared_before==shared_after,'allFrozenDriverPlanOriginalAndOriginBytesStable':before==after,'activeDescendants':receipt['activeDescendants'],'capSeconds':360,'maximumOrdinaryCalls':64,'coordinatorSHA256':sha(Path(__file__))}
result['scopeStatus']='PASS' if completed.returncode==0 and source_before==source_after and shared_before==shared_after and before==after and not receipt['activeDescendants'] else 'FAIL_OR_PARTIAL'
(ROOT/'EXTERNAL-GUARD-RECEIPT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result));sys.exit(0 if result['scopeStatus']=='PASS' else 1)

"""One frozen 360-second phase, with all external source/original guards."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).parent
CONFIG = json.loads((ROOT / 'SOURCE-FREEZE.json').read_text())
SOURCE = Path(CONFIG['source'])
BASELINE = Path(CONFIG['baseline'])

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs(directory):
    files = [p for n in ['src', 'tests', 'scripts', 'adapters', 'public'] for p in (directory / n).rglob('*') if p.is_file()]
    files += [directory / n for n in ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'index.html'] if (directory / n).is_file()]
    return {str(p.relative_to(directory)): sha(p) for p in sorted(files)}

scope = ROOT / 'actual01'
assert not scope.exists(), 'Never overwrite or extend an existing frozen phase'
frozen = json.loads((ROOT / 'FROZEN-FILES.json').read_text())
originals = json.loads((ROOT / 'PREPARATION-ORIGINAL-RECEIPT.json').read_text())['files']
def external():
    return {str(path): sha(path) for path in [*(ROOT / name for name in frozen), *(Path(entry['origin']) for entry in originals)]}
before = external()
assert all(sha(ROOT / name) == expected for name, expected in frozen.items())
source_before = inputs(SOURCE); baseline_before = inputs(BASELINE)
assert source_before == json.loads((ROOT / 'FINAL-INPUTS-351.json').read_text())
assert baseline_before == json.loads((ROOT / 'BASELINE-INPUTS-325.json').read_text())
assert len(source_before) == 351 and len(baseline_before) == 325
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
argv = ['node', '--import', 'tsx', str(ROOT / 'edf-integration.mjs')]
command = [sys.executable, str(ROOT / 'run-phase.py'), str(SOURCE), str(scope), json.dumps(argv), '360']
completed = subprocess.run(command, env=os.environ.copy())
after = external(); source_after = inputs(SOURCE); baseline_after = inputs(BASELINE)
receipt = json.loads((scope / 'receipt.json').read_text())
result = {'startedAt': started, 'endedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'command': command,
    'exitCode': completed.returncode, 'wrapperStatus': receipt['status'], 'sourceInputCount': len(source_before),
    'sourceInputManifestSHA256': CONFIG['inputManifestSHA256'], 'externalBaselineInputCount': len(baseline_before),
    'sourceInputsMatchFrozen351': True, 'externalBaselineMatchesFrozen325': True,
    'sourceInputBytesStable': source_before == source_after, 'externalBaselineInputBytesStable': baseline_before == baseline_after,
    'allFrozenDriverPlanAndOriginFilesBytesStable': before == after, 'activeDescendants': receipt['activeDescendants'],
    'coordinatorSHA256': sha(Path(__file__))}
result['scopeStatus'] = 'PASS' if completed.returncode == 0 and source_before == source_after and baseline_before == baseline_after and before == after and not receipt['activeDescendants'] else 'FAIL_OR_PARTIAL'
(ROOT / 'EXTERNAL-GUARD-RECEIPT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
sys.exit(0 if result['scopeStatus'] == 'PASS' else 1)

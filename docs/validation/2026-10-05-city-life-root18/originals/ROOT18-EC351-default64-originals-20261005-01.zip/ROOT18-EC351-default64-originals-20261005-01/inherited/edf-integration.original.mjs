import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const config = JSON.parse(readFileSync(join(root, 'SOURCE-FREEZE.json'), 'utf8'));
const artifacts = join(root, 'actual01', 'artifacts');
mkdirSync(artifacts, { recursive: true });
const sha = raw => createHash('sha256').update(raw).digest('hex');
const json = (name, value) => writeFileSync(join(artifacts, name), JSON.stringify(value, null, 2) + '\n');
const worldRaw = readFileSync(join(root, 'originals', 'WORLD-ORIGINAL.json'), 'utf8');
const edfRaw = readFileSync(join(root, 'originals', 'EDF-ORIGINAL.save.json'), 'utf8');
const oldTerminal = readFileSync(join(root, 'originals', 'BASELINE16-ORIGINAL.save.json'), 'utf8');
const expectedRows = JSON.parse(readFileSync(join(root, 'CANDIDATE06-16TICKS.original.json'), 'utf8')).rows;
const original = JSON.parse(edfRaw);
const counters = { simulationConstructors: 0, legacyBaselineStepCalls: 0, legacyFinalStepCalls: 0, upgradedSourceStepCalls: 0, wholeReaderStepCalls: 0, physicalPartsReaderStepCalls: 0, totalOrdinaryStepCalls: 0 };
let stage = 'preflight';
const progress = extra => json('CURRENT.json', { stage, counters, ...extra });
function completeBytes(actual, expected, label) {
  if (actual !== expected) {
    writeFileSync(join(artifacts, 'MISMATCH-actual.save.json'), actual);
    writeFileSync(join(artifacts, 'MISMATCH-expected.save.json'), expected);
    json('MISMATCH.json', { stage, label, actualSHA256: sha(actual), expectedSHA256: sha(expected), counters });
  }
  assert.ok(actual === expected, label);
}
function advance(sim, name) {
  assert.ok(counters.totalOrdinaryStepCalls < 104, 'The frozen total instance step bound is 104');
  assert.equal(sim.state.speed, 8, 'Keep the actual EDF saved speed');
  counters[name]++; counters.totalOrdinaryStepCalls++;
  sim.step(.25);
}
function restored(Simulation, label) {
  const sim = new Simulation(JSON.parse(worldRaw)); counters.simulationConstructors++;
  const result = sim.importSave(edfRaw); assert.ok(result.ok, `${label}: ${result.message}`);
  completeBytes(sim.exportSave(), edfRaw, `${label}: original EDF import/export must remain complete-byte exact`);
  assert.equal(sim.state.speed, 8); assert.equal(sim.state.tick, 1104); assert.equal(sim.state.citizens.length, 616);
  if (label === 'original325') {
    const saved = JSON.parse(sim.exportSave());
    assert.equal(Object.hasOwn(saved, 'freightPickupPolicyId'), false);
    assert.equal(Object.hasOwn(saved.runtime, 'freightPickupPolicyId'), false);
  } else assert.equal(sim.freightPickupPolicyId, 'legacy');
  return sim;
}

async function main() {
  assert.equal(sha(worldRaw), '2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512');
  assert.equal(sha(edfRaw), 'edf73ed2aa923b16248f3981092ea78dfe6375e5be1a4d4e3c6914ca84285754');
  assert.equal(sha(oldTerminal), 'f4b9076c3b04c0479035995a9a159310ff9f742cab78c55d2c1269dcb3474040');
  assert.equal(expectedRows.length, 16);
  assert.equal(original.state.extension.lastUpdate, 2688);
  assert.equal(original.freightPickupPolicyId, undefined); assert.equal(original.runtime.freightPickupPolicyId, undefined);
  const world = JSON.parse(worldRaw);
  assert.equal(world.buildings.length, 612); assert.equal(world.nodes.length, 674); assert.equal(world.edges.length, 691);
  assert.equal(world.seed, 20261001);
  progress({ source: config.source, inputCount: config.inputCount, initialSHA256: sha(edfRaw) });
  const { Simulation: Baseline } = await import(pathToFileURL(join(config.baseline, 'src/simulation.ts')).href);
  const { Simulation: Final } = await import(pathToFileURL(join(config.source, 'src/simulation.ts')).href);
  const { upgradeFreightPickup } = await import(pathToFileURL(join(config.source, 'src/host/upgrade-freight-pickup.ts')).href);
  const { partitionSave, assembleSave } = await import(pathToFileURL(join(config.source, 'src/persistence/partition.ts')).href);

  // Separate saved branches. Returning releases both audit references; the
  // later upgrade starts by importing the original EDF bytes into its reader.
  function auditOldContract() {
    stage = 'old-contract-16';
    const baseline = restored(Baseline, 'original325'), final = restored(Final, 'final old-policy reader');
    const rows = [];
    for (let i = 0; i < 16; i++) {
      advance(baseline, 'legacyBaselineStepCalls'); advance(final, 'legacyFinalStepCalls');
      const before = baseline.exportSave(), after = final.exportSave();
      completeBytes(after, before, `old contract full byte equality at frame ${i + 1}`);
      assert.equal(sha(after), expectedRows[i].saveSHA256, 'Keep the previously frozen actual baseline trajectory');
      assert.equal(final.state.tick, 1105 + i); assert.equal(baseline.state.tick, 1105 + i);
      rows.push({ frame: i + 1, tick: final.state.tick, clock: final.state.extension.lastUpdate, baselineAndFinalFullBytesEqual: true, saveSHA256: sha(after), frozenTickSHAEquals: true });
      json('OLD-COMPARE-16.json', rows); progress({ legacyFrame: i + 1, saveSHA256: sha(after) });
      console.log(JSON.stringify({ stage, frame: i + 1, tick: final.state.tick, saveSHA256: sha(after) }));
    }
    const actualOldTerminal = final.exportSave(); completeBytes(actualOldTerminal, oldTerminal, 'Actual final16 complete bytes equal the preserved F4B baseline terminal');
    writeFileSync(join(artifacts, 'LEGACY16-FINAL.save.json'), actualOldTerminal);
    return { frames: rows.length, terminalSHA256: sha(actualOldTerminal) };
  }
  const legacy = auditOldContract();

  stage = 'exact-edf-upgrade';
  const upgraded = restored(Final, 'independent original EDF upgrade reader');
  writeFileSync(join(artifacts, 'UPGRADE-BEFORE.save.json'), upgraded.exportSave());
  const bad = await upgradeFreightPickup(upgraded, '0'.repeat(64)); assert.equal(bad.ok, false);
  completeBytes(upgraded.exportSave(), edfRaw, 'Wrong SHA rejects without changing original EDF bytes');
  const result = await upgradeFreightPickup(upgraded, sha(edfRaw)); assert.ok(result.ok, result.message);
  const upgradedRaw = upgraded.exportSave(), marked = JSON.parse(upgradedRaw);
  assert.equal(marked.freightPickupPolicyId, 'road-food-pickup-v1'); assert.equal(marked.runtime.freightPickupPolicyId, 'road-food-pickup-v1');
  delete marked.freightPickupPolicyId; delete marked.runtime.freightPickupPolicyId;
  completeBytes(JSON.stringify(marked), edfRaw, 'Upgrade changes exactly two policy declarations; all original saved data remains byte exact');
  assert.equal(upgraded.state.tick, 1104); assert.equal(upgraded.state.speed, 8);
  const repeat = await upgradeFreightPickup(upgraded, sha(upgradedRaw)); assert.equal(repeat.ok, false);
  completeBytes(upgraded.exportSave(), upgradedRaw, 'Repeated upgrade cannot change the city');
  writeFileSync(join(artifacts, 'UPGRADED-EDF.save.json'), upgradedRaw);
  json('UPGRADE-RESULT.json', { status: 'PASS_EXACT_ORIGINAL_EDF_TWO_MARKER_CUTOVER', originalSHA256: sha(edfRaw), upgradedSHA256: sha(upgradedRaw), exactlyTwoDeclarationsChanged: true, wrongSHARejectedWithoutChange: true, repeatRejectedWithoutChange: true, bodyNeedsCashStockClockTickRngRoutesAndAllOtherFieldsByteExact: true, SimulationStepCallsForUpgrade: 0 });
  progress({ upgradedSHA256: sha(upgradedRaw) });

  stage = 'physical-save-readback';
  const parts = partitionSave(upgradedRaw, world); mkdirSync(join(artifacts, 'parts'), { recursive: true });
  const entries = parts.map((part, index) => {
    const name = `${String(index).padStart(4, '0')}.json`;
    writeFileSync(join(artifacts, 'parts', name), part.json);
    return { id: part.id, file: name, bytes: Buffer.byteLength(part.json), sha256: sha(part.json) };
  });
  json('PARTS-MANIFEST.json', entries);
  const readParts = entries.map(entry => {
    const raw = readFileSync(join(artifacts, 'parts', entry.file), 'utf8'); assert.equal(sha(raw), entry.sha256);
    return { id: entry.id, json: raw };
  });
  const assembled = assembleSave(readParts); completeBytes(assembled, upgradedRaw, 'Actual disk parts assemble to complete upgraded EDF bytes');
  writeFileSync(join(artifacts, 'PARTS-ASSEMBLED.save.json'), assembled);
  const whole = new Final(JSON.parse(worldRaw)), physical = new Final(JSON.parse(worldRaw)); counters.simulationConstructors += 2;
  for (const [sim, saved, label] of [[whole, readFileSync(join(artifacts, 'UPGRADED-EDF.save.json'), 'utf8'), 'physical whole file'], [physical, assembled, 'physical parts']]) {
    const imported = sim.importSave(saved); assert.ok(imported.ok, `${label}: ${imported.message}`);
    completeBytes(sim.exportSave(), upgradedRaw, `${label}: initial complete bytes`);
  }
  progress({ partitionParts: entries.length, physicalPartBytesChecked: true });

  stage = 'upgraded-future24';
  const events = [], futures = [];
  for (const type of ['cargo-loaded', 'cargo-arrived']) upgraded.onEvent(type, event => {
    events.push({ tick: upgraded.state.tick, clock: upgraded.state.extension.lastUpdate, event: { ...event } });
    json('OBSERVED-CARGO-EVENTS.json', events);
  });
  for (let frame = 0; frame < 24; frame++) {
    advance(upgraded, 'upgradedSourceStepCalls'); advance(whole, 'wholeReaderStepCalls'); advance(physical, 'physicalPartsReaderStepCalls');
    const saved = upgraded.exportSave();
    completeBytes(whole.exportSave(), saved, `Whole-reader complete bytes at future frame ${frame + 1}`);
    completeBytes(physical.exportSave(), saved, `Physical-parts-reader complete bytes at future frame ${frame + 1}`);
    assert.equal(upgraded.state.tick, 1105 + frame);
    futures.push({ frame: frame + 1, tick: upgraded.state.tick, clock: upgraded.state.extension.lastUpdate, saveSHA256: sha(saved), wholeAndPhysicalPartsFullBytesEqual: true });
    json('FUTURE24.json', futures); progress({ futureFrame: frame + 1, saveSHA256: sha(saved) });
    console.log(JSON.stringify({ stage, frame: frame + 1, tick: upgraded.state.tick, saveSHA256: sha(saved) }));
  }
  const future = upgraded.exportSave(); writeFileSync(join(artifacts, 'FUTURE24.save.json'), future);
  assert.equal(counters.totalOrdinaryStepCalls, 104);
  assert.equal(readFileSync(join(root, 'originals', 'WORLD-ORIGINAL.json'), 'utf8'), worldRaw);
  assert.equal(readFileSync(join(root, 'originals', 'EDF-ORIGINAL.save.json'), 'utf8'), edfRaw);
  stage = 'complete';
  const summary = { status: 'PASS_DEFAULT_ORIGINAL_EDF_LEGACY16_EXPLICIT_TWO_MARKER_UPGRADE_AND_PHYSICAL_FUTURE24', source: config.source, sourceInputCount: config.inputCount, sourceInputManifestSHA256: config.inputManifestSHA256, baselineInputCount: 325, worldSHA256: sha(worldRaw), worldCounts: { buildings: 612, nodes: 674, edges: 691, citizens: 616 }, originalEDFSHA256: sha(edfRaw), savedSpeed: 8, stepSeconds: .25, legacy, originalEDFUpgradeSHA256: sha(upgradedRaw), future24SHA256: sha(future), partitionParts: entries.length, physicalWholeAndAllPartsReadback: true, futureFrames: futures.length, counters, oldMarkerlessContractUnchanged: true, upgradeExactlyTwoMarkerBytesOnly: true, observedCargoEvents: events.length, scope: 'Exact saved default-city contract and explicit upgraded whole/physical reader replay only. No fresh city reset, actor/stock/cash/needs/clock/focus/speed/RNG edits. This scope makes no default named-pickup-cycle, supplier-revenue, steady-state, GPU, native-player journey or macOS claim.' };
  json('OBSERVED-CARGO-EVENTS.json', events); json('RESULT.json', summary); progress({ status: summary.status });
  console.log(JSON.stringify(summary));
}
try { await main(); }
catch (error) { json('FAILURE.json', { status: 'FAIL_SCOPE_PRESERVED_WITHOUT_EXTENDING_BOUND', stage, counters, message: error instanceof Error ? error.message : String(error) }); throw error; }

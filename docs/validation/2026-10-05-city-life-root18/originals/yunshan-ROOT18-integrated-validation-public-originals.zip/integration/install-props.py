import pathlib,json,hashlib,shutil,datetime
root=pathlib.Path('/workspace/yunshan');p=pathlib.Path(__file__).parent
origin=pathlib.Path('/tmp/ROOT18-props-integration-20261005-01');sha=lambda b:hashlib.sha256(b).hexdigest()
before=json.loads(pathlib.Path('/tmp/ROOT18-dynamic-execution-20261005-01/SOURCE-INPUTS-355.json').read_text())
assert len(before)==355 and all(sha((root/n).read_bytes())==v for n,v in before.items())
proof=json.loads(pathlib.Path('/tmp/ROOT18-props-gpu-20261005-01/COMPARISON.json').read_text());assert proof['status']=='PASS_CONTROLLED_LOCAL_VISUAL_INTEGRATION_AND_MATCHED_SAVE'
changes=json.loads((origin/'FINAL-CHANGE-MANIFEST.json').read_text())['changes']
for n,item in changes.items():
 dest=root/n;src=origin/'source'/n
 assert sha(src.read_bytes())==item['afterSHA256']
 assert sha(dest.read_bytes())==item['beforeSHA256'] if item['beforeSHA256'] else not dest.exists()
for n in changes:
 dest=root/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin/'source'/n,dest)
expected=before.copy()
for n,item in changes.items():expected[n]=item['afterSHA256']
assert len(expected)==357 and all(sha((root/n).read_bytes())==v for n,v in expected.items())
(p/'SOURCE-INPUTS-357.json').write_text(json.dumps(expected,indent=2)+'\n')
(p/'PROPS-INSTALL-RECEIPT.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'INSTALLED_EXACT_PROPS_CANDIDATE03_AFTER_REAL_GPU','changes':changes,'inputCount':len(expected),'graphSHA256StoredOrder':sha(json.dumps(expected,separators=(',',':')).encode()),'original229TestsAndFixturesUnchanged':True,'newHost4ExactUnchanged':True,'realGPUComparison':proof},indent=2)+'\n')
print('Installed exact 5 prop paths; combined357 inputs, original229 tests unchanged.')

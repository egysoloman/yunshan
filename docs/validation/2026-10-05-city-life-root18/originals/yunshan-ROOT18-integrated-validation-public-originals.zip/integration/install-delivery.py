import pathlib,json,hashlib,shutil,datetime
root=pathlib.Path('/workspace/yunshan');p=pathlib.Path(__file__).parent;origin=pathlib.Path('/tmp/ROOT18-economy-delivery-policy-20261005-01');sha=lambda b:hashlib.sha256(b).hexdigest()
before=json.loads((p/'SOURCE-INPUTS-357.json').read_text());base=json.loads((origin/'BASELINE-INPUTS-351.json').read_text());change=json.loads((origin/'CANDIDATE-PREPARATION.json').read_text())
assert all(sha((root/n).read_bytes())==v for n,v in before.items())
receipt=json.loads((origin/'actual02/receipt.json').read_text());result=json.loads((origin/'actual02/artifacts/RESULT.json').read_text())
assert receipt['status']=='PASS' and receipt['inputsStable'] and not receipt['activeDescendants']
assert result['counters']['deliveryCalls']==256 and result['namedFreightSupplierReceipts']==4 and result['flows']['cargoArrived']==56
for n,v in {**change['modified'],**change['added']}.items():
 assert sha((origin/'source'/n).read_bytes())==v
 assert sha((root/n).read_bytes())==base[n] if n in change['modified'] else not (root/n).exists()
for n in {**change['modified'],**change['added']}:
 dest=root/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin/'source'/n,dest)
expected={**before,**change['modified'],**change['added']};assert len(expected)==361 and all(sha((root/n).read_bytes())==v for n,v in expected.items())
assert all(sha((root/n).read_bytes())==v for n,v in base.items() if n.startswith('tests/'))
(p/'SOURCE-INPUTS-361-before-product.json').write_text(json.dumps(expected,indent=2)+'\n')
(p/'DELIVERY-INSTALL-RECEIPT.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXACT_VALIDATED_SOURCE_INSTALLED','changes':{**change['modified'],**change['added']},'beforeInputCount':357,'afterInputCount':361,'all229OriginalTestsExact':True,'native256Receipt':receipt,'actualResult':result,'scope':'Explicit rule option and guarded SHA upgrade API; new product entry wiring follows separately.'},indent=2)+'\n')
print('Installed7 exact delivery paths; combined361 before product entry, all229 originaltests SHA unchanged.')

import pathlib,json,hashlib,shutil,datetime
root=pathlib.Path('/workspace/yunshan');p=pathlib.Path(__file__).parent
origin=pathlib.Path('/tmp/ROOT18-dynamic-execution-20261005-01')
base=json.loads((origin/'input/SOURCE-INPUTS-351.json').read_text()) if (origin/'input/SOURCE-INPUTS-351.json').exists() else json.loads(pathlib.Path('/workspace/yunshan/docs/validation/2026-10-05-city-life-root17/SOURCE-INPUTS-351.json').read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
assert len(base)==351
assert all(sha((root/n).read_bytes())==v for n,v in base.items())
manifest=json.loads((origin/'CHANGE-MANIFEST.json').read_text())
for item in manifest['changes']:
 dest=root/item['path'];src=origin/'source'/item['path']
 assert item['action']=='add' and not dest.exists() and sha(src.read_bytes())==item['sha256']
for item in manifest['changes']:
 dest=root/item['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin/'source'/item['path'],dest)
final=json.loads((origin/'SOURCE-INPUTS-355.json').read_text())
assert len(final)==355 and all(sha((root/n).read_bytes())==v for n,v in final.items())
(p/'HOST-INSTALL-RECEIPT.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'INSTALLED_EXACT_NEW03','source355GraphSHA256':manifest['source355GraphSHA256'],'all351OriginalInputSHAUnchanged':True,'all4NewInputSHAAsNative03':True,'changes':manifest['changes'],'native03':manifest['verification']['native'],'scope':manifest['scope']},indent=2)+'\n')
print('Installed 4 exact NEW03 inputs; original351 byte unchanged.')

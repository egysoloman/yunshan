import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { appendFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

// This driver is frozen before the parent starts its exclusive guarded run.
// It only imports complete saves, exports them, and calls ordinary step(.25).
const ROOT = dirname(fileURLToPath(import.meta.url));
const DRIVER = fileURLToPath(import.meta.url);
const PLAN = join(ROOT, 'PLAN.json');
const FREEZE = join(ROOT, 'FROZEN.json');
const OUT = join(ROOT, 'actual01', 'artifacts');
assert.ok(!existsSync(OUT), 'Refuse to overwrite an earlier actual run.');
mkdirSync(OUT, { recursive: true });
const sha = value => createHash('sha256').update(value).digest('hex');
const stamp = () => new Date().toISOString();
const json = (name, value) => writeFileSync(join(OUT, name), JSON.stringify(value, null, 2) + '\n');
const stream = (name, value) => appendFileSync(join(OUT, name), JSON.stringify(value) + '\n');
const writeNew = (name, value) => writeFileSync(join(OUT, name), value, { flag: 'wx' });
const counters = {
  constructorBegun: 0, constructorCompleted: 0, importBegun: 0, importCompleted: 0,
  ordinaryCallsBegun: 0, ordinaryCallsCompleted: 0,
  instances: {
    control355full: { callsBegun: 0, callsCompleted: 0 },
    candidate362full: { callsBegun: 0, callsCompleted: 0 },
    candidate362physical: { callsBegun: 0, callsCompleted: 0 },
  },
};
const instances = [];
const ORDER = ['time', 'environment', 'energy', 'traffic', 'people', 'commerce', 'finance', 'security', 'politics', 'feedback'];
const sourceEvidence = {};
let plan, frozen, worldRaw, originalRaw, inputDocument, partitionEvidence;
let stage = 'preflight', failure = null, terminal = null, completedFrames = 0;
const progress = extra => json('CURRENT.json', { at: stamp(), stage, counters, completedFrames, ...extra });
const errorRecord = error => ({ name: error?.name ?? 'Error', message: error?.message ?? String(error), stack: error?.stack ?? null });
const finite = (value, label) => { assert.ok(Number.isFinite(value), `${label}: finite number required`); return value; };
const sum = (values, label) => values.reduce((total, value, index) => total + finite(value, `${label}[${index}]`), 0);
const minimum = (values, label) => values.length ? Math.min(...values.map((value, index) => finite(value, `${label}[${index}]`))) : null;
const sortedKeys = value => Object.fromEntries(Object.keys(value).sort().map(key => [key, value[key]]));

function sourceSnapshot(spec) {
  const manifestBytes = readFileSync(spec.manifest);
  const expected = JSON.parse(manifestBytes.toString('utf8'));
  const files = [];
  function walk(directory) {
    if (!existsSync(directory)) return;
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const path = join(directory, entry.name);
      if (entry.isDirectory()) walk(path);
      else if (entry.isFile()) files.push(relative(spec.root, path));
    }
  }
  for (const directory of ['src', 'tests', 'scripts', 'adapters', 'public']) walk(join(spec.root, directory));
  for (const filename of ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'index.html']) {
    if (existsSync(join(spec.root, filename))) files.push(filename);
  }
  const actualFileSet = new Set(files);
  const actual = {};
  const missing = [];
  for (const key of Object.keys(expected)) {
    if (!actualFileSet.has(key)) missing.push(key);
    else actual[key] = sha(readFileSync(join(spec.root, key)));
  }
  const unexpected = files.filter(key => !Object.hasOwn(expected, key)).sort();
  const mismatched = Object.keys(actual).filter(key => actual[key] !== expected[key]);
  return {
    root: spec.root, manifest: spec.manifest,
    manifestSHA256: sha(manifestBytes), inputCount: files.length,
    expectedManifestInputCount: Object.keys(expected).length,
    graphSHA256StoredManifestOrder: sha(JSON.stringify(actual)),
    graphSHA256SortedKeys: sha(JSON.stringify(sortedKeys(actual))),
    missing, unexpected, mismatched, inputs: actual,
  };
}

function assertSource(snapshot, spec) {
  assert.equal(snapshot.manifestSHA256, spec.manifestSHA256, `${spec.label} immutable manifest`);
  assert.equal(snapshot.inputCount, spec.inputCount, `${spec.label} functional input count`);
  assert.equal(snapshot.expectedManifestInputCount, spec.inputCount);
  assert.deepEqual(snapshot.missing, []);
  assert.deepEqual(snapshot.unexpected, []);
  assert.deepEqual(snapshot.mismatched, []);
  assert.equal(snapshot.graphSHA256StoredManifestOrder, spec.graphSHA256StoredManifestOrder);
  assert.equal(snapshot.graphSHA256SortedKeys, spec.graphSHA256SortedKeys);
}

function summarize(document, world) {
  const before = JSON.stringify(document);
  const state = document.state, runtime = document.runtime;
  const buildingKinds = new Map(world.buildings.map(building => [building.id, building.kind]));
  const shopInventoryByWorldKind = {};
  for (const shop of state.shops) {
    const kind = buildingKinds.get(shop.buildingId);
    assert.equal(typeof kind, 'string', `Trusted World building for ${shop.id}`);
    shopInventoryByWorldKind[kind] = (shopInventoryByWorldKind[kind] ?? 0) + finite(shop.inventory, `inventory:${shop.id}`);
  }
  const companies = state.extension.companies;
  const npcMoney = state.citizens.map(citizen => citizen.money);
  const profile = state.extension.actorProfiles;
  const operatingFunds = state.shops.map(shop => {
    const company = companies.find(item => item.buildingId === shop.buildingId && item.shopBindingReleasedAt === undefined);
    return company ? company.capital : shop.cash ?? 0;
  });
  const result = {
    tick: state.tick, day: state.day, hour: state.hour,
    clock: finite(state.extension.lastUpdate, 'saved clock'),
    speed: state.speed, paused: state.paused,
    mode: runtime.mode, detail: runtime.detail, focus: runtime.focus,
    counts: {
      worldBuildings: world.buildings.length, worldDistricts: world.districts.length,
      citizens: state.citizens.length, aliveCitizens: state.citizens.filter(citizen => profile[citizen.id].alive !== false).length,
      actorProfilesIncludingPlayer: Object.keys(profile).length, districts: state.districts.length,
      shops: state.shops.length, vehicles: state.vehicles.length, companies: companies.length,
      civicHistoryPages: state.civicHistory.pages.length,
    },
    inventory: {
      shopInventoryByWorldKind,
      foodShopInventory: sum(['market', 'farm', 'dock'].map(kind => shopInventoryByWorldKind[kind] ?? 0), 'food shops'),
      materialWorkshopInventory: shopInventoryByWorldKind.workshop ?? 0,
      citizenStoredFood: sum(state.citizens.map(citizen => citizen.food ?? 0), 'citizen food'),
      playerFood: finite(state.player.inventory.food ?? 0, 'player food'),
      vehicleCargoAllGoods: sum(state.vehicles.map(vehicle => vehicle.cargo), 'vehicle cargo'),
      districtFreightAllGoods: sum(Object.values(runtime.freight), 'district freight'),
      // freightLots and trade lots are ownership records, not extra stock.
    },
    money: {
      minimumNPCMoney: minimum(npcMoney, 'NPC money'),
      minimumActorMoneyIncludingPlayer: minimum([...npcMoney, state.player.money], 'actor money'),
      playerMoney: finite(state.player.money, 'player money'),
      minimumShopRecordedCash: minimum(state.shops.map(shop => shop.cash ?? 0), 'shop cash'),
      minimumCompanyCapital: minimum(companies.map(company => company.capital), 'company capital'),
      minimumShopOperatingFunds: minimum(operatingFunds, 'shop operating funds'),
      treasury: finite(state.treasury, 'treasury'), bankBalance: finite(state.bankBalance, 'bank balance'),
      bankCash: finite(state.banking.cash, 'bank cash'),
    },
    policies: Object.fromEntries(Object.keys(plan.expectedPolicies).map(key => [key, { envelope: document[key], runtime: runtime[key] }])),
    readOnlySummaryDocumentUnchanged: true,
  };
  assert.equal(JSON.stringify(document), before, 'Summarizer must leave the detached complete export unchanged.');
  return result;
}

function assertSavedContract(instance, document, futureStep) {
  const state = document.state, runtime = document.runtime;
  assert.equal(document.format, 'yunshan-save');
  assert.equal(document.version, 4);
  assert.equal(document.rulesetId, 'civic-local-v1');
  assert.equal(document.motionVersion, 2);
  assert.equal(runtime.npcMotionVersion, 2);
  assert.equal(document.historyPolicyId, 'civic-history-pages-v1');
  assert.equal(document.worldSeed, 20261001);
  assert.equal(state.seed, 20261001);
  assert.equal(document.worldFingerprint, plan.expectedWorldFingerprint);
  assert.equal(state.version, 1);
  assert.equal(instance.world.buildings.length, 612);
  assert.equal(instance.world.districts.length, 11);
  assert.equal(state.citizens.length, 616);
  assert.equal(new Set(state.citizens.map(citizen => citizen.id)).size, 616);
  assert.equal(state.districts.length, 11);
  assert.deepEqual(state.districts.map(district => district.id).sort(), instance.world.districts.map(district => district.id).sort());
  assert.equal(Object.keys(state.extension.actorProfiles).length, 617);
  assert.ok(Object.hasOwn(state.extension.actorProfiles, 'player'));
  for (const citizen of state.citizens) assert.ok(Object.hasOwn(state.extension.actorProfiles, citizen.id));
  assert.equal(state.speed, inputDocument.state.speed);
  assert.equal(state.speed, 8);
  assert.equal(state.paused, false);
  assert.equal(runtime.mode, inputDocument.runtime.mode);
  assert.equal(runtime.detail, inputDocument.runtime.detail);
  assert.deepEqual(runtime.focus, inputDocument.runtime.focus);
  for (const [key, value] of Object.entries(plan.expectedPolicies)) {
    assert.equal(document[key], value, `${instance.label} envelope ${key}`);
    assert.equal(runtime[key], value, `${instance.label} runtime ${key}`);
    assert.equal(instance.simulation[key], value, `${instance.label} native getter ${key}`);
  }
  for (const key of plan.preservedRuntimeMarkers) assert.equal(runtime[key], inputDocument.runtime[key], `${instance.label} preserved ${key}`);
  assert.equal(state.tick, plan.expectedStartTick + futureStep);
  assert.equal(state.extension.lastUpdate, plan.expectedStartClock + futureStep * 2);
  assert.equal(state.day, 2);
  assert.ok(Math.abs(state.day * 1440 + state.hour * 60 - state.extension.lastUpdate) < 1e-9);
  if (futureStep > 0) assert.deepEqual(state.lastSystemOrder, ORDER);
}

function snapshot(instance, futureStep) {
  const raw = instance.simulation.exportSave();
  instance.lastRaw = raw;
  const document = JSON.parse(raw);
  assertSavedContract(instance, document, futureStep);
  const summary = summarize(document, instance.world);
  return { instance: instance.label, saveSHA256: sha(raw), saveBytes: Buffer.byteLength(raw), ...summary };
}

try {
  const planBytes = readFileSync(PLAN), frozenBytes = readFileSync(FREEZE);
  plan = JSON.parse(planBytes.toString('utf8'));
  frozen = JSON.parse(frozenBytes.toString('utf8'));
  assert.equal(sha(planBytes), frozen.planSHA256, 'Frozen plan exact bytes');
  assert.equal(sha(readFileSync(DRIVER)), frozen.driverSHA256, 'Frozen driver exact bytes');
  assert.equal(plan.driverSHA256, frozen.driverSHA256);
  assert.equal(sha(readFileSync(plan.guard)), plan.guardSHA256);
  assert.equal(plan.maximumSimulationConstructors, 3);
  assert.equal(plan.maximumTotalOrdinaryCalls, 72);
  assert.equal(plan.callsPerInstance, 24);
  assert.equal(plan.ordinaryCallSeconds, .25);
  assert.equal(plan.capSeconds, 360);
  json('FROZEN-AT-RUN-START.json', { at: stamp(), planSHA256: sha(planBytes), driverSHA256: frozen.driverSHA256, freezeSHA256: sha(frozenBytes), guardSHA256: plan.guardSHA256 });
  for (const spec of plan.sources) {
    const before = sourceSnapshot(spec);
    sourceEvidence[spec.label] = { before };
    json(`${spec.label}-inputs-before.json`, before);
    assertSource(before, spec);
  }
  worldRaw = readFileSync(plan.world.path, 'utf8');
  originalRaw = readFileSync(plan.terminalInput.path, 'utf8');
  assert.equal(sha(worldRaw), plan.world.SHA256);
  assert.equal(sha(originalRaw), plan.terminalInput.SHA256);
  const world = JSON.parse(worldRaw);
  assert.equal(world.buildings.length, 612);
  assert.equal(world.districts.length, 11);
  assert.equal(world.nodes.length, 674);
  assert.equal(world.edges.length, 691);
  assert.equal(world.seed, 20261001);
  inputDocument = JSON.parse(originalRaw);
  assert.equal(inputDocument.state.tick, 1384);
  assert.equal(inputDocument.state.extension.lastUpdate, 3248);
  assert.equal(inputDocument.state.hour, 6.133333333333334);
  assert.equal(inputDocument.state.speed, 8);
  assert.equal(inputDocument.runtime.mode, 'walk');
  assert.equal(inputDocument.runtime.detail, 1);
  assert.deepEqual(inputDocument.runtime.focus, { x: -740, y: 18, z: 980 });
  progress({ originalSaveSHA256: sha(originalRaw), originalWorldSHA256: sha(worldRaw) });

  stage = 'import-exact-native-source-modules';
  progress();
  const controlSpec = plan.sources.find(spec => spec.label === 'source355');
  const candidateSpec = plan.sources.find(spec => spec.label === 'source362');
  const [{ Simulation: ControlSimulation }, { Simulation: CandidateSimulation }, { partitionSave, assembleSave }] = await Promise.all([
    import(pathToFileURL(join(controlSpec.root, 'src/simulation.ts')).href),
    import(pathToFileURL(join(candidateSpec.root, 'src/simulation.ts')).href),
    import(pathToFileURL(join(candidateSpec.root, 'src/persistence/partition.ts')).href),
  ]);

  stage = 'native-physical-partition-write-read-assemble';
  progress();
  const parts = partitionSave(originalRaw, world);
  assert.equal(new Set(parts.map(part => part.id)).size, parts.length);
  assert.ok(parts.some(part => /^chunk:-?\d+:-?\d+$/.test(part.id)), 'Full World produces spatial chunk parts.');
  const partsDirectory = join(OUT, 'physical-parts');
  mkdirSync(partsDirectory);
  const manifest = parts.map((part, index) => {
    const filename = `${String(index).padStart(6, '0')}.json`;
    const bytes = Buffer.from(part.json, 'utf8');
    writeFileSync(join(partsDirectory, filename), bytes, { flag: 'wx' });
    const kind = part.id === 'global' || part.id === 'player' ? part.id
      : /^chunk:-?\d+:-?\d+$/.test(part.id) ? 'spatial'
      : part.id.startsWith('chunk:civic-history:') ? 'civic-history' : 'other-chunk';
    return { index, id: part.id, filename, bytes: bytes.length, SHA256: sha(bytes), kind };
  });
  json('PHYSICAL-PARTS-MANIFEST.json', manifest);
  // Each original native part is read from its actual numbered file.
  const diskParts = manifest.map(entry => {
    const bytes = readFileSync(join(partsDirectory, entry.filename));
    assert.equal(bytes.length, entry.bytes);
    assert.equal(sha(bytes), entry.SHA256, `Stored part ${entry.index}`);
    assert.equal(bytes.toString('utf8'), parts[entry.index].json);
    return { id: entry.id, json: bytes.toString('utf8') };
  });
  const assembledRaw = assembleSave(diskParts);
  assert.equal(assembledRaw, originalRaw, 'Disk-assembled complete save equals the genuine original terminal bytes.');
  assert.ok(Buffer.from(assembledRaw).equals(readFileSync(plan.terminalInput.path)));
  partitionEvidence = {
    operation: 'actual partitionSave(originalTerminal, entireOriginalWorld)',
    totalParts: parts.length,
    countsByKind: Object.fromEntries(['global', 'player', 'spatial', 'civic-history', 'other-chunk'].map(kind => [kind, manifest.filter(entry => entry.kind === kind).length])),
    everyNativePartIndividuallyWrittenAndRead: true,
    manifestSHA256: sha(readFileSync(join(OUT, 'PHYSICAL-PARTS-MANIFEST.json'))),
    assembledSaveSHA256: sha(assembledRaw), assembledBytes: Buffer.byteLength(assembledRaw),
    exactOriginalBytes: true, worldArgument: 'entire original WorldDefinition; no projection or geometry edits',
  };
  json('PHYSICAL-PARTITION-RESULT.json', partitionEvidence);

  stage = 'construct-and-native-import-three-complete-generations';
  for (const [label, Constructor, raw] of [
    ['control355full', ControlSimulation, originalRaw],
    ['candidate362full', CandidateSimulation, originalRaw],
    ['candidate362physical', CandidateSimulation, assembledRaw],
  ]) {
    assert.ok(counters.constructorBegun < 3);
    const instanceWorld = JSON.parse(worldRaw);
    const instance = { label, world: instanceWorld, simulation: null, lastRaw: null };
    instances.push(instance);
    counters.constructorBegun++;
    stream('OPERATIONS.jsonl', { event: 'CONSTRUCTOR_BEGUN', at: stamp(), instance: label, counters });
    progress({ instance: label });
    instance.simulation = new Constructor(instanceWorld);
    counters.constructorCompleted++;
    counters.importBegun++;
    stream('OPERATIONS.jsonl', { event: 'IMPORT_BEGUN', at: stamp(), instance: label, importedSHA256: sha(raw), counters });
    const imported = instance.simulation.importSave(raw);
    assert.equal(imported.ok, true, `${label}: ${imported.message}`);
    counters.importCompleted++;
    const initial = snapshot(instance, 0);
    assert.equal(instance.lastRaw, originalRaw, `${label} native imported complete original bytes`);
    assert.equal(initial.counts.shops, 210);
    assert.equal(initial.counts.vehicles, 344);
    assert.equal(initial.counts.companies, 12);
    stream('INITIAL.jsonl', { at: stamp(), nativeImport: imported, ...initial });
    stream('OPERATIONS.jsonl', { event: 'IMPORT_COMPLETED', at: stamp(), instance: label, originalBytesExact: true, counters });
    progress({ instance: label, ...initial });
  }
  assert.equal(counters.constructorCompleted, 3);
  assert.equal(counters.importCompleted, 3);

  stage = 'ordinary-native-future24-three-instances';
  for (let futureStep = 1; futureStep <= 24; futureStep++) {
    const rows = [];
    for (const instance of instances) {
      assert.ok(counters.ordinaryCallsBegun < 72, 'Strict total ordinary-call cap');
      assert.ok(counters.instances[instance.label].callsBegun < 24, 'Strict per-instance call cap');
      counters.ordinaryCallsBegun++;
      counters.instances[instance.label].callsBegun++;
      stream('CALLS.jsonl', {
        event: 'CALL_BEGUN', at: stamp(), instance: instance.label, futureStep, argumentSeconds: .25,
        beforeSaveSHA256: sha(instance.lastRaw), counters,
      });
      progress({ instance: instance.label, futureStep, operation: 'before ordinary step(.25)' });
      instance.simulation.step(.25);
      counters.ordinaryCallsCompleted++;
      counters.instances[instance.label].callsCompleted++;
      stream('CALLS.jsonl', { event: 'CALL_RETURNED', at: stamp(), instance: instance.label, futureStep, counters });
      const row = snapshot(instance, futureStep);
      rows.push(row);
      stream('CALLS.jsonl', { event: 'COMPLETE_SAVE_CAPTURED', at: stamp(), futureStep, ...row, counters });
      progress({ futureStep, ...row });
    }
    const controlEqualsFull = instances[0].lastRaw === instances[1].lastRaw;
    const controlEqualsPhysical = instances[0].lastRaw === instances[2].lastRaw;
    stream('FRAMES.jsonl', {
      at: stamp(), futureStep, expectedTick: 1384 + futureStep, expectedClock: 3248 + futureStep * 2,
      controlEqualsFullCompleteBytes: controlEqualsFull, controlEqualsPhysicalCompleteBytes: controlEqualsPhysical,
      instances: rows, counters,
    });
    assert.equal(controlEqualsFull, true, `Future step ${futureStep}: source355/full source362 complete save bytes`);
    assert.equal(controlEqualsPhysical, true, `Future step ${futureStep}: source355/physical source362 complete save bytes`);
    completedFrames++;
    progress({ futureStep, threeCompleteSaveBytesExact: true });
  }
  assert.equal(counters.ordinaryCallsBegun, 72);
  assert.equal(counters.ordinaryCallsCompleted, 72);
  for (const value of Object.values(counters.instances)) assert.deepEqual(value, { callsBegun: 24, callsCompleted: 24 });
  stage = 'write-one-identical-full-terminal-save';
  writeNew('FINAL.save.json', instances[0].lastRaw);
  const terminalBytes = readFileSync(join(OUT, 'FINAL.save.json'));
  assert.equal(terminalBytes.toString('utf8'), instances[0].lastRaw);
  terminal = {
    filename: 'FINAL.save.json', bytes: terminalBytes.length, SHA256: sha(terminalBytes),
    allThreeNativeCompleteSaveBytesIdentical: true,
    tick: 1408, clock: 3296, threeNativeSaveSHA256: Object.fromEntries(instances.map(instance => [instance.label, sha(instance.lastRaw)])),
  };
} catch (error) {
  failure = { at: stamp(), stage, error: errorRecord(error), counters, completedFrames };
}

// Also seal both graphs and the raw inputs after a failure. Timeout evidence is
// additionally available in CURRENT.json and the append-only begun/return log.
const postflightErrors = [];
if (plan) {
  for (const spec of plan.sources) {
    try {
      const after = sourceSnapshot(spec);
      (sourceEvidence[spec.label] ??= {}).after = after;
      json(`${spec.label}-inputs-after.json`, after);
      assertSource(after, spec);
      if (sourceEvidence[spec.label].before) assert.deepEqual(after, sourceEvidence[spec.label].before);
    } catch (error) { postflightErrors.push({ source: spec.label, error: errorRecord(error) }); }
  }
  for (const [label, path, expectedSHA256] of [
    ['world', plan.world.path, plan.world.SHA256],
    ['terminalInput', plan.terminalInput.path, plan.terminalInput.SHA256],
    ['guard', plan.guard, plan.guardSHA256],
    ['driver', DRIVER, frozen?.driverSHA256],
    ['plan', PLAN, frozen?.planSHA256],
  ]) {
    try { assert.equal(sha(readFileSync(path)), expectedSHA256, `${label} immutable before/after`); }
    catch (error) { postflightErrors.push({ input: label, error: errorRecord(error) }); }
  }
}
if (postflightErrors.length && !failure) failure = { at: stamp(), stage: 'postflight-immutability', counters, completedFrames };
if (failure) {
  const partialSaves = [];
  for (const instance of instances) {
    if (!instance.simulation) continue;
    try {
      const raw = instance.simulation.exportSave();
      const filename = `${instance.label}.PARTIAL.save.json`;
      writeNew(filename, raw);
      const document = JSON.parse(raw);
      partialSaves.push({ instance: instance.label, filename, bytes: Buffer.byteLength(raw), SHA256: sha(raw), tick: document.state.tick, clock: document.state.extension?.lastUpdate, ordinaryCalls: counters.instances[instance.label] });
    } catch (error) { partialSaves.push({ instance: instance.label, error: errorRecord(error) }); }
  }
  json('FAILURE.json', { status: 'FAIL_PARTIAL', ...failure, postflightErrors, partitionEvidence, partialSaves, terminal });
  stage = 'FAIL_PARTIAL';
  progress({ failure, postflightErrors, partialSaves });
  console.error(JSON.stringify({ status: 'FAIL_PARTIAL', stage: failure.stage, counters, completedFrames, postflightErrors, error: failure.error ?? null }));
  process.exitCode = 1;
} else {
  stage = 'PASS';
  const result = {
    status: 'PASS_GENUINE_TERMINAL_PHYSICAL_PARTITION_AND_THREE_NATIVE_FUTURE24_COMPLETE_BYTES',
    at: stamp(), counters, completedFrames, partitionEvidence, terminal,
    planSHA256: frozen.planSHA256, driverSHA256: frozen.driverSHA256,
    originalWorldSHA256: plan.world.SHA256, originalTerminalSHA256: plan.terminalInput.SHA256,
    sourceGraphsBeforeAfterStable: true, originalSourceWorldAndTerminalBytesBeforeAfterStable: true,
    controlsRetained: { speed: 8, mode: inputDocument.runtime.mode, detail: inputDocument.runtime.detail, focus: inputDocument.runtime.focus },
    sourceGraphs: Object.fromEntries(plan.sources.map(spec => [spec.label, { inputCount: spec.inputCount, graphSHA256StoredManifestOrder: spec.graphSHA256StoredManifestOrder, graphSHA256SortedKeys: spec.graphSHA256SortedKeys }])),
    scope: '24 ordinary .25-second native calls per real instance at saved speed8; exact complete-byte compatibility and disk-backed physical-part restoration for this genuine terminal. No long-term economy, GPU, performance, or changed-world claim.',
  };
  json('RESULT.json', result);
  progress({ terminal, partitionEvidence, sourceGraphsBeforeAfterStable: true });
  console.log(JSON.stringify(result));
}

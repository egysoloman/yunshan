import json,pathlib,hashlib,datetime
p=pathlib.Path(__file__).parent;sha=lambda b:hashlib.sha256(b).hexdigest();rows=[]
for name in ['birth-matched-paused','river-b2-floor0','river-b37-floor0','market-b6-floor2']:
 a=p/'baseline02/artifacts';b=p/'candidate02/artifacts'
 sa=(a/(name+'.before.save.json')).read_bytes();sb=(b/(name+'.before.save.json')).read_bytes()
 assert sa==sb==(a/(name+'.after.save.json')).read_bytes()==(b/(name+'.after.save.json')).read_bytes()
 ra=json.loads((a/(name+'.json')).read_text());rb=json.loads((b/(name+'.json')).read_text())
 for field in ['body','player','insideId','floor','mode','camera','tick','day','hour','paused']:
  assert ra['before'][field]==rb['before'][field]
 for r in [ra,rb]:
  assert not r['before']['glErrors'] and all(q['linked'] and q['runnable'] is not False for q in r['before']['programs'])
 rows.append({'name':name,'wholeSaveSHA256':sha(sa),'wholeSaveBytes':len(sa),'baselinePNG':ra['pngSHA256'],'candidatePNG':rb['pngSHA256'],'baselineCalls':ra['before']['drawCalls'],'candidateCalls':rb['before']['drawCalls'],'baselineTriangles':ra['before']['triangles'],'candidateTriangles':rb['before']['triangles'],'sameBodyCameraWholeSave':True})
for v in ['baseline02','candidate02']:
 r=json.loads((p/v/'receipt.json').read_text());assert r['status']=='PASS' and r['inputsStable'] and not r['activeDescendants']
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_CONTROLLED_LOCAL_VISUAL_INTEGRATION_AND_MATCHED_SAVE','scope':'4 actual production screenshots per version; same genuine old native birth save and native pause, identical disclosed body/camera fixtures, actual E and service-point DOM rental each home. Not native walking route, natural NPC/family behavior or hardware FPS.','rows':rows,'artReview':{'localOfficeDesk':'PASS visible actual drawers/legs/wood top on existing legal office fixture','localCurtainX':'PASS visible pleated cloth in actual existing home window','localCurtainZ':'PASS visible pleated cloth around existing muntins in actual home window','completeReferenceArt':'FAIL pending city composition/street detail/lighting/complete asset-use loops','macOSHardware':'NOT_RUN'},'priorFailure':'baseline01 rental assertion failed on exterior non-service-point visual fixture; full original preserved; assertions and product rules retained by driver02.'}
(p/'COMPARISON.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

from pathlib import Path
p=Path(__file__).parent
s=Path('/tmp/ROOT17-integrated-gpu-20261005-02/capture.mjs').read_text()
s=s.replace("path.join(home, 'PLAN.json')","path.join(home, process.argv[2] + '-PLAN.json')")
s=s.replace('source = plan.source, output = process.argv[2]','source = plan.source, output = process.argv[3]')
s=s.replace('graph: plan.graph','graph: plan.graphSHA256StoredOrder')
start=s.index('  const birth = await page.evaluate(snapshot);')
end=s.index("  receipt.status = errors.length ?",start)
s=s[:start]+'''  const birth = await page.evaluate(snapshot);
  receipt.worldSHA256 = hash(await page.evaluate(() => JSON.stringify(window.__YUNSHAN__.world))); assert.equal(receipt.worldSHA256, plan.worldSHA256);
  await put('native-boot-before-controlled-restore.save.json', birth.save);
  const originalSave = await readFile(path.join(home, 'NATIVE-BIRTH-ORIGINAL.save.json'), 'utf8');
  assert.equal(hash(originalSave), plan.birthSaveSHA256);
  const restore = await page.evaluate(raw => {
    const d=window.__YUNSHAN__, result=d.simulation.importSave(raw);
    if(!result.ok) throw Error(result.message);
    const imported=d.simulation.exportSave();
    d.controller.setMode('walk',d.simulation.state.player.position);
    d.actions.command({type:'pause',value:1});
    return {result, imported, paused:d.simulation.state.paused};
  },originalSave);
  assert.equal(restore.imported, originalSave); assert(restore.paused);
  await put('controlled-original-save-restore.json',{importSHA256:hash(restore.imported),result:restore.result,scope:'Restore the same genuine old native birth save in both versions; normal pause only. No clock field, funds, identity or NPC edits.'});
  await capture('birth-matched-paused',plan.scope,await settle());
  const targetsRaw=await readFile(path.join(home,'GPU-TARGETS.json'));
  assert.equal(hash(targetsRaw),plan.targetsSHA256);
  const targets=JSON.parse(targetsRaw).targets.filter(t=>t.canStand===true);
  assert.equal(targets.length,3);
  for(const target of targets) {
    const id=target.binding.buildingId;
    if(target.kind==='curtain-inside') {
      const fixture=await page.evaluate(id=>{
        const d=window.__YUNSHAN__, b=d.world.buildings.find(b=>b.id===id);
        if(!b||b.kind!=='home') throw Error('Actual home absent');
        const prior=d.controller.position;
        const position={x:b.door.x+Math.sin(b.rotation)*2,y:b.door.y,z:b.door.z+Math.cos(b.rotation)*2};
        d.simulation.state.player.position=position;d.controller.setMode('walk',position);
        return {id,prior,position,door:b.door,money:d.simulation.state.player.money,publicFunds:d.simulation.state.treasury,scope:'Disclosed door approach visual body fixture; no continuous walking claim.'};
      },id);
      await settle();
      const button=page.locator(`button[data-command="rent"][data-target="${id}"]`).first();
      await button.waitFor({state:'visible',timeout:30000});
      assert(await button.isEnabled(),'Native rental UI must be enabled');
      await button.click();
      const rented=await page.evaluate(()=>{const s=window.__YUNSHAN__.simulation.state;return {homeId:s.player.homeId,money:s.player.money,publicFunds:s.treasury};});
      assert.equal(rented.homeId,id);assert.equal(rented.money,fixture.money-80);
      await page.keyboard.press('KeyE');
      await page.waitForFunction(id=>window.__YUNSHAN__.controller.inside?.id===id,id,{timeout:30000});
      await put(id+'-native-rent-and-E.json',{fixture,rented,insideAfterE:await page.evaluate(()=>window.__YUNSHAN__.controller.inside?.id),scope:'Real enabled DOM rental click, 80 actual existing coins, actual trusted E. Separate window position is another disclosed visual fixture.'});
    }
    const placed=await page.evaluate(t=>{
      const d=window.__YUNSHAN__, b=d.world.buildings.find(b=>b.id===t.binding.buildingId);
      if(!d.canAccessBuilding(b,t.binding.floor))throw Error('Actual actor lacks floor access');
      const before=d.controller.position;
      d.simulation.state.player.position={...t.bodyPosition};
      d.controller.setMode('walk',t.bodyPosition);
      return {before,after:d.controller.position,inside:d.controller.inside?.id,floor:d.controller.floor,yaw:d.controller.yaw,pitch:d.controller.pitch,scope:t.disclosure};
    },target);
    assert.equal(placed.inside,id);assert.equal(placed.floor,target.binding.floor);
    assert.deepEqual(placed.after,target.bodyPosition);
    const dx=target.lookAt.x-target.eye.x,dy=target.lookAt.y-target.eye.y,dz=target.lookAt.z-target.eye.z;
    const yaw=Math.atan2(-dx,-dz),pitch=Math.asin(dy/Math.hypot(dx,dy,dz));
    let yawDelta=placed.yaw-yaw;while(yawDelta>Math.PI)yawDelta-=2*Math.PI;while(yawDelta<-Math.PI)yawDelta+=2*Math.PI;
    const startX=720-yawDelta/.003/2,startY=370-(placed.pitch-pitch)/.0025/2;
    const endX=startX+yawDelta/.003,endY=startY+(placed.pitch-pitch)/.0025;
    await page.mouse.move(startX,startY);await page.mouse.down();await page.mouse.move(endX,endY,{steps:3});await page.mouse.up();
    const checkpoint=await settle();
    const actual=await page.evaluate(snapshot);
    assert(Math.abs(actual.camera.position[0]-target.eye.x)<1e-8);
    assert(Math.abs(actual.camera.position[1]-target.eye.y)<1e-8);
    assert(Math.abs(actual.camera.position[2]-target.eye.z)<1e-8);
    assert.deepEqual(actual.body,target.bodyPosition);
    await put(id+'-visual-fixture.json',{target,placed,mouse:{startX,startY,endX,endY,desiredYaw:yaw,desiredPitch:pitch},scope:'Supported actual saved building; real production controller and actual mouse events. No renderer, motor or main-loop substitution.'});
    await capture(id+'-floor'+target.binding.floor,plan.scope,checkpoint);
  }
''' + s[end:]
(p/'capture.mjs').write_text(s)
print('driver written')

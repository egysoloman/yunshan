# ROOT18 室内资源实际游戏验证

原351与候选353在Linux Chromium SwiftShader中使用同一真正出生存档原件，正常import后执行原生暂停。门外、服务点、窗旁及办公层位置均明确为受支持视觉夹具；没有声称从出生点连续步行到达，也未改NPC需要、身份、资金或时间字段。

baseline02：2026-10-05 05:13:06.909178—05:19:49.023205 UTC，402.114秒/cap600，4原生截图，输入351稳定、ownedActive=[]。candidate02：05:19:59.531763—05:27:15.069635 UTC，435.538秒/cap600，4原生截图，输入353稳定、ownedActive=[]。所有截图完整存档前后逐字一致，四处跨版本body、camera及完整业务存档也逐字一致；27着色程序均链接，GL错误0。源/构建/driver/plan/存档和PNG原SHA见各PLAN、receipt及COMPARISON.json。

实际x、z两个方向的住宅窗帘可见布褶皱，原窗框保留；商业bank market-b6真实二层原桌位出现抽屉、桌腿及木桌面。原床构件CPU字节不变。候选出生处增加2draw/4264 triangles；其余三处增加0—4draw/232—1368 triangles。这是四个控制场景的提交量记录，不是稳态FPS或macOS硬件性能结论。

两处住宅通过实际键盘E入门，在明确单独室内服务点位置夹具后，实际启用DOM租住按钮各支付80现有云币到公共账户，合计160。窗旁观察另有单独body初始化，不能简化为一次或自然旅行。房间外的租住按钮原本按实际function-point规则禁用；baseline01误将门外点当服务点，原159.75秒/cap360 FAIL和原driver/图/原件完整保留。driver02补正确服务点夹具，保留启用、真实支付、真实入门和全存档不变断言，没有修改产品规则。

局部办公桌和两窗帘接入通过。完整参考图美术仍FAIL：出生桥下构图、街景层次、光照和完整资源获取/放置/使用仍需推进。沙发、显示器、茶几模型原件不是已入城的购买与使用实现。macOS硬件未运行。该检查不验证自然NPC生命周期、经济稳态、拆楼或铺路。

复现入口：prepare.py记录基线与候选原SHA，capture.mjs及baseline01保留原失败；correct-driver02.py生成新版本capture02.mjs和事前cap600计划。run-phase.py按PID/start-time归属监控并封顶。baseline02和candidate02依各PLAN启动原Vite preview，使用debug=1入口，观察真实生产rAF，无替换controller/focus/motor/renderer/simulation callback。compare.py核对四完整存档与真实帧和提交数据。

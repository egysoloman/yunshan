import json,math,pathlib,hashlib,collections
p=pathlib.Path('/workspace/yunshan-work/ROOT16-food-integration-20261005-01/originals/WORLD-ORIGINAL.json')
raw=p.read_bytes();w=json.loads(raw);assert hashlib.sha256(raw).hexdigest()=='2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512'
adj={n['id']:set() for n in w['nodes']}
for e in w['edges']:
 if e['mode']=='road':adj[e['from']].add(e['to']);adj[e['to']].add(e['from'])
components={};sizes=[]
for node in adj:
 if node in components:continue
 todo=[node];idx=len(sizes);components[node]=idx;size=0
 while todo:
  a=todo.pop();size+=1
  for b in adj[a]:
   if b not in components:components[b]=idx;todo.append(b)
 sizes.append(size)
dist=lambda a,b:sum((a[k]-b[k])**2 for k in ['x','y','z'])
selected=[]
for b in w['buildings']:
 if b['kind'] not in ['farm','dock','market']:continue
 node=min(w['nodes'],key=lambda n:dist(n['position'],b['door']))
 selected.append({'buildingId':b['id'],'kind':b['kind'],'districtId':b['districtId'],'doorNearestNode':node['id'],'component':components[node['id']],'componentNodeCount':sizes[components[node['id']]]})
producers=[b for b in selected if b['kind'] in ['farm','dock']];retail=[b for b in selected if b['kind']=='market']
result={'scope':'Pure definition graph analysis; zero Simulation constructors or steps; topology ignores temporary runtime closures/signals/capacity. Delivery must still obey live road rules.','worldSHA256':hashlib.sha256(raw).hexdigest(),'layoutVersion':w['layoutVersion'],'edgeModes':dict(collections.Counter(e['mode'] for e in w['edges'])),'roadComponentSizes':sorted(sizes,reverse=True),'foodProducerCount':len(producers),'marketCount':len(retail),'allFoodProducerAndMarketDoorNearestNodesConnected':len(set(b['component'] for b in selected))==1,'selectedBuildings':selected}
out=pathlib.Path(__file__).parent/'ROAD-CONNECTIVITY.json';out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='selectedBuildings'},ensure_ascii=False))

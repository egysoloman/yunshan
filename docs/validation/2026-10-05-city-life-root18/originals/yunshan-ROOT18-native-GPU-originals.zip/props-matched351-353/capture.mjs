import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const home = path.dirname(fileURLToPath(import.meta.url));
const plan = JSON.parse(await readFile(path.join(home, process.argv[2] + '-PLAN.json'), 'utf8'));
const hash = value => createHash('sha256').update(value).digest('hex');
const source = plan.source, output = process.argv[3];
assert(output && output.startsWith(home + path.sep));
await mkdir(output, { recursive: false });
const put = (name, value) => writeFile(path.join(output, name), typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const receipt = { startedAt: new Date().toISOString(), source, graph: plan.graphSHA256StoredOrder, planSHA256: hash(await readFile(path.join(home, process.argv[2] + '-PLAN.json'))), driverSHA256: hash(await readFile(fileURLToPath(import.meta.url))), scope: plan.scope, artStatus: 'FAIL: native screenshots do not meet the supplied art references', captures: [] };
const errors = [];
let browser, server, serverIdentity, startup = '', page;
async function identity(pid) {
  try { const raw = await readFile(`/proc/${pid}/stat`, 'utf8'); const f = raw.slice(raw.lastIndexOf(')') + 2).split(' '); return { pid, parent: Number(f[1]), state: f[0], ticks: Number(f[19]) }; } catch (e) { if (e.code === 'ENOENT') return null; throw e; }
}
function snapshot() {
  const d = window.__YUNSHAN__, s = d.simulation.state, r = d.city.renderer, gl = r.getContext();
  const errors = [];
  for (let i = 0; i < 20; i++) { const e = gl.getError(); if (e === gl.NO_ERROR) break; errors.push(e); }
  return { tick: s.tick, day: s.day, hour: s.hour, paused: s.paused, body: d.controller.position, player: s.player.position, insideId: d.controller.inside?.id ?? null, floor: d.controller.floor, mode: d.controller.mode, camera: { position: d.city.camera.position.toArray(), quaternion: d.city.camera.quaternion.toArray(), fov: d.city.camera.fov }, drawCalls: r.info.render.calls, triangles: r.info.render.triangles, glErrors: errors, programs: (r.info.programs ?? []).map(p => ({ name: p.name, linked: gl.getProgramParameter(p.program, gl.LINK_STATUS), log: gl.getProgramInfoLog(p.program), runnable: p.diagnostics?.runnable ?? null })), save: d.simulation.exportSave() };
}
async function settle() {
  // Observe real production rAF. No substituted controller, focus, motor dt,
  // renderer or simulation callback. Stable checkpoints follow actual frames.
  for (let i = 0; i < 6; i++) {
    const before = await page.evaluate(() => window.__YUNSHAN__.simulation.exportSave());
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    const after = await page.evaluate(() => window.__YUNSHAN__.simulation.exportSave());
    if (before === after) return { observedFramePairs: i + 1, saveSHA256: hash(after) };
  }
  throw Error('Actual paused main loop did not settle within six real frame pairs');
}
async function capture(name, scope, checkpoint) {
  const before = await page.evaluate(snapshot);
  await page.screenshot({ path: path.join(output, name + '.png'), timeout: 90000 });
  const after = await page.evaluate(snapshot);
  await put(name + '.before.save.json', before.save); await put(name + '.after.save.json', after.save);
  assert.equal(before.save, after.save, 'Whole paused save must remain byte-identical through capture');
  for (const s of [before, after]) { assert(s.drawCalls > 0 && s.triangles > 0); assert.equal(s.glErrors.length, 0); for (const p of s.programs) { assert(p.linked); assert.notEqual(p.runnable, false); } }
  const image = await readFile(path.join(output, name + '.png'));
  const saveSHA256 = hash(before.save); delete before.save; delete after.save;
  const item = { name, scope, checkpoint, graph: plan.graphSHA256StoredOrder, buildEntry: plan.buildEntry, buildSHA256: plan.buildSHA256, worldSHA256: receipt.worldSHA256, saveSHA256, pngSHA256: hash(image), pngBytes: image.length, before, after };
  await put(name + '.json', item); receipt.captures.push(item); console.log(JSON.stringify({ name, stable: true, imageBytes: image.length }));
}
try {
  const index = await readFile(path.join(source, 'dist/index.html'), 'utf8');
  assert.equal(index.match(/src="([^"]+\.js)"/)?.[1], plan.buildEntry);
  assert.equal(hash(await readFile(path.join(source, 'dist', plan.buildEntry.slice(1)))), plan.buildSHA256);
  server = spawn(process.execPath, [path.join(source, 'node_modules/vite/bin/vite.js'), 'preview', '--host', '127.0.0.1', '--port', String(plan.port), '--strictPort'], { cwd: source, stdio: ['ignore', 'pipe', 'pipe'] });
  serverIdentity = await identity(server.pid); assert.equal(serverIdentity.parent, process.pid); receipt.previewIdentity = serverIdentity;
  server.stdout.on('data', data => { startup += data; }); server.stderr.on('data', data => { startup += data; });
  for (let i = 0; i < 100 && !startup.includes(`http://127.0.0.1:${plan.port}`); i++) { assert.equal(server.exitCode, null); await new Promise(r => setTimeout(r, 100)); }
  assert(startup.includes(`http://127.0.0.1:${plan.port}`));
  const origin = `http://127.0.0.1:${plan.port}`;
  assert.equal(hash(Buffer.from(await (await fetch(origin + plan.buildEntry)).arrayBuffer())), plan.buildSHA256);
  const require = createRequire(path.join(source, 'package.json')); const { chromium } = require('playwright-core');
  browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  page = await browser.newPage({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
  page.on('pageerror', e => errors.push({ scope: 'pageerror', message: e.message }));
  await page.goto(origin + '/?debug=1', { waitUntil: 'networkidle', timeout: 120000 });
  await page.waitForFunction(() => !!window.__YUNSHAN__?.city && window.__YUNSHAN__.simulation.state.tick >= 1, undefined, { timeout: 90000 });
  const birth = await page.evaluate(snapshot);
  receipt.worldSHA256 = hash(await page.evaluate(() => JSON.stringify(window.__YUNSHAN__.world))); assert.equal(receipt.worldSHA256, plan.worldSHA256);
  await put('native-boot-before-controlled-restore.save.json', birth.save);
  const originalSave = await readFile(path.join(home, 'NATIVE-BIRTH-ORIGINAL.save.json'), 'utf8');
  assert.equal(hash(originalSave), plan.birthSaveSHA256);
  const restore = await page.evaluate(raw => {
    const d=window.__YUNSHAN__, result=d.simulation.importSave(raw);
    if(!result.ok) throw Error(result.message);
    const imported=d.simulation.exportSave();
    d.controller.setMode('walk',d.simulation.state.player.position);
    d.actions.command({type:'pause',value:1});
    return {result, imported, paused:d.simulation.state.paused};
  },originalSave);
  assert.equal(restore.imported, originalSave); assert(restore.paused);
  await put('controlled-original-save-restore.json',{importSHA256:hash(restore.imported),result:restore.result,scope:'Restore the same genuine old native birth save in both versions; normal pause only. No clock field, funds, identity or NPC edits.'});
  await capture('birth-matched-paused',plan.scope,await settle());
  const targetsRaw=await readFile(path.join(home,'GPU-TARGETS.json'));
  assert.equal(hash(targetsRaw),plan.targetsSHA256);
  const targets=JSON.parse(targetsRaw).targets.filter(t=>t.canStand===true);
  assert.equal(targets.length,3);
  for(const target of targets) {
    const id=target.binding.buildingId;
    if(target.kind==='curtain-inside') {
      const fixture=await page.evaluate(id=>{
        const d=window.__YUNSHAN__, b=d.world.buildings.find(b=>b.id===id);
        if(!b||b.kind!=='home') throw Error('Actual home absent');
        const prior=d.controller.position;
        const position={x:b.door.x+Math.sin(b.rotation)*2,y:b.door.y,z:b.door.z+Math.cos(b.rotation)*2};
        d.simulation.state.player.position=position;d.controller.setMode('walk',position);
        return {id,prior,position,door:b.door,money:d.simulation.state.player.money,publicFunds:d.simulation.state.treasury,scope:'Disclosed door approach visual body fixture; no continuous walking claim.'};
      },id);
      await settle();
      const button=page.locator(`button[data-command="rent"][data-target="${id}"]`).first();
      await button.waitFor({state:'visible',timeout:30000});
      assert(await button.isEnabled(),'Native rental UI must be enabled');
      await button.click();
      const rented=await page.evaluate(()=>{const s=window.__YUNSHAN__.simulation.state;return {homeId:s.player.homeId,money:s.player.money,publicFunds:s.treasury};});
      assert.equal(rented.homeId,id);assert.equal(rented.money,fixture.money-80);
      await page.keyboard.press('KeyE');
      await page.waitForFunction(id=>window.__YUNSHAN__.controller.inside?.id===id,id,{timeout:30000});
      await put(id+'-native-rent-and-E.json',{fixture,rented,insideAfterE:await page.evaluate(()=>window.__YUNSHAN__.controller.inside?.id),scope:'Real enabled DOM rental click, 80 actual existing coins, actual trusted E. Separate window position is another disclosed visual fixture.'});
    }
    const placed=await page.evaluate(t=>{
      const d=window.__YUNSHAN__, b=d.world.buildings.find(b=>b.id===t.binding.buildingId);
      if(!d.canAccessBuilding(b,t.binding.floor))throw Error('Actual actor lacks floor access');
      const before=d.controller.position;
      d.simulation.state.player.position={...t.bodyPosition};
      d.controller.setMode('walk',t.bodyPosition);
      return {before,after:d.controller.position,inside:d.controller.inside?.id,floor:d.controller.floor,yaw:d.controller.yaw,pitch:d.controller.pitch,scope:t.disclosure};
    },target);
    assert.equal(placed.inside,id);assert.equal(placed.floor,target.binding.floor);
    assert.deepEqual(placed.after,target.bodyPosition);
    const dx=target.lookAt.x-target.eye.x,dy=target.lookAt.y-target.eye.y,dz=target.lookAt.z-target.eye.z;
    const yaw=Math.atan2(-dx,-dz),pitch=Math.asin(dy/Math.hypot(dx,dy,dz));
    let yawDelta=placed.yaw-yaw;while(yawDelta>Math.PI)yawDelta-=2*Math.PI;while(yawDelta<-Math.PI)yawDelta+=2*Math.PI;
    const startX=720-yawDelta/.003/2,startY=370-(placed.pitch-pitch)/.0025/2;
    const endX=startX+yawDelta/.003,endY=startY+(placed.pitch-pitch)/.0025;
    await page.mouse.move(startX,startY);await page.mouse.down();await page.mouse.move(endX,endY,{steps:3});await page.mouse.up();
    const checkpoint=await settle();
    const actual=await page.evaluate(snapshot);
    assert(Math.abs(actual.camera.position[0]-target.eye.x)<1e-8);
    assert(Math.abs(actual.camera.position[1]-target.eye.y)<1e-8);
    assert(Math.abs(actual.camera.position[2]-target.eye.z)<1e-8);
    assert.deepEqual(actual.body,target.bodyPosition);
    await put(id+'-visual-fixture.json',{target,placed,mouse:{startX,startY,endX,endY,desiredYaw:yaw,desiredPitch:pitch},scope:'Supported actual saved building; real production controller and actual mouse events. No renderer, motor or main-loop substitution.'});
    await capture(id+'-floor'+target.binding.floor,plan.scope,checkpoint);
  }
  receipt.status = errors.length ? 'FAIL' : 'PASS_TECHNICAL_AND_READONLY_UI';
} catch (error) { errors.push({ scope: 'fatal', message: error.message, stack: error.stack }); receipt.status = 'FAIL'; console.error(error.stack); }
finally {
  if (browser) await browser.close().catch(e => errors.push({ scope: 'browser-cleanup', message: e.message }));
  if (server && serverIdentity) { const now = await identity(server.pid); if (now?.ticks === serverIdentity.ticks && now.parent === process.pid && now.state !== 'Z') server.kill('SIGTERM'); }
  await put('preview.stdout-stderr.txt', startup); receipt.endedAt = new Date().toISOString(); receipt.errors = errors;
  await put('RESULTS.json', receipt); console.log(JSON.stringify({ status: receipt.status, shots: receipt.captures.length, errors: errors.length })); process.exitCode = errors.length ? 1 : 0;
}

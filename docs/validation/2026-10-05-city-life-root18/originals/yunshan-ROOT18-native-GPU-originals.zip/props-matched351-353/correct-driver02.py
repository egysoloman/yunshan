from pathlib import Path
import json,hashlib
p=Path(__file__).parent
s=(p/'capture.mjs').read_text()
s=s.replace("const button=page.locator(`button[data-command=\"rent\"][data-target=\"${id}\"]`).first();", """await page.keyboard.press('KeyE');
      await page.waitForFunction(id=>window.__YUNSHAN__.controller.inside?.id===id,id,{timeout:30000});
      const serviceFixture=await page.evaluate(id=>{
        const d=window.__YUNSHAN__,b=d.world.buildings.find(b=>b.id===id);
        const point=b.functionPoints.find(p=>p.floor===0&&p.purpose==='service');
        if(!point)throw Error('No actual ground-floor service point');
        const before=d.controller.position;d.simulation.state.player.position={...point.position};d.controller.setMode('walk',point.position);
        if(!d.simulation.isAtBuildingFunctionPoint(b))throw Error('Fixture is not the production function point');
        return {before,point,after:d.controller.position,scope:'Separate declared supported indoor service-point fixture, needed by the existing authoritative rental rule.'};
      },id);
      await settle();
      await put(id+'-rental-service-fixture.json',serviceFixture);
      const button=page.locator(`button[data-command=\"rent\"][data-target=\"${id}\"]`).first();""")
s=s.replace("      await page.keyboard.press('KeyE');\n      await page.waitForFunction(id=>window.__YUNSHAN__.controller.inside?.id===id,id,{timeout:30000});\n      await put(id+'-native-rent-and-E.json'", "      await put(id+'-native-rent-and-E.json'")
s=s.replace("Real enabled DOM rental click, 80 actual existing coins, actual trusted E. Separate window position is another disclosed visual fixture.","Actual trusted E enters the home, a separate indoor service-point body fixture permits real enabled DOM rental click and 80 actual existing coins; window position is another disclosed visual fixture.")
assert s!=(p/'capture.mjs').read_text()
(p/'capture02.mjs').write_text(s)
for variant in ['baseline','candidate']:
 plan=json.loads((p/(variant+'-PLAN.json')).read_text());plan['capSeconds']=600;plan['correction']='Original baseline01 FAIL: exterior doorway is not an authoritative rental function point. Driver02 keeps enabled-button/payment/admission assertions and adds disclosed indoor service-point fixture. Old raw/source/driver/cap retained. 600s frozen before this new run for four real captures and additional native actions.'
 (p/(variant+'02-PLAN.json')).write_text(json.dumps(plan,indent=2)+'\n')
# Driver selects the corrected plan namespace without changing its version tag.
s=(p/'capture02.mjs').read_text().replace("process.argv[2] + '-PLAN.json'","process.argv[2] + '02-PLAN.json'")
(p/'capture02.mjs').write_text(s)
(p/'CORRECTION02.json').write_text(json.dumps({'oldDriverSHA256':hashlib.sha256((p/'capture.mjs').read_bytes()).hexdigest(),'newDriverSHA256':hashlib.sha256((p/'capture02.mjs').read_bytes()).hexdigest(),'productSourcesUnchanged':True,'oldAssertionsRetained':True,'oldFailureRetained':'baseline01/receipt.json'},indent=2)+'\n')
print('Driver02 and cap600 plans frozen; not run.')

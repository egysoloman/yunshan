import json, hashlib, pathlib, shutil, datetime
root=pathlib.Path(__file__).parent
sha=lambda b:hashlib.sha256(b).hexdigest()
old=pathlib.Path('/tmp/ROOT17-integrated-gpu-20261005-02')
shutil.copy2('/tmp/ROOT18-props-integration-20261005-01/run-phase.py',root/'run-phase.py')
shutil.copy2('/tmp/ROOT18-props-integration-20261005-01/GPU-TARGETS.json',root/'GPU-TARGETS.json')
shutil.copy2(old/'actual01/artifacts/native-birth-initial.save.json',root/'NATIVE-BIRTH-ORIGINAL.save.json')
for variant,source,manifest,port in [
 ('baseline','/tmp/ROOT17-integration-20261005-01/source10','/tmp/ROOT17-integration-20261005-01/INPUTS-SOURCE10.json',4403),
 ('candidate','/tmp/ROOT18-props-integration-20261005-01/source','/tmp/ROOT18-props-integration-20261005-01/CANDIDATE03-INPUTS-353.json',4404)]:
 inp=json.loads(pathlib.Path(manifest).read_text())
 assert all(sha((pathlib.Path(source)/p).read_bytes())==v for p,v in inp.items())
 index=(pathlib.Path(source)/'dist/index.html').read_text()
 import re
 entry=re.search(r'src="([^"]+\.js)"',index)[1]
 plan={'variant':variant,'source':source,'inputCount':len(inp),'inputs':inp,
 'graphSHA256StoredOrder':sha(json.dumps(inp,separators=(',',':')).encode()),
 'buildEntry':entry,'buildSHA256':sha((pathlib.Path(source)/'dist'/entry.lstrip('/')).read_bytes()),
 'port':port,'capSeconds':360,'worldSHA256':'2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512',
 'birthSaveSHA256':sha((root/'NATIVE-BIRTH-ORIGINAL.save.json').read_bytes()),
 'targetsSHA256':sha((root/'GPU-TARGETS.json').read_bytes()),
 'scope':'Real Linux Chromium SwiftShader production rAF. Identical existing native birth save restored, then native pause. Supported body placements are declared visual fixtures. Real mouse input, actual home rental payment and E admission; no walking route, natural lifecycle, macOS FPS or full art completion claim.'}
 (root/(variant+'-PLAN.json')).write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'status':'FROZEN_NOT_RUN','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{p.name:sha(p.read_bytes()) for p in root.iterdir() if p.is_file()}}))

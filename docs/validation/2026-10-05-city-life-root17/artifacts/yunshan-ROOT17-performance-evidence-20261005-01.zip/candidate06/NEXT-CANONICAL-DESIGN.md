# 下一可证明优化：受控只读几何与公开可变 fallback（尚未实现/运行）

## 现有真实边界

已有代码自有生成器 makeBody 和 WeakMap BodyCache，可作为 provider 的起点；没有统一运行时几何 generation。stairGeometryRevision===2、commercialGeometryRevision===1/routeRevision===1 是可信配方版本与持久化身份，不能改成运行中递增计数。getBuildingBody/getBuildingFloorPlan 返回同一个公开可变对象，wallPanels/slabRegions/roofRegions 的返回数组也明确支持修改，因此不能直接冻结它们或用 tick/identity 假定它们没变。

最终profile16 people25.411秒，inclusive floorPlanSupport12.5125秒、localSolids4.8516秒、geometry2.2833秒（互相重叠，不能加总）。27pure+有限16档相等仅证明已有小改；没有可玩FPS结论。

## 可行路线

在既有 BodyCache 内增 ownership/mode 和独立 private generation，而非改世界配方或保存格式：

1. 由 makeBody 正常生成全部几何及既有 wall/slab 缓存，完成所有初始化后建立私有 canonical geometry。内部只读 reader 返回 readonly/frozen 的 canonical graph，官方修改采用整代替换及 generation 递增。不要冻结任何既有公开 mutable API 返回值。
2. 既有公开 getBuildingBody/getBuildingFloorPlan 作为“mutable view 暴露”入口。第一次公开暴露时切该建筑为永久 mutable fallback；其他建筑继续 canonical。公开 view 必须是未冻结的稳定对象，并保 repeated-call identity、数组/rect 的原共享别名、raw wall/slab 懒缓存的旧 lifetime。实现上可懒克隆完整联合图（body + 已建panel/slab/roof/相关derived cache entries）后重新绑定 WeakMap；联合克隆保持 rect/plan/cache 的引用关系。不能只 structuredClone(body) 然后重新推导已被primed的壁板，否则冷缓存/半径0旧契约会变。
3. 所有生产内部读改为明确 readonly reader。仅改变 NpcStairMotion 不够：27个模块读取这些symbols；savedWorldFingerprint/commercialNetworkConflicts、homeRestPoints、marketCounters、临床/教育/供电/卫生活动、renderer架构细节都会提前调用旧公开getters，从而让整城落入fallback。应一次列清并迁移内部纯读，保旧export供外部/test/改造使用。
4. 发现一个真实别名出口：marketShopfrontBoards 的 notice host.rect 直接是 panel.rect；architectureProgramSignPlacement 返回原 wall；architectureProgramRoofEdges 的 region 返回原 roof。它们的现有公开export仍须视为 mutable escape。内部renderer可使用新readonly版本/内部helper，不能把 frozen wall/roof 混入旧公开输出或删其别名语义。纯数值/Vec3返回的 getBuildingEntrance/UsePoints/StairPosition 可以内部只读，不需让body逃逸。
5. WorldDefinition 与 Building 当前仍公开可变。每个几何查询都要读取当前源header：getBuildingBody现有scalar/ref cache key、Npc geometry额外id/profile/recipe/position/routeRevision，以及本leg的floorFootprints内容；嵌套position、footprint新增键/键序和accessor必须能让fast path退出。不能因canonical plan未暴露就忽略 b.width/b.position 或 raw footprint nested edit。对这些小参数做 current-value guard；非普通数据、异常/稀疏或shape改变走完整旧值比较。generation只在显式权威编辑中提供快捷失效，外部raw修改仍要现读。
6. canonical 支持/碰撞预编译 nearPlans/stairSurfaces/localSolids/supportFootprints 和 XZ/height有界索引，每query只取圆/扫掠可能命中的候选。保 exact narrowphase、原数组顺序和tie order，不能把“只查包围框”当身体通过。未暴露canonical无需每点重扫数百成员；mutable fallback仍完整检查当前成员/坐标/高度/holes。
7. Npc geometry 可按 canonical generation+leg floor set 缓存完整原 JSON signature。signature文本必须保持旧值；从canonical切换mutable但没改几何时，不能仅因mode/token变化把正常旧腿判blocked。每次仍做当前building membership/source header检查；mutable模式继续原JSON全值串。revision/token只优化取得同一指纹，不取代它的语义。
8. ACL/角色、placed voxels、road closures/可达图是独立 live state，不能装进immutable floor cache。现有 canAccessFloor、citizenPhysicalSegmentAllowed、route callback、gift/clinical station voxel gate 必须每次照旧运行。road和building collection自己的revision/外部raw修改策略另列，不用 geometry token 掩盖它们。

## 受影响真实路径

GEOMETRY-READ-PATH-INVENTORY.json列27个模块和源SHA（lexical，不冒每个词都运行）。关键：

- architecture-floor-plan.ts：makeBody/BodyCache、public getters、panel/slab/roof的public别名、nearPlans/localSolids/supportFootprints/routeGrid。
- npc-stair-motion.ts geometry/describe/pose/materialize/advance/validate/remaining；cached fingerprint取得方式必须同语义。
- simulation.ts people/moveCitizenPhysical/citizenPhysicalSegmentAllowed/floorPlanPresence/function point。
- controller.ts player support/roof/ACL/voxel与真实motor，不能只优化NPC而引入两套物理。
- persistence/world-layout.ts savedWorldFingerprint：新内部reader应生成完全同descriptor JSON/FNV。保存不用记录private derived generation，正式动态CityPatch需另有持久化参数契约。
- home-rest.ts：现pointCache仅building+floor，注释假定不可变世界。真正动态geometry编辑时应绑定generation；不能让改造后继续使用旧床点。现公开mutable fallback的旧cache寿命需先审计，不能把新修复混当等语义优化。
- commercial-district/world生成、renderer架构与shopfront、临床/教育/银行/治理/文化/供电/卫生/gift等读者，共27模块；原生产写入主要在makeBody初始化及fresh商业/世界配方，不在正常模拟中改FloorPlan。

## 必须先完成的证明

只读设计，本文件0新实现/0Simulation/0benchmark，不预填提速：

1. provider纯测试：旧public对象保持可修改且same identity，panel/slab/roof引用与冷priming lifetime；clone floorPlans、不归属plan、duplicate/sparse/null/undefined/accessor/删除或替换数组和rect、同tick修改都进入旧fallback并给原结果/异常。
2. source header测试：position/尺寸/footprint nested edits、recipe/input replacement/current member移除/同长度集合变化，不等待下一tick；其中现有legacy cache可能已存在缺口，需明确分开修复。
3. signature测试：未改geometry的public escape不block；改任意旧指纹字段则stale；JSON文本/保存fingerprint与旧source完全同；readonly renderer helper不泄漏mutable aliases。
4. 先纯query case矩阵与原27回归，tsc；然后NEW有限default source baseline/candidate各原16逐tick full save等、terminal f4b9076c固定。旧default/civic/历史保存recipe都保留，不能换小城求PASS。
5. 再原native mid-riser/+24 whole/partition、player stair/roof/body、gift/clinic/education、道路封闭/体素/ACL窄范围。原完整suite的OOM/TIMEOUT要另证，不能因provider局部PASS抹掉。

若无法可靠区别内部只读与公开可变别名，不启用canonical fast path；留旧fallback比错误缓存好。可以先仅在未escaped的纯headless default证明效果，再迁renderer，明确这不是终局性能达标。

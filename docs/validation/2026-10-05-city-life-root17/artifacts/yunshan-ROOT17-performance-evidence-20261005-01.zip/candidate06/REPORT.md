# ROOT17 楼层查询性能候选与实际等价验证

当前是 private candidate06，未编辑共享仓库、未提交推送。原325图0c7aea22807f69ac83450ecd201d5ee6e933dff816e937cf18b0728e97d7a0da上的唯一生产文件 `src/architecture-floor-plan.ts` 替换，另加两纯测试，共327输入。原其余324文件与所有旧测试逐字未改；`NpcStairMotion.geometry` 未改。安装前后值见 INSTALL-CANDIDATE.json，不能把整份旧source覆盖root其他子系统修改。

## 已实现

1. localSolids每次仍逐成员读取当前 panel/fixture/tread/landing/upper slab、rect引用及高度，取消每成员校验闭包。
2. floorPlanSupport取消私有数组some/every闭包；真实solid离完整圆体bbox很远时可保守排除。四个rect坐标按原circleDistance顺序一次读入复用，near/reversed/NaN/Infinity仍原圆距判定，不用过时p.broadphase。
3. boundaryLoops对普通数据矩形每格占据union一次计算，原.2m量化、边顺序、trace和异常不变，最大65536cell/64KiB，超大网保留原path；公开坐标getter/custom-array保留原重复读取路径，每次边界重新读取当前真实矩形。
4. getBuildingFloorPlan取消每查询find闭包，保原first match/稀疏访问/captured length、getter缩短集合异常。

## 实际验证（可追溯原件）

- 最终candidate06原20几何+新增7纯（528圆距角点/切边/反向/NaN/Infinity组合、live rect移动与替换、getter顺序/次数、duplicate/sparse/getter缩短数组、边序/holes/invalid、getter重复读取）**27/27 PASS**。纯阶段01:31:46.606990—01:32:28.903970 UTC、42.296980秒/cap120、输入327稳定/owned active[]。最终tsc **PASS**，14.540840秒/cap120，327稳定/owned active[]。
- 先candidate02的独立paired original16：baseline/candidate各原.25×16、交替先后，每tick full state/runtime逐字相同。实际68.629399秒/cap180，原NPC数值/世界/钱粮/需求/速度/焦点没有修改；末档f4b9076c…与最初profile16原件完全相同。同一进程baseline28.104512725秒/candidate26.267261346秒，单次6.54%差异；不能当稳定提速或最终06计时。
- 最终06 **actual16-01 PASS**：01:33:07.133111—01:33:39.570965 UTC，32.437854秒/cap120，输入327稳定/owned active[]。严格从原default世界2912839d…、原229后真终档edf73ed2…恢复，普通.25×16，没有新城或NPC/需求/钱料/时钟/焦点/速度/政策/位置/身份注入。每tick complete-save SHA等之前实际baseline固定16个SHA，终完整字节同时等真正baseline16原件。
- 终档 `f4b9076c3b04c0479035995a9a159310ff9f742cab78c55d2c1269dcb3474040`，tick1120。最终16步25.740031117秒，people25.411445993秒、初始化3.071849676秒。原初profile步耗26.760660830秒；这两个独立scope且最终多16次export/校验，不把异次差异当稳定性能结论。
- 1000µs原始CPU profile和逐tick/原raw/receipt/source前后/owned/SHA、源码与原世界/存档全部保留。tsx profile的原line1不能冒原TS精确行号。最终inclusive floorPlanSupport12.512505秒/localSolids4.851588秒/Npc geometry2.283281秒；inclusive相互重叠，不能合计。

## 真实失败及未验证

candidate04新边界测试在NaN case后未恢复rect.x1，再测试hole时先触发既有Error('invalid region')而非TypeError。**Node25 tests/24PASS/1FAIL**、34.715160秒/cap120、源327稳定/owned active[]原件保持。NEW05先恢复前件后26/26PASS，再NEW06保坐标原读取顺序并加一回归27/27；没有改旧断言、没有倒写04 PASS。candidate03–05没有实际Simulation运行。

**性能目标仍未达到**：默认城市人物16步仍约25秒；本阶段只证明小优化及实际有限轨迹等价，不认证流畅FPS/macOS/GPU或原全suite TIMEOUT已解决。原全suite OOM/TIMEOUT_PARTIAL、UI/Browser/Mac既有未跑范围保持。完整统计区/流式、人群/路线成本仍待继续；没有降低NPC数量或移动速度、跳过阶段、加钱粮或削弱测试。

## 下一步

继续在真实CPU样本上减少重复查询，优先共享有界空间候选列表，必须读取当前变化并保几何/ACL/道路/体素。geometry完整公开可变JSON指纹暂不跳过：tick或identity缓存会漏当前nested mutation。后续按新scope逐tick核完整保存，不盲重跑原一小时全suite。

原件包/输入manifest与 INSTALL-CANDIDATE.json 足够重建候选；本文件和child封存不宣告root已集成，root最终集成build/其他子系统测试需另有回执。

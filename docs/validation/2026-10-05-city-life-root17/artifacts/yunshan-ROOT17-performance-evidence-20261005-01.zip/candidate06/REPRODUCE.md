# 重放原件

baseline-source-325.zip是6a614c5时期原325精确输入（图0c7），无node_modules/.git；入口manifest逐entry SHA。使用Node >=22.19与原package-lock正常npm ci。按INSTALL-CANDIDATE.json仅替换生产文件和加入两新测试，勿覆盖其他工作。

各driver保存原绝对路径，未悄悄改写执行脚本。若需原scope重放，在独立空workspace还原 /workspace/yunshan-work/ROOT17-performance-20261005-01/source 原baseline，并按证据路径恢复 ROOT16-food-integration-20261005-01/originals/WORLD-ORIGINAL.json 和 outputs/all229-continuation01/terminal.save.json（包originals中原SHA字节）。candidate02还原在既有root/candidate02，最终06 source/driver还原到 /tmp/yunshan-ROOT17-performance-candidate06-20261005-01。独立重放输出请使用NEW运行目录和新声明budget，勿覆盖已封回执。脚本/数据/旧FAIL SHA必须核对。

纯测试：node --import tsx --test --test-isolation=process --test-concurrency=1 tests/floor-plan-derived-cache.test.ts tests/floor-plan-empty-support.test.ts tests/floor-plan-self-collision.test.ts tests/floor-plan-support-broadphase.test.ts tests/floor-plan-selection.test.ts tests/architecture-floor-plan.test.ts

类型：node node_modules/typescript/bin/tsc --noEmit

最终实际16是已完成有限scope，保存32.437854秒/cap120及inputsStable/ownedActive[]。不会自动延旧cap或换原场景做PASS；完整游戏/Mac/全suite仍未验证。

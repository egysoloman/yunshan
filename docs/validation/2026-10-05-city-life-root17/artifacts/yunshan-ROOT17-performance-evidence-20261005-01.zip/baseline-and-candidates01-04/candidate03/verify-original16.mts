import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { Simulation } from './source/src/simulation';
const root='/workspace/yunshan-work/ROOT17-performance-20261005-01',dir=root+'/candidate03';
const worldFile='/workspace/yunshan-work/ROOT16-food-integration-20261005-01/originals/WORLD-ORIGINAL.json';
const saveFile='/workspace/yunshan-work/ROOT16-food-integration-20261005-01/outputs/all229-continuation01/terminal.save.json';
const sha=(x:string|Buffer)=>createHash('sha256').update(x).digest('hex');
const inputs=JSON.parse(readFileSync(dir+'/INPUTS-326.json','utf8'));
const referenceFile=root+'/candidate02/comparison-artifacts/SUMMARY.json',referenceBytes=readFileSync(referenceFile,'utf8'),reference=JSON.parse(referenceBytes);
assert.equal(reference.status,'PASS_ORIGINAL_16_EACH_STEP_BYTE_EQUIVALENT');assert.equal(reference.rows.length,16);
const guard=()=>{for(const [n,h] of Object.entries(inputs))assert.equal(sha(readFileSync(dir+'/source/'+n)),h,n);};guard();
const wb=readFileSync(worldFile,'utf8'),sb=readFileSync(saveFile,'utf8');
assert.equal(sha(wb),'2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512');assert.equal(sha(sb),'edf73ed2aa923b16248f3981092ea78dfe6375e5be1a4d4e3c6914ca84285754');
const world=JSON.parse(wb),t=performance.now(),sim=new Simulation(world);assert.equal(sim.importSave(sb).ok,true);assert.equal(sim.exportSave(),sb);const initializationMilliseconds=performance.now()-t;
const bus=Reflect.get(sim,'bus'),original=bus.emit,phases:Record<string,number>={};
bus.emit=function(event:any){if(!event.type.startsWith('system:'))return Reflect.apply(original,this,[event]);const t=performance.now();try{return Reflect.apply(original,this,[event]);}finally{phases[event.type]=(phases[event.type]??0)+performance.now()-t;}};
const rows=[],firstTick=sim.state.tick;
for(let i=0;i<16;i++){
 const t=performance.now();sim.step(.25);const elapsedMilliseconds=performance.now()-t;assert.equal(sim.state.tick,firstTick+i+1);
 const bytes=sim.exportSave();assert.equal(sha(bytes),reference.rows[i].saveSHA256,`tick ${sim.state.tick} complete state/runtime must equal the actual frozen baseline tick`);
 rows.push({step:i+1,tick:sim.state.tick,saveSHA256:sha(bytes),elapsedMilliseconds});
}
const terminal=sim.exportSave();assert.equal(terminal,readFileSync(root+'/artifacts/baseline16.save.json','utf8'));assert.equal(sha(terminal),'f4b9076c3b04c0479035995a9a159310ff9f742cab78c55d2c1269dcb3474040');
guard();assert.equal(readFileSync(worldFile,'utf8'),wb);assert.equal(readFileSync(saveFile,'utf8'),sb);assert.equal(readFileSync(referenceFile,'utf8'),referenceBytes);
const summary={status:'PASS_ALL_16_ORIGINAL_BASELINE_TICK_HASHES_AND_TERMINAL_BYTES',sourceCount:326,initializationMilliseconds,stepMilliseconds:rows.reduce((x,y)=>x+y.elapsedMilliseconds,0),phaseMilliseconds:phases,rows,terminalSHA256:sha(terminal),referenceSHA256:sha(referenceBytes),candidateFloorPlanSHA256:inputs['src/architecture-floor-plan.ts'],scope:'One actual original restored default city instance, 16 ordinary .25 steps, current candidate326; every full state/runtime matches independently previously run baseline per-tick SHA plus terminal actual byte compare. No baseline rerun/new city/GPU/commands, no needs/body/count/clock/stock/money/policy/focus changes; timing is one bounded CPU case, not stable FPS/macOS proof.'};
mkdirSync(dir+'/artifacts');writeFileSync(dir+'/artifacts/terminal.save.json',terminal);writeFileSync(dir+'/artifacts/SUMMARY.json',JSON.stringify(summary,null,2)+'\n');console.log(JSON.stringify(summary));

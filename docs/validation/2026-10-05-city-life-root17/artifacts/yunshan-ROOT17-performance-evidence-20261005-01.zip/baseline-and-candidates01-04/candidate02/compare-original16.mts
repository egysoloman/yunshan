import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { Simulation as BaselineSimulation } from '../source/src/simulation';
import { Simulation as CandidateSimulation } from './source/src/simulation';
const root='/workspace/yunshan-work/ROOT17-performance-20261005-01';
const out=root+'/candidate02/comparison-artifacts';
const worldFile='/workspace/yunshan-work/ROOT16-food-integration-20261005-01/originals/WORLD-ORIGINAL.json';
const saveFile='/workspace/yunshan-work/ROOT16-food-integration-20261005-01/outputs/all229-continuation01/terminal.save.json';
const sha=(x:string|Buffer)=>createHash('sha256').update(x).digest('hex');
const baselineInputs=JSON.parse(readFileSync(root+'/INPUTS-325.json','utf8'));
const candidateInputs=JSON.parse(readFileSync(root+'/candidate02/INPUTS-325.json','utf8'));
function sourceGuard(){for(const [n,h] of Object.entries(baselineInputs))assert.equal(sha(readFileSync(root+'/source/'+n)),h,n);for(const [n,h] of Object.entries(candidateInputs))assert.equal(sha(readFileSync(root+'/candidate02/source/'+n)),h,n);}
sourceGuard();
const wb=readFileSync(worldFile,'utf8'),sb=readFileSync(saveFile,'utf8');
assert.equal(sha(wb),'2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512');
assert.equal(sha(sb),'edf73ed2aa923b16248f3981092ea78dfe6375e5be1a4d4e3c6914ca84285754');
const world0=JSON.parse(wb),world1=JSON.parse(wb),init=performance.now();
const baseline=new BaselineSimulation(world0),candidate=new CandidateSimulation(world1);
const times={baseline:[] as number[],candidate:[] as number[]};
for(const sim of [baseline,candidate]){assert.equal(sim.importSave(sb).ok,true);assert.equal(sim.exportSave(),sb);}
assert.equal(JSON.stringify(world0),JSON.stringify(world1));
const initializationMilliseconds=performance.now()-init;
const firstTick=baseline.state.tick,rows=[];
for(let i=0;i<16;i++){
  // Alternate which independent instance runs first to reduce a fixed ordering
  // bias. Both use the original .25 step and the identical persisted inputs.
  for(const [label,sim] of (i%2===0?[['baseline',baseline],['candidate',candidate]]:[['candidate',candidate],['baseline',baseline]]) as [keyof typeof times,typeof baseline][]){const t=performance.now();sim.step(.25);times[label].push(performance.now()-t);assert.equal(sim.state.tick,firstTick+i+1);}
  const b=baseline.exportSave(),c=candidate.exportSave();
  assert.equal(c,b,`whole serialized state+runtime must be byte-identical at tick ${firstTick+i+1}`);
  rows.push({step:i+1,tick:baseline.state.tick,saveSHA256:sha(b),baselineMilliseconds:times.baseline.at(-1),candidateMilliseconds:times.candidate.at(-1)});
}
const terminal=baseline.exportSave();assert.equal(sha(terminal),'f4b9076c3b04c0479035995a9a159310ff9f742cab78c55d2c1269dcb3474040','same result as the original frozen profile16');
assert.equal(terminal,readFileSync(root+'/artifacts/baseline16.save.json','utf8'));
sourceGuard();assert.equal(readFileSync(worldFile,'utf8'),wb);assert.equal(readFileSync(saveFile,'utf8'),sb);assert.equal(JSON.stringify(world0),JSON.stringify(world1));
const baselineMilliseconds=times.baseline.reduce((a,b)=>a+b,0),candidateMilliseconds=times.candidate.reduce((a,b)=>a+b,0);
const result={status:'PASS_ORIGINAL_16_EACH_STEP_BYTE_EQUIVALENT',stepsPerInstance:16,initializationMilliseconds,baselineMilliseconds,candidateMilliseconds,elapsedReductionFraction:1-candidateMilliseconds/baselineMilliseconds,rows,terminalSHA256:sha(terminal),candidateFloorPlanSHA256:candidateInputs['src/architecture-floor-plan.ts'],scope:'Two original saved worlds, same edf73 inputs and ordinary .25 steps; no renderer/no commands/no NPC-count/needs/cash/stock/policy/clock/focus mutations. Wall timing alternates order, one bounded process and no speed assertions. CPU timing does not establish FPS or Mac performance.'};
mkdirSync(out);writeFileSync(out+'/terminal.save.json',terminal);writeFileSync(out+'/SUMMARY.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));

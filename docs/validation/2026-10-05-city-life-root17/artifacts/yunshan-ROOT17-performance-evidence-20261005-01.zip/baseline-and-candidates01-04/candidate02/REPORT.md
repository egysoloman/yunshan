# ROOT17 candidate02：楼层几何循环优化

本候选未安装共享仓库。唯一生产文件 `src/architecture-floor-plan.ts`，在源325图 `0c7aea22807f69ac83450ecd201d5ee6e933dff816e937cf18b0728e97d7a0da` 上保留全部旧文件与原测试，仅改该文件。

逐次读可变 wall panel/fixture/tread/landing/upper slab 的成员、rect 引用及高度不变；取消每次 localSolids 成员校验的闭包调用，取消 floorPlanSupport 私有派生数组的 some/every 回调分配。既有冷缓存 priming、稀疏/null 成员异常、非有限半径、实际支撑、楼层/权限/道路/体素调用规则不改变。没有改 NPC 数量/速度/时间/钱粮/需求/世界/断言，也没有基于 tick 的失效绕过。

## 实际验证

- candidate01 原20项 floor-plan-derived-cache/empty-support/self-collision/architecture-floor-plan PASS；该旧候选保留。candidate02 继续变化后原17项 derived-cache/empty-support/self-collision PASS，tsc PASS；源325均前后稳定、owned active[]。
- NEW paired original16/cap180 actual-comparison01，2026-10-05 01:11:33.465660—01:12:42.095059 UTC，68.629399秒，PASS。从原 World SHA2912839d…与原终档edf73ed2…，独立 baseline/candidate 各16个正常 `.25` step，交替运行先后，每tick whole state/runtime 保存逐字相同。
- 16后两实例及原 profile16 终档均 `f4b9076c3b04c0479035995a9a159310ff9f742cab78c55d2c1269dcb3474040`。终档原件及逐tick SHA见 `comparison-artifacts`；初始世界/存档和baseline325/candidate325输入前后逐SHA相同。
- 同一进程baseline16步累计28.104512725秒，candidate26.267261346秒，单次减少6.5372112905%。初始化两实例6.719210719秒。原 profile CPU 和这次 paired wall 并非相同测量仪器；轻型外部CPU可影响wall，不能凭单例认定稳定提速或总体性能通过。

## 边界

本阶段不是游戏FPS/macOS实机/渲染性能PASS，不是全suite或旧3600秒TIMEOUT已解决。geometry字符串指纹仍逐次读取完整可变floor plan；支持/路径/楼层几何热点仍占主要CPU。完整游戏目标继续；后续可使用新的保守支持查询剔除候选，但必须读当前真实rect，不能信旧p.broadphase。

## 原件

- `INPUTS-325.json`：最终候选精确源输入；原全部测试与baseline相同。
- `PATCH.diff`：源码原→新差异，SHA6ff96bf5deb3defd9f176c035bb7580f80695eeab07e600e4e1ac792f5d356c1。
- 新源文件SHA `b1d52c55e4bcbeea332e78eeedf9f6b3bde6207d376c5a29b0a49af7eb5191d6`；原文件SHA按baseline325清单核对。
- `COMPARISON-PLAN.json`、`compare-original16.mts`、`actual-comparison01` 的原raw/receipt/before/after/owned，以及全保存和SUMMARY；driverSHA0014bec9a0756792352b5742c74e4ba73b05d1c969e618c5dcb700f607682da2。
- `pure01`、`types01`：原结果与source稳定/owned证明。

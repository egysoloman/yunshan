# 独立回归与原件恢复

完整ZIP采用 `sources/manifests/<scope>.json` 路径→SHA清单和 `sources/blobs/<sha>` 原文件内容，去重只发生在封装中。四种源恢复后均是普通独立源码目录，未更改任何运行输入；不含node_modules、Git或凭据。

```sh
python3 restore-source.py medical-v5 /tmp/yunshan-medical-v5
cd /tmp/yunshan-medical-v5
npm ci
node node_modules/typescript/bin/tsc --noEmit
node --import tsx --test --test-isolation=none tests/clinical-procurement-power-reason.test.ts tests/clinical-grid-power-pure.test.ts tests/clinical-open-minutes.test.ts tests/power-grid.test.ts
ROOT17_GRID_FUNCTIONAL_OUTPUT=/tmp/yunshan-medical-result node --import tsx --test --test-isolation=none tests/clinical-grid-native-start-functional.test.ts
```

实际原argv及120秒/PID守卫在各scope的receipt.json；`run-phase.py`接收 source、全新run目录、JSON argv与cap秒，输出首尾全输入SHA/raw/PID。实际medical01旧版333是历史FAIL；medical02新334才为4/4PASS，不把两者合并成一次通过。

```sh
python3 restore-source.py estate-after /tmp/yunshan-estate-after
cd /tmp/yunshan-estate-after
npm ci
YUNSHAN_FAMILY_ESTATE_EVIDENCE=/tmp/yunshan-estate-result node --import tsx --test --test-isolation=none --test-name-pattern='actual finite loan' tests/family-estate-escrow.test.ts
```

遗产旧325原driver与新326测试的断言相同，旧driver仅import路径绑定旧source。归档原driver的绝对路径来自本次冻结目录；独立复现旧错误时将新326测试复制到恢复的旧325 `tests/family-estate-escrow.test.ts`，保持相对imports不变即可。原325清单不含此新增测试，需另存外部driver/记录新执行输入，不能把该准备动作冒成原325字节完全未动。若仅查看本轮已运行证据，不需重跑。

原医疗四案是声明的有限电网初始地图，既有真实医患的一次初始站位；遗产案例为反复受控站位/needs、保存年龄/关系/出生边界和一次致死health控制。所有受控条件详见REPORT；这些输入用于隔离资金和护理契约，不证明默认城市自然生命周期。

"""Restore a SHA-verified frozen source snapshot from this original archive."""
import hashlib
import json
import pathlib
import sys

scope, destination = sys.argv[1:]
root = pathlib.Path(__file__).resolve().parent
target = pathlib.Path(destination)
assert not target.exists(), "use a new destination; existing files are never overwritten"
manifest = json.loads((root / "sources" / "manifests" / (scope + ".json")).read_text())
for name, expected in manifest.items():
    relative = pathlib.PurePosixPath(name)
    assert not relative.is_absolute() and ".." not in relative.parts
    data = (root / "sources" / "blobs" / expected).read_bytes()
    assert hashlib.sha256(data).hexdigest() == expected, name
    path = target / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
print(json.dumps({"scope": scope, "files": len(manifest), "destination": str(target), "allSHA256Verified": True}))

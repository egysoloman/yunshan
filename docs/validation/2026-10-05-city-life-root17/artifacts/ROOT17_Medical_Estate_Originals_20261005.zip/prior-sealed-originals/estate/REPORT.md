# ROOT17 家庭课程托管与遗产债务：隔离候选

截至 2026-10-05 02:01 UTC：仅候选完成。strict 退出0；四项纯合同回归通过；原325源码的同四项纯合同为2通过、2真实失败。**真实 Simulation 贷款→部分课程→死亡→继承案例及其24步续演仍 NOT_RUN，等待 root 功能 CPU 窗口。** 没有共享源码修改、GPU、构建、全套测试或上传。

## 原件与范围

- 只读完整报告：`/tmp/ROOT17-family-dynamic-city-readonly-20261005-01/REPORT.md`，SHA `fad7fc5c5a4a9bd01d35c1ff124237b5ca12bfb8a68f6adf03467d824b77ae0a`。实际生育、儿童登记、课程、清债和商铺交接，以及拆迁/消防/地震/空间损伤缺项均在该报告分开陈述。
- 基线：`BASELINE-INPUTS-325.json`，按既有325清单逐文件读取当前共享源并逐 SHA 核对；baseline/source和candidate/source都是这些精确原文件的独立副本。未跟随或复制node_modules，只有显式链接。
- 生产仅 `src/simulation/banking.ts` 一行。`tests/family-estate-escrow.test.ts` 是唯一新增项目测试；候选326文件。`CANDIDATE.patch` 为可审查完整两文件差异。
- 字段、schema、初始化、加载迁移和世界几何都没有改动。没有课程时新增 optional 查询为假。

## 真正原因与最小修复

原银行 `settleDeceasedAccount` 的未结资产判断遗漏 `familyEducation.active`。家庭 people 执行遗产先于课程 people 退款；如果现有现金不足债、唯一未到账资产是课程未赚托管款，原银行会提前核销债并关闭账户。课程随后原额退款，下一次遗产执行可能把本应先还债的款交给继承人。

候选仅追加：

```ts
|| s.familyEducation?.active.some(course => course.payerId === actorId && course.escrow > EPS)
```

因此未还清债且该死者仍持有课程托管时，保持原债与未结账户，等待现有课程模块退回原钱包。现有执行人之后先偿债，再继承净额。不会直接从课程账户扣钱，也不会改变教材、已赚课程费、60分钟、原40文、工资、退款上限或任何法定继承人。

本轮纯合同已证明旧函数会错误核销并关账，但 **完整医疗/生活相位下这条新实景链路仍未运行**；原先 STATIC_NOT_REPRODUCED 的完整流程事实不被纯合同结果冒替。

## 已实际运行

| scope | 实际结果 | 输入/原日志 |
|---|---|---|
| strict01 | 02:00:02退出0；tsc严格类型通过 | 326首尾同，`strict01/receipt.json`；raw空SHA为标准空文件 |
| pure-before01 | 4项中2PASS、2FAIL；player与NPC均提前 `unpaidLoss:20, closed:true` | 原325首尾同，`pure-before01/raw.log`及receipt |
| pure-after01 | 4/4PASS、0FAIL | 候选326首尾同，`pure-after01/raw.log`及receipt |

纯合同不实例化Simulation，不导入save，不伪造贷款或工资事件：

1. player有30未赚托管与20欠债，保持未结，重复执行不消费托管。
2. 同样守卫覆盖具名NPC付款人。
3. 无课程、零托管、其他付款人课程不妨碍原真实损失关账合同。
4. 明示十亿钱包开账边界：原取消代码保留40 refundPending；有限两侧现金转移产生容量后只退款一次，不删除待办、不重复退款。

第四项是纯容量模型，**不是自然获得十亿现金或有效世界存档的证据**。所有原始FAIL和日志保留。

## 真实功能待跑合同

`RUN-PLAN.json` 给出精确argv。旧源码的外部 `drivers/family-estate-before.test.ts` 与候选测试相同断言，仅静态import路径分别绑定旧/新源。

真实链路使用既有9楼、384原居民的familyFeeFixture。它明示保存年龄/关系边界、银行与教室站位、needs和一次致死health=0控制，不称自然婚育或自然死亡。原角色、钱包、库存、教师出勤和工资保持原来源：

- 另一个原有富余钱包居民真实柜台存100；payer没有存款抵债，避免遮蔽原因。
- player到原银行实际loan20；到原教室实际签40学费、购一份原工坊教材，实际已付薪教师只完成部分课程。
- 一次合法捐赠把现有整数现金转给既有组织，确保钱包不足债；双方现金计入守恒，不注入金钱、不抹余额。
- 一次受控死亡，由原life/family/课程/finance相位实际退款、清债、继承；强断言损失未增加、实债先偿、净额继承、已赚课程/原教材保留。
- 真实全档分区重组、立即import/export逐字相同，再双实例24次`.25`普通tick逐字同；无位置或钱补丁去迎合结果。

最多原实例75次`.25`step，续演clone24次；wall guard120秒。如果超时或前置条件失败原样FAIL/NOT_COMPLETE，不延长或改人钱角色。原正常无课程立即全字节/+24与银行债/继承回归建议见RUN-PLAN，需要root另功能GO。

## 交付与剩余

`EXECUTION-MANIFEST.json` 索引实际scope、argv、PID/startTicks、首尾SHA和日志。`CLOSURE.json` 核实本生产者当前没有活跃owned进程；esbuild僵尸观察单列，不称已删除。代码候选准备好供root审查，未接共享。真实功能链路、旧正常字节/+24及最终守卫集成仍待完成；本补丁不解决自然护理现场权限、真正托管服务、空间拆迁或灾害伤损。

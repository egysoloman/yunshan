# ROOT18 室内资产纵切：23 项纯回归、类型与构建通过；实际 GPU 尚未运行

在已封存的 ROOT17 source327 视觉候选上继续，没有改动共享仓库或 ROOT17 GPU 输入、失败记录及截图。最终候选是 candidate04-source，共 329 项功能输入；标准差异 candidate04.patch（另有只增加两行 new file mode 100644 的 candidate04-metadata02.patch）只涉及 `src/rendering/interior-props.ts`、`src/rendering/architecture-bodies.ts`、`src/renderer.ts` 与新增 `tests/interior-props.test.ts`。

实际接缝包含 381 个原有商业楼上层 table 的办公桌表现，以及 221 栋住宅的 442 个原有封闭窗的窗帘表现。桌子全部留在原 table 碰撞包围体内；窗帘和薄玻璃显示层全部留在原玻璃碰撞体内，门洞、楼梯、使用点、fixture 与建筑/世界权威数据不变。没有增加商品、租赁、公司、通电、睡眠、使用家具、窗帘操作或住户功能。

沙发、茶几、显示器已生成通用原模型，尚未安置进城市；其安置需要后续真实家具权威定义。完整床品 `programLinenTemplate` 与 ROOT17 的 44 三角形原实现逐字不变，旧测试也全部逐字不变。

最终 source329 图哈希（排序紧凑 JSON）为 `3260c3775614b10c0f12c3b47da070750d1cfb0381aa75c0179c60c118482db9`。基线 source327 图哈希为 `20b3d603c2a71e36cf0c29a5196e672b10a43b4bd9b2a7fd5c6249e04cc96306`；原世界 612 建筑的 JSON SHA256 保持 `2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512`。

## 实际修正的原因

第一次 pure01 实跑 20/21，失败是既有床品测试将所有 `fabric` 限定为床品。给非床品布艺增加独立 `cloth` 表现类别，并在实际 CityRenderer.buildHouse 单点映射到已有 fabric 材质；未削弱旧断言、未修改 shader 或新增材质资源。pure02 实跑 15/16，新增接缝测试误用了不存在的 Renderer 导出名，修正为实际 CityRenderer 后 pure03 22/22、类型/构建通过；两次失败及各自冻结输入都保留。

随后静态复核发现：既有 glass 是不透明完整盒，若把窗帘全部置于其中，所有布料都会被盒表面遮住。candidate04 保留权威 glass solid 和旧声明包围尺寸，仅为这两个实际目标窗画一层位于实际外侧的闭合薄玻璃。外侧由现有 interior 区域判断；无法唯一判别室内侧的窗不接窗帘，交通窗和其他窗保持原几何。

新增 CPU 三角形射线检查覆盖实际 442 个窗的 884 条布料视线：旧完整不透明玻璃盒均先挡住布料；新接缝均先击中真实布料，打开的中央仍先击中闭合玻璃。此项验证是几何遮挡检查，没有启动 WebGL，不替代实际画面验收。

## 原始美术交付

assets/models 共 20 个原文件：五种模型各 GLB、OBJ、MTL、geometry JSON。标准尺寸和真实 mesh 边界都记录于 assets/ASSET-MANIFEST.json，manifest SHA256 为 `012c9c42b9b296791cb9adf11cfc978a5b83030728dfdf01c618348324dd5bbd`。单模型三角形数依次为办公桌 96、沙发 144、茶几 84、显示器 48、窗帘 116，总计 488。

export02 使用实际 provider 构造模型，再用独立 GLTFLoader / OBJLoader 读回，检查原模型、GLB、OBJ 共 1464 个三角形的有限坐标、非退化面积、部分数量和真实边界；所有保存原文件读回 SHA256 相同。没有浏览器、Canvas、GPU、Simulation、付费或过期凭据调用。模型是原创低多边形 v1，仍需要后续材质细化与更多生活物品。

assets/MODEL-PREVIEW.png 与 .svg 是实际导出 OBJ 的 CPU 深度缓冲投影，标注标准米制尺寸与安置状态。已直接查看原 PNG；它们是模型预览，不是游戏截图，也不代表参考图质量验收。

## 运行与验证

| 阶段 | 实际状态 | 固定上限 | 证据 |
| --- | --- | ---: | --- |
| pure01 / candidate01 | FAIL，20/21；旧床品分类冲突 | 180 秒 | 原 raw.log、329 输入、receipt 留存 |
| pure02 / candidate02 | FAIL，15/16；新增测试导出类名错误 | 180 秒 | 原 raw.log、329 输入、receipt 留存 |
| pure03 / candidate03 | PASS，22/22；其后发现静态完整玻璃遮挡缺项 | 180 秒 | 原 PASS 不扩大为实际可见性验收 |
| pure04 / candidate04 | PASS，23/23，40.648490 秒 | 180 秒 | raw SHA `5036944452995561789278b485cfd31f32bfc7b07e59c7911c1e3d46940667f8` |
| build02 / candidate04 | PASS，tsc --noEmit 与 Vite，18.385553 秒 | 180 秒 | raw SHA `32fa77f50afa7016cb1599080ffd9f45de245c688b6fae58131db8cd642e9cb5` |
| export02 / candidate04 | PASS，20 原文件读回，1.315717 秒 | 120 秒 | raw SHA `f94cbc42884f6cc099d9e124c2f43ceed65a3c105305acc02c7da241b47eca87` |
| preview03 / candidate04 | PASS，CPU OBJ 深度投影，3.290791 秒 | 60 秒 | 原 PNG/SVG 与 preview receipt |
| patchcheck01 / source327 | PASS，标准 patch --dry-run | 30 秒 | 327 输入前后相同，原 receipt |
| gitapplycheck01 / source327 | PASS，metadata02 标准 git apply --check | 30 秒 | 仅补 new file mode；code/hunks/graphs 不变 |
| ROOT18 GPU / Mac / Simulation | NOT RUN，保持父任务 HOLD | — | 不复用旧 source327 GPU 作为新候选证据 |

每阶段记录真实 UTC 开始/结束、固定上限、进程 PID/start-time、观测到的后代、原始日志 SHA256 与功能输入前后；上述已结束阶段 inputstable=true、activeDescendants=[]。结束后仍可见的僵尸进程有记录，不冒充活跃进程。构建仍有既有大 bundle 警告，未修改警告上限或安排性能验收。

## 界限与直接接续

ROOT17 两次 16 张 GPU 的 native W waypoint 与 paused full-save FAIL 仍保持原事实，详见 `/tmp/ROOT17-visual-audit-20261005-02/REPORT.md`。本批没有修旧截图、旧失败、GPU driver 或断言，也不把这批 23 项几何检查记成旧 GPU PASS。对照 Git 五张参考图，街道密度、城市纵深、木梁石材、暖窗与生活物品等全城美术缺项仍存在，整体 ART FAIL 未翻转。

先由父任务按最终组合源码进行差异评审和必要集成；新 GPU 输入应独立冻结，再实际验证已有商业上层桌与有窗帘的住宅窗、布料 shader/薄玻璃图形接缝、真实操作路径与资源预算。每栋窗帘硬上限为两个窗，各增加两块 52 三角形布料与一根 12 三角形杆；442 个窗合计增加 51272 三角形，far LOD 不增加这些资产。新增模板/近景批次的实际帧时与图形表现尚未测量。

沙发、茶几、显示器下一步应先加入版本化的权威家具放置、占用、身份/租赁/库存等必要契约，依功能范围选择交互；没有凭此模型宣称家具使用已完成。房门、墙、床沿既有权威建筑定义继续，床原改进不覆盖。

本子任务未执行 Git 写入、commit、push、共享源树修改或 Library 写入；按父任务明确要求，额外执行了只读 git apply --check。依父任务指定的 No Library 交付边界，文件在封存包内待父任务制作对用户交付并上传；此处没有 LibraryID，不声称附件已经送达用户。

独立模型资源包为 yunshan-ROOT18-original-interior-models-v1.zip，333798 字节，SHA256 `99c2a3625d4831f63636a24d201eaca909025c594ad1e239eb26da68f6f375b2`，26 项均已 ZIP CRC 与逐文件 SHA256 读回；其中 20 项是模型原文件。metadata02 标准 patch 的 SHA256 为 `0779077fd94ddd4c2d3dc0e49a65f5ac3205d6c715955e4146abc4a0243d68e8`。父任务当前生产 source351 保持独立，不把本候选 CPU 验证或薄玻璃推断记为生产已安装或 WebGL PASS。

"""CPU-only orthographic drawing of the actual exported OBJ triangles.

No game, browser, GPU, Simulation, reference-image compositing or lighting
state is used. These drawings are artwork previews, not game screenshots.
"""
import hashlib, json, pathlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
import numpy as np

root = pathlib.Path(__file__).resolve().parent
manifest = json.loads((root/'assets/ASSET-MANIFEST.json').read_text())
direction = np.array([4., 3., 6.]); direction /= np.linalg.norm(direction)
horizontal = np.cross(np.array([0., 1., 0.]), direction); horizontal /= np.linalg.norm(horizontal)
vertical = np.cross(direction, horizontal)
light = np.array([-2., 5., 6.]); light /= np.linalg.norm(light)
fig, axes = plt.subplots(2, 3, figsize=(14, 8.5), dpi=160)
fig.patch.set_facecolor('#ebe9df')
descriptions = {'office-desk':'Existing upper-floor table host', 'sofa':'Prepared; no city fixture yet',
    'coffee-table':'Prepared; no city fixture yet', 'monitor':'Prepared; no powered UI or fixture',
    'open-curtains':'Existing sealed home window host'}
triangles_checked = 0
for ax, asset in zip(axes.flat, manifest['assets']):
    asset_id = asset['id']; materials = {}; current = None
    for line in (root/f'assets/models/{asset_id}.mtl').read_text().splitlines():
        words = line.split()
        if not words: continue
        if words[0] == 'newmtl': current = words[1]
        elif words[0] == 'Kd': materials[current] = np.array([float(n) for n in words[1:4]])
    vertices = []; faces = []; material = None
    for line in (root/f'assets/models/{asset_id}.obj').read_text().splitlines():
        words = line.split()
        if not words: continue
        if words[0] == 'v': vertices.append([float(n) for n in words[1:4]])
        elif words[0] == 'usemtl': material = words[1]
        elif words[0] == 'f': faces.append(([int(n.split('/')[0])-1 for n in words[1:]], material))
    vertices = np.array(vertices); assert np.isfinite(vertices).all()
    centre = (vertices.max(0)+vertices.min(0))/2
    projected = np.column_stack(((vertices-centre)@horizontal, (vertices-centre)@vertical))
    sorted_faces = sorted(faces, key=lambda f: np.mean(vertices[f[0]]@direction))
    polygons = []; colors = []
    for indices, material in sorted_faces:
        assert len(indices) == 3
        triangle = vertices[indices]
        normal = np.cross(triangle[1]-triangle[0], triangle[2]-triangle[0]); normal /= np.linalg.norm(normal)
        # Culling uses actual outward mesh faces. Lighting only makes their
        # silhouette and folds readable on this labelled CPU drawing.
        if np.dot(normal, direction) <= 0: continue
        intensity = .55 + .45*max(0, np.dot(normal, light))
        polygons.append(projected[indices]); colors.append(np.clip(materials[material]*intensity,0,1)); triangles_checked += 1
    ax.add_collection(PolyCollection(polygons, facecolors=colors, edgecolors=colors, linewidths=.25))
    minp, maxp = projected.min(0), projected.max(0); margin = max(maxp-minp)*.15
    ax.set_xlim(minp[0]-margin,maxp[0]+margin); ax.set_ylim(minp[1]-margin,maxp[1]+margin); ax.set_aspect('equal'); ax.axis('off')
    d=asset['logicalDimensions']; ax.set_title(f"{asset_id}\n{d['x']:g} × {d['y']:g} × {d['z']:g} m (W × H × D)",fontsize=13,color='#30483c',pad=10)
    ax.text(.5,-.10,descriptions[asset_id],transform=ax.transAxes,ha='center',fontsize=9,color='#526255')
axes.flat[-1].axis('off')
axes.flat[-1].text(.05,.7,'ORIGINAL MESH FILES\n\nGLB + OBJ / MTL + geometry JSON\n1 unit = 1 metre; +Y up; +Z front\nFloor-centred origin\n\nCPU orthographic drawing\nGame / browser / GPU: NOT RUN\nNo interaction or ownership granted',transform=axes.flat[-1].transAxes,fontsize=12,linespacing=1.5,color='#3e5146')
fig.suptitle('YUNSHAN — INTERIOR PROPS v1\nActual exported triangle geometry · CPU artwork preview',fontsize=19,color='#263f34')
fig.subplots_adjust(top=.81,bottom=.10,hspace=.65,wspace=.25)
outputs={}
for ext in ['svg','png']:
    p=root/f'assets/MODEL-PREVIEW.{ext}'; fig.savefig(p,facecolor=fig.get_facecolor()); outputs[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
plt.close(fig)
receipt={'status':'PASS','sourceModelManifestSHA256':hashlib.sha256((root/'assets/ASSET-MANIFEST.json').read_bytes()).hexdigest(),
    'driverSHA256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'visibleActualTriangles':triangles_checked,
    'scope':'CPU OBJ triangle projection; no game screenshot or visual acceptance claim','Simulation':0,'GPU':0,'outputs':outputs}
(root/'assets/PREVIEW-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt))

import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import * as THREE from 'three';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJExporter } from 'three/addons/exporters/OBJExporter.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { MTLLoader } from 'three/addons/loaders/MTLLoader.js';
import { buildInteriorPropAsset, type InteriorPropAssetId } from './candidate04-source/src/rendering/interior-props.ts';

// Node's Blob is sufficient for a binary export with no image, Canvas or GPU.
// The exporter assigns onloadend after calling readAsArrayBuffer, so keep the
// completion asynchronous as it is in a browser's native FileReader.
class NodeBinaryFileReader {
  result: ArrayBuffer | string | null = null;
  error: unknown = null;
  onloadend?: () => void;
  onerror?: () => void;
  readAsArrayBuffer(blob: Blob) { blob.arrayBuffer().then(result => { this.result = result; this.onloadend?.(); }, error => { this.error = error; this.onerror?.(); }); }
  readAsDataURL(blob: Blob) { blob.arrayBuffer().then(result => { this.result = `data:${blob.type};base64,${Buffer.from(result).toString('base64')}`; this.onloadend?.(); }, error => { this.error = error; this.onerror?.(); }); }
}
Object.assign(globalThis, { FileReader: NodeBinaryFileReader });
const root = dirname(fileURLToPath(import.meta.url)), destination = resolve(root, 'assets/models');
await mkdir(destination, { recursive: true });
const ids: InteriorPropAssetId[] = ['office-desk', 'sofa', 'coffee-table', 'monitor', 'open-curtains'];
const sha = (data: Uint8Array | string) => createHash('sha256').update(data).digest('hex');
const inputs = JSON.parse(await readFile(resolve(root, 'CANDIDATE04-INPUTS-329.json'), 'utf8'));
const providerSHA256 = inputs['src/rendering/interior-props.ts'];
const plan = JSON.parse(await readFile(resolve(root, 'PLAN.json'), 'utf8'));
assert.equal(sha(await readFile(resolve(root, 'candidate04-source/src/rendering/interior-props.ts'))), providerSHA256);
const entries: object[] = [];
let checkedTriangles = 0;

function measure(object: THREE.Object3D) {
  object.updateMatrixWorld(true);
  const box = new THREE.Box3().setFromObject(object, true);
  assert.ok(!box.isEmpty());
  return { min: { x: box.min.x, y: box.min.y, z: box.min.z }, max: { x: box.max.x, y: box.max.y, z: box.max.z },
    dimensions: Object.fromEntries(['x', 'y', 'z'].map(axis => [axis, box.max[axis as 'x'] - box.min[axis as 'x']])) };
}
function inspect(object: THREE.Object3D) {
  let meshes = 0, triangles = 0;
  object.traverse(node => {
    if (!(node instanceof THREE.Mesh)) return;
    meshes++;
    const geometry = node.geometry, positions = geometry.getAttribute('position'), normals = geometry.getAttribute('normal');
    assert.ok(positions && normals);
    assert.ok(Array.from(positions.array).every(Number.isFinite));
    assert.ok(Array.from(normals.array).every(Number.isFinite));
    const indices = geometry.getIndex();
    const count = indices?.count ?? positions.count;
    assert.equal(count % 3, 0);
    for (let i = 0; i < count; i += 3) {
      const vertices = [0, 1, 2].map(j => new THREE.Vector3().fromBufferAttribute(positions, indices ? indices.getX(i + j) : i + j));
      assert.ok(new THREE.Triangle(vertices[0], vertices[1], vertices[2]).getArea() > 1e-12);
    }
    triangles += count / 3;
  });
  return { meshes, triangles };
}
function closeBounds(actual: ReturnType<typeof measure>, expected: ReturnType<typeof measure>) {
  for (const side of ['min', 'max'] as const) for (const axis of ['x', 'y', 'z'] as const)
    assert.ok(Math.abs(actual[side][axis] - expected[side][axis]) < 2e-6, `readback ${side}.${axis} differs from original provider geometry`);
}
function dispose(object: THREE.Object3D) {
  object.traverse(node => { if (!(node instanceof THREE.Mesh)) return; node.geometry.dispose();
    for (const material of Array.isArray(node.material) ? node.material : [node.material]) material.dispose(); });
}

for (const id of ids) {
  const asset = buildInteriorPropAsset(id), group = new THREE.Group();
  group.name = `Yunshan original ${id}`;
  group.userData = { assetId: id, version: asset.version, unit: 'metre', origin: 'floor-centred; +Y up; +Z front',
    logicalHull: asset.logicalHull, interaction: asset.interaction, placement: asset.placement,
    sourceGraphSHA256: plan.sourceGraphSHA256, providerSHA256 };
  for (const [i, part] of asset.parts.entries()) {
    let geometry: THREE.BufferGeometry;
    if (part.template) {
      geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.Float32BufferAttribute(part.template.positions, 3));
      geometry.setAttribute('normal', new THREE.Float32BufferAttribute(part.template.normals, 3));
      geometry.setAttribute('uv', new THREE.Float32BufferAttribute(part.template.uvs, 2));
      geometry.setIndex(part.template.indices);
    } else geometry = new THREE.BoxGeometry(1, 1, 1);
    const cloth = part.material === 'cloth' || part.material === 'fabric', metal = part.material === 'metal', glass = part.material === 'glass';
    const material = new THREE.MeshStandardMaterial({ color: part.color, roughness: cloth ? .96 : glass ? .25 : metal ? .42 : .83,
      metalness: metal ? .72 : glass ? .32 : cloth ? 0 : .05 });
    material.name = `${id}_${i}_${part.material}`;
    const mesh = new THREE.Mesh(geometry, material);
    mesh.name = `${id}_part_${i}`;
    mesh.position.set(part.position.x, part.position.y, part.position.z);
    mesh.scale.set(part.size.x, part.size.y, part.size.z);
    mesh.userData = { providerMaterial: part.material, template: part.template?.key ?? 'box', facadeHint: part.facade ?? null };
    group.add(mesh);
  }
  const originalBounds = measure(group), originalGeometry = inspect(group);
  for (const axis of ['x', 'y', 'z'] as const) {
    assert.ok(originalBounds.min[axis] >= asset.logicalHull.min[axis] - 1e-6);
    assert.ok(originalBounds.max[axis] <= asset.logicalHull.max[axis] + 1e-6);
  }

  const exported = await new GLTFExporter().parseAsync(group, { binary: true, onlyVisible: true });
  assert.ok(exported instanceof ArrayBuffer);
  const glb = Buffer.from(exported), header = new DataView(exported);
  assert.equal(header.getUint32(0, true), 0x46546c67); assert.equal(header.getUint32(4, true), 2); assert.equal(header.getUint32(8, true), glb.length);
  assert.equal(header.getUint32(16, true), 0x4e4f534a);
  const gltfJson = JSON.parse(glb.subarray(20, 20 + header.getUint32(12, true)).toString('utf8'));
  assert.ok(!gltfJson.images && !gltfJson.textures);
  assert.ok(gltfJson.buffers.every((buffer: { uri?: string }) => !buffer.uri));
  const decoded = await new GLTFLoader().parseAsync(exported, '');
  const glbBounds = measure(decoded.scene), glbGeometry = inspect(decoded.scene);
  closeBounds(glbBounds, originalBounds); assert.deepEqual(glbGeometry, originalGeometry);

  let mtl = `# Yunshan original ${id}; units metres. No external textures.\n`;
  group.traverse(node => {
    if (!(node instanceof THREE.Mesh)) return;
    const material = node.material as THREE.MeshStandardMaterial, srgb = material.color.clone().convertLinearToSRGB();
    mtl += `newmtl ${material.name}\nKa 0 0 0\nKd ${srgb.r} ${srgb.g} ${srgb.b}\nKs ${material.metalness} ${material.metalness} ${material.metalness}\nNs ${(1 - material.roughness) * 1000}\nd 1\nillum 2\n\n`;
  });
  const obj = `# Yunshan ${id}; 1 unit = 1 metre; +Y up; +Z front; floor-centred origin.\nmtllib ${id}.mtl\n` + new OBJExporter().parse(group);
  const creator = new MTLLoader().parse(mtl, ''); creator.preload();
  const objDecoded = new OBJLoader().setMaterials(creator).parse(obj);
  const objBounds = measure(objDecoded), objGeometry = inspect(objDecoded);
  closeBounds(objBounds, originalBounds); assert.equal(objGeometry.triangles, originalGeometry.triangles); assert.equal(objGeometry.meshes, originalGeometry.meshes);
  const originals = { [`${id}.glb`]: glb, [`${id}.obj`]: obj, [`${id}.mtl`]: mtl,
    [`${id}.geometry.json`]: JSON.stringify({ ...asset, sourceGraphSHA256: plan.sourceGraphSHA256, providerSHA256 }, null, 2) + '\n' };
  const files: object[] = [];
  for (const [name, data] of Object.entries(originals)) {
    const path = resolve(destination, name); await writeFile(path, data);
    const saved = await readFile(path); assert.equal(sha(saved), sha(data));
    files.push({ path: `assets/models/${name}`, bytes: saved.length, sha256: sha(saved) });
  }
  entries.push({ id, unit: 'metre', logicalDimensions: asset.dimensions, logicalHull: asset.logicalHull,
    actualMeshBounds: originalBounds, geometry: originalGeometry, GLB_CPUReadback: glbGeometry, OBJ_CPUReadback: objGeometry,
    interaction: asset.interaction, placement: asset.placement, cityBinding: id === 'office-desk' ? 'existing commercial upper-floor table' : id === 'open-curtains' ? 'up to two actual sealed ground-floor home window panels' : 'prepared only; no authoritative city fixture yet',
    textures: 0, poweredDisplayOrInventedFunction: false, files });
  checkedTriangles += originalGeometry.triangles + glbGeometry.triangles + objGeometry.triangles;
  dispose(group); dispose(decoded.scene); dispose(objDecoded);
}
const manifest = { version: 'interior-props-v1', generator: 'original procedural geometry; Three.js 0.180.0 exporters',
  generatedAt: new Date().toISOString(), sourceGraphSHA256: plan.sourceGraphSHA256, providerSHA256,
  exporterDriverSHA256: sha(await readFile(fileURLToPath(import.meta.url))), sourceInputCount: 329, simulationInstances: 0, simulationSteps: 0, GPUorBrowser: 'NOT_RUN_HOLD',
  verified: 'CPU original/GLB/OBJ finite geometry, nondegenerate triangles and unchanged actual bounds; saved file readback SHA256', checkedTriangles, assets: entries };
await writeFile(resolve(root, 'assets/ASSET-MANIFEST.json'), JSON.stringify(manifest, null, 2) + '\n');
console.log(JSON.stringify({ status: 'PASS', assets: entries.length, originalFiles: entries.length * 4, checkedTriangles,
  manifestSHA256: sha(await readFile(resolve(root, 'assets/ASSET-MANIFEST.json'))), sourceGraphSHA256: plan.sourceGraphSHA256, simulationInstances: 0, simulationSteps: 0, GPUorBrowser: 'NOT_RUN_HOLD' }));

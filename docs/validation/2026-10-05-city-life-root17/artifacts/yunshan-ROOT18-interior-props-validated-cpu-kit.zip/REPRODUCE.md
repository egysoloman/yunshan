# 在相同已封存功能输入上复核

最终可交付候选是 candidate04-source 与 CANDIDATE04-INPUTS-329.json；candidate-source、candidate02-source、candidate03-source 及全部原运行目录用于保留先前观察。先核验 CLOSURE.json/封装内 SHA，再运行。此包不包含 node_modules，可按原 package-lock.json 安装正常依赖；安装不等于已验证。

严格类型与构建命令：

```sh
npm run build
```

纯几何回归命令（在最终 candidate04-source 内）：

```sh
node --import tsx --test --test-isolation=process --test-concurrency=1 tests/interior-props.test.ts tests/rendering-street-life.test.ts tests/architecture-wall-finish.test.ts tests/rendering-city-readability.test.ts
```

封装根目录的 run-phase.py 记录固定上限、输入与观测到的进程。原始 argv / cwd / 时间见各目录 receipt.json；重新运行必须用新的输出目录，不能覆盖旧运行目录。

模型导出命令（确保封装根目录 node_modules 能解析相同 Three.js / tsx）：

```sh
node --import tsx export-assets.mts
python3 preview-assets.py
```

上述导出脚本绑定候选04路径和329输入；移到不同根目录后允许保持相同相对结构。运行将更新 assets，不可在已封存原包内原地重跑；请先复制工作副本。NodeBinaryFileReader 仅供无图像 binary GLB 的 CPU 导出，未创建 browser/Canvas。CPU预览另需 numpy/matplotlib，图未被当作游戏截图。

标准 patch 在 source327 原封存候选上只读复核的实际命令：

```sh
patch --dry-run --batch -p1 -i candidate04.patch
```

以上纯调用没有 new Simulation 或 .step。实际 GPU 与玩家流程仍需由父任务安排新的串行窗口，不能用 ROOT17 旧 GPU 的截图或 PASS/FAIL 冒充 candidate04 的结果。

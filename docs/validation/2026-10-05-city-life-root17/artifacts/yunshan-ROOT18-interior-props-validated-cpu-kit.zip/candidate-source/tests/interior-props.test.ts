import assert from 'node:assert/strict';
import test from 'node:test';
import * as THREE from 'three';
import { createHash } from 'node:crypto';
import { getBuildingBody, wallPanels, type FloorFixture, type WallPanel } from '../src/architecture-floor-plan';
import { createWorld } from '../src/world';
import { buildProgramArchitecture, programLinenTemplate, type ProgramArchitecturePart } from '../src/rendering/architecture-bodies';
import { buildInteriorPropAsset, HOME_CURTAIN_WINDOW_BUDGET, interiorCurtainTemplate, officeDeskFixtureParts, windowCurtainParts, type InteriorPropAssetId } from '../src/rendering/interior-props';

const ids: InteriorPropAssetId[] = ['office-desk', 'sofa', 'coffee-table', 'monitor', 'open-curtains'];
const min = (p: ProgramArchitecturePart) => ({ x: p.position.x - p.size.x / 2, y: p.position.y - p.size.y / 2, z: p.position.z - p.size.z / 2 });
const max = (p: ProgramArchitecturePart) => ({ x: p.position.x + p.size.x / 2, y: p.position.y + p.size.y / 2, z: p.position.z + p.size.z / 2 });

test('five reusable original assets have human-scale metre hulls and no invented interaction', () => {
  const expected = [{ x: 2.4, y: .8, z: 1.2 }, { x: 2.2, y: .8, z: .8 }, { x: 1.2, y: .4, z: .8 }, { x: .6, y: .6, z: .2 }, { x: 2, y: 1.4, z: .2 }];
  for (const [i, id] of ids.entries()) {
    const asset = buildInteriorPropAsset(id); assert.deepEqual(asset.dimensions, expected[i]);
    assert.equal(asset.interaction, 'none'); assert.equal(asset.placement, 'prepared-unplaced'); assert.equal(asset.version, 'interior-props-v1');
    assert.ok(asset.parts.length > 0 && asset.parts.length <= 8);
    for (const p of asset.parts) {
      const a = min(p), b = max(p); assert.ok(Object.values(p.size).every(n => Number.isFinite(n) && n > 0));
      for (const axis of ['x', 'y', 'z'] as const) assert.ok(a[axis] >= asset.logicalHull.min[axis] - 1e-8 && b[axis] <= asset.logicalHull.max[axis] + 1e-8, `${id} component escaped its metre hull`);
    }
  }
});

test('folded cloth is closed outward-facing finite geometry with a shared bounded template', () => {
  for (const axis of ['x', 'z'] as const) {
    const a = interiorCurtainTemplate(axis); assert.equal(interiorCurtainTemplate(axis), a); assert.equal(a.indices.length / 3, 52);
    assert.equal(a.positions.length, a.normals.length); assert.equal(a.uvs.length, a.positions.length / 3 * 2);
    assert.ok([...a.positions, ...a.normals, ...a.uvs].every(Number.isFinite));
    assert.ok(a.positions.every(x => x >= -.5 - 1e-8 && x <= .5 + 1e-8));
    let volume = 0;
    for (let i = 0; i < a.indices.length; i += 3) {
      const vs = a.indices.slice(i, i + 3).map(index => new THREE.Vector3(...a.positions.slice(index * 3, index * 3 + 3) as [number, number, number]));
      assert.ok(new THREE.Triangle(...vs as [THREE.Vector3, THREE.Vector3, THREE.Vector3]).getArea() > 1e-8);
      volume += vs[0].dot(new THREE.Vector3().crossVectors(vs[1], vs[2])) / 6;
    }
    assert.ok(volume > .1 && volume < .3, 'closed cloth normals face out rather than inside');
    for (let i = 0; i < a.normals.length; i += 3) assert.ok(Math.abs(Math.hypot(...a.normals.slice(i, i + 3)) - 1) < 1e-6);
  }
});

test('desk adapter retains real table occupancy and rejects beds counters and undersized solids', () => {
  const fixture: FloorFixture = { id: 'actual-office-table', kind: 'table', rect: { x0: 3, x1: 5.4, z0: -4, z1: -2.8 }, bottom: 0, top: .8 };
  const before = JSON.stringify(fixture), plan = { floor: 6, y: 26.4 }, desk = officeDeskFixtureParts(fixture, plan); assert.equal(desk.length, 8);
  for (const p of desk) { const a = min(p), b = max(p); assert.equal(p.propHostId, fixture.id); assert.equal(p.propAssetId, 'office-desk'); assert.equal(p.floor, 6);
    assert.ok(a.x >= 3 - 1e-8 && b.x <= 5.4 + 1e-8 && a.z >= -4 - 1e-8 && b.z <= -2.8 + 1e-8 && a.y >= 26.4 - 1e-8 && b.y <= 27.2 + 1e-8); }
  for (const kind of ['bed', 'counter', 'shelf'] as const) assert.deepEqual(officeDeskFixtureParts({ ...fixture, kind }, plan), []);
  assert.deepEqual(officeDeskFixtureParts({ ...fixture, top: .2 }, plan), []); assert.deepEqual(officeDeskFixtureParts({ ...fixture, top: NaN }, plan), []);
  assert.equal(JSON.stringify(fixture), before);
});

test('both curtain orientations retain actual sealed window bounds and an open centre', () => {
  for (const thinX of [true, false]) {
    const panel: WallPanel = { kind: 'glass', bottom: .8, top: 2.2, rect: thinX ? { x0: 4, x1: 4.4, z0: -2, z1: -.4 } : { x0: -2, x1: -.4, z0: 4, z1: 4.4 } };
    const original = JSON.stringify(panel), parts = windowCurtainParts(panel, { floor: 0, y: 0 }, 'real-window'); assert.equal(parts.length, 3);
    for (const p of parts) { const a = min(p), b = max(p); assert.equal(p.purpose, 'curtain'); assert.equal(p.propHostId, 'real-window');
      assert.ok(a.x >= panel.rect.x0 - 1e-8 && b.x <= panel.rect.x1 + 1e-8 && a.z >= panel.rect.z0 - 1e-8 && b.z <= panel.rect.z1 + 1e-8 && a.y >= .8 - 1e-8 && b.y <= 2.2 + 1e-8); }
    const cloth = parts.filter(p => p.material === 'fabric'); assert.equal(cloth.length, 2);
    const centre = thinX ? (panel.rect.z0 + panel.rect.z1) / 2 : (panel.rect.x0 + panel.rect.x1) / 2;
    assert.ok(cloth.every(p => thinX ? max(p).z < centre || min(p).z > centre : max(p).x < centre || min(p).x > centre));
    assert.deepEqual(windowCurtainParts({ ...panel, kind: 'solid' }, { floor: 0, y: 0 }, 'not-a-window'), []);
    assert.equal(JSON.stringify(panel), original);
  }
});

test('actual city desk and curtain bindings preserve all authoritative geometry use points beds and far LOD', () => {
  const world = createWorld(), original = JSON.stringify(world), linen = JSON.stringify(programLinenTemplate()); let desks = 0, curtainWindows = 0, houses = 0;
  for (const building of world.buildings) {
    const body = getBuildingBody(building); if (!body) continue;
    const before = JSON.stringify(body), near = buildProgramArchitecture(building, 'near')!, far = buildProgramArchitecture(building, 'far')!;
    assert.ok(far.every(p => !p.propAssetId), 'prepared assets cannot grow the far renderer');
    for (const plan of body.floorPlans) {
      const desk = near.filter(p => p.floor === plan.floor && p.propAssetId === 'office-desk');
      if (desk.length) { assert.equal(building.commercialGeometryRevision, 1); assert.ok(plan.floor >= 2); assert.equal(desk.length % 8, 0); desks += desk.length / 8;
        for (const p of desk) { const fixture = plan.fixtures.find(f => f.id === p.propHostId)!; assert.ok(fixture); assert.equal(fixture.kind, 'table'); } }
      const curtains = near.filter(p => p.floor === plan.floor && p.purpose === 'curtain');
      if (curtains.length) { assert.equal(building.kind, 'home'); assert.equal(plan.floor, 0); assert.ok(curtains.length <= HOME_CURTAIN_WINDOW_BUDGET * 3); houses++; curtainWindows += curtains.length / 3;
        for (const p of curtains) { const index = Number(p.propHostId!.split(':')[1]), glass = wallPanels(plan)[index]; assert.equal(glass.kind, 'glass'); const a = min(p), b = max(p);
          assert.ok(a.x >= glass.rect.x0 - 1e-7 && b.x <= glass.rect.x1 + 1e-7 && a.z >= glass.rect.z0 - 1e-7 && b.z <= glass.rect.z1 + 1e-7 && a.y >= plan.y + glass.bottom - 1e-7 && b.y <= plan.y + glass.top + 1e-7); } }
    }
    assert.equal(JSON.stringify(body), before, 'semantic furniture and door/collision geometry cannot be edited by rendering');
    assert.ok(near.every(p => !['sofa', 'monitor', 'coffee-table'].includes(p.propAssetId ?? '')), 'missing authoritative hosts keep prepared models unplaced');
  }
  assert.ok(desks > 100 && houses > 100 && curtainWindows > 200); assert.equal(JSON.stringify(programLinenTemplate()), linen);
  assert.equal(JSON.stringify(world), original); assert.equal(createHash('sha256').update(original).digest('hex'), '2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512');
  console.log(JSON.stringify({ scope: 'pure-geometry-no-simulation', buildings: world.buildings.length, desks, houses, curtainWindows, unchangedWorld: true }));
});

test('legacy worlds without semantic programme bodies do not acquire free interior props', () => {
  const legacy = createWorld(20261001, 'current-v3'), before = JSON.stringify(legacy);
  for (const building of legacy.buildings) assert.equal(buildProgramArchitecture(building, 'near'), null);
  assert.equal(JSON.stringify(legacy), before);
});

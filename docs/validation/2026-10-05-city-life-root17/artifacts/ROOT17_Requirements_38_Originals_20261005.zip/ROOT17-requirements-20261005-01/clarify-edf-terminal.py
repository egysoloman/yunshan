from pathlib import Path
import csv, datetime, hashlib, json
ROOT=Path('/tmp/ROOT17-requirements-20261005-01')
CSV=ROOT/'MATRIX-38-AUDIT.csv'
BASE=Path('/workspace/yunshan/docs/validation/2026-10-05-city-life-root16/evidence/requirements/MATRIX-38-AUDIT.csv')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(CSV)=='8e199069438988c72077dfffa7bb00354b757dd0b9c048dd41d1edac89689ecd'
PREV=ROOT/'MATRIX-38-NEXT-ACCEPTANCE-04-00.csv'
assert not PREV.exists();PREV.write_bytes(CSV.read_bytes())
with CSV.open(encoding='utf-8-sig',newline='') as f:
 reader=csv.DictReader(f);cols=reader.fieldnames;rows=list(reader)
before=[dict(r) for r in rows]
replacements={
'SYS-01':('旧325/新351各16逐全save同原f4b','旧325/新351各16步逐全save相同并匹配16个原SHA，终档同原F4B'),
'SAVE-01':('原325/新351各16每save同f4b','原325/新351各16步逐全save相同并匹配16个原SHA，终档同原F4B'),
}
for r in rows:
 if r['id'] in replacements:
  old,new=replacements[r['id']];assert r['latest_actual_run'].count(old)==1
  r['latest_actual_run']=r['latest_actual_run'].replace(old,new)
with CSV.open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=cols,lineterminator='\r\n');w.writeheader();w.writerows(rows)
with BASE.open(encoding='utf-8-sig',newline='') as f:original=list(csv.DictReader(f))
preserved=['id','domain','original_requirement','original_asof1439_validation','original_missing_or_blocked','latest_complete_requirement']
for a,b,c in zip(original,before,rows):
 assert all(a[k]==c[k] for k in preserved)
 assert all(b[k]==c[k] for k in cols if k!='latest_actual_run')
receipt={
'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'status':'FINAL_CSV_PRECISE_PER_TICK_VERSUS_TERMINAL_EDF_WORDING',
'previousSHA256':sha(PREV),'finalSHA256':sha(CSV),'finalBytes':CSV.stat().st_size,
'rows':38,'columns':11,'preservedColumns':preserved,
'onlyChangesFromRevision03':[{'id':i,'field':'latest_actual_run'} for i in replacements],
'originalRoot16SHA256':sha(BASE),'initialSHA256':sha(ROOT/'MATRIX-38-INITIAL-03-44.csv'),
'allRemainingFieldsUnchangedFromRevision03':True,
'reason':'Independent readonly review: each old/new save equals corresponding frozen per-tick SHA; only tick16 terminal equals F4B.',
'childSimulations':0,'childSteps':0,'childCommands':0,'childBuilds':0,'childTests':0,'childGPU':0,
'noSharedEdits':True,'noGitWrite':True,'noLibraryWrite':True,
}
(ROOT/'RECONCILIATION-RECEIPT04.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(receipt,ensure_ascii=False))

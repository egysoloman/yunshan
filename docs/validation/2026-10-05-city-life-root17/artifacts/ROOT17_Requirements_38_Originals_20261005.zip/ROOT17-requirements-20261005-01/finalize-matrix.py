from pathlib import Path
import csv
import datetime
import hashlib
import json

ROOT = Path('/tmp/ROOT17-requirements-20261005-01')
BASE = Path('/workspace/yunshan/docs/validation/2026-10-05-city-life-root16/evidence/requirements/MATRIX-38-AUDIT.csv')
CSV = ROOT / 'MATRIX-38-AUDIT.csv'
INITIAL = ROOT / 'MATRIX-38-INITIAL-03-44.csv'
assert not INITIAL.exists()
assert hashlib.sha256(CSV.read_bytes()).hexdigest() == '2388a90f288103b7c3c98b54bdb1f8caabadc520ba58e2c994e247815a834e87'
INITIAL.write_bytes(CSV.read_bytes())
with CSV.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    columns = reader.fieldnames
    rows = list(reader)
with BASE.open(encoding='utf-8-sig', newline='') as stream:
    old = list(csv.DictReader(stream))
changes = {
    'SYS-01': {
        'latest_actual_run': 'source09=349的23模块142/142 PASS（Node273.6567s/wall274.0107s）；source10=351 build21.8297s/影响18PASS；最终351真EDF104普通calls/191.478627s PASS，旧325/新351各16逐全save同原f4b，真实显式升级与whole/实盘124parts三实例future24逐字；GPU NEW02两真实PNG/readonlyUI PASS192.572791s。见/tmp/ROOT17-default-edf-integration-20261005-02/REPORT.md与/tmp/ROOT17-integrated-gpu-20261005-02/actual01/receipt.json。',
        'latest_verified_boundary': 'PARTIAL：同核无renderer/最终完整旧档兼容与显式升级续演、真实出生/受控门前E/只读诊断点击已验；142与18是不同冻结scope，不冒同次全suite或完整2D/3D自然旅程。',
    },
    'MAP-02': {
        'latest_verified_boundary': 'PARTIAL：两组真参数只读诊断PASS；默认两人安置容量/连路可行仍保原住所/consent/canExecute=false，医疗跨区断连拒迁居；source351 NEW02实际DOM E+building-impact按钮与展开details、rAF后整份保存不变PASS；非拆迁或完整设施健康审计。',
    },
    'MAP-03': {
        'latest_actual_run': '原325/渲染327各16真实PNG/World291…与612near-far1224几何身份核同；最终351 NEW02另2真实PNG：native出生只pause、原river-b1门前+2m一次body fixture后实际E和诊断点击；shader/GL0error、整份save精确不变。/tmp/ROOT17-integrated-gpu-20261005-02/actual01/artifacts/RESULTS.json。',
        'latest_verified_boundary': 'PARTIAL / ART FAIL：351新2图技术及只读UI PASS不证明参考城市气氛；旧325/327五路点与室内采样FAIL仍保，未复验完整步行；床布料/牌匾不补齐全部家具。',
    },
    'BLD-01': {
        'latest_actual_run': '真实readonly02默认612/616与医疗47/616参数全覆盖，0Sim/0step/0cmd；source10相关18/18/buildPASS；最终351 GPU NEW02实际E/点击检查整栋改造影响/展开details、rAF后整份save不变，未执行施工安置。',
        'latest_verified_boundary': 'PARTIAL诊断/UI PASS / NOT_IMPLEMENTED整栋施工：原住户/财产工资服务保护与实际只读按钮已验，canExecute=false；预览容量/路连通过不等已同意/迁出/拆楼。',
    },
    'BLD-02': {
        'latest_actual_run': 'readonly02两真实World/save均不变：默认拟两人容量176/4→6及岗位连路可行仍blocked原住所/canExecute=false；medical容量120/56→58仍跨区断连拒；source10 18PASS，NEW02真实DOM只读评估/展开details及整份save不变；无拆迁新路实际命令。',
    },
    'FOOD-01': {
        'latest_actual_run': 'ROOT16原229全部513本人收据/128+256步恢复、616存活；真实食品90.350289736695，原day财政-9.412%/steady=false；ROOT17 compact具名28运输318步/生产0；最终351真实EDFedf正确SHA加两个marker后whole/physical124parts各future24 PASS，期间cargo-loaded/arrived均0。',
        'latest_verified_boundary': 'PARTIAL：原229已全恢复、真实EDF旧合同和升级保存续演已验；24帧货运观察0不是默认粮食闭环；旧异图14日现金-65.14%/7公司归零与当前短scope分别保，尚无长稳态。',
    },
    'TRA-01': {
        'latest_actual_run': 'compact384/真实原farm/2node/200m tick109扣160→132装具名28、tick318下一node卸具名lot，现金/粮每tick残差0，physical5parts/三实例future24逐字；旧无marker88同；最终351真EDFedf exactSHA只增envelope/runtime两marker/错SHA与重复拒、whole+physical124parts三实例24逐字。/tmp/ROOT17-default-edf-integration-20261005-02/REPORT.md。',
        'latest_verified_boundary': 'PARTIAL：有限库存实体货权运输及真实默认旧档显式升级/保存续演已证；compact生产0，默认升级后24帧cargo-loaded/arrived=0，不证明默认新一轮装卸运输、销售到账或材料链。',
        'latest_remaining': '具名仓库订单/付费派遣、供应商货款到账/零售消费者、材料产业链/跨区调度；默认真实新一轮具名运输未观察，长期供需未验证。',
    },
    'TRA-02': {
        'latest_actual_run': '旧browser11各自controlled身份/机坪功能PASS；最终351 NEW02仅出生和一次受控市场门前E/只读评估2图PASS，未运行无人机/VTOL新驾驶链或完整browser11/UI35。',
    },
    'TRA-03': {
        'latest_actual_run': '原325实际键鼠37.922m/渲染327约38.064m均前三点到达第四超时、第五未跑/冻结五点FAIL；最终351 NEW02未重跑此路线，仅原出生pause与一次market door+2m setup后实际E/只读点击/整份save不变PASS。',
        'latest_verified_boundary': 'FAIL旧五点 / PARTIAL：新2图证实readonly UI与保存稳定，不改旧步行或旧室内采样FAIL，不等普通城市连续步行或上下车/护栏净空验收。',
    },
    'LIFE-01': {
        'latest_actual_run': 'ROOT16真实18购粮/13实体合法gift/3各15休息保；ROOT17布料/幕墙CPU/build与old/new各16图，旧室内采样FAIL；最终351 NEW02受控门前实际E/检查按钮/展开details2图技术PASS、rAF后整份save逐字同；ROOT18新家居用途/GPU仍未验。',
        'latest_verified_boundary': 'PARTIAL / ART FAIL：旧有限日常和新readonlyUI/save稳定各自通过；新门前是明确一次fixture，未完整普通出生步行进屋；素材模型不等可买/摆放/使用，完整家居没有验收齐。',
    },
    'INF-01': {
        'latest_actual_run': '修缮141+24/grid67+8/粮318+24各自PASS；source10影响18与两真World只读诊断、NEW02实际检查按钮/save不变PASS；未执行供水排污消防通信等有权运营更换。',
    },
    'SAVE-01': {
        'latest_actual_run': '历史ROOT16 EDF/medical future24、ROOT17shop/freight physical5、grid future8/estate memoryparts24各scope保；最终351真EDFedf104calls PASS191.478627s：原325/新351各16每save同f4b，正确SHA只增两marker，whole+实写124地理parts重组及三实例24每全save同；NEW02两实际rAF截图before/after全save精确不变。',
        'latest_verified_boundary': 'PASS限最终351旧档/合法升级/physical124未来24与readonlyUI范围 / PARTIAL总体；旧source325完整npm OOM、3600s TIMEOUT359/280PASS/79cancel及旧16PNG五点/室内FAIL保；不同142/18不外推全套。',
        'latest_remaining': '所有组合长周期容量/live满quota与崩溃恢复、任意地图/实际WorldPatch迁移；真实EDF升级已验但默认下一轮named货运未观察，非所有旧parts范围均物理写盘。',
    },
    'ART-01': {
        'latest_actual_run': 'renderer20CPU/build/1224near-far身份PASS；原325/327各16PNG shader无error仍五路点/室内采样FAIL；最终351 NEW02两图PASS_TECHNICAL_AND_READONLY_UI/192.572791s、0error、整份save不变；NEW01等待90s失败/0图原件保。/tmp/ROOT17-integrated-gpu-20261005-02/actual01/artifacts/RESULTS.json。',
        'latest_verified_boundary': 'ART FAIL总体保留：最终351技术/只读UI两图PASS不重判旧32图FAIL，不复验五点旅程或默认参考美术；只暂停的真实出生仍有站棚遮挡，Mac未跑。',
    },
    'VAL-01': {
        'latest_actual_run': 'source09=349：build17.7524s/23模块142PASS；source10=351：build21.829689s/影响18PASS1.722816s；真EDF NEW02 104calls PASS191.478627s与physical124未来24；GPU NEW02两PNG/readonlyUI PASS192.572791s/0errors，各稳定/active[]；旧325全npm OOM/3600s TIMEOUT359/280PASS/79cancel保，不合并142+18冒同suite。',
        'latest_verified_boundary': 'PARTIAL：最终351必要全档/parts与2图技术点击scopePASS，非全npm/UI35/browser11/完整38域；旧325/327各16五点/室内FAIL、GPU NEW01等待FAIL0图、EDF NEW01旧API前件FAIL0步及医护/estate旧FAIL均保；readonly诊断可执行=false。',
    },
    'MAC-01': {
        'latest_actual_run': '原EDF perf16保存等价、people仍约25.41s；旧325/327各16图810.60/864.67s，各scopeFAIL；最终351 SwiftShader NEW02仅2图192.572791s技术/UI PASS；Mac Safari/Chrome/Firefox真实硬件/FPS仍NOT_RUN。',
    },
}
changed_fields = []
for row in rows:
    for field, value in changes.get(row['id'], {}).items():
        assert field.startswith('latest_') and field != 'latest_complete_requirement'
        changed_fields.append({'id': row['id'], 'field': field})
        row[field] = value
with CSV.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=columns, lineterminator='\r\n')
    writer.writeheader()
    writer.writerows(rows)
with CSV.open(encoding='utf-8-sig', newline='') as stream:
    result = list(csv.DictReader(stream))
assert len(result) == 38 and CSV.read_bytes().startswith(b'\xef\xbb\xbf')
preserved = ['id', 'domain', 'original_requirement', 'original_asof1439_validation', 'original_missing_or_blocked', 'latest_complete_requirement']
for before, after in zip(old, result):
    assert all(before[name] == after[name] for name in preserved)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
edf = Path('/tmp/ROOT17-default-edf-integration-20261005-02/actual01/receipt.json')
gpu = Path('/tmp/ROOT17-integrated-gpu-20261005-02/actual01/receipt.json')
for p in [edf, gpu]:
    receipt = json.loads(p.read_text())
    assert receipt['status'] == 'PASS' and receipt['inputCount'] == 351 and receipt['inputsStable'] and not receipt['activeDescendants']
receipt = {
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'FINAL_CSV_38_ROWS_REQUIREMENTS_EXACT_FINAL351_ACTUAL_EDF_GPU_EVIDENCE_RECONCILED',
    'sourceSHA256': sha(BASE), 'initialSHA256': sha(INITIAL),
    'finalSHA256': sha(CSV), 'finalBytes': CSV.stat().st_size,
    'preservedColumns': preserved, 'rows': 38, 'columns': columns,
    'changedFieldsFromInitial': changed_fields,
    'EDFReceiptPath': str(edf), 'EDFReceiptSHA256': sha(edf),
    'GPUReceiptPath': str(gpu), 'GPUReceiptSHA256': sha(gpu),
    'functionalGraph': '74aee7b713f03c51b9fd7427ed7fbfccdb60b451919c64c36295c75cb627c2be',
    'source09_142AndSource10_18AreSeparateScopes': True,
    'notFullSuiteOrComplete38': True, 'ART': 'FAIL', 'Mac': 'NOT_RUN',
    'childSimulationConstructionCount': 0, 'childSteps': 0, 'childCommands': 0,
    'noSharedEdits': True, 'noGitWrite': True, 'noLibraryWrite': True,
}
(ROOT / 'RECONCILIATION-RECEIPT02.json').write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(receipt, ensure_ascii=False))

from pathlib import Path
import csv
import datetime
import hashlib
import json
import re
import shutil
import zipfile

ROOT = Path('/tmp/ROOT17-requirements-20261005-01')
BASE = Path('/workspace/yunshan/docs/validation/2026-10-05-city-life-root16/evidence/requirements/MATRIX-38-AUDIT.csv')
CSV = ROOT / 'MATRIX-38-AUDIT.csv'
ZIP = Path('/tmp/ROOT17_Requirements_38_Originals_20261005.zip')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(CSV) == 'b749f8ca1106f9e41cdd5f6c77a7c48aac52445420fa02e8e481bb904122afb0'
assert not ZIP.exists()
originals = ROOT / 'originals'
assert not originals.exists()
originals.mkdir()
old_index = json.loads((ROOT / 'EVIDENCE-INDEX01.json').read_text())
entries = old_index['inputs']
for e in entries:
    p = Path(e['path'])
    assert p.is_file() and sha(p) == e['sha256'] and p.stat().st_size == e['bytes']
entries += [
    {'label': 'R16-matrix-original', 'path': str(BASE), 'scopeBoundary': '38行原始完整要求/历史验证/原缺项，6列逐字段不变'},
    {'label': 'R17-source09-targeted-raw', 'path': '/tmp/ROOT17-integration-20261005-01/targeted09/raw.log', 'scopeBoundary': '349输入23模块142PASS，不同于351影响18'},
    {'label': 'R17-source09-build-raw', 'path': '/tmp/ROOT17-integration-20261005-01/build09/raw.log', 'scopeBoundary': '349构建17.752381秒'},
    {'label': 'R17-source10-build-raw', 'path': '/tmp/ROOT17-integration-20261005-01/build10/raw.log', 'scopeBoundary': '351构建21.829689秒'},
    {'label': 'R17-source10-diagnosis18-raw', 'path': '/tmp/ROOT17-integration-20261005-01/building-impact10/raw.log', 'scopeBoundary': '351影响诊断18PASS独立范围'},
    {'label': 'R17-source10-EDF02-receipt', 'path': '/tmp/ROOT17-default-edf-integration-20261005-02/actual01/receipt.json', 'scopeBoundary': '最终351真EDF104calls PASS191.478627秒，stable/active[]'},
    {'label': 'R17-source10-EDF02-raw', 'path': '/tmp/ROOT17-default-edf-integration-20261005-02/actual01/raw.log', 'scopeBoundary': '每旧新tick对应SHA，终档F4B；whole/physical124parts未来24'},
    {'label': 'R17-EDF01-oldAPI-fail-receipt', 'path': '/tmp/ROOT17-default-edf-integration-20261005-01/actual01/receipt.json', 'scopeBoundary': '旧325缺新增API前件FAIL，原EDF导出先通过，0steps'},
    {'label': 'R17-EDF01-oldAPI-fail-raw', 'path': '/tmp/ROOT17-default-edf-integration-20261005-01/actual01/raw.log', 'scopeBoundary': '封存前件FAIL原始输出，不改为PASS'},
    {'label': 'R17-source10-GPU02-receipt', 'path': '/tmp/ROOT17-integrated-gpu-20261005-02/actual01/receipt.json', 'scopeBoundary': '351技术/readonlyUI两图PASS192.572791秒，stable/active[]'},
    {'label': 'R17-source10-GPU02-results', 'path': '/tmp/ROOT17-integrated-gpu-20261005-02/actual01/artifacts/RESULTS.json', 'scopeBoundary': '真实出生仅pause；明确一次门前fixture后DOM E/诊断点击/rAF全save不变；ART仍FAIL'},
    {'label': 'R17-source10-GPU02-raw', 'path': '/tmp/ROOT17-integrated-gpu-20261005-02/actual01/raw.log', 'scopeBoundary': '两scope实际输出，不替旧5waypoints/UI35/browser11/Mac'},
    {'label': 'R17-source10-GPU02-native-birth', 'path': '/tmp/ROOT17-integrated-gpu-20261005-02/actual01/artifacts/native-birth-paused.png', 'scopeBoundary': '原身体原出生只nativepause，真实截图，不达参考美术'},
    {'label': 'R17-source10-GPU02-actual-E-impact', 'path': '/tmp/ROOT17-integrated-gpu-20261005-02/actual01/artifacts/actual-E-market-and-building-impact.png', 'scopeBoundary': '明确原river-b1门前+2m一次fixture后实际E/按钮/展开details，不是自然整程步行或拆楼'},
    {'label': 'R17-source10-GPU01-wait-fail-receipt', 'path': '/tmp/ROOT17-integrated-gpu-20261005-01/actual01/receipt.json', 'scopeBoundary': '首次351等待90000ms FAIL/0captures，原件保留'},
    {'label': 'R17-source10-GPU01-wait-fail-results', 'path': '/tmp/ROOT17-integrated-gpu-20261005-01/actual01/artifacts/RESULTS.json', 'scopeBoundary': '旧waitForFunction超时，不改判美术或第二次PASS'},
    {'label': 'R17-source10-GPU01-wait-fail-raw', 'path': '/tmp/ROOT17-integrated-gpu-20261005-01/actual01/raw.log', 'scopeBoundary': '首次失败原始输出'},
]
labels = [e['label'] for e in entries]
assert len(labels) == len(set(labels))
for e in entries:
    p = Path(e['path'])
    if e['label'] == 'R17-source10-EDF02':
        e['scopeBoundary'] = '最终351真EDF104calls、准确SHA两marker升级与whole/physical124parts未来24通过；默认新具名运输观察0'
    e['bytes'] = p.stat().st_size
    e['sha256'] = sha(p)
    out = originals / (e['label'] + p.suffix)
    shutil.copyfile(p, out)
    assert sha(out) == e['sha256']
    e['archivePath'] = str(out.relative_to(ROOT))
index = {
    'capturedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'FINAL_MATRIX_EVIDENCE_ORIGINALS_COPIED_AND_SHA_VERIFIED',
    'matrixSHA256': sha(CSV),
    'functionalGraph': '74aee7b713f03c51b9fd7427ed7fbfccdb60b451919c64c36295c75cb627c2be',
    'inputs': entries,
    'source349_142AndSource351_18SeparateScopes': True,
    'scope': 'Readonly documentary reconciliation; no new project executions.',
    'childSimulations': 0, 'childSteps': 0, 'childCommands': 0,
    'childBuilds': 0, 'childTests': 0, 'childGPU': 0,
    'noSharedEdits': True, 'noGitWrite': True, 'noLibraryWrite': True,
    'LibraryID': None,
}
(ROOT / 'EVIDENCE-INDEX02.json').write_text(json.dumps(index, indent=2, ensure_ascii=False) + '\n')
with BASE.open(encoding='utf-8-sig', newline='') as f:
    reader = csv.DictReader(f); original_columns = reader.fieldnames; original_rows = list(reader)
with CSV.open(encoding='utf-8-sig', newline='') as f:
    reader = csv.DictReader(f); final_columns = reader.fieldnames; final_rows = list(reader)
preserved = ['id', 'domain', 'original_requirement', 'original_asof1439_validation', 'original_missing_or_blocked', 'latest_complete_requirement']
assert len(final_rows) == len(original_rows) == 38 and final_columns == original_columns
assert CSV.read_bytes().startswith(b'\xef\xbb\xbf')
assert all(all(a[k] == b[k] for k in preserved) for a, b in zip(original_rows, final_rows))
assert all(all(row[k] for k in final_columns) for row in final_rows)
files = sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name not in {'CLOSURE.json', 'PACKAGE-RECEIPT.json'})
pattern = re.compile(rb'(?:tsk_[A-Za-z0-9_-]{20,}|sk-[A-Za-z0-9_-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
assert not any(pattern.search(p.read_bytes()) for p in files)
closure = {
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'MATRIX_38_ORIGINALS_CLOSURE',
    'files': [{'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files],
    'fileCountExcludingClosure': len(files), 'contentBytesExcludingClosure': sum(p.stat().st_size for p in files),
    'matrixSHA256': sha(CSV), 'root16OriginalSHA256': sha(BASE),
    'rows': 38, 'columns': 11, 'utf8BOM': True, 'preservedColumnsExact': preserved,
    'secretPatternMatches': 0, 'LibraryID': None,
    'allProjectExecutionsByThisMatrixTask': 0,
    'noSharedEdits': True, 'noGitWrite': True, 'noLibraryWrite': True,
    'boundary': 'This is a requirements/evidence closure, not full game source/save replay closure or certification that all 38 requirements are complete. Parent owns broader original archives and Library upload.',
}
(ROOT / 'CLOSURE.json').write_text(json.dumps(closure, indent=2, ensure_ascii=False) + '\n')
with zipfile.ZipFile(ZIP, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for p in files + [ROOT / 'CLOSURE.json']:
        archive.write(p, arcname='ROOT17-requirements-20261005-01/' + str(p.relative_to(ROOT)))
with zipfile.ZipFile(ZIP) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(files) + 1
    for e in closure['files']:
        data = archive.read('ROOT17-requirements-20261005-01/' + e['path'])
        assert len(data) == e['bytes'] and hashlib.sha256(data).hexdigest() == e['sha256']
    assert archive.read('ROOT17-requirements-20261005-01/CLOSURE.json') == (ROOT / 'CLOSURE.json').read_bytes()
receipt = {
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'PASS_CRC_EVERY_ORIGINAL_SHA_AND_PRESERVED_REQUIREMENT_CELLS',
    'zipPath': str(ZIP), 'zipSHA256': sha(ZIP), 'zipBytes': ZIP.stat().st_size,
    'zipEntries': len(files) + 1, 'closureSHA256': sha(ROOT / 'CLOSURE.json'),
    'matrixPath': str(CSV), 'matrixSHA256': sha(CSV), 'matrixBytes': CSV.stat().st_size,
    'originalEvidenceFiles': len(entries), 'rows': 38, 'columns': 11,
    'preservedOriginalCells': 38 * len(preserved),
    'LibraryID': None, 'LibraryUploadOwner': 'Parent root consolidated original producer',
    'noSharedEdits': True, 'noGitWrite': True, 'noLibraryWrite': True,
}
(ROOT / 'PACKAGE-RECEIPT.json').write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(receipt, ensure_ascii=False))

"""Read-only evidence reconciliation; writes only this new audit namespace."""
from pathlib import Path
import csv
import datetime
import hashlib
import json

BASE = Path('/workspace/yunshan/docs/validation/2026-10-05-city-life-root16/evidence/requirements/MATRIX-38-AUDIT.csv')
OUT = Path('/tmp/ROOT17-requirements-20261005-01')
FIELDS = ['latest_implemented', 'latest_actual_run', 'latest_verified_boundary', 'latest_remaining', 'latest_next_acceptance']

# Each five-tuple preserves the original complete requirement and changes only
# implementation/run/verification/remaining/next evidence, without simulation.
UPDATES = {
    'SYS-01': (
        '既有无renderer数值Simulation/WorldDefinition与固定十阶段；ROOT17 source09隔离接合旧合同、有限电网、显式道路装粮、医疗/遗产/修缮守卫和几何查询优化，349输入；尚非共享安装回执。',
        'ROOT16真实默认612/616城一天、原229恢复及whole/parts未来24；ROOT17 source09 build退出0/17.7524s，23模块142/142 PASS（Node273.6567s；wall274.0107s）；见/tmp/ROOT17-integration-20261005-01/{build09,targeted09}/receipt.json。',
        'PARTIAL：无renderer业务实际运行；142仅14新模块+9原相关模块，不是全部系统完成；当前组合EDF/全UI/GPU尚待新回执。',
        '完整2D/文字产品、部分私有耦合/直接state暴露、合法移动宿主接线；setFocus写身体仍不能冒普通步行。',
        '新组合原档与合法命令/移动在headless、2D、3D逐tick钱物/任务/保存一致；另记录控制输入与普通玩家路径。'),
    'MAP-01': (
        '参数化WorldDefinition、受信recipe/fingerprint/ACL引用；可显式声明有限储能电网及道路装粮政策，旧未声明图保旧未来；任意地图适配未开放。',
        'ROOT17四建筑/384人/0载具受控另一城电网67调用+便携8旧档基准PASS；紧凑原农场/2节点200m物流318步+24 PASS；来源/tmp/ROOT17-power-network-20261005-01/REPORT12.md与/tmp/ROOT17-freight-close-20261005-01/REPORT.md。',
        'PARTIAL：两个明确参数小图可运行不等完整另一城市；旧无声明电网保存不暗升；任意GIS/程序生成与地图迁移NOT_VERIFIED。',
        '任意地图导入/设施能力映射/坐标地形与人口就业配方；legacy能源固定ID仍在旧分支；真实地图和动态拓扑迁移欠。',
        '两完整不同拓扑/设施ID城市声明人口和容量；缺项可诊断，合法路程/ACL/经济/旧新保存未来24各实跑。'),
    'MAP-02': (
        '既有食品访问CLI与真实门路/车道查询；有限电网分表缺供诊断；ROOT18 building-alteration为只读拟拆/拟路影响分析候选，不执行WorldPatch。',
        'ROOT17原1342有向路端×47生产者=63074纯参数对，旧humanoid47/car0明确定位；ROOT18候选13纯与类型PASS见/tmp/ROOT18-dynamic-city-20261005-01/{pure01,types01}/receipt.json，0Sim/0step；当前候选尚未共享。',
        'PARTIAL：纯诊断能列真实缺引用/被切通勤/权利债务等范围；不是实际拆迁、统一城市健康能力审计或完整替代城市验收。',
        '完整设施/容量/环境/跨区供应统一健康报告；拟拆诊断后真实有权事务、居民安置与审批资金仍未实施。',
        '冻结当前真实World/完整save运行只读报告并核输入不变；随后另有权有限项目验证报告所指缺项，不能把预览变更当完工。'),
    'MAP-03': (
        '既有v6 612楼/616人/11区/674节点/691边、5商业高楼/137实体商业层、30层天枢阁；ROOT17增加真实站柱路标、机构牌、商业幕墙与原床布料。',
        'ROOT17原325/渲染327各16张实际PNG，World同2912839d…；612 near/far1224几何身份核对；/tmp/ROOT17-visual-gpu-20261005-01/{baseline-gpu01,candidate-gpu01}/artifacts/RESULTS.json。',
        'PARTIAL / ART FAIL：城市计数与有商业高楼已核；两GPUscope均native五路点及室内状态采样FAIL，不认证参考图城市气氛或最终349组合画面。',
        '出生桥站棚遮挡、空街/重复立面、街院/植被/机场景观/家具密度与跨山层次仍欠。',
        '同普通出生/原身体连续键鼠步行、进楼及昼夜原PNG对照参考；可辨街区用途、人群和全景尺度。'),
    'ENG-01': (
        'legacy聚合电力/真实有限维修保留；ROOT17可选finite-storage-network显式节点/线缆容量、建筑与交通分表、最大流/库存/缺供、当前通电paid生产；默认612城未启用新电网。',
        '候选11受控4楼/384人/0车67普通调用PASS；实购41食物、原35工作托管，有电产粮.3666667/耗尽9PMinutes产粮0，断北馈线农场关而南店开；candidate12额外8旧保存SHA PASS。组合source09含原power及新grid相关142scope。证据/tmp/ROOT17-power-network-20261005-01/REPORT12.md。',
        'PARTIAL：有限储能/支路容量/缺供/旧合同窄验证；无隐式发电充值；功率P模型、受控声明资产不等默认实际建网或完整发电产业。',
        '合法设备产权、有限铺线工料/充电/发电燃料链/故障修缮、航空用能/本地灯火、车辆换馈线实景与长稳态欠。',
        '实际居民有权购置设备与材料/工班施工→燃料或合法产能源→某支路断电/修复；总库存/负荷/其他区账不造能。'),
    'ENG-02': (
        '新图可声明有限储能、source/node/link及building/transport接入；缺/空/岛馈线明确失供，旧未声明图保持legacy；有声明图拒直接跳钟保护真实耗能历史。',
        '同ROOT17电网67+便携8受控另一城；whole与4个World辅助parts重组/三实例未来8逐字，恶改储能/给旧图注入新资产原子拒绝；REPORT12.md。',
        'PARTIAL：显式有限网络适配PASS；不能把旧缺ID的legacy聚合回退称新城发电成功；默认612及真实车辆跨馈线未验。',
        '能源设施建设映射/真实source经营/电网扩建、账单欠费救济；四utility命令仅类型/适配契约无handler，保持未实现。',
        '另一完整城市按有权资产声明配置，未供/缺引用报告；真实有能时运行及耗尽后影响，并验证新旧版本和实际计费。'),
    'MED-01': (
        '既有30托管/20共同分钟/1料、真实身体服务站/ACL与当前医生paid容量；ROOT17保17点前缀、声明电网须足额且首次购材反馈准确说明缺电。',
        'ROOT16自定义47楼/616人真实1玩家患者20分钟完成；ROOT17 closing327四步护理0/4/5/5；v5四案16步满电0/4/8/8、耗尽0/4/4/4、1%及null全0；纯32/类型及source09相关回归PASS。/tmp/ROOT17-medical-estate-close-20261005-01/REPORT.md。',
        'PARTIAL：ROOT16一次20分钟完成与ROOT17关闭/供能前缀分别证实；新电网四案均未20分钟完成、材料reserved1/consumed0，不冒原公共六名全疗。',
        '诊断检验/药械/专科住院/急救运输与分诊排队；默认自然通勤供料/医师容量和完整需求仍欠。',
        '默认伤患自然需求→合法身体到站→有限供料与当前满电paid医患窗口→20分钟耗料/健康/费用/废物及全档未来24。'),
    'MED-02': (
        '既有有限40 health公共预算、同厅两当前实薪签来源/V2追加≤160、真材料priority/wake；ROOT17共享claim新增当前满电门控，不增加预算或护理容量。',
        'ROOT16 NEW512界实际292 main帧/984tick/3936游戏分，headless身体真实1074.74m/13合法赠粮/18购粮/3付费休息；原cap40实付40，消耗1/served1/5剩余，whole/44parts未来24 PASS；旧240帧0/6 FAIL保。证据root16/evidence/medical/REPORT.md。',
        'PARTIAL：一次具名公共患者完整有限治疗PASS；47楼自定义11道路组件、受控身体宿主，非默认612自然公共医疗；新grid四案不完成20分钟。',
        '原5患者、下一当前实薪本地审批、有限材料缺口/医生与生产者补给、默认自治排队和自然医卫供需未验。',
        '从真实129bb28c…/92d706cd…终档接续，普通供粮/到岗与当前合法双签先满足，再购料/到诊20分钟及下一患者结果，不延旧FAIL边界。'),
    'HYG-01': (
        '真实临床/公共耗料产生可追溯waste；既有有限清洁料1、20费用、10剩余医生paid分钟封存并保残渣；未新增家庭街道垃圾或污水终端。',
        'ROOT16一次公共20分钟实际consume1→唯一waste-1；ROOT17 grid四案consume0故不产新waste；旧卫生18/GUI与原1批仅各自scope；/tmp/ROOT17-medical-hygiene-power-20261005-01/MATRIX38-HYGIENE-POWER.md。',
        'PARTIAL：实际源批次已产生，不能沿旧矩阵报本次0batch；plain用品废物不是病原来源，封存不等处理/清运全链。',
        '家庭街道垃圾/公厕/污水水厂、清洁职业与NPC日常环卫、公共有限预算、全城循环和可追溯终端欠。',
        '真实日常产污→有限料工收集/清洁→具名运输→终端能料工处置；全部污染物/残渣/托管不凭空消失。'),
    'HYG-02': (
        '原玩家有限kit与两端医生实际2分钟、真实3unit托管cargo、取消/死亡物权保留；未实施自动NPC清运与终端处理。',
        '历史165m步行和18项独立规则保留；ROOT17本scope不重跑卫生转运，不以food cargo318步替代废物运输或许可处置。',
        'PARTIAL：原托管转运窄PASS；licensed terminal disposal仍NOT_IMPLEMENTED，不因增加电网或新waste变成已处理。',
        '处理厂、有限回收/消毒/销毁/排放/再利用链、环卫居民或车辆路程、终端角色许可欠。',
        '合法运输实际两端交接/在岗→有限终端能料工处理→明确剩余物/排放去向与污染反馈/保存。'),
    'VIR-01': (
        '既有游戏YV1来源/dose/episode/免疫可追溯受控规则；默认无自然外来病原种源，不将普通医疗waste感染化。',
        '历史受控病理保存/+24保留；ROOT17未新运行自然疫情、外来感染或全城传播，医护满电/耗尽测试不产生病原。',
        'PARTIAL：游戏受控病理规则支持不等天然来源或自治传播；自然源/城市接触与环境循环仍未实现验证。',
        '合法有限外来入口、人际/环境暴露、检测诊断/隔离/疫苗、监测自然恢复与医卫完整响应欠。',
        '有明确初始来源及每次真实接触/剂量时间证据→潜伏症状→有限医卫结果/免疫；无凭空seed或感染通知替代机制。'),
    'TEC-01': (
        '既有七领域及本人200现金/120实际科研分钟、正式学历和现场权限；可选有限电网消费入口读取当前供能，未新增设备产业。',
        'ROOT16原一天一研究本人真实200扣入；ROOT17 source09未专门新跑科研整链；电网小图不会被报成七领域成果验收。',
        'PARTIAL：旧具名研究钱/时间范围保留；七领域均可玩、耗材实验/成果工业采用NOT_VERIFIED。',
        '设备耗材、实验失败、协作/知识专利、制造产业采用和领域社会影响欠。',
        '实际买/使用设备与有限钱能料工研究→真实成果→制造采用/失效成本→居民社会可观察后果与保存。'),
    'EDU-01': (
        '原40托管/1教材/60真实师生paid重叠分钟/4席位与正式学历来源；ROOT17家庭学费未赚托管纳入遗产资产守卫，退款先偿债。',
        '旧school95=93PASS/1旧byteFAIL/1SKIP保；ROOT17真实4已赚课时/教材实购4、原40费用、退款33.6→债20→继承13.6及两实例24 PASS；source09相关新家庭/旧banking回归PASS。/tmp/ROOT17-medical-estate-close-20261005-01/REPORT.md。',
        'PARTIAL：遗产课程原资金优先级已实证，不授新学历；受控六岁/保存时钟/每traffic站位needs，不等自然18年通学或完整考试就业。',
        '完整课程考核、通勤/家庭困难/照料、公校覆盖、升学职业与自然多年学业欠。',
        '有限家庭或公共教材/师资→正常到课各60实分钟→正式来源学历/考试就业，跨成年、贫困、死亡退款及保存。'),
    'EDU-02': (
        '原40与显式V2追加≤160、同厅双在任paid来源、真material wake/priority与剩余供给估价；未新增默认全校制度。',
        'ROOT15/16不同冻结业务图各6目标/6材料/各60分钟：108实际步、唯一cap11追加实付9.870811616545707（4f图）与旧5a10.040936509分别保；whole/parts24；ROOT17无新的自然公校全覆盖运行。',
        'PASS限compact既存实薪consumer；actual01/02仅4/5服务FAIL保；不是全城公校、自然通勤/全年学历或MED结果。',
        '默认全校自然短缺/师生通勤、家庭教材资助、长期供需/财政能力欠。',
        '当前产品新图自然课堂需求→有限request双签/真实配送→60授课/学籍学历/就业→日间及跨日供料保存。'),
    'POL-01': (
        '原60公务paid分钟/本人120保100储备、无薪现场登记双见证/两天投票/14日次身份来源与history；gift权威2m/支撑/ACL/连续阻碍守卫保留。',
        '原两自然同厅term、H14容量迁移/申请86、ROOT16有限真实赠粮13次及医疗前日工班/当前day9医生出勤均原scope；ROOT17无默认14日renewal新运行。',
        'PARTIAL：source/term/钱费窄链保留，合法赠粮非直接授予身份；142回归不包含自然完整政治生涯。',
        '默认14日续任/财政持续、更多职务/民意竞争及长期历史容量、多候选政党体系欠。',
        '普通居民自然到期续任→本人实费登记票/当前实薪合法现场与完整档；身份变更/卸任权限失效及拒绝反馈。'),
    'POL-02': (
        'BudgetAuthority V1/V2合法来源/同厅两在任实薪签和旧revision0保护；公共医教有限消费；utility四命令仍仅声明无handler。',
        'ROOT16六人公共教育限定追加cap11；医疗原cap40实付40/consume1/served1；原默认day财政80000→72470.2121876365（-9.412%）steady=false；ROOT17不新增长期预算稳态scope。',
        'PARTIAL：有权钱≠实物/出勤；原医疗0/6旧FAIL与后1名真实完成分别保；不能继续报全部医疗0，也不以电网或142验收财政。',
        '自然双委员短缺、下一医疗cap14审批、本地current工资与物料能力；公私长期供需和财政稳态欠。',
        '自然短缺/两当前合法paid委员真实签→有限到账/采购/劳动/服务→权失效拒/账料保存；另有界长日财政原因审计。'),
    'POL-03': (
        '原政策选举/请愿迟延回复、调查追缴/ACL/就业身份历史；未新添法院监狱、福利外交或政党制度。',
        '历史治理治安与UI公共信息/关系冲突限定scope保留；ROOT17无完整司法/法律/福利新增真实循环，142相关规则不外推。',
        'PARTIAL：原有限治理可用；归档、供电及诊断不会完成法律军事外交广度。',
        '法院审判辩护/监狱、复杂犯罪/黑市、政党议会监督福利、阶层族群迁移军政外交欠。',
        '具名事件证据、人员实际到场、合法程序、有限财政与执行→社会关系治安政治结果来源及旧新保存。'),
    'ENV-01': (
        '既有天气昼夜/可见度与区级水质、生物多样性、污染、风暴风险；有限电网与实物资源读取实际状态，未新增真实水管污染扩散。',
        'ROOT16默认一天环境与食品财政原运行保留；ROOT17没有自然季节/全城水生态长跑，医疗grid和13项拟拆纯诊断不替生态验收。',
        'PARTIAL：聚合环境在用；渲染云雾/受控初始电池不等生态闭环或环境改善。',
        '污水水网/空气扩散/垃圾土壤、季节气候/食物链、生态修复产业和天然长期反馈欠。',
        '真实污染生产源与空间受体→居民企业影响→有限有权治理料能工→质量变化和物料/排放守恒。'),
    'DIS-01': (
        '原canonical雨洪/区损失/既有edge封闭及有权有限修复；ROOT18拟拆影响诊断只读，不新增火震空间损伤。',
        '历史洪灾/道路受控规则保留；ROOT17未运行火灾地震/结构坍塌/自然救援，source09 142不能算灾害新验收。',
        'PARTIAL：雨洪机制存在；火震传播/空间结构破坏NOT_IMPLEMENTED，拟拆预览不等真实毁损。',
        '着火传播/坍塌/伤亡、消防急救疏散避难安置/保险/余震、有限实际重建欠。',
        '合法自然风险→真实空间破坏→居民意愿/身份驱动有限人员救援与安置→有钱料工重建/后续保存。'),
    'SHOP-01': (
        '原困难三AND/本人意愿/合法身体到店、产权与经营分离、买租/工资债/自筹复工；ROOT17修缮只接本城当前原生工资对象并去重，不安装旧未验tenant policy。',
        '真实旧受控compact384/7楼租约档：141普通speed1步/35.25游戏分、11原员工完成60已赚分钟/消费1重开；旧325/新328全部141+24 save逐字同，5物理parts读写PASS；source09新5+旧shop相关PASS。/workspace/yunshan-work/ROOT17-shop-lifecycle-20261005-01/REPORT.md。',
        'PARTIAL：正常有限修缮及通知不可伪工资已验证；这是旧受控初始分配/困难开局续演，非默认109市场下一自然倒闭周期。',
        '默认109市场均缺至少一种同区farm/dock或workshop；自然第三次困难/新租户状态仍NOT_OBSERVED；全楼/土地产权与真实换业尚欠。',
        '保原profit/库存/freeFunds三AND、意愿/生活储备/债押金；建立真实跨区供应后另有限自然多轮买租换业/复工终点及未来24。'),
    'SHOP-02': (
        '原产权/operator分离、合约租金押金advance与欠债/寄售货权/公司返还经营资产历史；current-native工资认证保护60分钟复工，不变原合同。',
        'ROOT17旧新141+24全字节及physical5parts未来24、现金残差2.04e-10；generic/clone/foreign/retained/同对象重复通知不能改真实修缮钱料债；旧writer误将parts[]作Record FAIL保。',
        'PARTIAL：原paid正常路径不变，负例只验证修缮真实账料，不宣称所有通用通知observer整个save不变；旧tenant第三轮未见，不降断言。',
        '各层独立店面/房土租赁、行业更替/经营迁址和法定清算；新tenant waiting/endPending/reopening自然见证与终点未验。',
        '有限居民正常钱包/物料/路线买租另一轮，保押金50/advance200与工资租债、历史货权；逐层产权及有权清算另真实保存。'),
    'BLD-01': (
        '原有权现场.2m体素/1料建造、只拆自放方块回1、expand60工时；ROOT18只读building-alteration候选诊断拟拆影响与财产权债，并非实际建筑事务。',
        '历史build/ownership与UI窄范围；ROOT18纯13/类型早期candidate PASS（/tmp/ROOT18-dynamic-city-20261005-01），0Sim/0step/未共享；实际整栋拆迁NOT_RUN。',
        'PARTIAL：已可改自己的放置体素；诊断有住户/产权/债保护不等已取得许可或能拆原楼。',
        '整栋结构/楼层/设备可变权威几何，居民意愿/合法审批/承包施工、安全/有限补偿与迁居欠。',
        '冻结真实楼房权利/住户债清单；有权有限项目补偿安置、钱料工施工→碰撞/ACL/功能/存档版本一致。'),
    'BLD-02': (
        '原闭路诉求→双官员有限40预算/1料/60现场paid劳动恢复旧edge；ROOT18能只读预览拟删桥/道路占用/新路既有node连接影响，尚无CityPatch。',
        'ROOT18候选13纯/类型PASS：真实拟切通勤/死者排除、原closure区别、旋转3D占用/高架区分、错误引用原子拒；未改World或state；实际有权拆迁新路NOT_RUN。',
        'NOT_IMPLEMENTED实际动态事务 / PARTIAL诊断：只读预览和既有edge修复不算新路已铺或房屋已拆，root source09未包含ROOT18。',
        '土地房权/补偿迁居、居民意愿签批、CityPatch原子提交、新旧route/index/cache/能力与保存迁移欠。',
        '真实住户权利清单→有限合法资金补偿/迁居/料工→原子CityPatch新通路；取消及跨区任务重算、完整档恢复真实版本。'),
    'FOOD-01': (
        '原实薪农业生产/库存缓冲、身体柜台餐与携粮消费、meal-route显式旧新合同；ROOT17新图道路装粮把真实producer库存变具名在途货权，不补钱粮。',
        'ROOT16默认原229全部柜台513本人收据：128+256普通步/768游戏分、最后首次+295步；616存活/末饥饿无携粮0，生产90.350289736695；原一天公库-9.412%仍steady=false。ROOT17compact有限库存具名28真实运输318步，不观察生产。',
        'PARTIAL：229名单已经全恢复，不能保旧未观察为当前结论；有限食品/现金严格守恒不等长期稳定。旧异图14日居民现金-65.14%/7公司归零仍保，不能借最新day12公司无0反证。',
        '新鲜默认电网/具名物流与真实销售供需尚未长跑；默认day粮店库存净下降、公共财政持续压力、私人岗位与14日稳态欠。',
        '从真实EDF和显式SHA政策选择出发，真实生产→运输货款/店库存→本人日常消费；另冻结长日审计查有限资金/劳动/供给原因，不送钱弱断言。'),
    'TRA-01': (
        'ROOT17显式road-food-pickup-v1：真实fleet/capacity/开放road端点1.3m车道/producer2m距离装粮，源店扣库存、cargoSources与freight lot保货权；旧无marker未来保持。',
        '紧凑384/原真实farm/2node/200m：tick109卸初始匿名28并扣farm160→132装具名28；tick318下一node实际卸入具名lot；318普通speed1步，现金/粮每tick残差0；5parts磁盘写读、whole/physical reader未来24逐字；旧325/新331无marker88步全字节同。/tmp/ROOT17-freight-close-20261005-01/REPORT.md。',
        'PARTIAL：真实有限存货的装车/移动/卸货及货权已验证，不再仅access helper；本fixture生产0，不证明供应商销售收入、零售补给或材料运输。',
        '具名仓库订单/付费派遣与货款到账、零售消费者、材料产业链/跨区调度；实际默认EDF opt-in升级及续演NOT_RUN。',
        '真EDF完整SHA两marker升级仅变声明；实际具名运输→合法货款/仓库库存→生产/零售消费及长期守恒/保存，不把cargo custody当销售。'),
    'TRA-02': (
        '原城内实体无人机/VTOL位置许可、租费24/电池/返航落地退出；保第一人称获取接近进入玩法，不增独立模式入口。',
        '旧browser11图各自controlled身份/机坪前件PASS；ROOT17原325/渲染327各16PNG未覆盖城市租机完整驾驶链；source09全新组合browser/UI未运行。',
        'PARTIAL：旧城市载具功能证据仍保；普通旅行者谋生/训练许可到机场自然全程与最新组合驾驶未验，软件GPU不认证Mac。',
        '普通出生获得身份钱/训练许可、合法到机坪；完整航班旅客/货物/航空能耗与职业链欠。',
        '普通生活谋生/资格/钱→连续有权到机坪→实体进入驾驶/返航落地退出/结费/档；拒无证/余额不足/空中退出。'),
    'TRA-03': (
        '既有权威楼层支撑/圆足投影/车道身体查询与退出候选；ROOT17保live几何查询优化，不改真实body；渲染改牌/布料几何身份核同。',
        'ROOT17原325真实键鼠约37.922m、渲染327约38.064m均前三路点到达/第四超时，第五未跑；两个冻结五路点scope均FAIL；旧T14地板/rail退出FAIL保。/tmp/ROOT17-visual-gpu-20261005-01/*/artifacts/RESULTS.json。',
        'FAIL / PARTIAL：实际身体确有移动，不能说已通过五点或直接断言实体堵死；原采样/步行失败须诊断，不能改body/删障碍/降到达标准改判PASS。',
        '站点/护栏/车辆附件/动态门、其他乘客占位/驾驶座、地表支撑与转角、正常上下车与可用净空欠。',
        '新冻结真实按键采样明确每段身体/支撑与事件；原护栏和站棚问题实修后合法退出、站点费占位/FIFO/运输流程验收。'),
    'FAM-01': (
        '原同意同住/婚育父母真实100托管、270日孕期、子女登记6岁school18岁work、现金债资产股份经营继承；ROOT17未赚家庭课程escrow阻止提前银行writeoff。',
        '旧受控出生成年与公司返权9保；ROOT17旧/新死亡前save同a90f9cf9…：原有效借20/真40课学4分钟后，旧loss20、新refund33.6→debt20→netheirs13.6，钱差5.82e-11；新84instance步骤含memoryparts/24未来PASS。/tmp/ROOT17-medical-estate-close-20261005-01/REPORT.md。',
        'PARTIAL：债款优先真实修好；既有fixture每traffic固定身体needs、保存年龄/关系/出生边界、一次health0死亡，不等自然完整一代。',
        '自然父母照料/住就业/家庭困难、长期关系心理、养老丧葬、完整自治一代和住房产权动态欠。',
        '有限普通家庭逐节点自然一代；债资产课程/就业钱料守恒，儿童人口/索引引用完整；自然与受控证据分别记录。'),
    'LIFE-01': (
        '原住房租费80/床桌柜functionPoints、20分钟床侧休息、有限烹饪/光照/2m合法赠粮；ROOT17原床8片cloth换几何模板不增加权威用途。ROOT18办公桌/窗帘finish与sofa/coffee-table/monitor素材仅私有候选。',
        'ROOT16真实18次购食13次合法赠粮3次各15付费诊所休息；ROOT17床cloth/商业幕墙CPU与build、old/new各16原PNG；source09相关渲染测试PASS，但室内paused完整save采样FAIL；ROOT18新增家具功能/GPU未验。',
        'PARTIAL / ART FAIL：原日常有限用途保留；视觉素材准备不等可获取/摆放/碰撞/使用资产，沙发/显示器/完整厨卫没有验收齐。',
        '完整家居/办公/厨卫分类权威对象、购买制造安装及可交互功能；普通日常完整流程/采样状态干净和氛围欠。',
        '每家具真实资产用途/身体碰撞/ACL/有限钱料与使用结果；普通一天进屋做饭休息工作，昼夜原图对参考。'),
    'LIFE-02': (
        '原付费现场culture项目、公共info来源evidence/verify/延迟回复、有限真钱食物仪式；本轮未新实现全域文化行业。',
        '历史UI文化/info/仪式限定scope保留；ROOT17供电/遗产/装粮/几何142测试不覆盖语言宗教媒体体育产业自然日常。',
        'PARTIAL：归档/任期及暖灯不扩文化制度；未新跑自然文化生产传播长周期。',
        '语言文学艺术音乐宗教哲学、媒体谣言情报隐私、体育娱乐节庆旅行宠物及社会传播产业欠。',
        '各领域真实场地需求与有限素材/钱/劳动→生产消费→传播社会关系/政治后果来源，逐域验证保存。'),
    'LIFE-03': (
        '原hunger/fatigue/social/health/stress/mood、年龄关系、携食真实消费、有限服务及YV1受控窄链；未新增营养或成瘾治疗。',
        'ROOT16原229全部真实513柜台收据/食物恢复及一患者20min健康增益；ROOT17供电护理部分窗口有当前needs与paid证据；estate反复needs控制只为隔离金钱契约。',
        'PARTIAL：实际需求衰减/恢复和健康窄反馈有证；不以受控遗产或赠粮案例认证全心理/营养/疾病自治。',
        '食材营养/饮食设备产业、精神医疗/成瘾、复杂情感依恋与多主体长期反馈欠。',
        '普通居民有限能力/食钱医卫与真实互动→健康情绪关系后果；各来源和控制条件明确，不填needs掩盖供给缺陷。'),
    'INF-01': (
        '原市场买租/经营返权、既有道路有限维修、固定设施ACL和有限采购；新增可声明有限电网分表与真实food装运；ROOT18拟改影响诊断只读。',
        'ROOT17既有修缮141+24、有限grid67+8、named粮318+24分别窄PASS；没有供水/排污/消防/通信/学校/码头全产权运营更替新实际案例。',
        'PARTIAL：market守卫、宣告电网/运输不会泛化全部公共设施运营/迁移；utility命令实际handler未实现。',
        '供水排污垃圾消防通信仓库等管网/产权/新经营者、真实老化迁移扩建、设施用地施工和持续预算欠。',
        '一设施有权新运营者或迁移扩建有限钱料能工事务→居民就业/供电交通/污水结果→新旧版本保存。'),
    'PER-01': (
        '原616常驻1/4/16降频/渲染chunk上限/history页parts；ROOT17减少live几何分配/保守bbox排除/边界union；ROOT18owned geometry缓存仅私有候选，未统计卸载。',
        'ROOT16 EDF终档whole/787genericparts future24逐字、124World辅助parts物理重组exact；ROOT17最终perf06原EDF16步每save同基准f4b9076c…，约25.74s步耗 vs旧异次26.76s（单case约3.8%），非FPS；/tmp/yunshan-ROOT17-performance-candidate06-20261005-01/REPORT.md。',
        'PARTIAL：保存分块与渲染驻留不等真统计区人口卸载/冷DB；小优化轨迹等价已验，未证明性能目标或ROOT18新缓存实际效果。',
        '聚合迁入迁出/居民身份钱物恢复、跨区任务守恒、异步chunk/DB冷加载/崩溃事务与真实规模性能欠。',
        '不可见聚合↔个体合法还原、跨区钱物任务相同；独立流式故障恢复/吞吐/帧时，不降速度/人数或跳阶段。'),
    'SAVE-01': (
        '原native4/history1、严格来源/旧档无暗升/完整keyset；ROOT17可选grid来源与elapsed校验、原生工资witness、显式freight两marker exactSHA升级，既有法院家庭等保存保留。',
        'ROOT16 EDF whole/787parts future24、World124物理0Sim repack；公共医疗whole/44parts future24；ROOT17shop141+24 physical5、freight318+24 physical5/legacy88、gridwhole/4parts future8、estate memoryparts双实例24；source09 142相关PASS。',
        'PASS限具名保存scope / PARTIAL总体：root最终349统一EDF与新GPU/全UI尚待；旧源325完整npm OOM及3600s TIMEOUT359/280PASS/79cancel保留，不被142覆盖。',
        '默认真实EDF启用freight二marker升级实际续演、全部组合长期quota/崩溃容量、任意地图/动态WorldPatch迁移；非所有parts范围都物理写盘。',
        '最终source09完整原档和真实升级冻结/whole+physicalparts future24；旧bad档原子拒；实际长日/满quota和地图事务另明确验收。'),
    'ADP-01': (
        '原numeric walker/CitySession/Worker FIFO/queue256与MZ bridge；ROOT17未重建独立MZbundle或把新命令类型当handler；四utility继续禁用。',
        '历史Worker8tick/973heartbeat/max45.9ms仅旧独立图；本ROOT17没有新Worker/MZ实机端到端或异步UI验收，source09业务142不外推发行物。',
        'PARTIAL：同数值核心可headless；当前新业务源码与旧MZbundle版本独立，ack仅处理完成≠命令业务成功。',
        '新bundle/contract受信重建、main异步UI接线、MZ合法空间素材/完整新默认端到端/性能欠。',
        '独立版本bundle/契约绑定同源码，单权威Session/FIFO/result/十阶段/合法身体/完整旧新档一致；不自动升级MZ。'),
    'ART-01': (
        '原体素石木深青瓦/有限灯；ROOT17真实站柱路标/机构短牌/商业幕墙/原床布料，几何权威不变；ROOT18窗帘/办公桌与未摆沙发显示器茶几仅私有素材候选。',
        'ROOT17 renderer CPU20/构建/1224near-far几何身份PASS；原325和327各16真实PNG，shader链接/GL无error，但每scope native五点FAIL、paused室内全档采样FAIL；/tmp/ROOT17-visual-gpu-20261005-01。root source09未新GPU。',
        'ART FAIL总体保留：32真实PNG不是32美术验收PASS；旧原失败不过滤状态改判；功能shader通过不等参考国风城市，软件GPU不是Mac。',
        '出生站棚/桥层遮挡、街面人气/绿植/精细立面和窗影、完整厨卫家具/灯火与宏伟层次仍欠；外部付费/过期Tripo key不扩授权。',
        '当前完整源同合法出生连续走街进楼/日夜原图逐类对5张Git参考；真实functionPoints/碰撞材质/氛围一起验收，不以概念图替游戏。'),
    'VAL-01': (
        '所有scope冻结src/tests/scripts/adapters/public+配置、raw/argv/cap/ownedPID-startTicks与原件SHA；局部候选集成先独立type/build/针对性旧新回归，旧FAIL保留。',
        'ROOT17 source09 349输入build17.7524s PASS；14新模块+9原相关共23模块142/142 PASS，Node273.6567s/wall274.0107s，source stable/active[]；旧325 fullnpm heap OOM、再3600s TIMEOUT_PARTIAL359 Node总/280PASS/79cancel保；/tmp/ROOT17-integration-20261005-01/targeted09/receipt.json。',
        'PARTIAL：142不是全npm或38需求全部完成；独立327GPU双FAIL、医疗v4提示FAIL/estate旧lossFAIL和各source前件FAIL均保存；最新349统一EDF/GPU/全UI待run。',
        '当前源码未安装/提交发布回执、当前Library上传尚无新ID；完整域、长期14日财政供粮稳态、自然动态城市、美术/Mac等开放。',
        '按最终冻结图必要whole/physicalparts/实际UI/GPU终局；完整报告/矩阵/原件Library实结果，正常授权工作分支提交推送另核，不以计数替完成。'),
    'MAC-01': (
        '既有画质/LOD/分级选项、Linux运行路径；ROOT17live几何查询优化、ROOT18owned cache候选；不改变NPC数/移动速度/资金或十阶段。',
        'ROOT17原EDF16实际保存等价/people仍约25.41s；原325/327 Chromium SwiftShader16图各scope约810.60/864.67s；Mac Safari/Chrome/Firefox、真实硬件/FPS仍NOT_RUN。',
        'NOT_RUN Mac；单case约3.8%跨次CPU差异不等稳定提速/流畅帧率，softwareGPU/截图墙钟不等实机benchmark。',
        'macOS实机Safari/Chrome/Firefox、CPU/GPU帧时/内存/长帧与常用质量配置；大城体素/统计流式仍欠。',
        '独立实机普通启动/走路进楼/驾驶飞行/存档，绑定机型版本质量、CPU/GPU帧时/FPS/内存/stutter；先满足可玩不隐藏缺项。'),
}

# New parent evidence arrived before the first CSV was written. source10 adds
# read-only diagnosis; this neither reruns the 142 tests nor executes demolition.
ROOT10_DELTAS = {
    'SYS-01': {
        'latest_implemented': '既有无renderer数值Simulation/WorldDefinition/固定十阶段；ROOT17 source09集成有限电网/装粮/医护/遗产/修缮/几何，source10再接只读整栋影响诊断与UI按钮，共351输入，功能图74aee7b713f03c51b9fd7427ed7fbfccdb60b451919c64c36295c75cb627c2be；尚非共享安装回执。',
        'latest_actual_run': 'source09 23模块142/142 PASS（Node273.6567s/wall274.0107s），build17.7524s；source10新build21.8297s与building-impact18/18 PASS/1.7228s，351首尾同/active[]；/tmp/ROOT17-integration-20261005-01/{build10,building-impact10}/receipt.json；source10真实EDF actual02正在RUNNING，未填PASS。',
        'latest_verified_boundary': 'PARTIAL：无renderer业务运行/只读真参数诊断已验；source09 142与source10 18各自范围，不能相加冒全套；当前组合EDF/RUNNING与GPU/NOT_RUN待回执。',
    },
    'MAP-02': {
        'latest_implemented': '既有食品访问CLI/道路装货/有限电网诊断；ROOT18 CANDIDATE02已接ROOT17 source10，只读整栋改造/拟删路/拟安置影响分析，并有检查按钮；不提交WorldPatch。',
        'latest_actual_run': 'readonly02真实默认World291…+EDFedf…逐612栋覆盖616居民；保护已赚私营工资债438.7805373812361与当日未赚承诺807.9392723936588；原47楼medical World/129bb…逐47覆盖616，保护waste1/未完成service-2；0Sim/0step/0cmd，原参数不变。source10相关18/18 PASS；/tmp/ROOT18-dynamic-city-20261005-01/readonly02/artifacts/RESULTS.json。',
        'latest_verified_boundary': 'PARTIAL：两组真实存档只读影响诊断PASS；默认两人安置道路/容量预览通过但仍有原住所且requiresConsent/canExecute=false，医疗跨区断连拒迁居；按钮已实现未新DOM点击验证；非实际拆迁或统一城市全部设施健康审计。',
        'latest_remaining': '缺设施/容量/生态/供给统一能力报告；原住所与产权债、审批/补偿/意愿需要真实事务；实际拆楼/迁居/新路NOT_RUN且不可由诊断按钮执行。',
    },
    'BLD-01': {
        'latest_implemented': '原有权.2m/1料体素建造与60工时扩建；ROOT17 source10已接整栋只读影响检查按钮，保护真实住户/岗位/产权/stock/欠薪承诺/临床和废物；未提供实际拆栋命令。',
        'latest_actual_run': 'ROOT18真实readonly02默认612栋/616人和医疗47栋/616人全覆盖、输入不变；source10 build21.8297s、building-impact18/18 PASS；仍0constructor/Sim/step/command，无施工或安置。',
        'latest_verified_boundary': 'PARTIAL诊断PASS / NOT_IMPLEMENTED整栋施工：原住户与银行/经营债、工资/公共服务保护已实证；canExecute=false，拟安置容量通过不等原居民已经同意或迁出。',
    },
    'BLD-02': {
        'latest_implemented': '原有限旧edge维修保留；source10接CANDIDATE02只读拟切通勤/新路占用/拟安置诊断及按钮；没有土地权利/钱料工CityPatch提交。',
        'latest_actual_run': '真实readonly02两World/save原文件和解析参数均不变；默认拟2人安置容量176/4→6与岗位连接可行仍blocked原住所/canExecute=false；medical跨道路组件安置capacity120/56→58仍因不连通拒；source10相关18/18 PASS，/tmp/ROOT18-dynamic-city-20261005-01/readonly02/artifacts/RESULTS.json。',
        'latest_verified_boundary': 'PARTIAL只读诊断已接合 / NOT_IMPLEMENTED实际动态事务：预览合法容量不移人、不给同意/补偿、不改道路；实际拆栋/安置/新拓扑NOT_RUN。',
    },
    'INF-01': {
        'latest_implemented': '市场买租/旧路维修/设施ACL/有限采购、电网分表/具名装粮；source10只读设施改造影响保护工资债、未赚承诺、stock、未结医疗与waste，未泛化公用设施运营产权。',
        'latest_actual_run': 'ROOT17修缮141+24/grid67+8/粮318+24分别PASS；source10影响18/18及两个真实World/save只读保护PASS；未实现/运行供水排污消防通信等有权运营更换。',
    },
    'SAVE-01': {
        'latest_actual_run': 'ROOT16 EDF whole/787parts future24、World124物理repack；公共医疗whole/44parts future24；ROOT17shop/freight各physical5 future24、grid未来8、estate memoryparts双实例24；source09相关142 PASS；source10真实EDF actual02 RUNNING/结果未出，readonly02只读诊断不import或写存档。',
        'latest_verified_boundary': 'PASS限具名旧scope / PARTIAL总体：当前source10=351新组合EDF正RUNNING，未提前认证；旧source325全npm OOM/3600s TIMEOUT359/280PASS/79cancel保，142和18不替全套。',
    },
    'VAL-01': {
        'latest_actual_run': 'source09 349 build17.7524s/23模块142 PASS；source10 351新build21.829689s/影响18 PASS1.722816s/首尾同active[]，当前EDF actual02 RUNNING；旧325全npm OOM及3600s TIMEOUT_PARTIAL359/280PASS/79cancel保；/tmp/ROOT17-integration-20261005-01/{targeted09,build10,building-impact10}/receipt.json。',
        'latest_verified_boundary': 'PARTIAL：142与18分别冻结/不同源码scope，不相加成全suite；source10真实EDF RUNNING、集成GPU/全UI尚NOT_RUN；旧GPU双FAIL、医疗提示FAIL/遗产旧lossFAIL均保留；真实只读诊断PASS不等执行拆迁。',
    },
}
for identity, changes in ROOT10_DELTAS.items():
    values = dict(zip(FIELDS, UPDATES[identity]))
    values.update(changes)
    UPDATES[identity] = tuple(values[name] for name in FIELDS)

with BASE.open(encoding='utf-8-sig', newline='') as stream:
    reader = csv.DictReader(stream)
    fieldnames = reader.fieldnames
    original_rows = list(reader)
assert len(original_rows) == 38 and len(UPDATES) == 38
assert {row['id'] for row in original_rows} == set(UPDATES)
rows = [dict(row) for row in original_rows]
for row in rows:
    row.update(dict(zip(FIELDS, UPDATES[row['id']])))
csv_path = OUT / 'MATRIX-38-AUDIT.csv'
assert not csv_path.exists(), 'use a separate revision; do not overwrite an audit artifact'
with csv_path.open('w', encoding='utf-8-sig', newline='') as stream:
    writer = csv.DictWriter(stream, fieldnames=fieldnames, lineterminator='\r\n')
    writer.writeheader()
    writer.writerows(rows)
with csv_path.open(encoding='utf-8-sig', newline='') as stream:
    readback = list(csv.DictReader(stream))
assert csv_path.read_bytes().startswith(b'\xef\xbb\xbf')
assert len(readback) == 38
preserved = [name for name in fieldnames if name not in FIELDS]
for before, after in zip(original_rows, readback):
    for name in preserved:
        assert before[name] == after[name], (before['id'], name)
    assert all(after[name] for name in FIELDS)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
receipt = {
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'READONLY_RECONCILIATION_CSV_BOM_38_ROWS_ORDER_AND_REQUIREMENTS_EXACT',
    'source': str(BASE), 'sourceSHA256': sha(BASE),
    'output': str(csv_path), 'outputSHA256': sha(csv_path), 'outputBytes': csv_path.stat().st_size,
    'rows': 38, 'columns': fieldnames, 'preservedColumns': preserved,
    'changedColumnsOnly': FIELDS, 'rowIDsExactlyPreserved': True,
    'simulationConstructionCount': 0, 'steps': 0, 'builds': 0, 'tests': 0, 'GPU': 0,
    'noSharedEdits': True, 'noGitWrite': True, 'noLibraryWrite': True,
    'pendingNewEvidence': ['root source10 actual02 EDF/parts future currently RUNNING', 'root final composite GPU/UI', 'actual demolition/relocation/CityPatch NOT_RUN'],
    'notOverallComplete': True,
}
(OUT / 'RECONCILIATION-RECEIPT01.json').write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(receipt, ensure_ascii=False))

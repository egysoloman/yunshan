from pathlib import Path
import csv, datetime, hashlib, json
ROOT=Path('/tmp/ROOT17-requirements-20261005-01')
CSV=ROOT/'MATRIX-38-AUDIT.csv'
BASE=Path('/workspace/yunshan/docs/validation/2026-10-05-city-life-root16/evidence/requirements/MATRIX-38-AUDIT.csv')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(CSV)=='eee7a401cae35033d319accf5be658cd46ae1ee6e0b528f4ae0433c409393fcd'
PREVIOUS=ROOT/'MATRIX-38-EDF-GPU-03-55.csv'
assert not PREVIOUS.exists()
PREVIOUS.write_bytes(CSV.read_bytes())
with CSV.open(encoding='utf-8-sig',newline='') as f:
 reader=csv.DictReader(f); columns=reader.fieldnames; rows=list(reader)
with BASE.open(encoding='utf-8-sig',newline='') as f: old=list(csv.DictReader(f))
changes={
'MAP-02':'沿两真参数/只读UI已验报告继续缺设施/容量/生态/供给统一能力诊断；随后另有权有限项目验真实意愿/审批/补偿和迁居施工，不能把预览变更当完工。',
'TRA-01':'沿真实EDF已验SHA升级续演，观察默认下一实际具名装卸运输→合法供应商货款/仓库库存→生产/零售消费及长期守恒/保存，不把cargo custody当销售。',
'SAVE-01':'沿最终351完整旧档/显式升级/whole与physical124未来24已验边界，另验长日/live满quota/崩溃恢复和实际地图事务迁移；新bad档与失败事务仍需原子拒绝。',
'VAL-01':'沿最终351已验全档/physical124续演与两图技术UI范围，补普通出生连续步行/完整UI与browser及各真实子系统缺项；完整报告/矩阵/原件Library实回执、工作分支提交推送由父会话另核。',
}
before_rows=[dict(r) for r in rows]
for r in rows:
 if r['id'] in changes:r['latest_next_acceptance']=changes[r['id']]
with CSV.open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=columns,lineterminator='\r\n');writer.writeheader();writer.writerows(rows)
with CSV.open(encoding='utf-8-sig',newline='') as f: result=list(csv.DictReader(f))
preserved=['id','domain','original_requirement','original_asof1439_validation','original_missing_or_blocked','latest_complete_requirement']
assert len(result)==38 and CSV.read_bytes().startswith(b'\xef\xbb\xbf')
assert columns==list(old[0])
assert len({r['id'] for r in result})==38
for a,b,c in zip(old,before_rows,result):
 assert all(a[k]==c[k] for k in preserved)
 assert all(b[k]==c[k] for k in columns if k!='latest_next_acceptance')
 assert all(c[k] for k in columns)
receipt={
 'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'FINAL_38_ROWS_BOM_FIELDS_PRESERVED_SCOPE_AND_FUTURE_ACCEPTANCE_RECONCILED',
 'root16SHA256':sha(BASE),'initialSHA256':sha(ROOT/'MATRIX-38-INITIAL-03-44.csv'),
 'finalEDF_GPURevisionSHA256':sha(PREVIOUS),'finalSHA256':sha(CSV),'finalBytes':CSV.stat().st_size,
 'rows':len(result),'columns':columns,'preservedColumns':preserved,
 'onlyChangesFromRevision02':[{'id':i,'field':'latest_next_acceptance'} for i in changes],
 'allRemainingFieldsUnchangedFromRevision02':True,
 'allNoEmptyFields':True,'source349_142AndSource351_18SeparateScopes':True,
 'finalFunctionalGraph':'74aee7b713f03c51b9fd7427ed7fbfccdb60b451919c64c36295c75cb627c2be',
 'childSimulations':0,'childSteps':0,'childCommands':0,'childBuilds':0,'childTests':0,'childGPU':0,
 'noSharedEdits':True,'noGitWrite':True,'noLibraryWrite':True,
 'overall38Complete':False,'ART':'FAIL','Mac':'NOT_RUN',
}
(ROOT/'RECONCILIATION-RECEIPT03.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(receipt,ensure_ascii=False))

# ROOT17 既有店铺真实修缮劳动修复候选

此候选修复一条实际可复现的资源规则错误：既有市场的修缮监听器只检查正额/分钟/时窗，通用通知能够冒充已资助出勤，把1单位真实材料消费掉并使店铺重开。现仅接受本城当前state对象/当前tick和clock的原生不可变NPC工资事件，并对同一真实事件保持幂等。没有更改困难门槛、本人意愿、资格、身体/路线、供应、采购、产权、租金押金垫款或工资债；没有安装ROOT15未验tenant policy。

候选仅存在此NEW私有目录；共享源码、Git、main、远端、PR、部署、付费/密钥、Library均未写。parent可审查并应用OWNED.patch，交付生产者仍由root统一负责。

## 真实来源与代码

- 原HEAD为`6a614c5d74ecb53ce9a495dc48c12add7216d4f0`/`takeover-city-life`，325输入图`0c7aea22807f69ac83450ecd201d5ee6e933dff816e937cf18b0728e97d7a0da`。BASELINE-INPUTS-325逐项核对共享文件SHA后原样复制，原目录未更改。
- 新候选328输入仍81生产文件，改动仅`src/simulation.ts`和`src/simulation/shop_lifecycle.ts`；新增`tests/shop-native-repair.test.ts`5项，以及原生旧存档和来源说明两个fixture文件。全部旧测试/原断言逐SHA不变。CANDIDATE-INPUTS-328与candidate-frozen保持代码/fixture原件。
- 通用`isCanonicalNpcWage(event)`维持原仅认证原生对象的语义。新增可选Simulation参数才要求该城当前state/tick/clock；修缮消费者使用这项严格判别和WeakSet去重。无存档字段、schema、policy或默认world recipe变化。
- 生产patch SHA `b547dd3e3675f190db8343601c4a03913ba1904342a3b553bc1b3e12b92d9077`，OWNED.patch SHA `43b64fb767d64ecce1bb8393ff06817b26181b5e022e962318fd12868b5e74ed`。两者已在精确私有baseline用`git apply --check`通过；未实际应用到共享。

## 实际复现、运行与原件

| Scope | 结果 | 预算与边界 |
|---|---|---|
| reproduce01 | FAIL，保留 | 1.158秒/cap60；原档job刚启动，clock==startedAt，driver要求已有时间差的前件断言失败，0step、325稳/owned active[]；不是生产错误反证 |
| reproduce02 | PASS_REPRODUCTION | 1.417秒/cap60，325稳/active[]；同原档正常4个.25step后仍reopening，随后0step/不改clock、钱包/真工资债，60原市场员工通用正额通知冒出60维修分钟、消费1材料并变operating |
| types01 | PASS | 11.757秒/cap120；严格tsc覆盖源、新5项测试和全部旧tests，328输入稳/owned active[] |
| native-rules01 | 5/5 PASS | 7.503秒/cap120，328稳/active[]；通用正额、克隆、外城同帧、本城真实同对象重复、旧state/跨帧、真实有限完成和whole/partition24 |
| native-comparison01 | FAIL，保留 | 8.266秒/cap120；141普通step和后24每步baseline/current/full/parts字节检查已完成，物理writer误把SavePart[]作Record写文件时TypeError；原driver/plan/raw及全部产物保存，不倒写为PASS |
| native-comparison02 | PASS | 14.838秒/cap120，生产328完全不改，仅NEW writer/plan/output修正SavePart[]；原同141step完成，后24 baseline/current/full/parts逐字同；5个真实World辅助part落盘写读/重组exact |
| legacy-three01 | 原3项PASS | 1.807秒/cap120；原未改shop-lifecycle.test.ts中的旧工资债/寄售和实际修缮、居民自主购店路线、zero-wage负例，328稳/active[]；未宣称全15或完整npm套件 |

共同原件为ROOT13原受控有限初始分配/明确困难参数后，居民普通路线实际成交租约且进入重开的真实存档：`originals/controlled-actual-reopening.save.json`，569397B SHA`63670a12ece4f11c5d53d93f46fa48755bb2388522dd5b070867275823c801a2`。这是可信compact384居民/7楼的已有受控场景，不是默认612建筑城市的新自然日常证明。新运行没有改身体、角色、需要、钱粮库存、住房、RNG或时钟；旧受控初始分配/困难开局的事实不能因新验证而改称自然。

native-comparison02的真正有限出勤141普通.25step/原speed1=35.25游戏分钟，具名11员工共同完成60已赚正额原生分钟、消耗1材料；不是60墙钟分钟，工资债依原工资流程后续支付。该scope记录628笔market原生工资事件（包括实际job窗之外或累积观察），不能把所有628都当60分钟的入账行。

原新job完工clock2007，完整终档SHA`ae0dfd1571c960d8a150fc720f3ae3eb31e16534a98d04e3941b1123ae666bc7`，恰与原ROOT15后续输入相同；after24 SHA`24fc30b1d2e2523897a6bc613a7d7537babb1caaf82b8b51ddb90ecda8216a57`。两份旧/新实现每141+24个实际quarter step整个save逐字相等，说明正常自然paid路径保留。现金最大残差`2.0372681319713593e-10`。全原save/parts/物理parts/每步SHA/实际工资和job劳动行均在`native-comparison02-artifacts/`，不只摘要。

负事件测试只严格断言生命周期/真实现金债合同库存不改变：现有trade统计仍监听通用通知，会记录通知的劳动成本。此候选没有冒称所有其他observer或整个伪事件后save均无变化；该独立统计通知合同仍可后续审计。正常未注入的完整save等价scope与这些负例分开。

## 旧失败原因与完整目标边界

旧ROOT15 tenant两段256普通step均第三周期NOT_OBSERVED，是原profit<=-600、inventory<1e-7、freeFunds<6.6666667三AND没有同真，不存在本审计证实的意愿/路线bug。原default120到121.50秒后raw1断言虽PASS仍TIMEOUT_PARTIAL；旧tenant-distress waiting/endPending/reopening及终点future24未获得原生证据，候选继续未安装。未降低门槛、补钱包、搬stock、取消押金/欠租/advance/工资债或无限等待来充数。

额外0Sim/0step纯参数核对当前default World SHA`2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512`和ROOT16真实terminal `edf73ed2aa923b16248f3981092ea78dfe6375e5be1a4d4e3c6914ca84285754`：109私营market中97缺同区workshop、94缺同区farm/dock、82两种皆缺，因此109缺至少一种，0同时齐。该结论只是有限同区采购条件缺项参数诊断，未调用quoteSupply或运行真实复工；具名所有行见`DEFAULT-SHOP-SUPPLY-DIAGNOSIS.json`。

109市场建筑均多层，但当前shop/title以整栋既有经营资产和同址使用许可绑定；没有真正每层多个店面/分租权利/土地楼宇产权、清算迁址或新业种。实际市场公共柜台/经营点/楼层权限可用，不等于楼层店面租赁全部实现。

下一可接续验收：先从真实default停业资产、本人正常钱包/物料及合法工班建立跨区真实配送的在途货权、搬运劳动和抵达库存路径，或由既有有余库存的同址供给实现有限复工；任何新区供给不可免费建店或瞬间跨区变材料。再对具名租户困难、保留三AND/生活储备/押金50和真实advance工资租债进行新的有界自然下一周期，并对新waiting/endPending/reopening状态和真正终点做future24。逐层店面资产/不同店主及行业、整栋拆迁安置新路、火震空间损伤、卫生病毒、长期稳态/真流式/参考美术/Mac和完整38域仍欠。

本候选尚未新跑build/UI/browser/全npm/长日/Mac；root合并多候选后按冻结新图做适当检查。无需重跑已通过旧巨大suite来以测试数掩盖这些剩余。

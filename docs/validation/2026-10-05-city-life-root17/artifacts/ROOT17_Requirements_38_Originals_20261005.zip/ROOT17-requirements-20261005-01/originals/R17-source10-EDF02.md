# ROOT17 默认 EDF 组合验收

2026-10-05 03:44 UTC，实际最终组合源 `source10` 的 351 个功能输入验证通过。此报告新增真实结果，不改旧失败、原存档或此前紧凑货运的封存证据。

## 已运行与已验证

真实 World 为 seed20261001、612 建筑、674 节点、691 边；SHA256 `2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512`。真实 EDF 原档为原 229 居民购粮续演终档，616 人、tick1104、clock2688、speed8，SHA256 `edf73ed2aa923b16248f3981092ea78dfe6375e5be1a4d4e3c6914ca84285754`。未重新生成地图或产品初始档。

执行范围冻结为原 `.25` 普通步长，保留原存档 speed8。实际 03:40:46.025351 至 03:43:57.503978，191.478627 秒 / cap360，104 次实例普通步进，5 个恢复读取器构造。已观测自有 PID/start-time 子进程均结束，active descendants 为空。

| 阶段 | 实际证明 | 普通步进 |
| --- | --- | ---: |
| 原规则对照 | 原 325 与最终 351 都导入、导出完整 EDF 字节相同；各 16 步，每一步全 save 字节相同，也等封存的 16 个 SHA | 32 |
| 原规则终档 | 最终 16 步完整字节等真实原 F4B 终档 `f4b9076c3b04c0479035995a9a159310ff9f742cab78c55d2c1269dcb3474040` | 已含上行 |
| 显式升级 | 独立恢复原 EDF；正确原 SHA 升级只增加 envelope/runtime 两个 `road-food-pickup-v1` 声明，删除这两项后完整 JSON 字节等原 EDF。错 SHA 与重复升级拒绝且全档不变 | 0 |
| 实盘读回与续演 | upgraded whole 实写读、124 个 World-assisted 地理 parts 各实写读，组装立即字节相同；源、whole reader、physical-part reader 未来 24 帧每一帧全 save 字节相同 | 72 |

升级前后其他所有保存字段，包括身体、需求、现金、库存、时间、tick、speed、角色、路径、focus 和 RNG，完整字节不变；未新增补钱、补粮、瞬移、改变作息或改变实体速度。

升级原件 SHA256 为 `16e47f570f4dc9c1edf81b4bd3a935b81c27009360736d4f306744e2fb45ead7`；未来 24 帧终档为 `992488b1c53c17014bd4c56916a1133b1db2f0e948509605ff71b948ba28f7e3`。每帧 tick/SHA、完整终档、124 原 parts、physical manifest、actual raw/receipt、输入前后及外部守护回执均保存。

最终 351 功能输入文件 manifest SHA256 `c3cc044331e046cd8e180d86c21b679d22c26de7649f13bd2b913cc7f2e90419`；父集成记录 functional graph `74aee7b713f03c51b9fd7427ed7fbfccdb60b451919c64c36295c75cb627c2be`。实际每个功能输入逐 SHA 与冻结 manifest 一致，外部原 325 源、全部旧测试/fixtures、driver/plan、World/EDF 原文件及物理复制品前后均未改变。

## 保留的失败与修正

`ROOT17-default-edf-integration-20261005-01` 的第一次准备误猜旧终档文件名 `terminal.save.json`；原实际文件是 `baseline16.save.json`，找到后才逐 SHA 复制。该准备失败为 0 Simulation / 0 step，原记录保留。

同一 01 命名空间的 actual01 在 5.411849 秒后 FAIL：新验证脚本错误要求旧 325 也拥有新增 `freightPickupPolicyId` getter。旧版没有这个 API，返回 undefined；此前唯一 baseline reader 的真实 EDF 导入导出已完整字节通过，实际 0 step，owned active 空。raw SHA256 `f8c215c685efbea2d2e652345f02213f7011efc6d23ebc8694571fd0d6fb488b`。这不是产品存档或模拟失败，不能改写旧 FAIL 为 PASS。

父会话另行批准 NEW02，只修旧基准 API 前件：旧档 envelope/runtime 两 marker 缺省；最终版仍要求 getter 为 legacy，其他完整字节、逐 tick、F4B、104 calls 和 cap360 全部不变。未修改旧代码、旧测试或 fixture。NEW02 实际 raw SHA256 `ed56dbdc5095b41fc389d1732e5e7cc00bb29827038549d51de78207f2efe505`。

## 边界与接续

默认城本次升级后 24 帧的 cargo-loaded/cargo-arrived 观察量为 **0**。本结果证明实际默认旧档合同保持不变、合法显式升级和保存恢复续演；不证明默认下一轮实际取货/卸货/供应商收款，也不证明财政或供给稳态。此前 331 紧凑场景的真实有限 28 单位运输属于不同范围，未重复运行，也不能替代默认城闭环。

软件 GPU、正常第一人称玩家旅程、Mac 性能、完整动态城市施工/灾害/卫生传播、长期经济及其他完整目标未由此范围验收。唯一重型窗口已释放，父会话可继续组合界面/GPU 验证。本子任务仅创建私有证据文件，不改 shared 源或备忘录，不提交、推送或写入 Library；由父会话纳入统一原件交付。

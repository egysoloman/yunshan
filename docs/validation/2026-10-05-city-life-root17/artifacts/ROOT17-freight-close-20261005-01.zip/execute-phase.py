"""Run one pre-approved frozen phase, preserving external input guards.

This coordinator does not import TypeScript, create a Simulation or edit inputs.
Only execute after the parent releases the exclusive simulation window.
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/yunshan-work/ROOT17-freight-pickup-20261005-02')
SOURCE = ROOT / 'candidate-source'
BASELINE = Path('/workspace/yunshan-work/ROOT17-shop-lifecycle-20261005-01/baseline-source')
OUTPUT = Path(__file__).parent
SCOPES = {
    'native01': (['node', '--import', 'tsx', '--test', '--test-concurrency=1', 'tests/freight-native-pickup.test.ts'], 600),
    'factory01': (['node', '--import', 'tsx', '--test', '--test-concurrency=1', 'tests/city-life-product.test.ts'], 120),
    'legacy01': (['node', '--import', 'tsx', '../legacy-compact-comparison.mts'], 120),
}
FROZEN = {
    'TRIP-PLAN.json': 'f1a5101adf8768d08131c9839fa6644b20941c32278874cff53e1d1f0bc1650e',
    'run-phase.py': 'c53609fd7a6b132768b01b66a4206ac0a018658734075d558a7299a0d7dfe9cd',
    'legacy-compact-comparison.mts': '5bbb77c4ed56dbff7edadc06f36fba343f3f005aa395a421add32bcac12dab53',
    'candidate-source/tests/freight-native-pickup.test.ts': '3128edcdeab9976ae2eb5c034b01130b0c4c9476eb730b90e8d7093a08d98e87',
    'candidate-source/tests/city-life-product.test.ts': '9e8cceaac2c65c7dcc8a28148ad496ac7ef87c97de22bec84b328ad8cf4f22b7',
    'CANDIDATE-INPUTS-331.json': 'afd7c13d99e02ea2631a971fb0a7c06d751089ab9b8edc71eec8fbbc81c4d1f3',
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs(directory):
    files = [p for n in ['src', 'tests', 'scripts', 'adapters', 'public'] for p in (directory / n).rglob('*') if p.is_file()]
    files += [directory / n for n in ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'index.html'] if (directory / n).is_file()]
    return {str(p.relative_to(directory)): sha(p) for p in sorted(files)}

phase = sys.argv[1]
assert phase in SCOPES, 'Only a frozen named phase is allowed'
scope = OUTPUT / phase
assert not scope.exists(), 'Never overwrite or rerun an existing bounded phase'
frozen_before = {name: sha(ROOT / name) for name in FROZEN}
assert frozen_before == FROZEN, 'Frozen driver or plan drift'
candidate_before = inputs(SOURCE)
baseline_before = inputs(BASELINE)
assert candidate_before == json.loads((ROOT / 'CANDIDATE-INPUTS-331.json').read_text())
assert baseline_before == json.loads((ROOT / 'BASELINE-INPUTS-325.json').read_text())
if phase == 'legacy01':
    assert not (ROOT / 'LEGACY-COMPACT-RESULT.json').exists(), 'Existing actual result must be inspected first'
guard = OUTPUT / f'{phase}-external-guard.json'
assert not guard.exists()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
argv, seconds = SCOPES[phase]
env = os.environ.copy()
if phase == 'native01':
    env['FREIGHT_PICKUP_ARTIFACTS'] = str(scope / 'artifacts')
command = [sys.executable, str(ROOT / 'run-phase.py'), str(SOURCE), str(scope), json.dumps(argv), str(seconds)]
completed = subprocess.run(command, env=env)
frozen_after = {name: sha(ROOT / name) for name in FROZEN}
candidate_after = inputs(SOURCE)
baseline_after = inputs(BASELINE)
receipt = json.loads((scope / 'receipt.json').read_text())
result = {
    'startedAt': started,
    'endedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'phase': phase,
    'command': command,
    'exitCode': completed.returncode,
    'wrapperStatus': receipt['status'],
    'candidateInputCount': len(candidate_before),
    'externalBaselineInputCount': len(baseline_before),
    'candidateBeforeMatchesFrozen331': True,
    'baselineBeforeMatchesFrozen325': True,
    'candidateInputBytesStable': candidate_before == candidate_after,
    'externalBaselineInputBytesStable': baseline_before == baseline_after,
    'allFrozenDriverAndPlanBytesStable': frozen_before == frozen_after == FROZEN,
    'coordinatorSHA256': sha(Path(__file__)),
    'activeDescendants': receipt['activeDescendants'],
    'scopeStatus': 'PASS' if completed.returncode == 0 and candidate_before == candidate_after and baseline_before == baseline_after and frozen_before == frozen_after == FROZEN and not receipt['activeDescendants'] else 'FAIL_OR_PARTIAL',
}
guard.write_text(json.dumps(result, indent=2) + '\n')
if phase == 'legacy01' and (ROOT / 'LEGACY-COMPACT-RESULT.json').exists():
    (scope / 'LEGACY-COMPACT-RESULT.original.json').write_bytes((ROOT / 'LEGACY-COMPACT-RESULT.json').read_bytes())
print(json.dumps(result))
sys.exit(0 if result['scopeStatus'] == 'PASS' else 1)

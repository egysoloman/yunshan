# Explicit native road food pickup candidate

Status: isolated implementation + pure/type evidence; **native transport remains NOT_RUN, waiting for root's exclusive CPU release after GPU/power67**. No shared source was changed, and no Simulation instance has been constructed or advanced by this candidate's producing runs so far.

Baseline is the immutable ROOT16 325-input source, `0c7aea22807f69ac83450ecd201d5ee6e933dff816e937cf18b0728e97d7a0da`, initial shared HEAD6a614c5. Candidate freezes 331 inputs / 82 source files. All original tests and fixtures keep their original byte hashes. `CANDIDATE-INPUTS-331.json` and `TRIP-PLAN.json` bind the candidate and queued runtime driver.

Six production paths change: Simulation connects its existing finite cargo host to the existing exact `freightPickupAccess` witness; the witness module gains policy-pair validation; city ruleset recognizes it; partition retains/validates both declarations; the fresh current-product recipe selects it and async city-life delegates to that actual source; and a new host helper upgrades an existing v4/native-motion2 snapshot through a complete exact-SHA handshake. Archived recipes, every older undeclared save (including old current-product saves) and flight loading retain their original loading predicates. The fresh current-product recipe explicitly declares the new road contact; its saved declaration controls subsequent behavior.

The policy is `road-food-pickup-v1`. The host still requires a trusted generated carrier of matching kind, zero cargo and legal occupied/passenger count. The witness requires the original vehicle and building objects, exact actual incoming endpoint/progress/direction, the open road, the native signed 1.3m lane position, its own warehouse door within 2m, matching real district/shop and finite food inventory. The existing transfer deducts producer inventory into cargo, assigns `cargoSources`, then a later actual arrival moves it into the named regional freight lot. Human room access, fleet capacity, stock targets, fiscal rates, money, labor and ownership rules are unchanged. The helper certifies access and creates no order, cargo, payment or fee.

`upgradeFreightPickup` requires the actual full current v4 save SHA256, production-reader validation and unchanged bytes after asynchronous hashing. It changes exactly the envelope/runtime declarations. Wrong SHA, drift, wrong version or repeated activation reject. This provides the planned route for the actual EDF continuation without rebuilding or resetting cash, needs, body, clock, routes or inventory. Actual EDF upgraded runtime and future continuation have not run here.

| Fresh 02 scope | Actual result | Wall / bound | Scope |
|---|---|---:|---|
| pure01 | 6 PASS | 7.605s / 120s | 331 inputs, 47 real default potential contact parameters |
| types01 | PASS | 21.794s / 120s | 331 inputs, includes queued native regression |
| pure-partition01 | PASS | 2.038s / 120s | Exact EDF / two-marker pure clone, 124 blocks |

All scope input readbacks are stable; strong PID/start-time ownership receipts show zero active descendants. Pure scopes construct 0 Simulation instances and perform 0 steps. Four unchanged original pure freight-access cases test identity, exact contact, malformed contacts, closed roads, wrong warehouse/source, existing cargo, reversed path and original flight witness. Two new pure cases test declaration pairs and all47 preserved default producer contact parameters. The actual default original human lane check remains 0/47; witness contacts pass47/47 without mutating producer parameters. Parameter fixture is explicitly potential arrivals, not an observed trip.

Pure partition validation retains real EDF SHA `edf73ed2aa923b16248f3981092ea78dfe6375e5be1a4d4e3c6914ca84285754` byte for byte; the derived two-marker policy fixture also roundtrips exactly. Both incomplete pairs and removed runtime-order metadata are rejected. This validates serialization structure; it does not replace the production Simulation reader or future runtime checks.

`tests/freight-native-pickup.test.ts` is the next installed regression. Its fixed declared compact world has384 generated people, an unchanged actual default farm body, two station nodes, a200m road and the original28-unit carrier recipe. No post-constructor actor, inventory, cash, need, departure, position, signal, clock, speed or RNG value is injected. It requires real anonymous unloading, real finite named pickup, actual travel to a subsequent node, named unloading, food and cash conservation each tick, unchanged strict human-room access, physical partition write/read/assembly and exact full/parts future24. It stops within768 ordinary .25/speed1 steps (192 game minutes), followed by24 future frames (6 minutes). There are at most3 simultaneous compact instances and at most840 instance tick advances in this phase, under600s wall. Failure or timeout is terminal for that frozen scope.

A separate private `legacy-compact-comparison.mts` checks88 compact frames against the immutable baseline, then exact-SHA/no-reset two-marker cutover on an old synchronous current-product snapshot. Its private baseline import is validation tooling only; the installed tests depend exclusively on repository files. This second phase is bounded120s and remains queued, requiring root's serial scheduling.

The unchanged original `city-life-product.test.ts` requires async city-life to add only the service declaration to the actual current-product source, with exact SHA and whole bytes after removing that one declaration. Static reading found that the unrun frozen01 factory arrangement violated this contract. A NEW02 source therefore declares road pickup in fresh `createCurrentProductCity` and restores async delegation; no test assertion was changed. 01 source, plan, pure/type receipts and patches remain intact; no native01 runtime was started. The private cutover driver explicitly constructs the old current flags with no pickup marker, then certifies an upgrade that changes only the two pickup declarations.

Exact immutable baseline325 apply-check succeeds:

* `PRODUCTION.patch`: SHA256 `881ae3ab02769567a4254270df2877855aa76b4c06db299877908bfe3a790b8d`.
* `OWNED.patch`: SHA256 `a3c61b52c4be229f45e03df6537a04a113e50ec8da85be1c49460901b0524288`.
* Input manifest SHA256 `afd7c13d99e02ea2631a971fb0a7c06d751089ab9b8edc71eec8fbbc81c4d1f3`.

The source/trip contract is frozen02, pending root's exclusive release; queued native transport, legacy comparison and the two original factory regressions are not yet run. Earlier01 patch-metadata failure and its corrected artifacts remain in01, and are not falsely described as a02 runtime failure.

The original two ROOT17 shop repair production edits are not included in this independent baseline candidate. Root must integrate them together with other Simulation changes. This candidate is not an established default-city production/revenue recovery, freight sale/payment proof, economic steady state, per-floor shop property/lease turnover or natural repeated reopening. Default three-district food gaps and original old14-day cash/job/company failures stay open in their original scopes. No full suite, GPU, commit, push, Library or paid action was performed by this task.

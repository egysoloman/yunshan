"""Restore byte-verified original files from the local content-addressed ZIP."""
import argparse, hashlib, json, pathlib, zipfile

parser = argparse.ArgumentParser()
parser.add_argument('archive', type=pathlib.Path)
parser.add_argument('destination', type=pathlib.Path)
args = parser.parse_args()
if args.destination.exists():
    parser.error('destination must be a new directory')
with zipfile.ZipFile(args.archive) as archive:
    paths = json.loads(archive.read('PATHS.json'))
    verified = {}
    for name, record in paths.items():
        relative = pathlib.PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts:
            parser.error('unsafe original relative path')
        digest = record['sha256']
        if len(digest) != 64 or any(c not in '0123456789abcdef' for c in digest):
            parser.error('invalid object digest')
        data = verified.get(digest)
        if data is None:
            data = archive.read('objects/' + digest)
            if hashlib.sha256(data).hexdigest() != digest:
                parser.error('object checksum mismatch')
            verified[digest] = data
        if len(data) != record['bytes']:
            parser.error('original size mismatch')
    args.destination.mkdir(parents=True)
    for name, record in paths.items():
        target = args.destination.joinpath(*pathlib.PurePosixPath(name).parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(verified[record['sha256']])
print(json.dumps({'restoredPaths': len(paths), 'verifiedObjects': len(verified)}))

import assert from 'node:assert/strict';
import { writeFileSync } from 'node:fs';
import { Simulation } from './source/src/simulation';
import { getBuildingEntrance, getBuildingUsePoints } from './source/src/architecture-floor-plan';
import { homeRestPoints, homeRestPointAt } from './source/src/simulation/home-rest';
import type { Building, Vec3, WorldDefinition } from './source/src/types';
const distance = (a: Vec3, b: Vec3) => Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
function world(): WorldDefinition {
  // The existing real v4 three-floor home recipe; four unmarked public sites
  // keep this a small 5-building fixture, never the default 612-building city.
  const home: Building = { id: 'market-b24', districtId: 'market', name: '真实三层里居', kind: 'home', position: { x: -390.8, y: 76, z: 316.2 }, width: 40, depth: 34.4, height: 10.2, floors: 3, rotation: 0, door: { x: 0, y: 0, z: 0 }, capacity: 129, seed: 668619109, floorPlanProfile: 'v4-program-bodies-02' };
  home.door = getBuildingEntrance(home);
  home.functionPoints = Array.from({ length: home.floors }, (_, floor) => getBuildingUsePoints(home, floor)).flat();
  const kinds: Building['kind'][] = ['pavilion', 'clinic', 'school', 'bank'];
  const buildings = [home, ...kinds.map((kind, i): Building => ({ id: `voxel-${kind}`, districtId: 'market', name: kind, kind, position: { x: home.position.x + (i + 1) * 120, y: 76, z: home.position.z }, width: 20, depth: 20, height: 6, floors: 1, rotation: 0, door: { x: home.position.x + (i + 1) * 120, y: 76.6, z: home.position.z + 10 }, capacity: 50, seed: i + 7 }))];
  const nodes = buildings.flatMap(b => [{ id: `${b.id}-door`, name: b.name, districtId: 'market', position: { ...b.door }, station: false }, { id: `${b.id}-street`, name: b.name, districtId: 'market', position: { x: b.position.x, y: 76.6, z: home.position.z + 35 }, station: false }]);
  const edges: WorldDefinition['edges'] = buildings.map((b, i) => ({ id: `voxel-door-${b.id}`, from: nodes[i * 2].id, to: nodes[i * 2 + 1].id, mode: 'road', length: distance(nodes[i * 2].position, nodes[i * 2 + 1].position), capacity: 20, points: [nodes[i * 2].position, nodes[i * 2 + 1].position] }));
  for (let i = 1; i < buildings.length; i++) edges.push({ id: `voxel-street-${i}`, from: nodes[i * 2 - 1].id, to: nodes[i * 2 + 1].id, mode: 'road', length: 120, capacity: 20, points: [nodes[i * 2 - 1].position, nodes[i * 2 + 1].position] });
  return { seed: 911, voxelSize: .2, size: 4000, buildings, nodes, edges, districts: [{ id: 'market', name: '床侧体素受控回归', kind: 'market', center: { ...home.position }, radius: 1200, color: '#888888', population: 384 }], spawn: { ...home.door }, mountains: [], river: [], waterfall: { top: { x: 1800, y: 100, z: 1800 }, bottom: { x: 1800, y: 0, z: 1800 }, width: 10 } };
}

const sim = new Simulation(world()), home = sim.worldDefinition.buildings[0];
const directory = '/tmp/yunshan-npc-bed-voxel-candidate-01/evidence/command-probe';
const service = home.functionPoints!.find(p => p.floor === 0 && p.purpose === 'service')!;
assert(service); const wallet = sim.state.player.money, blocks = sim.state.player.inventory.block!;
sim.setFocus(service.position, 'walk'); const rented = sim.command({type:'rent',targetId:home.id});
assert(rented.ok, rented.message); assert.equal(sim.state.player.homeId,home.id); assert.equal(sim.state.player.money,wallet-80);
const points = homeRestPoints(home,0).sort((a,b)=>distance(a.position,service.position)-distance(b.position,service.position));
const point=points[0]; assert(point); sim.setFocus(point.position,'walk');
assert.equal(homeRestPointAt(home,sim.state.player.position,sim.state.player)?.id,point.id);
const before = sim.exportSave(); writeFileSync(directory+'/before.json',before);
const requested={...point.position,y:point.position.y+.8}; const result=sim.command({type:'build',targetId:home.id,position:requested});
const after=sim.exportSave(); writeFileSync(directory+'/after.json',after);
const evidence={scope:'Native rent and build command with controlled function-point/bed-side setFocus; no ordinary Controller travel claim',rented,build:result,homeId:sim.state.player.homeId,service:service.position,point,serviceToBed:distance(service.position,point.position),requested,walletBefore:wallet,walletAfter:sim.state.player.money,blocksBefore:blocks,blocksAfter:sim.state.player.inventory.block,voxels:sim.state.voxels,rejectionAtomic:after===before};
writeFileSync(directory+'/result.json',JSON.stringify(evidence,null,2)+'\n'); console.log(JSON.stringify(evidence));
assert(result.ok,result.message);
assert.equal(sim.state.player.inventory.block,blocks-1); assert.equal(sim.state.voxels.length,1);
assert.equal(sim.state.player.money,wallet-80);

# 建筑体量与共享楼层候选 01（仅 CPU 原型）

状态：这是可复查、可继续开发的 `/tmp` 候选；没有写入游戏生产源码，没有创建 WebGL、浏览器渲染器或修改存档。**六类体量、视觉参考匹配和 utilities 均未作为已完成验收。**

根实际看过六代表 CPU PNG 后指出：住宅、市集、书院、诊所地面仍为相近 U 形加中轴，3D 是反复 L/U 盒体，主要依靠高度退台。这个判断成立。六个不同 silhouette SHA 包含尺寸和楼层差异，不能证明六种用途轮廓可辨。屋顶也只是体量代理，尚没有参考图中的完整檐口、窗、斗拱、院落摆设及环境构图。候选 02 在另一个目录继续尝试用途不同的物理布局；本版不覆盖。

## 原始交付

- `six-family-bodies.png`：实际导出 far 几何的 CPU 正交三维图。
- `six-family-ground-plans.png`：实际共享房间、空院、廊与墙/门描述的 CPU 平面图。
- `six-family-body-plans.svg`：同一候选 CPU 图。
- `preview-geometry.json`：六代表的原始几何和地面楼层模型。
- `prototype/floor-plan.ts`：房间矩形并集、门与墙、楼梯孔及平台、实心挤出、共享 far 箱体实例。
- `prototype/check.ts`、`results-{20261001,7,2024}.json`：真实 612 建筑、3516 楼层和旧世界验证数据。
- `prototype/guards.ts`、`guards-results.json`：12 条具名正/负几何与支持检查。
- `source-manifest.json`：checkpoint `3f01707581eef697572ffa58bdb994bef037e98d` 的 33 文件 SHA，以及五张原参考和六张 Macro6 实际阅读图片 SHA。

图中已经明确写出 CPU diagram，**这些不是游戏截图**。所有 PNG 在交付前实际打开检查。

## 检查范围与结果

三 seed 都实际运行了独立 CPU 检查。源码前后 SHA 一致，所有 33 冻结源码逐项 SHA 一致。每个 seed 都是 612 建筑、3516 楼层。612 全楼检查原尺寸、门、楼层数量、固定 shaft、floor/use 点可站立、正高度、far 并集覆盖和每个 MeshPart 闭合/朝向/0.2m 网格；仅六代表逐层执行 0.8m 分辨率、0.35m 半径轴向采样的 BFS。

|seed|闭合 MeshPart|旧 far 建筑三角分量|候选三角分量|三角比|buffer 比|
|---|---:|---:|---:|---:|---:|
|20261001|124183|237392|236080|0.994473|1.063390|
|7|124285|237608|236272|0.994377|1.061913|
|2024|124306|237360|236308|0.995568|1.063600|

buffer 是实际旧 frozen `CityRenderer.prototype.buildHouse` 记录出的建筑组件 geometry attributes/index + instance matrix/color/facade 与候选同类库存比较（384m 空间/材质/geometry grouping）。没有实例化 CityRenderer 或 GL。它不代表实际 frustum 提交、完整场景、shadow 提交、帧时间、FPS 或近景常驻量。候选用了共享箱体 instance descriptor；独有 whole-building far mesh 的高内存中间版本已经保留为失败历史，并没有用于最终预算结论。

12 个旧生成器证明：current-v3/current-v2/current-v2-r5 各三个 seed 与可信 fixture 的完整 world `deepEqual`、JSON SHA、实际 savedWorldFingerprint 相同；legacy-ee3e7a1 的三个 seed 去掉 recipe 的 layoutVersion 后与原 main body SHA 一致，实际 fingerprint 一致。这里没有声称 legacy 新增 label 的整个 JSON 与原 main 字节完全相同。运行 existing-envelope 构造器之后，当前生成的 world JSON 全部保持原字节。**不是 12 个完整模拟存档续演测试。**

天枢主阁和全部 pavilion 保留原 renderer 路径，core 有原 30 地上层、2 地下层；使用原 canAccessFloor 核验 public 29 与无权限 -2，原 floor permissions metadata 原样保留。

## 几何合同与限制

实际空院属于 ground supported platform；房间并集产生墙、门与 collision panel，near/far 都来自该并集；真正 stairHole 从楼板扣除，独立 stairLanding 有真实 0.2m slab，不把孔洞空气假作地面。低廊屋顶位于 2.6–2.8m，原门内落脚点保持。

这些检查仍有明确限制：`canStand` 的脚底只用中心及四轴采样，尚非完整圆盘扫掠；`closedMesh` 是每个 part 的索引边流形与朝向，不证明不同交叠 part 整体无缝。BFS 为六代表逐层，不是所有楼层的真实 Controller 连续行走。外门只查有限 terrain/getWalkHeight 和内落脚点，没有连续接入实际道路。没有权限迁移、跨楼层受控 action 或 WASD 楼梯斜面接入；没有真实 NPC 去新 usePoints 路线、完整存档重载或 GL。旋转 localPosition 是候选 helper，生产 Controller 仍需统一。不能把这些限制升级为浏览器可玩通过。

## 两个可 review 的集成方向

1. existing-envelope 仅用作保留旧 renderer/旧矩形碰撞的兼容桥。它没有改变建筑体量，不能声明它已消除同质高塔。现市场矮柜与共享 site fixtures 是独立可逆的 renderer/controller 改善，由 root 实施，本原型不修改它。
2. v4-wings 真正改变占地和空院，需要新世界 recipe。world 生成/可信 descriptor+fingerprint、access/floor support、controller 碰撞与旋转、near/far residency、NPC usePoints、保存 recipe 路由须共同接入。原四 recipe 必须保留；不能 renderer 画出空院而原 controller/world 仍支撑一整块矩形。权限继续由原 canAccessFloor 判定。

## 保留的失败

- `check-first.log`：面积浮点精确比较，之后只在算术面积等式使用 1e-7；世界字节比较仍严格。
- `check-second.log`、`mesh-smoke-first.log`：-10.600000000000001 与 -10.6 的细缝使 union 边界退化；几何 cuts 先规范 0.2m 格，不改真实世界原值。
- `check-fourth.log`、`check-final.log`：独有 far mesh 库存过大；换为共享矩形 box 实例，后续三 seed 原始日志仍在。
- `preview-raster.log`：ImageMagick 缺 rsvg-convert；实际最终 PNG 改用 Matplotlib Agg。

## 复跑

在此目录：`npx tsc -p tsconfig.json`；`YUNSHAN_ARCHITECTURE_SEED=20261001 npx tsx prototype/check.ts`（另外 7/2024）；`npx tsx prototype/guards.ts`；`npx tsx prototype/export-geometries.ts`；`MPLCONFIGDIR=./mpl-config python prototype/plot-geometries.py`。依赖 symlink 指向实际工作区 node_modules，冻结源码是本地 checkpoint 内容。没有下载或联系外部服务。

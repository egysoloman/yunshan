import * as THREE from 'three';
import { writeFileSync, readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { createWorld, terrainHeight } from '/tmp/yunshan-phase2-root-coherent-02/src/world.ts';
import { getFloorDimensions } from '/tmp/yunshan-phase2-root-coherent-02/src/access.ts';
import { buildLandscape } from '/tmp/yunshan-phase2-root-coherent-02/src/rendering/terrain.ts';

// Isolated geometry study. This reads the frozen world and changes neither
// production source nor the authoritative tree roots or walk-height function.
const useBands=process.argv.includes('--bands');
const OUT = '/tmp/yunshan-forest-canopy-prototype'+(useBands?'/bands':'');
const world = createWorld(), landscape = buildLandscape(world);
const q = (x: number) => Math.round(x / .2) * .2;
interface Root { id: number; x: number; y: number; z: number; height: number; color: THREE.Color }
interface Crown { x: number; z: number; bottom: number; top: number; color: THREE.Color; sources: Set<number> }
interface Data { positions: number[]; colors: number[]; indices: number[] }
const roots: Root[] = [], baseline: THREE.InstancedMesh[] = [];
const matrix = new THREE.Matrix4(), position = new THREE.Vector3(), scale = new THREE.Vector3(), rotation = new THREE.Quaternion();
landscape.vegetation.traverse(object => {
  if (!(object instanceof THREE.InstancedMesh)) return;
  if (object.name === '远林树干代理' || object.name === '远林错层树冠代理') baseline.push(object);
  if (object.name !== '山林树干') return;
  const group = object.parent!;
  const crownMesh = group.children.find(child => child.name === '错层乔木冠') as THREE.InstancedMesh;
  for (let i = 0; i < object.count; i++) {
    object.getMatrixAt(i, matrix); matrix.decompose(position, rotation, scale);
    const color = new THREE.Color(); crownMesh.getColorAt(i * 4, color);
    roots.push({ id: roots.length, x: position.x, y: q(position.y - scale.y / 2), z: position.z, height: q(scale.y / .7), color });
  }
});

// Use the same rotated floor footprints for plant clearance as actual building
// occupation. A crown is clipped below the real roof; planting is unchanged.
const size = 96, buildings = new Map<string, typeof world.buildings>();
for (const b of world.buildings) {
  const radius = Math.hypot(b.width, b.depth) / 2 + 24;
  for (let x = Math.floor((b.position.x - radius) / size); x <= Math.floor((b.position.x + radius) / size); x++)
    for (let z = Math.floor((b.position.z - radius) / size); z <= Math.floor((b.position.z + radius) / size); z++) {
      const key = `${x}:${z}`, list = buildings.get(key) ?? []; list.push(b); buildings.set(key, list);
    }
}
function obstruction(x: number, z: number, half: number, bottom: number, top: number) {
  for (const b of buildings.get(`${Math.floor(x / size)}:${Math.floor(z / size)}`) ?? []) {
    const dx = x - b.position.x, dz = z - b.position.z, cos = Math.cos(b.rotation), sin = Math.sin(b.rotation);
    const bx = dx * cos - dz * sin, bz = dx * sin + dz * cos, spread = half * (Math.abs(cos) + Math.abs(sin));
    const floorHeight = b.height / b.floors;
    for (let floor = 0; floor < b.floors; floor++) {
      const dims = getFloorDimensions(b, floor), overhang = Math.max(2, Math.min(12, dims.width * .14));
      const lo = b.position.y + floorHeight * floor, hi = lo + floorHeight + Math.min(14, dims.width * .18);
      if (hi < bottom || lo > top) continue;
      if (Math.abs(bx) < dims.width / 2 + overhang + spread && Math.abs(bz) < dims.depth / 2 + overhang + spread) return true;
    }
  }
  return false;
}

const hash=(x:number,z:number)=>{const v=Math.sin(x*12.9898+z*78.233+world.seed*.113)*43758.5453;return v-Math.floor(v);};
const distanceSegment=(x:number,z:number,a:{x:number;z:number},b:{x:number;z:number})=>{
  const dx=b.x-a.x,dz=b.z-a.z,t=Math.max(0,Math.min(1,((x-a.x)*dx+(z-a.z)*dz)/(dx*dx+dz*dz||1)));
  return Math.hypot(x-a.x-dx*t,z-a.z-dz*t);
};
const roadSegments=new Map<string,{a:{x:number;z:number};b:{x:number;z:number};width:number}[]>();
for (const edge of world.edges.filter(e=>['road','bridge','lightRail'].includes(e.mode))) for(let i=1;i<edge.points.length;i++) {
  const a=edge.points[i-1],b=edge.points[i],width=edge.id.includes('airport-runway-strip')?25:8;
  for(let x=Math.floor((Math.min(a.x,b.x)-width)/96);x<=Math.floor((Math.max(a.x,b.x)+width)/96);x++)
    for(let z=Math.floor((Math.min(a.z,b.z)-width)/96);z<=Math.floor((Math.max(a.z,b.z)+width)/96);z++){
      const key=`${x}:${z}`,list=roadSegments.get(key)??[];list.push({a,b,width});roadSegments.set(key,list);
    }
}
function rootAllowed(x:number,z:number,y:number) {
  if(y<8 || y>630 || obstruction(x,z,3,y,y+2))return false;
  if((roadSegments.get(`${Math.floor(x/96)}:${Math.floor(z/96)}`)??[]).some(s=>distanceSegment(x,z,s.a,s.b)<s.width+3))return false;
  if(world.river.slice(1).some((p,i)=>distanceSegment(x,z,world.river[i],p)<20))return false;
  if(Math.hypot(x-world.waterfall.bottom.x,z-world.waterfall.bottom.z)<60 || Math.abs(x-world.waterfall.top.x)<50 && z>world.waterfall.top.z-20 && z<world.waterfall.bottom.z+20)return false;
  return Math.abs(terrainHeight(world,x+2,z)-y)<=8 && Math.abs(terrainHeight(world,x,z+2)-y)<=8;
}
const originalRoots=roots.map(root=>({...root,color:root.color.clone()}));
const bandCells:{anchor:number;x:number;z:number;trees:number}[]=[];
if(useBands){
  const candidates=new Map<string,{x:number;z:number;y:number}>();
  for(let x=-68;x<68;x++)for(let z=-68;z<68;z++) {
    const xx=(x+.5)*32,zz=(z+.5)*32,yy=q(terrainHeight(world,xx,zz));
    let allowed=rootAllowed(xx,zz,yy);
    if(!allowed)for(const[dx,dz]of[[-8,-8],[8,8]]){const y=q(terrainHeight(world,xx+dx,zz+dz));if(rootAllowed(xx+dx,zz+dz,y)){allowed=true;break;}}
    if(allowed)candidates.set(`${x}:${z}`,{x,z,y:yy});
  }
  const anchors=[...world.districts.filter(d=>!['airport','starport'].includes(d.kind)).map((d,i)=>{
    const angle=i*2.39996;return{x:d.center.x+Math.cos(angle)*d.radius*.90,z:d.center.z+Math.sin(angle)*d.radius*.90};
  }),...world.mountains.map((m,i)=>{const angle=i*2.39996+.8;return{x:m.x+Math.cos(angle)*m.radius*.54,z:m.z+Math.sin(angle)*m.radius*.54};})];
  roots.length=0;const occupied=new Set<string>();
  anchors.forEach((anchor,anchorIndex)=>{
    const seed=[...candidates.values()].sort((a,b)=>Math.hypot((a.x+.5)*32-anchor.x,(a.z+.5)*32-anchor.z)-Math.hypot((b.x+.5)*32-anchor.x,(b.z+.5)*32-anchor.z))[0];
    if(!seed)return;
    const target=Math.floor(5200/anchors.length)+(anchorIndex<5200%anchors.length?1:0),seen=new Set<string>();
    const frontier=[seed];let planted=0;
    while(frontier.length && planted<target){
      frontier.sort((a,b)=>{
        const cost=(c:typeof seed)=>Math.hypot(c.x-seed.x,c.z-seed.z)*.6+Math.abs(c.y-seed.y)/22+hash(c.x,c.z)*.05;
        return cost(a)-cost(b);
      });
      const cell=frontier.shift()!,key=`${cell.x}:${cell.z}`;if(seen.has(key))continue;seen.add(key);
      for(const [dx,dz]of[[-1,0],[1,0],[0,-1],[0,1]]){const neighbour=candidates.get(`${cell.x+dx}:${cell.z+dz}`);if(neighbour&&!seen.has(`${neighbour.x}:${neighbour.z}`))frontier.push(neighbour);}
      if(occupied.has(key))continue;
      occupied.add(key);let trees=0;
      for(const [dx,dz]of[[-8,-8],[8,-8],[-8,8],[8,8],[-10,0],[10,0],[0,-10],[0,10]]){
        if(planted>=target)break;
        const x=q((cell.x+.5)*32+dx),z=q((cell.z+.5)*32+dz),y=q(terrainHeight(world,x,z));if(!rootAllowed(x,z,y))continue;
        const height=q(19+hash(x,z)*10),color=new THREE.Color(anchorIndex%5===0?'#6a8147':'#365d40').lerp(new THREE.Color('#6c8960'),hash(z,x)*.22);
        roots.push({id:roots.length,x,y,z,height,color});planted++;trees++;
      }
      if(trees)bandCells.push({anchor:anchorIndex,x:cell.x,z:cell.z,trees});
    }
  });
}

function crownField(step: number) {
  const field = new Map<string, Crown>(); let clipped = 0;
  for (const root of roots) {
    // Each existing tree contributes three connected, unequal lobes. There are
    // no isolated far trunks. Near geometry retains the actual supporting tree.
    const lobes = [
      { dx: -.11, dz: -.08, rx: .43, rz: .35, top: .90, bottom: .49 },
      { dx: .12, dz: .10, rx: .37, rz: .32, top: 1.00, bottom: .60 },
      { dx: .02, dz: -.13, rx: .27, rz: .30, top: .98, bottom: .64 },
    ];
    for (const lobe of lobes) {
      const cx = root.x + root.height * lobe.dx, cz = root.z + root.height * lobe.dz, rx = root.height * lobe.rx, rz = root.height * lobe.rz;
      for (let ix = Math.floor((cx - rx) / step); ix <= Math.floor((cx + rx) / step); ix++)
        for (let iz = Math.floor((cz - rz) / step); iz <= Math.floor((cz + rz) / step); iz++) {
          const x = (ix + .5) * step, z = (iz + .5) * step;
          const radius = Math.hypot((x - cx) / rx, (z - cz) / rz);
          if (radius > 1) continue;
          const top = q(root.y + root.height * (lobe.top - .14 * radius * radius)), bottom = q(root.y + root.height * lobe.bottom);
          if (obstruction(x, z, step / 2, bottom, top)) { clipped++; continue; }
          const key = `${ix}:${iz}`, current = field.get(key);
          if (!current) field.set(key, { x: ix, z: iz, bottom, top, color: root.color.clone(), sources: new Set([root.id]) });
          else { current.bottom = Math.min(current.bottom, bottom); if (top > current.top) { current.top = top; current.color.copy(root.color); } current.sources.add(root.id); }
        }
    }
  }
  let clippedTerrain=0,clippedCombinedBuilding=0;
  for(const [key,c]of field){
    const ground=Math.max(...[[0,0],[0,step],[step,0],[step,step],[step/2,step/2]].map(([dx,dz])=>terrainHeight(world,c.x*step+dx,c.z*step+dz)));
    c.bottom=q(Math.max(c.bottom,ground+.4));
    if(c.bottom>=c.top){field.delete(key);clippedTerrain++;}
    else if(obstruction((c.x+.5)*step,(c.z+.5)*step,step/2,c.bottom,c.top)){field.delete(key);clippedCombinedBuilding++;}
  }
  return { field, clipped,clippedTerrain,clippedCombinedBuilding };
}
function quad(data: Data, points: number[], color: THREE.Color) {
  const i = data.positions.length / 3; data.positions.push(...points);
  for (let n = 0; n < 4; n++) data.colors.push(color.r, color.g, color.b);
  data.indices.push(i, i + 1, i + 2, i, i + 2, i + 3);
}
function volume(field: Map<string, Crown>, step: number, continuous = false) {
  const chunks = new Map<string, Data>();
  const nodes = new Map<string,{ top:number; bottom:number }>();
  const node = (x:number,z:number) => {
    const key = `${x}:${z}`, known = nodes.get(key); if (known) return known;
    const members = [field.get(`${x-1}:${z-1}`),field.get(`${x-1}:${z}`),field.get(`${x}:${z-1}`),field.get(`${x}:${z}`)].filter(Boolean) as Crown[];
    const value = { top:q(members.reduce((sum,c)=>sum+c.top,0)/members.length),bottom:q(members.reduce((sum,c)=>sum+c.bottom,0)/members.length) };
    nodes.set(key,value); return value;
  };
  for (const c of field.values()) {
    const chunk = `${Math.floor(c.x * step / 384)}:${Math.floor(c.z * step / 384)}`, data = chunks.get(chunk) ?? { positions: [], colors: [], indices: [] };
    chunks.set(chunk, data);
    const ax = c.x * step, bx = ax + step, az = c.z * step, bz = az + step;
    if (continuous) {
      const a=node(c.x,c.z),b=node(c.x,c.z+1),d=node(c.x+1,c.z+1),e=node(c.x+1,c.z);
      quad(data,[ax,a.top,az, ax,b.top,bz, bx,d.top,bz, bx,e.top,az],c.color.clone().multiplyScalar(1.08));
      quad(data,[ax,b.bottom,bz, ax,a.bottom,az, bx,e.bottom,az, bx,d.bottom,bz],c.color.clone().multiplyScalar(.70));
    } else {
      quad(data, [ax,c.top,az, ax,c.top,bz, bx,c.top,bz, bx,c.top,az], c.color.clone().multiplyScalar(1.08));
      quad(data, [ax,c.bottom,bz, ax,c.bottom,az, bx,c.bottom,az, bx,c.bottom,bz], c.color.clone().multiplyScalar(.70));
    }
    const neighbour = [[-1,0],[1,0],[0,-1],[0,1]];
    neighbour.forEach(([dx,dz], side) => {
      const other = field.get(`${c.x + dx}:${c.z + dz}`), sections: [number,number][] = [];
      if (continuous) {
        if (other) return;
        const a=node(c.x,c.z),b=node(c.x,c.z+1),d=node(c.x+1,c.z+1),e=node(c.x+1,c.z);
        const points = side===0 ? [ax,b.bottom,bz, ax,b.top,bz, ax,a.top,az, ax,a.bottom,az] : side===1 ? [bx,e.bottom,az, bx,e.top,az, bx,d.top,bz, bx,d.bottom,bz] : side===2 ? [ax,a.bottom,az, ax,a.top,az, bx,e.top,az, bx,e.bottom,az] : [bx,d.bottom,bz, bx,d.top,bz, ax,b.top,bz, ax,b.bottom,bz];
        quad(data,points,c.color.clone().multiplyScalar(.83+side*.04)); return;
      }
      if (!other || other.bottom >= c.top || other.top <= c.bottom) sections.push([c.bottom,c.top]);
      else { if (other.bottom > c.bottom) sections.push([c.bottom,Math.min(c.top,other.bottom)]); if (other.top < c.top) sections.push([Math.max(c.bottom,other.top),c.top]); }
      for (const [lo,hi] of sections) {
        const points = side === 0 ? [ax,lo,bz, ax,hi,bz, ax,hi,az, ax,lo,az] : side === 1 ? [bx,lo,az, bx,hi,az, bx,hi,bz, bx,lo,bz] : side === 2 ? [ax,lo,az, ax,hi,az, bx,hi,az, bx,lo,az] : [bx,lo,bz, bx,hi,bz, ax,hi,bz, ax,lo,bz];
        quad(data, points, c.color.clone().multiplyScalar(.83 + side * .04));
      }
    });
  }
  const group = new THREE.Group(); group.name = 'PROTOTYPE 32m连续冠群，不是生产美术验收';
  const material = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1 });
  for (const [key,data] of chunks) {
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position',new THREE.Float32BufferAttribute(data.positions,3)); geometry.setAttribute('color',new THREE.Float32BufferAttribute(data.colors,3)); geometry.setIndex(data.indices); geometry.computeVertexNormals(); geometry.computeBoundingSphere();
    const mesh = new THREE.Mesh(geometry,material); mesh.name = `连续冠群384m合批 ${key}`; group.add(mesh);
  }
  return { group, triangles: [...chunks.values()].reduce((sum,data) => sum + data.indices.length / 3,0) };
}
function connectivity(field: Map<string,Crown>, step: number) {
  const todo = new Set(field.keys()), areas: number[] = [];
  while (todo.size) {
    const stack = [todo.values().next().value!]; todo.delete(stack[0]); let count = 0;
    while (stack.length) {
      const key = stack.pop()!, [x,z] = key.split(':').map(Number); count++;
      for (const [dx,dz] of [[-1,0],[1,0],[0,-1],[0,1]]) { const k = `${x+dx}:${z+dz}`; if (todo.delete(k)) stack.push(k); }
    }
    areas.push(count * step * step);
  }
  areas.sort((a,b) => b-a);
  return { components: areas.length, largestAreaMetresSquared: areas[0], largestTenAreaMetresSquared: areas.slice(0,10), totalAreaMetresSquared: areas.reduce((a,b)=>a+b,0) };
}
function greedyVolume(field:Map<string,Crown>,step:number){
  const vertical=4,planes=new Map<string,{axis:number;sign:number;at:number;family:number;faces:Map<string,[number,number]>}>(),columns=new Map<string,{lo:number;hi:number;family:number}>();
  const add=(axis:number,sign:number,at:number,u:number,v:number,family:number)=>{
    const key=`${axis}:${sign}:${at}:${family}`,p=planes.get(key)??{axis,sign,at,family,faces:new Map()};p.faces.set(`${u}:${v}`,[u,v]);planes.set(key,p);
  };
  for(const [key,c]of field){
    const hi=Math.floor(c.top/vertical),lo=Math.max(Math.ceil(c.bottom/vertical),hi-4);
    if(hi<=lo)continue;
    columns.set(key,{lo,hi,family:c.color.r/Math.max(.001,c.color.g)>.5?1:0});
  }
  for(const[key,a]of columns){
    const[x,z]=key.split(':').map(Number);
    add(1,1,a.hi*vertical,x,z,a.family);add(1,-1,a.lo*vertical,x,z,a.family);
    for(const[dx,dz]of[[-1,0],[1,0],[0,-1],[0,1]]){
      const b=columns.get(`${x+dx}:${z+dz}`);
      for(let y=a.lo;y<a.hi;y++)if(!b||y<b.lo||y>=b.hi){
        if(dx)add(0,dx,(x+(dx>0?1:0))*step,z,y,a.family);
        else add(2,dz,(z+(dz>0?1:0))*step,x,y,a.family);
      }
    }
  }
  const chunks=new Map<string,Data>();let originalUnitFaces=0,rectangles=0,maxSpan=0;
  for(const p of planes.values()){
    originalUnitFaces+=p.faces.size;
    while(p.faces.size){
      const[u,v]=p.faces.values().next().value!;
      let width=1,height=1;
      while(p.faces.has(`${u+width}:${v}`)&&width<4)width++;
      rows:while(height<4){for(let offset=0;offset<width;offset++)if(!p.faces.has(`${u+offset}:${v+height}`))break rows;height++;}
      for(let dx=0;dx<width;dx++)for(let dy=0;dy<height;dy++)p.faces.delete(`${u+dx}:${v+dy}`);
      rectangles++;
      const us=step,vs=p.axis===1?step:vertical,a=u*us,b=(u+width)*us,c=v*vs,d=(v+height)*vs;
      let points=p.axis===1?[a,p.at,c,a,p.at,d,b,p.at,d,b,p.at,c]:p.axis===0?[p.at,c,a,p.at,d,a,p.at,d,b,p.at,c,b]:[a,c,p.at,a,d,p.at,b,d,p.at,b,c,p.at];
      const naturalSign=p.axis===1?1:p.axis===0?1:-1;
      if(naturalSign!==p.sign)points=[...points.slice(9,12),...points.slice(6,9),...points.slice(3,6),...points.slice(0,3)];
      const x=p.axis===0?p.at:(a+b)/2,z=p.axis===2?p.at:p.axis===0?(a+b)/2:(c+d)/2,key=`${Math.floor(x/384)}:${Math.floor(z/384)}`,data=chunks.get(key)??{positions:[],colors:[],indices:[]};chunks.set(key,data);
      const color=new THREE.Color(p.family?'#667c47':'#3a6246').multiplyScalar(p.axis===1?(p.sign>0?1.08:.70):(.82+(p.sign>0?.08:0)));
      quad(data,points,color);maxSpan=Math.max(maxSpan,b-a,d-c);
    }
  }
  const group=new THREE.Group(),material=new THREE.MeshStandardMaterial({roughness:1,vertexColors:true});group.name='PROTOTYPE quantized canopy volumes with greedy planar faces';
  for(const[key,data]of chunks){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(data.positions,3));g.setAttribute('color',new THREE.Float32BufferAttribute(data.colors,3));g.setIndex(data.indices);g.computeVertexNormals();g.computeBoundingSphere();const m=new THREE.Mesh(g,material);m.name=`封闭量化冠群 ${key}`;group.add(m);}
  return{group,triangles:rectangles*2,originalUnitFaces,mergedRectangles:rectangles,canopyColumnCount:columns.size,maximumLeafVolumeHeightMetres:16,maximumMergedFaceSpanMetres:maxSpan};
}
function voxelForest(step:number){
  const occupied=new Map<string,{x:number;y:number;z:number;family:number;sources:Set<number>}>(),ground=new Map<string,number>(),blocked=new Map<string,boolean>();
  let terrainRejected=0,buildingRejected=0;
  const groundAt=(x:number,z:number)=>{
    const key=`${x}:${z}`,known=ground.get(key);if(known!==undefined)return known;
    let h=-Infinity;for(let dx=0;dx<=step;dx+=2)for(let dz=0;dz<=step;dz+=2)h=Math.max(h,terrainHeight(world,x*step+dx,z*step+dz));ground.set(key,h);return h;
  };
  for(const tree of roots)for(let tier=0;tier<3;tier++)for(let leaf=0;leaf<3;leaf++){
    const h=tree.height,sign=tier%2?-1:1,offset=q(h*(.16-tier*.03)),x=q(tree.x+sign*offset+(leaf-1)*h*.19),z=q(tree.z+(tier-1)*h*.11+(leaf%2?1:-1)*h*.11),y=q(tree.y+h*(.62+tier*.11)+(leaf%2?.8:0)),w=q(h*(.32-tier*.045)),d=q(h*(.28-tier*.03)),height=q(h*.16);
    for(let vx=Math.ceil((x-w/2)/step-.5);vx<=Math.floor((x+w/2)/step-.5);vx++)for(let vz=Math.ceil((z-d/2)/step-.5);vz<=Math.floor((z+d/2)/step-.5);vz++)for(let vy=Math.ceil((y-height/2)/step-.5);vy<=Math.floor((y+height/2)/step-.5);vy++){
      const key=`${vx}:${vy}:${vz}`;
      if(vy*step<groundAt(vx,vz)+.2){terrainRejected++;continue;}
      let obstructionHere=blocked.get(key);if(obstructionHere===undefined){obstructionHere=obstruction((vx+.5)*step,(vz+.5)*step,step/2,vy*step,(vy+1)*step);blocked.set(key,obstructionHere);}
      if(obstructionHere){buildingRejected++;continue;}
      const known=occupied.get(key);if(known){known.sources.add(tree.id);continue;}
      occupied.set(key,{x:vx,y:vy,z:vz,family:tree.color.r/Math.max(.001,tree.color.g)>.5?1:0,sources:new Set([tree.id])});
    }
  }
  const planes=new Map<string,{axis:number;sign:number;at:number;family:number;faces:Map<string,[number,number]>}>();
  const add=(axis:number,sign:number,at:number,u:number,v:number,family:number)=>{const key=`${axis}:${sign}:${at}:${family}`,p=planes.get(key)??{axis,sign,at,family,faces:new Map()};p.faces.set(`${u}:${v}`,[u,v]);planes.set(key,p);};
  const field=new Map<string,Crown>();
  for(const cell of occupied.values()){
    for(const[dx,dy,dz]of[[-1,0,0],[1,0,0],[0,-1,0],[0,1,0],[0,0,-1],[0,0,1]]){
      if(occupied.has(`${cell.x+dx}:${cell.y+dy}:${cell.z+dz}`))continue;
      if(dx)add(0,dx,(cell.x+(dx>0?1:0))*step,cell.z,cell.y,cell.family);
      if(dy)add(1,dy,(cell.y+(dy>0?1:0))*step,cell.x,cell.z,cell.family);
      if(dz)add(2,dz,(cell.z+(dz>0?1:0))*step,cell.x,cell.y,cell.family);
    }
    const key=`${cell.x}:${cell.z}`,known=field.get(key);if(known){known.top=Math.max(known.top,(cell.y+1)*step);known.bottom=Math.min(known.bottom,cell.y*step);for(const id of cell.sources)known.sources.add(id);}
    else field.set(key,{x:cell.x,z:cell.z,top:(cell.y+1)*step,bottom:cell.y*step,color:new THREE.Color(cell.family?'#667c47':'#3a6246'),sources:new Set(cell.sources)});
  }
  const chunks=new Map<string,Data>();let originalUnitFaces=0,rectangles=0,maxSpan=0;
  for(const p of planes.values()){
    originalUnitFaces+=p.faces.size;
    while(p.faces.size){const[u,v]=p.faces.values().next().value!;let width=1,height=1;while(p.faces.has(`${u+width}:${v}`)&&width*step<32)width++;
      rows:while(height*step<32){for(let offset=0;offset<width;offset++)if(!p.faces.has(`${u+offset}:${v+height}`))break rows;height++;}
      for(let dx=0;dx<width;dx++)for(let dy=0;dy<height;dy++)p.faces.delete(`${u+dx}:${v+dy}`);
      rectangles++;const a=u*step,b=(u+width)*step,c=v*step,d=(v+height)*step;
      let points=p.axis===1?[a,p.at,c,a,p.at,d,b,p.at,d,b,p.at,c]:p.axis===0?[p.at,c,a,p.at,d,a,p.at,d,b,p.at,c,b]:[a,c,p.at,a,d,p.at,b,d,p.at,b,c,p.at];
      const naturalSign=p.axis===1?1:p.axis===0?1:-1;if(naturalSign!==p.sign)points=[...points.slice(9,12),...points.slice(6,9),...points.slice(3,6),...points.slice(0,3)];
      const x=p.axis===0?p.at:(a+b)/2,z=p.axis===2?p.at:p.axis===0?(a+b)/2:(c+d)/2,key=`${Math.floor(x/384)}:${Math.floor(z/384)}`,data=chunks.get(key)??{positions:[],colors:[],indices:[]};chunks.set(key,data);
      quad(data,points,new THREE.Color(p.family?'#667c47':'#3a6246').multiplyScalar(p.axis===1?(p.sign>0?1.08:.70):.82+(p.sign>0?.08:0)));maxSpan=Math.max(maxSpan,b-a,d-c);
    }
  }
  const group=new THREE.Group(),material=new THREE.MeshStandardMaterial({roughness:1,vertexColors:true});group.name='PROTOTYPE independent 3D 4m branch-crown union';
  for(const[key,data]of chunks){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(data.positions,3));g.setAttribute('color',new THREE.Float32BufferAttribute(data.colors,3));g.setIndex(data.indices);g.computeVertexNormals();g.computeBoundingSphere();const m=new THREE.Mesh(g,material);m.name=`同层冠体闭合合批 ${key}`;group.add(m);}
  return{group,triangles:rectangles*2,originalUnitFaces,mergedRectangles:rectangles,canopyColumnCount:field.size,occupiedVoxelCount:occupied.size,maximumLeafVolumeHeightMetres:'independent 4m occupied cells; disjoint height ranges stay disjoint',maximumMergedFaceSpanMetres:maxSpan,field,terrainRejected,buildingRejected,occupied};
}
let step = 4, result = voxelForest(step), generated={field:result.field,clipped:result.buildingRejected,clippedTerrain:result.terrainRejected,clippedCombinedBuilding:0};
const budgetTrials = [{ step, cells: generated.field.size, triangles: result.triangles }];

// CPU orthographic/perspective silhouettes are diagnostic projections only.
// These omit terrain/building occlusion, lighting, shaders and actual GPU.
const camera = new THREE.PerspectiveCamera(48,1440/900,.5,8000); camera.position.set(440,325,640); camera.lookAt(210,215,-45); camera.updateMatrixWorld(true);
function polygons(objects: THREE.Mesh[], instanced: boolean) {
  const triangles: { depth: number; points: number[][]; color: string }[] = [], vertex = new THREE.Vector3(), projected = new THREE.Vector3(), tint = new THREE.Color();
  for (const object of objects) {
    const count = instanced ? (object as THREE.InstancedMesh).count : 1, attrs = object.geometry.getAttribute('position'), colors = object.geometry.getAttribute('color'), index = object.geometry.index;
    for (let instance = 0; instance < count; instance++) {
      if (instanced) { (object as THREE.InstancedMesh).getMatrixAt(instance,matrix); (object as THREE.InstancedMesh).getColorAt(instance,tint); } else matrix.identity();
      for (let face = 0; face < (index?.count ?? attrs.count); face += 3) {
        const points: number[][] = []; let depth = 0, clipped = false;
        for (let n = 0; n < 3; n++) {
          const i = index ? index.getX(face+n) : face+n; vertex.fromBufferAttribute(attrs,i).applyMatrix4(matrix); depth += vertex.distanceTo(camera.position);
          projected.copy(vertex).project(camera); if (projected.z > 1 || projected.z < -1) clipped = true;
          points.push([(projected.x+1)*720,(1-projected.y)*450]);
        }
        if (clipped || points.every(p=>p[0]<0) || points.every(p=>p[0]>1440) || points.every(p=>p[1]<0) || points.every(p=>p[1]>900)) continue;
        let color = tint.clone(); if (!instanced && colors) color.fromBufferAttribute(colors,index ? index.getX(face) : face);
        triangles.push({depth:depth/3,points,color:`#${color.getHexString()}`});
      }
    }
  }
  triangles.sort((a,b)=>b.depth-a.depth);
  return triangles;
}
const baselineTriangles = baseline.reduce((sum,mesh)=>sum+mesh.count*(mesh.geometry.index?.count ?? mesh.geometry.getAttribute('position').count)/3,0);
const oldPolygons = polygons(baseline,true), newPolygons = polygons(result.group.children as THREE.Mesh[],false);
for (const [name,shapes] of [['baseline',oldPolygons],['prototype',newPolygons]] as const) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="900" viewBox="0 0 1440 900"><rect width="1440" height="900" fill="#dce2e2"/><g>${shapes.map(p=>`<polygon points="${p.points.map(point=>point.map(x=>x.toFixed(2)).join(',')).join(' ')}" fill="${p.color}"/>`).join('')}</g><text x="20" y="30" fill="#152521" font-size="18">CPU unoccluded forest projection only: ${name}; NO GPU / NO art pass</text></svg>`;
  writeFileSync(`${OUT}/${name}-core-cpu.svg`,svg);
}
const rootsBy96 = new Map<string,Root[]>();
for (const root of roots) { const key = `${Math.floor(root.x/96)}:${Math.floor(root.z/96)}`, list = rootsBy96.get(key) ?? []; list.push(root); rootsBy96.set(key,list); }
const nearBudget = [...rootsBy96.values()].map(list=>list.length).sort((a,b)=>b-a).slice(0,16).reduce((a,b)=>a+b,0);
function nearCell(key:string, trees:Root[]) {
  const group = new THREE.Group(); group.name=`PROTOTYPE lazy96m tree cell ${key}`;
  const wood:{p:number[];s:number[];c:THREE.Color}[]=[], leaves:typeof wood=[];
  for (const tree of trees) {
    wood.push({p:[tree.x,q(tree.y+tree.height*.38),tree.z],s:[.6,q(tree.height*.76),.6],c:new THREE.Color('#66523d')});
    for (let tier=0;tier<3;tier++) {
      const h=tree.height, sign=tier%2?-1:1, branchY=q(tree.y+h*(.56+tier*.10)), offset=q(h*(.16-tier*.03));
      wood.push({p:[q(tree.x+sign*offset/2),branchY,q(tree.z+(tier-1)*h*.06)],s:[q(offset+.6),.4,.4],c:new THREE.Color('#66523d')});
      for (let leaf=0;leaf<3;leaf++) {
        const x=q(tree.x+sign*offset+(leaf-1)*h*.19),z=q(tree.z+(tier-1)*h*.11+(leaf%2?1:-1)*h*.11),y=q(tree.y+h*(.62+tier*.11)+(leaf%2?.8:0));
        const dimensions=[q(h*(.32-tier*.045)),q(h*.16),q(h*(.28-tier*.03))];
        if (obstruction(x,z,Math.max(dimensions[0],dimensions[2])/2,y-dimensions[1]/2,y+dimensions[1]/2)) continue;
        leaves.push({p:[x,y,z],s:dimensions,c:tree.color.clone().multiplyScalar(.89+tier*.09+(leaf%2)*.04)});
      }
    }
  }
  for (const [name,blocks] of [['枝干',wood],['错层小冠',leaves]] as const) {
    const mesh=new THREE.InstancedMesh(new THREE.BoxGeometry(1,1,1),new THREE.MeshStandardMaterial({color:'white',roughness:1}),blocks.length),o=new THREE.Object3D(); mesh.name=name;
    blocks.forEach((b,i)=>{o.position.fromArray(b.p);o.scale.fromArray(b.s);o.updateMatrix();mesh.setMatrixAt(i,o.matrix);mesh.setColorAt(i,b.c);}); mesh.computeBoundingSphere();group.add(mesh);
  }
  return group;
}
const nearGroup=new THREE.Group(); nearGroup.name='PROTOTYPE 16 lazy forest cells at core camera';
const selectedNear=[...rootsBy96].map(([key,trees])=>{const [x,z]=key.split(':').map(Number);return {key,trees,distance:Math.hypot((x+.5)*96-camera.position.x,(z+.5)*96-camera.position.z)};}).sort((a,b)=>a.distance-b.distance).slice(0,16);
selectedNear.forEach(cell=>nearGroup.add(nearCell(cell.key,cell.trees)));
writeFileSync(`${OUT}/near-forest-model.json`,JSON.stringify(nearGroup.toJSON()));
const nearMeshes=nearGroup.children.flatMap(g=>g.children) as THREE.InstancedMesh[];
const baselineField = new Map<string,Crown>();
for (const mesh of baseline.filter(mesh=>mesh.name==='远林错层树冠代理')) for (let i=0;i<mesh.count;i++) {
  mesh.getMatrixAt(i,matrix);matrix.decompose(position,rotation,scale);
  for (let x=Math.floor((position.x-scale.x/2)/step);x<=Math.floor((position.x+scale.x/2)/step);x++)
    for (let z=Math.floor((position.z-scale.z/2)/step);z<=Math.floor((position.z+scale.z/2)/step);z++) {
      if (Math.abs((x+.5)*step-position.x)>scale.x/2 || Math.abs((z+.5)*step-position.z)>scale.z/2) continue;
      baselineField.set(`${x}:${z}`,{x,z,bottom:position.y-scale.y/2,top:position.y+scale.y/2,color:new THREE.Color(),sources:new Set()});
    }
}
const represented=new Set([...generated.field.values()].flatMap(c=>[...c.sources]));
const patches=new Set([...generated.field.values()].map(c=>`${Math.floor((c.x+.5)*step/32)}:${Math.floor((c.z+.5)*step/32)}`));
const report = {
  prototypeOnly: true, physicalWorldChanged: false, gpuRun: false,
  prototypeSourceSHA:createHash('sha256').update(readFileSync('/tmp/yunshan-forest-canopy-prototype/prototype.ts')).digest('hex'),
  frozenWorldSHA: createHash('sha256').update(readFileSync('/tmp/yunshan-phase2-root-coherent-02/src/world.ts')).digest('hex'),
  originalRootCount: originalRoots.length, prototypeRootCount:roots.length, rootPositionChangeCount:useBands?roots.length:0,bandPlacementPrototype:useBands,bandCells:bandCells.length,
  baseline: { triangles:baselineTriangles, calls:baseline.length, projectedTriangles:oldPolygons.length,...connectivity(baselineField,step) },
  prototype: { stepMetres:step, groupPatchMetres:32, nominalPatches:patches.size, renderBatchMetres:384, triangles:result.triangles, calls:result.group.children.length, projectedTriangles:newPolygons.length, occupiedCells:generated.field.size, representedRoots:represented.size, rootsClippedOrSubpixel:roots.length-represented.size, clippedCrownContributions:generated.clipped,clippedTerrainCells:generated.clippedTerrain,clippedCombinedBuildingCells:generated.clippedCombinedBuilding,originalUnitFaces:result.originalUnitFaces,mergedRectangles:result.mergedRectangles,canopyColumnCount:result.canopyColumnCount,maximumLeafVolumeHeightMetres:result.maximumLeafVolumeHeightMetres,maximumMergedFaceSpanMetres:result.maximumMergedFaceSpanMetres,...connectivity(generated.field,step) },
  budgetTrials,
  nearPrototype: { cellMetres:96,maximumResidentCells:16, actualSelectedCells:selectedNear.length, actualSelectedRoots:selectedNear.reduce((sum,cell)=>sum+cell.trees.length,0),actualTriangles:nearMeshes.reduce((sum,mesh)=>sum+mesh.count*12,0),actualCalls:nearMeshes.length,maxExistingRootsInSixteenDensestCells:nearBudget,branchesPerTree:3,leafLobesPerTree:9,boxTrianglesUpperBound:(1+3+9)*12*nearBudget,allDimensionsQuantizedToMetres:.2, implementedIsolated:true,productionHook:false },
  limitations: [ 'CPU projection excludes terrain/building occlusion, shading and materials and cannot be compared as a final game screenshot.',useBands?'Root placement is regenerated only inside this isolated prototype; all roots are checked against the frozen v3 height, building, road and water clearances.':'Preserving every old tree root does not plant new canopy across existing bare mountain land.', 'Crown intervals are clipped against actual floor/roof and terrain volume. No new walk geometry is created.', 'Prototype near cells are independently created in this artifact; production activation/release hooks and GPU are not verified.', 'V4 actual cliffs, building floorPlan and food retail geography remain separately required.' ],
};
writeFileSync(`${OUT}/report.json`,JSON.stringify(report,null,2));
writeFileSync(`${OUT}/forest-model.json`,JSON.stringify(result.group.toJSON()));
writeFileSync(`${OUT}/root-placement.json`,JSON.stringify({roots:roots.map(root=>({x:root.x,y:root.y,z:root.z,height:root.height})),bands:bandCells}));
// Independent CPU depth diagnostic. Authoritative rectangular floor bodies are
// conservative occluders; it deliberately omits roof, opening and shader detail.
const opaque:{positions:number[];kind:number}[]=[];
for(const o of landscape.group.children)if(o instanceof THREE.Mesh && (o.name.startsWith('山形合批代理')||o.name.startsWith('远山'))){
  const position=o.geometry.getAttribute('position'),index=o.geometry.index!,positions:number[]=[];
  for(let i=0;i<index.count;i++){const id=index.getX(i);positions.push(position.getX(id),position.getY(id),position.getZ(id));}
  opaque.push({positions,kind:1});
}
const box=new THREE.BoxGeometry(1,1,1),points=box.getAttribute('position'),indices=box.index!,o=new THREE.Object3D();
for(const b of world.buildings)for(let floor=0;floor<b.floors;floor++){
  const dims=getFloorDimensions(b,floor),h=b.height/b.floors;o.position.set(b.position.x,b.position.y+.6+h*(floor+.5),b.position.z);o.rotation.y=b.rotation;o.scale.set(dims.width,h,dims.depth);o.updateMatrix();
  const positions:number[]=[];for(let i=0;i<indices.count;i++){const id=indices.getX(i),v=new THREE.Vector3().fromBufferAttribute(points,id).applyMatrix4(o.matrix);positions.push(v.x,v.y,v.z);}opaque.push({positions,kind:2});
}
for(const [label,meshes,isInstanced]of[['baseline',baseline,true],['prototype',result.group.children as THREE.Mesh[],false]]as const){
  const content=opaque.slice();
  for(const mesh of meshes){const attrs=mesh.geometry.getAttribute('position'),index=mesh.geometry.index!,count=isInstanced?(mesh as THREE.InstancedMesh).count:1;
    const positions:number[]=[];for(let instance=0;instance<count;instance++){if(isInstanced)(mesh as THREE.InstancedMesh).getMatrixAt(instance,matrix);else matrix.identity();for(let i=0;i<index.count;i++){const v=new THREE.Vector3().fromBufferAttribute(attrs,index.getX(i)).applyMatrix4(matrix);positions.push(v.x,v.y,v.z);}}content.push({positions,kind:3});
  }
  writeFileSync(`${OUT}/${label}-depth-input.json`,JSON.stringify({cameraProjection:camera.projectionMatrix.elements,cameraInverse:camera.matrixWorldInverse.elements,cameraPosition:camera.position.toArray(),meshes:content}));
}
console.log(JSON.stringify(report,null,2));
landscape.dispose();

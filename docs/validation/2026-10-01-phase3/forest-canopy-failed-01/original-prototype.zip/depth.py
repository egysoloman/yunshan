"""Small CPU Z buffer for a scientific projection, NOT a game/GL screenshot."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import json

folder=Path('/tmp/yunshan-forest-canopy-prototype/bands')
width,height=1440,900
font=ImageFont.truetype('DejaVuSans.ttf',12)
report={}
for name in ['baseline','prototype']:
    data=json.loads((folder/f'{name}-depth-input.json').read_text())
    projection=np.asarray(data['cameraProjection']).reshape(4,4).T
    inverse=np.asarray(data['cameraInverse']).reshape(4,4).T
    view=projection@inverse
    camera=np.asarray(data['cameraPosition'])
    zbuffer=np.full((height,width),np.inf,dtype=np.float32)
    ids=np.zeros((height,width),dtype=np.uint8)
    colour=np.zeros((height,width,3),dtype=np.uint8)+np.asarray([207,218,220],dtype=np.uint8)
    base={1:np.asarray([127,144,129]),2:np.asarray([211,195,161]),3:np.asarray([49,95,67])}
    triangles=0
    for mesh in data['meshes']:
        world=np.asarray(mesh['positions'],dtype=np.float64).reshape(-1,3,3)
        normal=np.cross(world[:,1]-world[:,0],world[:,2]-world[:,0])
        visible=np.einsum('ij,ij->i',normal,camera-world.mean(axis=1))>0
        world=world[visible]; normal=normal[visible]
        points=np.concatenate([world,np.ones((*world.shape[:2],1))],axis=2)@view.T
        ndc=points[:,:,:3]/points[:,:,3:4]
        valid=(ndc[:,:,2]>-1).all(axis=1)&(ndc[:,:,2]<1).all(axis=1)
        ndc=ndc[valid];normal=normal[valid]
        ndc[:,:,0]=(ndc[:,:,0]+1)*width/2
        ndc[:,:,1]=(1-ndc[:,:,1])*height/2
        for p,n in zip(ndc,normal):
            x0=max(0,int(np.floor(p[:,0].min())));x1=min(width-1,int(np.ceil(p[:,0].max())))
            y0=max(0,int(np.floor(p[:,1].min())));y1=min(height-1,int(np.ceil(p[:,1].max())))
            if x1<x0 or y1<y0:continue
            area=(p[1,1]-p[2,1])*(p[0,0]-p[2,0])+(p[2,0]-p[1,0])*(p[0,1]-p[2,1])
            if abs(area)<1e-8:continue
            yy,xx=np.mgrid[y0:y1+1,x0:x1+1];xx=xx+.5;yy=yy+.5
            a=((p[1,1]-p[2,1])*(xx-p[2,0])+(p[2,0]-p[1,0])*(yy-p[2,1]))/area
            b=((p[2,1]-p[0,1])*(xx-p[2,0])+(p[0,0]-p[2,0])*(yy-p[2,1]))/area
            c=1-a-b
            depth=a*p[0,2]+b*p[1,2]+c*p[2,2]
            inside=(a>=-1e-8)&(b>=-1e-8)&(c>=-1e-8)
            target=zbuffer[y0:y1+1,x0:x1+1];changed=inside&(depth<target)
            target[changed]=depth[changed]
            ids[y0:y1+1,x0:x1+1][changed]=mesh['kind']
            # Display-only directional shade; these are not actual shaders.
            n=n/(np.linalg.norm(n) or 1);shade=.65+.35*max(0,np.dot(n,np.asarray([.25,.85,.45])))
            colour[y0:y1+1,x0:x1+1][changed]=np.clip(base[mesh['kind']]*shade,0,255).astype(np.uint8)
            triangles+=1
    img=Image.fromarray(colour)
    draw=ImageDraw.Draw(img);draw.rectangle((0,0,width,41),fill='#cfdadc')
    draw.text((8,5),f'{name}: CPU depth diagnostic ONLY; NOT GPU / NOT art acceptance',font=font,fill='#203d2b')
    draw.text((8,22),'Frozen terrain + conservative floor-body occluders; roofs/openings/shaders omitted',font=font,fill='#203d2b')
    img.save(folder/f'{name}-core-cpu-depth.png')
    Image.fromarray(np.where(ids==3,255,0).astype(np.uint8)).save(folder/f'{name}-core-cpu-depth-mask.png')
    report[name]={'diagnosticPixels':width*height,'visibleCanopyOrTrunkPixels':int((ids==3).sum()),'terrainPixels':int((ids==1).sum()),'buildingBodyPixels':int((ids==2).sum()),'frontProjectedTriangles':triangles}
report['limitations']=['1440x900 CPU projection, no GL','Actual frozen proxy terrain is used; building bodies are conservative shared floor rectangles','Detailed roofs, doors, transparent windows, actors, water, lighting and shaders are omitted','Canopy pixels are an optical diagnostic, not plantable-ground coverage or reference art acceptance']
(folder/'depth-report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))

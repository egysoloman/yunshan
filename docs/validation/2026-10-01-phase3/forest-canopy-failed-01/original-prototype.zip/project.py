"""CPU rasterisation of the exported technical projection; never a GPU capture."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
from collections import deque
import xml.etree.ElementTree as ET
import json

root = Path('/tmp/yunshan-forest-canopy-prototype')
font = ImageFont.truetype('DejaVuSans.ttf', 19)
report = {}
for folder in [root, root / 'bands']:
    if not (folder / 'report.json').exists():
        continue
    for name in ['baseline', 'prototype']:
        source = folder / f'{name}-core-cpu.svg'
        if not source.exists():
            continue
        svg = ET.parse(source).getroot()
        png = Image.new('RGB', (1440, 900), '#dce2e2')
        mask = Image.new('1', png.size, 0)
        draw, mask_draw = ImageDraw.Draw(png), ImageDraw.Draw(mask)
        for polygon in svg.iter('{http://www.w3.org/2000/svg}polygon'):
            points = [tuple(float(x) for x in point.split(',')) for point in polygon.get('points').split()]
            draw.polygon(points, fill=polygon.get('fill'))
            mask_draw.polygon(points, fill=1)
        draw.rectangle((0, 0, 1440, 56), fill='#dce2e2')
        draw.text((16, 9), f'{folder.name} / {name}: CPU projection ONLY, no terrain or building occlusion, NO GL / art acceptance', font=font, fill='#15382a')
        png.save(folder / f'{name}-core-cpu.png')
        mask.save(folder / f'{name}-core-cpu-mask.png')
        report[f'{folder.name}/{name}'] = {'unoccludedCrownAndTrunkPixels': sum(mask.getdata()), 'totalPixels': 1440 * 900}
root.joinpath('projection-report.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))

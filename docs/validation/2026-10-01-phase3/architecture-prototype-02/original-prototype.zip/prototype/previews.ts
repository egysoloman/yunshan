import { readFile, writeFile } from 'node:fs/promises';
import { createWorld } from '../frozen/src/world';
import { makeBody, buildMeshes } from './floor-plan';

const results = JSON.parse(await readFile('./results.json', 'utf8'));
const world = createWorld(20261001, 'current-v3');
const items = results.sixRepresentatives.map((row: { id: string }) => world.buildings.find(b => b.id === row.id)!);
const palette = { stone: '#7c807c', plaster: '#c7c9c5', timber: '#626861', tile: '#444e49', glass: '#adb8b4' };
let panels = '';
for (let n = 0; n < items.length; n++) {
  const b = items[n], body = makeBody(b, 'v4-wings'), ox = n % 3 * 500, oy = Math.floor(n / 3) * 490, scale = 2.8;
  const project = (x: number, y: number, z: number) => [ox + 230 + (x * .8 - z * .66) * scale, oy + 195 - (y * .9 + x * .24 + z * .3) * scale];
  const triangles: { depth: number; d: string; fill: string }[] = [];
  for (const part of buildMeshes(body, 'far')) for (let i = 0; i < part.mesh.indices.length; i += 3) {
    const ps = part.mesh.indices.slice(i, i + 3).map(index => part.mesh.positions.slice(index * 3, index * 3 + 3));
    const [a, v, c] = ps, u = v.map((x, j) => x - a[j]), w = c.map((x, j) => x - a[j]);
    const normal = [u[1] * w[2] - u[2] * w[1], u[2] * w[0] - u[0] * w[2], u[0] * w[1] - u[1] * w[0]];
    if (normal[0] + normal[1] * 1.1 + normal[2] <= 0) continue;
    triangles.push({ depth: ps.reduce((sum, p) => sum + p[0] + p[2] - p[1] * .02, 0), d: ps.map((p, j) => `${j ? 'L' : 'M'}${project(p[0], p[1], p[2]).join(',')}`).join(' ') + 'Z', fill: palette[part.material] });
  }
  triangles.sort((a, b) => a.depth - b.depth);
  panels += `<g><rect x="${ox + 8}" y="${oy + 8}" width="480" height="470" fill="#fafbf8" stroke="#c6cdc5"/><text x="${ox + 22}" y="${oy + 33}" font-size="16">${body.family} / ${b.id}</text><text x="${ox + 22}" y="${oy + 54}" font-size="12">${b.width.toFixed(1)} × ${b.depth.toFixed(1)}m; ${b.floors} floors; actual occupied union</text>${triangles.map(t => `<path d="${t.d}" fill="${t.fill}"/>`).join('')}`;
  const p = body.floorPlans.find(p => p.floor === 0)!, s = 3, cx = ox + 250, cz = oy + 355;
  const rect = (r: { x0: number; x1: number; z0: number; z1: number }, fill: string) => `<rect x="${cx + r.x0 * s}" y="${cz + r.z0 * s}" width="${(r.x1 - r.x0) * s}" height="${(r.z1 - r.z0) * s}" fill="${fill}"/>`;
  panels += `${rect(p.broadphase, '#e9eee7')}${p.interior.map(r => rect(r, '#aeb8ad')).join('')}${p.circulation.map(r => rect(r, '#d0cbbd')).join('')}`;
  for (const wall of p.walls) {
    panels += `<line x1="${cx + wall.a[0] * s}" y1="${cz + wall.a[1] * s}" x2="${cx + wall.b[0] * s}" y2="${cz + wall.b[1] * s}" stroke="#303b35" stroke-width="1.3"/>`;
    if (wall.opening) { const len = Math.hypot(wall.b[0] - wall.a[0], wall.b[1] - wall.a[1]), u = (wall.b[0] - wall.a[0]) / len, v = (wall.b[1] - wall.a[1]) / len; panels += `<line x1="${cx + (wall.a[0] + u * wall.opening.from) * s}" y1="${cz + (wall.a[1] + v * wall.opening.from) * s}" x2="${cx + (wall.a[0] + u * wall.opening.to) * s}" y2="${cz + (wall.a[1] + v * wall.opening.to) * s}" stroke="#fafbf8" stroke-width="3"/>`; }
  }
  panels += `<circle cx="${cx + p.stair.x * s}" cy="${cz + p.stair.z * s}" r="4" fill="#292f2d"/>${p.usePoints.map(point => `<circle cx="${cx + point.x * s}" cy="${cz + point.z * s}" r="3" fill="#65614e"/>`).join('')}<text x="${ox + 22}" y="${oy + 453}" font-size="11">Ground plan: occupied rooms / covered gallery / open court; shaft ●</text></g>`;
}
await writeFile('./six-family-body-plans.svg', `<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="1010" viewBox="0 0 1500 1010"><rect width="1500" height="1010" fill="#f0f3ed"/><g font-family="sans-serif" fill="#25302b">${panels}<text x="20" y="999" font-size="12">CPU geometry diagram from prototype meshes and shared plans — not a browser render, screenshot or visual acceptance.</text></g></svg>`);
console.log('Wrote six-family-body-plans.svg from actual CPU meshes and floor-plan data.');

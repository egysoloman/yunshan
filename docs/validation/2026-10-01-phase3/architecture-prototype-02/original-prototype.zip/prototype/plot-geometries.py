import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.patches import Rectangle, Circle

entries=json.loads(Path('preview-geometry.json').read_text())['entries']
palette={'stone':'#7c807c','plaster':'#c7c9c5','timber':'#626861','tile':'#444e49','glass':'#adb8b4'}
fig=plt.figure(figsize=(16,10),facecolor='#f3f5ee')
for i,entry in enumerate(entries):
    ax=fig.add_subplot(2,3,i+1,projection='3d')
    for part in entry['parts']:
        p=part['mesh']['positions']; indices=part['mesh']['indices']
        vertices=[(p[j],p[j+2],p[j+1]) for j in range(0,len(p),3)]
        faces=[[vertices[k] for k in indices[j:j+3]] for j in range(0,len(indices),3)]
        ax.add_collection3d(Poly3DCollection(faces,facecolors=palette[part['material']],edgecolors='none'))
    dim=entry['dimensions']; w,d,h=dim['width'],dim['depth'],dim['height']
    ax.set_xlim(-w*.56,w*.56);ax.set_ylim(-d*.56,d*.56);ax.set_zlim(0,h+4)
    ax.set_box_aspect((w,d,h+4));ax.set_proj_type('ortho');ax.view_init(elev=24,azim=-48)
    ax.set_axis_off();ax.set_title(f"{entry['family']} · {entry['id']}\n{w:.1f} × {d:.1f}m · {dim['floors']} floors",fontsize=10)
fig.suptitle('Six real occupied bodies — CPU geometry diagram; not a browser render',fontsize=17)
fig.savefig('six-family-bodies.png',dpi=140,bbox_inches='tight',facecolor=fig.get_facecolor())
plt.close(fig)
fig,axes=plt.subplots(2,3,figsize=(16,10),facecolor='#f3f5ee')
for ax,entry in zip(axes.flat,entries):
    p=entry['floorPlan']; full=p['broadphase']
    def box(r,color):
        ax.add_patch(Rectangle((r['x0'],r['z0']),r['x1']-r['x0'],r['z1']-r['z0'],facecolor=color,edgecolor='none'))
    box(full,'#e1e8dd')
    for r in p['interior']:box(r,'#aeb8ad')
    for r in p['circulation']:box(r,'#c9bda2')
    for wall in p['walls']:
        a,b=wall['a'],wall['b'];ax.plot([a[0],b[0]],[a[1],b[1]],color='#303b35',lw=1.5)
        opening=wall.get('opening')
        if opening:
            length=((b[0]-a[0])**2+(b[1]-a[1])**2)**.5
            u,v=(b[0]-a[0])/length,(b[1]-a[1])/length
            ax.plot([a[0]+u*opening['from'],a[0]+u*opening['to']],[a[1]+v*opening['from'],a[1]+v*opening['to']],color='#f3f5ee',lw=4)
    ax.add_patch(Circle((p['stair']['x'],p['stair']['z']),.6,color='#202c24'))
    for point in p['usePoints']:ax.add_patch(Circle((point['x'],point['z']),.45,color='#746642'))
    ax.set_xlim(full['x0']-2,full['x1']+2);ax.set_ylim(full['z1']+2,full['z0']-2);ax.set_aspect('equal')
    ax.set_title(f"{entry['family']} · {entry['id']}",fontsize=11);ax.set_axis_off()
fig.suptitle('Shared ground plans: room union / real open court / covered gallery / original shaft',fontsize=16)
fig.savefig('six-family-ground-plans.png',dpi=140,bbox_inches='tight',facecolor=fig.get_facecolor())
print('Wrote actual CPU body/ground-plan PNG diagrams with Matplotlib Agg; no GL.')

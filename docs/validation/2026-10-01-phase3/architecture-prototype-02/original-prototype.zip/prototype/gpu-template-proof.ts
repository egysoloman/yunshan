import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import * as THREE from 'three';
import { createWorld } from '../frozen/src/world';
import { makeBody,buildMeshes } from './floor-plan';
const world=createWorld(20261001,'current-v3'), before=JSON.stringify(world), profiles=new Set<string>();
let roofs=0,vertices=0,maxPositionError=0,maxNormalUnitError=0;
for(const b of world.buildings) for(const part of buildMeshes(makeBody(b,'v4-wings'),'far')) {
 const t=part.instance, g=t?.geometry; if(!t || !g) continue;
 roofs++;profiles.add(g.key);
 // These are the actual GPU-bound 32-bit arrays, not double JSON values.
 const p=new Float32Array(g.positions),n=new Float32Array(g.normals),u=new Float32Array(g.uvs);
 assert([...p,...n,...u].every(Number.isFinite));
 const matrix=new THREE.Matrix4().compose(new THREE.Vector3(t.rect.x0,t.bottom,t.rect.z0),new THREE.Quaternion(),new THREE.Vector3(t.rect.x1-t.rect.x0,t.top-t.bottom,t.rect.z1-t.rect.z0));
 for(let i=0;i<p.length;i+=3) {
  const actual=new THREE.Vector3(p[i],p[i+1],p[i+2]).applyMatrix4(matrix);
  const expected=new THREE.Vector3(part.mesh.positions[i],part.mesh.positions[i+1],part.mesh.positions[i+2]);
  const error=actual.distanceTo(expected);maxPositionError=Math.max(maxPositionError,error);assert(error<1e-7);
  const unitError=Math.abs(Math.hypot(n[i],n[i+1],n[i+2])-1);maxNormalUnitError=Math.max(maxNormalUnitError,unitError);assert(unitError<2e-6);
  vertices++;
 }
 assert.equal(p.byteLength+n.byteLength+u.byteLength+new Uint16Array(g.indices).byteLength,g.bytes);
}
assert.equal(profiles.size,2);assert.equal(JSON.stringify(world),before);
const result={scope:'CPU actual Float32 template and matrix proof, no WebGL draw',roofs,vertices,profileCount:profiles.size,maxPositionError,maxNormalUnitError,finiteActualFloat32:true,actualAttributeBytesVerified:true,anchor:'rect minimum x/z and bottom y; not the centered existing box matrix',oldWorldUnchanged:true};
await writeFile('gpu-template-proof.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));

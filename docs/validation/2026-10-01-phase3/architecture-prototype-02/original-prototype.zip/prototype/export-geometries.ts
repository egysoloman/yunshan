import { readFile, writeFile } from 'node:fs/promises';
import { createWorld } from '../frozen/src/world';
import { makeBody, buildMeshes } from './floor-plan';
const results = JSON.parse(await readFile('./results.json', 'utf8')), world = createWorld(20261001, 'current-v3');
const entries = results.sixRepresentatives.map((row: { id: string }) => {
  const building = world.buildings.find(b => b.id === row.id)!, body = makeBody(building, 'v4-wings');
  return { id: building.id, family: body.family, dimensions: body.immutableDimensions, floorPlan: body.floorPlans.find(p => p.floor === 0), parts: buildMeshes(body, 'far') };
});
await writeFile('./preview-geometry.json', JSON.stringify({ scope: 'CPU authority geometry, no GPU capture', entries }));
console.log('Exported actual six prototype bodies and ground plans for CPU diagrams.');

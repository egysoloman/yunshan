import * as THREE from 'three';
import type { Building, Vec3 } from '../frozen/src/types';
import { getFloorDimensions, getStairPosition } from '../frozen/src/access';

export const PROTOTYPE_RECIPE = 'architecture-v4-program-bodies-02';
export type Family = 'home' | 'market' | 'workshop' | 'civic-academy' | 'finance-health' | 'transport-waterfront';
export type Candidate = 'existing-envelope' | 'v4-wings';
export type Material = 'stone' | 'plaster' | 'timber' | 'tile' | 'glass';
export interface Rect { x0: number; x1: number; z0: number; z1: number }
export interface Wall { a: [number, number]; b: [number, number]; thickness: number; height: number; opening?: { from: number; to: number; height: number; use: 'entrance' | 'courtyard' } }
export interface FloorPlan {
  floor: number; y: number; ceilingY: number; broadphase: Rect;
  interior: Rect[]; circulation: Rect[]; courtyard: Rect[]; stairHole: Rect | null; stairLanding: Rect;
  walls: Wall[]; stair: { x: number; z: number }; usePoint: { x: number; z: number };
  usePoints: { id: string; x: number; z: number }[];
  program: string; permission: string;
}
export interface BuildingBody {
  buildingId: string; family: Family; candidate: Candidate; needsV4: boolean;
  preserveExistingMesh: boolean;
  immutableDimensions: { width: number; depth: number; height: number; floors: number; basements: number; door: Vec3 };
  floorPlans: FloorPlan[]; roofRhythm: 'split-gable' | 'hall-and-shops' | 'industrial-spans' | 'court-wings' | 'hall-and-service-tower' | 'covered-platform';
}
export interface MeshData { positions: number[]; indices: number[] }
export interface MeshPart { material: Material; floor: number; purpose: 'slab' | 'wall' | 'body' | 'roof'; mesh: MeshData; instance?: { rect: Rect; bottom: number; top: number; geometry?: { key: string; positions: number[]; normals: number[]; uvs: number[]; indices: number[]; bytes: number } } }
const q = (n: number) => Math.round(n * 5) / 5;
const eps = 1e-7;
const rect = (x0: number, x1: number, z0: number, z1: number): Rect => ({ x0: q(x0), x1: q(x1), z0: q(z0), z1: q(z1) });
export const contains = (r: Rect, x: number, z: number) => x >= r.x0 - eps && x <= r.x1 + eps && z >= r.z0 - eps && z <= r.z1 + eps;
export const containsUnion = (rs: readonly Rect[], x: number, z: number) => rs.some(r => contains(r, x, z));
export const familyOf = (b: Building): Family => b.kind === 'home' || b.kind === 'farm' ? 'home' : b.kind === 'market' ? 'market' : b.kind === 'workshop' ? 'workshop' : ['hall', 'school', 'police', 'core'].includes(b.kind) ? 'civic-academy' : b.kind === 'bank' || b.kind === 'clinic' ? 'finance-health' : 'transport-waterfront';

/** Rectilinear union boundary, with every intersection split before tracing.
 * This is shared by watertight mesh caps and the wall/collision contract. */
export function boundaryLoops(regions: readonly Rect[], holes: readonly Rect[] = []): [number, number][][] {
  for (const r of [...regions, ...holes]) if (![r.x0, r.x1, r.z0, r.z1].every(Number.isFinite) || r.x1 <= r.x0 || r.z1 <= r.z0) throw new Error('invalid region');
  // World dimensions retain their exact saved floating-point representation;
  // geometry cuts snap to the declared .2m lattice before partitioning. This
  // merges -10.6 and -10.600000000000001 rather than creating a sliver cell.
  const xs = [...new Set([...regions, ...holes].flatMap(r => [q(r.x0), q(r.x1)]))].sort((a, b) => a - b);
  const zs = [...new Set([...regions, ...holes].flatMap(r => [q(r.z0), q(r.z1)]))].sort((a, b) => a - b);
  const occupied = (i: number, j: number) => i >= 0 && j >= 0 && i < xs.length - 1 && j < zs.length - 1 && containsUnion(regions, (xs[i] + xs[i + 1]) / 2, (zs[j] + zs[j + 1]) / 2) && !containsUnion(holes, (xs[i] + xs[i + 1]) / 2, (zs[j] + zs[j + 1]) / 2);
  const edges = new Map<string, [number, number][]>();
  const add = (a: [number, number], b: [number, number]) => { const k = a.join(','); const list = edges.get(k) ?? []; list.push(b); edges.set(k, list); };
  for (let i = 0; i < xs.length - 1; i++) for (let j = 0; j < zs.length - 1; j++) if (occupied(i, j)) {
    if (!occupied(i, j - 1)) add([xs[i], zs[j]], [xs[i + 1], zs[j]]);
    if (!occupied(i + 1, j)) add([xs[i + 1], zs[j]], [xs[i + 1], zs[j + 1]]);
    if (!occupied(i, j + 1)) add([xs[i + 1], zs[j + 1]], [xs[i], zs[j + 1]]);
    if (!occupied(i - 1, j)) add([xs[i], zs[j + 1]], [xs[i], zs[j]]);
  }
  const loops: [number, number][][] = [];
  while (edges.size) {
    const first = edges.keys().next().value!; let cursor = first; const loop: [number, number][] = [];
    do {
      const list = edges.get(cursor);
      if (!list || list.length !== 1) throw new Error(`ambiguous/disconnected boundary at ${cursor}`);
      loop.push(cursor.split(',').map(Number) as [number, number]);
      const next = list[0]; edges.delete(cursor); cursor = next.join(',');
    } while (cursor !== first);
    const corners = loop.filter((p, i) => { const a = loop[(i + loop.length - 1) % loop.length], b = loop[(i + 1) % loop.length]; return Math.abs((p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0])) > eps; });
    if (corners.length < 4) throw new Error('degenerate polygon boundary');
    loops.push(corners);
  }
  return loops;
}
const area = (loop: readonly [number, number][]) => loop.reduce((sum, a, i) => { const b = loop[(i + 1) % loop.length]; return sum + a[0] * b[1] - b[0] * a[1]; }, 0) / 2;

/** Closed orthogonal extrusion; no internal faces, T-junctions or open caps. */
export function extrude(regions: readonly Rect[], bottom: number, top: number, holes: readonly Rect[] = []): MeshData {
  if (top <= bottom || !regions.length) return { positions: [], indices: [] };
  const loops = boundaryLoops(regions, holes), outer = loops.filter(loop => area(loop) > 0), voids = loops.filter(loop => area(loop) < 0);
  const positions: number[] = [], indices: number[] = [];
  for (const contour of outer) {
    const inPolygon = (p: [number, number]) => { let inside = false; for (let i = 0, j = contour.length - 1; i < contour.length; j = i++) { const a = contour[i], b = contour[j]; if ((a[1] > p[1]) !== (b[1] > p[1]) && p[0] < (b[0] - a[0]) * (p[1] - a[1]) / (b[1] - a[1]) + a[0]) inside = !inside; } return inside; };
    const inner = voids.filter(loop => inPolygon(loop[0])), polygons = [contour, ...inner], flat = polygons.flat(), offset = positions.length / 3, count = flat.length;
    for (const y of [bottom, top]) for (const [x, z] of flat) positions.push(x, y, z);
    const triangles = THREE.ShapeUtils.triangulateShape(contour.map(([x, z]) => new THREE.Vector2(x, z)), inner.map(loop => loop.map(([x, z]) => new THREE.Vector2(x, z))));
    for (const [a, b, c] of triangles) indices.push(offset + a, offset + b, offset + c, offset + count + a, offset + count + c, offset + count + b);
    let start = 0;
    for (const loop of polygons) {
      for (let i = 0; i < loop.length; i++) { const a = offset + start + i, b = offset + start + (i + 1) % loop.length; indices.push(a, a + count, b, b, a + count, b + count); }
      start += loop.length;
    }
  }
  return { positions, indices };
}

/** Disjoint rectangle cover of the identical occupied union, for the existing
 * instanced-box far renderer. It exchanges hidden internal faces for bounded
 * matrix/color buffers instead of a unique whole-building mesh per actor. */
export function rectangleCover(regions: readonly Rect[], holes: readonly Rect[] = []): Rect[] {
  const xs = [...new Set([...regions, ...holes].flatMap(r => [q(r.x0), q(r.x1)]))].sort((a, b) => a - b), zs = [...new Set([...regions, ...holes].flatMap(r => [q(r.z0), q(r.z1)]))].sort((a, b) => a - b);
  const nx = xs.length - 1, nz = zs.length - 1, filled = new Set<number>();
  for (let z = 0; z < nz; z++) for (let x = 0; x < nx; x++) if (containsUnion(regions, (xs[x] + xs[x + 1]) / 2, (zs[z] + zs[z + 1]) / 2) && !containsUnion(holes, (xs[x] + xs[x + 1]) / 2, (zs[z] + zs[z + 1]) / 2)) filled.add(z * nx + x);
  const cover: Rect[] = [];
  for (let z = 0; z < nz; z++) for (let x = 0; x < nx; x++) if (filled.has(z * nx + x)) {
    let endX = x + 1, endZ = z + 1;
    while (endX < nx && filled.has(z * nx + endX)) endX++;
    while (endZ < nz && Array.from({ length: endX - x }, (_, dx) => endZ * nx + x + dx).every(k => filled.has(k))) endZ++;
    for (let zz = z; zz < endZ; zz++) for (let xx = x; xx < endX; xx++) filled.delete(zz * nx + xx);
    cover.push(rect(xs[x], xs[endX], zs[z], zs[endZ]));
  }
  return cover;
}

export function makeBody(b: Building, candidate: Candidate): BuildingBody {
  const family = familyOf(b), plans: FloorPlan[] = [], floorHeight = b.height / b.floors;
  const keepEnvelope = candidate === 'existing-envelope' || b.id === 'core-main' || b.kind === 'pavilion';
  for (let floor = -(b.basements ?? 0); floor < b.floors; floor++) {
    const dim = getFloorDimensions(b, floor), w = dim.width, d = dim.depth, full = { x0: -w / 2, x1: w / 2, z0: -d / 2, z1: d / 2 };
    const originalStair = getStairPosition(b, floor), stair = { x: originalStair.x - b.position.x, z: originalStair.z - b.position.z };
    const stairHull = rect(stair.x - 2.4, stair.x + 2.4, stair.z - 3, stair.z + 3);
    let interior: Rect[];
    const norm = (x0: number, x1: number, z0: number, z1: number) => rect(w * x0, w * x1, d * z0, d * z1);
    const spine = norm(-.08, .08, -.42, floor === 0 ? .5 : .05);
    // Candidate 02 gives each programme a distinct occupied topology. All
    // rectangles are shared physical rooms, rather than drawn facade labels.
    if (keepEnvelope || floor < 0) interior = [full];
    else if (family === 'home') {
      interior = [norm(-.5, .02, -.5, .04), spine];
      if (floor < 2) interior.push(norm(.14, .46, -.34, .06), norm(-.06, .18, -.18, -.06));
      if (floor === 0) interior.push(norm(-.48, -.22, .18, .44), norm(-.32, -.20, .00, .20));
    } else if (family === 'market') {
      interior = [norm(-.5, .5, -.5, -.18), spine];
      if (floor === 0) interior.push(norm(-.5, -.20, .04, .34), norm(-.16, .16, .04, .34), norm(.20, .5, .04, .34));
    } else if (family === 'workshop') {
      interior = [norm(-.5, .5, -.5, floor === b.floors - 1 ? -.18 : .20), spine];
    } else if (family === 'civic-academy') {
      interior = [norm(-.5, floor < 2 ? .5 : .20, -.5, -.26), spine];
      if (floor < 2) interior.push(norm(-.5, -.32, -.28, .26), norm(.30, .5, -.28, .26));
      if (floor === 0) interior.push(norm(-.26, .26, .36, .5));
    } else if (family === 'finance-health' && b.kind === 'bank') {
      interior = floor < 2 ? [full] : [norm(-.5, .14, -.5, .18), spine];
    } else if (family === 'finance-health') {
      // H wards: a transverse clinical link joins two unequal ward wings.
      interior = [norm(-.5, -.26, -.5, .36), norm(-.28, .30, -.08, .08), spine];
      if (floor < Math.max(2, b.floors - 2)) interior.push(norm(.28, .5, -.40, .28));
    } else {
      // Actual open waiting floor + two low side canopies; upper floors live
      // in the fixed-shaft service wing rather than enclosing that open hall.
      interior = [norm(-.5, -.20, -.5, .02), spine];
      if (floor === 0) interior.push(norm(.26, .5, -.5, -.18));
    }
    // The fixed shaft stays at the exact legacy shared stair point; each level
    // retains a connected service spine. Dimensions/count/door never change.
    interior.push(stairHull);
    const galleries = family === 'market' ? [norm(-.5, .5, -.08, .04), norm(-.5, .5, .34, .46)]
      : family === 'home' ? [norm(-.20, .18, .02, .14)]
      : family === 'civic-academy' ? [norm(-.32, .30, .18, .30)]
      : family === 'finance-health' ? [norm(-.26, .28, .12, .22)]
      : family === 'transport-waterfront' ? [norm(-.20, .26, -.38, .30), norm(.26, .5, -.08, .28)]
      : [norm(-.46, .46, .22, .36)];
    const circulation: Rect[] = !keepEnvelope && floor === 0 ? rectangleCover(galleries, interior) : [];
    const courtyard = !keepEnvelope && floor === 0 ? rectangleCover([full], interior) : [];
    const height = q(floorHeight - .4), walls: Wall[] = boundaryLoops(interior).flatMap(loop => loop.map((a, i) => {
      const z = loop[(i + 1) % loop.length], length = Math.hypot(z[0] - a[0], z[1] - a[1]);
      const wall: Wall = { a, b: z, thickness: .4, height };
      const entrance = floor === 0 && Math.abs(a[1] - d / 2) < eps && Math.abs(z[1] - d / 2) < eps && Math.min(a[0], z[0]) < 0 && Math.max(a[0], z[0]) > 0;
      const courtyardDoor = floor === 0 && !keepEnvelope && !entrance && length >= 4 && Math.abs((a[0] + z[0]) / 2) < w * .48 && Math.abs((a[1] + z[1]) / 2) < d * .4;
      if (entrance || courtyardDoor) {
        const halfWidth = q(Math.min(entrance ? 2.4 : 1.6, (length - .8) / 2)), mid = entrance ? Math.abs(a[0]) : length / 2;
        wall.opening = { from: q(mid - halfWidth), to: q(mid + halfWidth), height: q(Math.min(2.8, height)), use: entrance ? 'entrance' : 'courtyard' };
      }
      return wall;
    }));
    const usePoint = family === 'home' && !keepEnvelope && floor >= 0 ? { x: q(-w * .20), z: q(-d * .26) }
      : family === 'finance-health' && b.kind !== 'bank' && !keepEnvelope && floor >= 0 ? { x: 0, z: 0 }
      : family === 'transport-waterfront' && !keepEnvelope && floor > 0 ? { x: q(-w * .40), z: q(-d * .08) }
      : { x: 0, z: q(-d * .34) };
    const usePoints = family === 'market' && floor === 0 && !keepEnvelope ? [{ id: 'sale-west', x: q(-w * .35), z: q(d * .18) }, { id: 'sale-center', x: 0, z: q(d * .18) }, { id: 'sale-east', x: q(w * .35), z: q(d * .18) }] : [{ id: 'program', ...usePoint }];
    plans.push({ floor, y: q(floor * floorHeight), ceilingY: q((floor + 1) * floorHeight), broadphase: full, interior, circulation, courtyard, stairHole: floor > -(b.basements ?? 0) ? rect(stair.x - 1.4, stair.x + 1.4, stair.z - 2.4, stair.z + 2.4) : null, stairLanding: rect(stair.x - 1.4, stair.x + 1.4, stair.z - 1.2, stair.z + 1.2), walls, stair, usePoint, usePoints, program: floor < 0 ? b.basementUses?.[-floor - 1] ?? '地下空间' : b.floorUses?.[floor] ?? b.kind, permission: floor < 0 ? 'original-canAccessFloor' : b.floorPermissions?.[floor] ?? (floor < (b.publicFloors ?? b.floors) ? 'public' : b.requiredPermission ?? 'public') });
  }
  return { buildingId: b.id, family, candidate, needsV4: !keepEnvelope, preserveExistingMesh: keepEnvelope, immutableDimensions: { width: b.width, depth: b.depth, height: b.height, floors: b.floors, basements: b.basements ?? 0, door: { ...b.door } }, floorPlans: plans, roofRhythm: ({ home: 'split-gable', market: 'hall-and-shops', workshop: 'industrial-spans', 'civic-academy': 'court-wings', 'finance-health': 'hall-and-service-tower', 'transport-waterfront': 'covered-platform' })[family] as BuildingBody['roofRhythm'] };
}

function wallRects(w: Wall): { rect: Rect; bottom: number; top: number }[] {
  const length = Math.hypot(w.b[0] - w.a[0], w.b[1] - w.a[1]), dx = (w.b[0] - w.a[0]) / length, dz = (w.b[1] - w.a[1]) / length;
  const panel = (from: number, to: number, bottom: number, top: number) => ({ rect: rect(Math.min(w.a[0] + dx * from, w.a[0] + dx * to) - (dz ? w.thickness / 2 : 0), Math.max(w.a[0] + dx * from, w.a[0] + dx * to) + (dz ? w.thickness / 2 : 0), Math.min(w.a[1] + dz * from, w.a[1] + dz * to) - (dx ? w.thickness / 2 : 0), Math.max(w.a[1] + dz * from, w.a[1] + dz * to) + (dx ? w.thickness / 2 : 0)), bottom, top });
  if (!w.opening) return [panel(0, length, 0, w.height)];
  const o = w.opening;
  return [panel(0, o.from, 0, w.height), panel(o.to, length, 0, w.height), panel(o.from, o.to, o.height, w.height)].filter(p => p.top > p.bottom + eps && p.rect.x1 > p.rect.x0 && p.rect.z1 > p.rect.z0);
}
const wallBoxes = new WeakMap<FloorPlan, ReturnType<typeof wallRects>>();
export function wallCollisionBoxes(plan: FloorPlan) { let boxes = wallBoxes.get(plan); if (!boxes) { boxes = plan.walls.flatMap(wallRects); wallBoxes.set(plan, boxes); } return boxes; }
const supportAreas = new WeakMap<FloorPlan, Rect[]>();
export function canStand(plan: FloorPlan, x: number, z: number, radius = .35): boolean {
  let occupied = supportAreas.get(plan);
  if (!occupied) { const areas = [...plan.interior, ...plan.circulation, ...plan.courtyard]; occupied = plan.stairHole ? [...rectangleCover(areas, [plan.stairHole]), plan.stairLanding] : areas; supportAreas.set(plan, occupied); }
  if (![[0, 0], [radius, 0], [-radius, 0], [0, radius], [0, -radius]].every(([dx, dz]) => containsUnion(occupied, x + dx, z + dz))) return false;
  return !wallCollisionBoxes(plan).some(box => box.bottom < 1.72 && box.top > .05 && x > box.rect.x0 - radius && x < box.rect.x1 + radius && z > box.rect.z0 - radius && z < box.rect.z1 + radius);
}
export function floorSupport(plan: FloorPlan, x: number, z: number): { kind: 'floor' | 'stairs'; y: number } | null {
  if (!canStand(plan, x, z)) return null;
  return { kind: plan.stairHole && contains(plan.stairHole, x, z) ? 'stairs' : 'floor', y: plan.y };
}
export function localPosition(b: Building, p: Vec3) { const dx = p.x - b.position.x, dz = p.z - b.position.z, c = Math.cos(b.rotation), s = Math.sin(b.rotation); return { x: dx * c - dz * s, y: p.y - b.position.y - .6, z: dx * s + dz * c }; }

/** A closed, low gable volume with every final vertex on the .2m lattice.
 * Far instances share a normalized profile, not a stack of five roof boxes. */
function gableMesh(r: Rect, low: number): MeshData {
  const alongX = r.x1 - r.x0 <= r.z1 - r.z0;
  const a = alongX ? r.x0 : r.z0, b = alongX ? r.x1 : r.z1, mid = q((a + b) / 2);
  const contour: [number, number][] = [[a, q(low)], [b, q(low)], [b, q(low + .4)], [mid, q(low + 1.2)], [a, q(low + .4)]];
  const positions: number[] = [], indices: number[] = [], count = contour.length;
  for (const end of alongX ? [r.z0, r.z1] : [r.x0, r.x1]) for (const [u, y] of contour) positions.push(...(alongX ? [u, y, end] : [end, y, u]));
  for (const [a, b, c] of THREE.ShapeUtils.triangulateShape(contour.map(([x,y]) => new THREE.Vector2(x,y)), [])) indices.push(a,c,b,count+a,count+b,count+c);
  for (let i=0;i<count;i++) { const j=(i+1)%count; indices.push(i,j,count+i,j,count+j,count+i); }
  const mesh = {positions,indices};
  if (closedMesh(mesh).signedVolume < 0) for (let i=0;i<indices.length;i+=3) [indices[i+1],indices[i+2]]=[indices[i+2],indices[i+1]];
  return mesh;
}
function normalizedGeometry(mesh: MeshData, r: Rect, low: number) {
  const width=r.x1-r.x0, depth=r.z1-r.z0, height=1.2;
  const positions=mesh.positions.map((v,i)=>Number(((v-(i%3===0?r.x0:i%3===1?low:r.z0))/(i%3===0?width:i%3===1?height:depth)).toFixed(12)));
  const geometry=new THREE.BufferGeometry();
  geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
  geometry.setIndex(mesh.indices); geometry.computeVertexNormals();
  const uvs=positions.flatMap((_,i)=>i%3===0?[positions[i],positions[i+2]]:[]);
  geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));
  const normals=Array.from(geometry.getAttribute('normal').array);
  const bytes=Object.values(geometry.attributes).reduce((n,a)=>n+a.array.byteLength,0)+geometry.index!.array.byteLength;
  geometry.dispose();
  return {key: JSON.stringify([positions,mesh.indices]), positions, normals, uvs, indices: [...mesh.indices],bytes};
}

export function buildMeshes(body: BuildingBody, lod: 'near' | 'far'): MeshPart[] {
  // The landmark/open pavilion remain wholly on their existing renderer, including the open
  // observation deck, stepped six-storey tiers and both basement rooms.
  if (body.preserveExistingMesh) return [];
  const parts: MeshPart[] = [];
  const add = (material: Material, floor: number, purpose: MeshPart['purpose'], regions: Rect[], low: number, high: number, holes: Rect[] = []) => {
    if (high <= low || !regions.length) return;
    try {
      if (lod === 'far') for (const r of rectangleCover(regions, holes)) parts.push({ material, floor, purpose, mesh: extrude([r], q(low), q(high)), instance: { rect: r, bottom: q(low), top: q(high) } });
      else { const mesh = extrude(regions, q(low), q(high), holes); if (mesh.indices.length) parts.push({ material, floor, purpose, mesh }); }
    } catch (error) { throw new Error(`${body.buildingId}:${lod}:${floor}:${purpose}:${JSON.stringify({ regions, holes })}`, { cause: error }); }
  };
  if (lod === 'far') {
    for (let i = 0; i < body.floorPlans.length;) {
      const p = body.floorPlans[i]; let end = i + 1;
      while (end < body.floorPlans.length && JSON.stringify(body.floorPlans[end].interior) === JSON.stringify(p.interior)) end++;
      add(p.floor < 0 || body.family === 'finance-health' ? 'stone' : 'plaster', p.floor, 'body', p.interior, p.y, body.floorPlans[end - 1].ceilingY);
      i = end;
    }
  } else for (const p of body.floorPlans) {
    add(p.floor <= 0 ? 'stone' : 'timber', p.floor, 'slab', [...p.interior, ...p.circulation, ...p.courtyard], p.y - .2, p.y, p.stairHole ? [p.stairHole] : []);
    if (p.stairHole) add('stone', p.floor, 'slab', [p.stairLanding], p.y - .2, p.y);
    for (const box of wallCollisionBoxes(p)) {
      const skirt = Math.min(.8, box.top);
      if (box.bottom < skirt) add('stone', p.floor, 'wall', [box.rect], p.y + box.bottom, p.y + skirt);
      if (box.top > Math.max(box.bottom, skirt)) add(body.family === 'finance-health' ? 'stone' : 'plaster', p.floor, 'wall', [box.rect], p.y + Math.max(box.bottom, skirt), p.y + box.top);
    }
  }
  for (let i = 0; i < body.floorPlans.length; i++) {
    const p = body.floorPlans[i]; if (p.floor < 0) continue;
    if (p.circulation.length) add('timber', p.floor, 'roof', p.circulation, p.y + 2.6, p.y + 2.8, p.interior);
    const next = body.floorPlans[i + 1];
    // The same real occupied wing derives the low pitched roof in both LODs.
    // Empty courts stay unroofed except explicit lower circulation canopies.
    for (const outline of rectangleCover(p.interior, next?.interior ?? [])) {
      const low = p.ceilingY, r = {...outline}, alongX=r.x1-r.x0<=r.z1-r.z0;
      const span=alongX?r.x1-r.x0:r.z1-r.z0;
      // Odd .2m widths receive a real flat .2m weather strip. The remaining
      // gable span is divisible by .4m, so its center is on-grid and only two
      // normalized roof templates are needed across all buildings/chunks.
      if(Math.round(span*5)%2!==0) {
        const strip=alongX?rect(r.x1-.2,r.x1,r.z0,r.z1):rect(r.x0,r.x1,r.z1-.2,r.z1);
        add('tile',p.floor,'roof',[strip],low,low+.4);
        if(alongX) r.x1=q(r.x1-.2); else r.z1=q(r.z1-.2);
      }
      if(r.x1<=r.x0 || r.z1<=r.z0) continue;
      const mesh = gableMesh(r, low);
      parts.push({material: body.family === 'finance-health' ? 'glass' : 'tile', floor:p.floor,purpose:'roof',mesh,
        ...(lod === 'far' ? {instance:{rect:r,bottom:low,top:q(low+1.2),geometry:normalizedGeometry(mesh,r,low)}} : {})});
    }

  }
  return parts;
}

export function closedMesh(mesh: MeshData): { closed: boolean; nonManifoldEdges: number; triangles: number; quantized: boolean; orientationConsistent: boolean; signedVolume: number } {
  const incidence = new Map<string, number>(), directed = new Map<string, number>(); let volume = 0;
  for (let i = 0; i < mesh.indices.length; i += 3) for (let e = 0; e < 3; e++) {
    const a = mesh.indices[i + e], b = mesh.indices[i + (e + 1) % 3], k = a < b ? `${a}:${b}` : `${b}:${a}`;
    incidence.set(k, (incidence.get(k) ?? 0) + 1);
    directed.set(k, (directed.get(k) ?? 0) + (a < b ? 1 : -1));
  }
  for (let i = 0; i < mesh.indices.length; i += 3) {
    const a = mesh.indices[i] * 3, b = mesh.indices[i + 1] * 3, c = mesh.indices[i + 2] * 3, p = mesh.positions;
    volume += (p[a] * (p[b + 1] * p[c + 2] - p[b + 2] * p[c + 1]) + p[a + 1] * (p[b + 2] * p[c] - p[b] * p[c + 2]) + p[a + 2] * (p[b] * p[c + 1] - p[b + 1] * p[c])) / 6;
  }
  const bad = [...incidence.values()].filter(n => n !== 2).length;
  return { closed: bad === 0, nonManifoldEdges: bad, triangles: mesh.indices.length / 3, quantized: mesh.positions.every(n => Number.isFinite(n) && Math.abs(n * 5 - Math.round(n * 5)) < 1e-6), orientationConsistent: [...directed.values()].every(n => n === 0), signedVolume: volume };
}

import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile } from 'node:fs/promises';
import { gunzipSync } from 'node:zlib';
import { createWorld, terrainHeight, getWalkHeight } from '../frozen/src/world';
import { getStairPosition, getFloorDimensions, canAccessFloor } from '../frozen/src/access';
import { savedWorldFingerprint } from '../frozen/src/persistence/world-layout';
import { CityRenderer } from '../frozen/src/renderer';
import { createRoofGeometry } from '../frozen/src/rendering/architecture-layout';
import type { Building } from '../frozen/src/types';
import { makeBody, buildMeshes, closedMesh, boundaryLoops, containsUnion, rectangleCover, wallCollisionBoxes, canStand, familyOf, type Family, type FloorPlan, type Rect } from './floor-plan';

const sha = (s: string | Uint8Array) => createHash('sha256').update(s).digest('hex');
const source = JSON.parse(await readFile('./source-manifest.json', 'utf8'));
for (const [path, expected] of Object.entries(source.frozenSourceHashes)) assert.equal(sha(await readFile(`./frozen/${path}`)), expected, path);
const seed = Number(process.env.YUNSHAN_ARCHITECTURE_SEED ?? 20261001);
assert([20261001, 7, 2024].includes(seed));
const world = createWorld(seed, 'current-v3'), originalWorld = JSON.stringify(world);
const families: Family[] = ['home', 'market', 'workshop', 'civic-academy', 'finance-health', 'transport-waterfront'];
const representative = families.map(family => world.buildings.find(b => (family === 'home' ? b.id === 'west-b0' : family === 'market' ? b.id === 'market-b0' : familyOf(b) === family && b.id !== 'core-main' && (family !== 'civic-academy' || b.kind === 'school') && (family !== 'finance-health' || b.kind === 'clinic') && (family !== 'transport-waterfront' || b.kind === 'station')))!);
const rows: Record<string, unknown>[] = [];
const prototypePaths = ['prototype/floor-plan.ts', 'prototype/check.ts'];
const prototypeHashesBefore = Object.fromEntries(await Promise.all(prototypePaths.map(async path => [path, sha(await readFile(path))])));
const errors: { buildingId: string; floor?: number; issue: string }[] = [];
let floors = 0, closedParts = 0, quantizedParts = 0, actualFarTriangles = 0, candidateFarTriangles = 0, candidateNearTriangles = 0, actualFarInstances = 0, actualFarInstanceAttributeBytes = 0, candidateFarUnmergedGeometryBytes = 0;
const oldGroups = new Map<string, { key: string; geometryBytes: number; instances: number }>(), candidateGroups = new Map<string, { key: string; geometryBytes: number; instances: number }>();
const boxGeometryBytes = 840;
const oldRenderer = Object.create(CityRenderer.prototype) as { buildHouse(b: Building, batch: unknown, far: boolean): void };
const oldCounts = (b: Building, far: boolean, addTo?: typeof oldGroups) => {
  let triangles = 0, instances = 0, instanceAttributeBytes = 0; const keys = new Set<string>();
  const batch = { box(key: string, _x: number, _y: number, _z: number, sx: number, sy: number, sz: number, _color?: string, _rotation?: number, _tag?: unknown, profile?: { form: 'hip' | 'gable'; simple: boolean; innerHole?: readonly [number, number, number, number] }) {
    if (Math.min(sx, sy, sz) <= 0) return;
    instances++; instanceAttributeBytes += 76 + (key === 'wall' ? 16 : 0); keys.add(`${key}:${profile ? profile.form + ':' + profile.simple + ':' + (profile.innerHole?.join(',') ?? 'solid') : 'box'}`);
    let geometryBytes = boxGeometryBytes;
    if (profile) { const geometry = createRoofGeometry(profile.form, profile.simple, profile.innerHole); triangles += geometry.index!.count / 3; geometryBytes = Object.values(geometry.attributes).reduce((n, a) => n + a.array.byteLength, 0) + geometry.index!.array.byteLength; geometry.dispose(); } else triangles += 12;
    if (addTo) { const id = `${key}:${Math.floor(_x / 384)}:${Math.floor(_z / 384)}:${profile ? profile.form + ':' + profile.simple + ':' + (profile.innerHole?.join(',') ?? 'solid') : 'box'}`; const group = addTo.get(id) ?? { key, geometryBytes, instances: 0 }; group.instances++; addTo.set(id, group); }
  } };
  oldRenderer.buildHouse(b, batch, far);
  return { triangles, instances, instanceAttributeBytes, nominalMaterialGeometryGroups: keys.size };
};

// Reachability uses the same generated walls and .35m body radius, at .8m
// resolution. Targets are the fixed legacy shaft and a real occupied use point.
function reachable(plan: FloorPlan, from: { x: number; z: number }, to: { x: number; z: number }) {
  const step = .8, x0 = Math.ceil((plan.broadphase.x0 + .6) / step) * step, z0 = Math.ceil((plan.broadphase.z0 + .6) / step) * step;
  const nx = Math.floor((plan.broadphase.x1 - .6 - x0) / step) + 1, nz = Math.floor((plan.broadphase.z1 - .6 - z0) / step) + 1;
  const index = (x: number, z: number) => Math.round((z - z0) / step) * nx + Math.round((x - x0) / step);
  const start = index(from.x, from.z), goal = index(to.x, to.z), seen = new Set<number>([start]), queue = [start];
  const point = (id: number) => ({ x: x0 + (id % nx) * step, z: z0 + Math.floor(id / nx) * step });
  if (!canStand(plan, point(start).x, point(start).z) || !canStand(plan, point(goal).x, point(goal).z)) return false;
  for (let head = 0; head < queue.length; head++) {
    const id = queue[head]; if (id === goal) return true;
    const x = id % nx, z = Math.floor(id / nx);
    for (const [dx, dz] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const a = x + dx, b = z + dz; if (a < 0 || a >= nx || b < 0 || b >= nz) continue;
      const next = b * nx + a, p = point(next); if (!seen.has(next) && canStand(plan, p.x, p.z)) { seen.add(next); queue.push(next); }
    }
  }
  return false;
}
const rectArea = (r: Rect) => (r.x1 - r.x0) * (r.z1 - r.z0);
const unionArea = (rs: Rect[]) => boundaryLoops(rs).reduce((sum, loop) => sum + loop.reduce((a, p, i) => { const z = loop[(i + 1) % loop.length]; return a + p[0] * z[1] - z[0] * p[1]; }, 0) / 2, 0);

for (const b of world.buildings) {
  const before = JSON.stringify(b), body = makeBody(b, 'v4-wings'), old = makeBody(b, 'existing-envelope');
  assert.equal(JSON.stringify(b), before);
  assert.equal(body.immutableDimensions.height, b.height); assert.deepEqual(body.immutableDimensions.door, b.door);
  assert.equal(body.floorPlans.length, b.floors + (b.basements ?? 0));
  for (const p of body.floorPlans) {
    floors++;
    const s = getStairPosition(b, p.floor);
    assert.equal(p.stair.x, s.x - b.position.x); assert.equal(p.stair.z, s.z - b.position.z);
    assert(containsUnion(p.interior, p.stair.x, p.stair.z), `${b.id}:${p.floor}: shaft outside room`);
    assert(canStand(p, p.stair.x, p.stair.z), `${b.id}:${p.floor}: shaft clearance`);
    assert(canStand(p, p.usePoint.x, p.usePoint.z), `${b.id}:${p.floor}: occupied use point`);
    assert(p.ceilingY - p.y >= 2.4, `${b.id}:${p.floor}: ceiling height`);
    const cover = rectangleCover(p.interior);
    for (let x = p.broadphase.x0 + .37; x < p.broadphase.x1; x += 1.1) for (let z = p.broadphase.z0 + .43; z < p.broadphase.z1; z += 1.1) assert.equal(containsUnion(cover, x, z), containsUnion(p.interior, x, z), `${b.id}:${p.floor}: far cover changes occupied outline`);
    for (const r of p.interior) if (r.x0 < p.broadphase.x0 - 1e-7 || r.x1 > p.broadphase.x1 + 1e-7 || r.z0 < p.broadphase.z0 - 1e-7 || r.z1 > p.broadphase.z1 + 1e-7) errors.push({ buildingId: b.id, floor: p.floor, issue: 'interior outside immutable bounds' });
    const oldPlan = old.floorPlans.find(z => z.floor === p.floor)!;
    assert(Math.abs(unionArea(oldPlan.interior) - rectArea(oldPlan.broadphase)) < 1e-7, `${b.id}: old envelope is not altered`);
    const dimensions = getFloorDimensions(b, p.floor);
    assert.equal(oldPlan.broadphase.x1 - oldPlan.broadphase.x0, dimensions.width); assert.equal(oldPlan.broadphase.z1 - oldPlan.broadphase.z0, dimensions.depth);
  }
  const ground = body.floorPlans.find(p => p.floor === 0)!;
  assert(ground.walls.some(w => w.opening?.use === 'entrance'), `${b.id}: missing actual entry portal`);
  const outside = { x: b.door.x, z: b.door.z + 2.2 }, innerZ = b.depth / 2 - 1;
  assert(Number.isFinite(terrainHeight(world, outside.x, outside.z)) && Number.isFinite(getWalkHeight(world, outside.x, outside.z, b.door.y)));
  assert(canStand(ground, 0, innerZ), `${b.id}: door inner standing space`);
  if (representative.includes(b)) for (const p of body.floorPlans) {
    const start = p.floor === 0 ? { x: 0, z: innerZ } : p.usePoint;
    if (!reachable(p, start, p.stair) || !reachable(p, start, p.usePoint)) errors.push({ buildingId: b.id, floor: p.floor, issue: 'entry/use/shaft unreachable in .8m body-radius grid' });
    for (const target of p.usePoints) if (!reachable(p, start, target)) errors.push({ buildingId: b.id, floor: p.floor, issue: `${target.id}: program bay unreachable` });
    if (p.floor === 0 && p.courtyard.length) for (const side of [-1, 1]) if (!reachable(p, start, { x: side * b.width * .19, z: 0 })) errors.push({ buildingId: b.id, floor: p.floor, issue: 'courtyard is visually open but body cannot reach it' });
  }
  const oldFar = oldCounts(b, true, oldGroups); actualFarTriangles += oldFar.triangles; actualFarInstances += oldFar.instances; actualFarInstanceAttributeBytes += oldFar.instanceAttributeBytes;
  if (body.preserveExistingMesh) { candidateFarTriangles += oldFar.triangles; candidateNearTriangles += oldCounts(b, false).triangles; oldCounts(b, true, candidateGroups); continue; }
  let farTriangles = 0, nearTriangles = 0;
  for (const lod of ['far', 'near'] as const) for (const part of buildMeshes(body, lod)) {
    const proof = closedMesh(part.mesh);
    if (!proof.closed) errors.push({ buildingId: b.id, floor: part.floor, issue: `${lod}:${part.purpose}: ${proof.nonManifoldEdges} nonmanifold edges` }); else closedParts++;
    if (!proof.quantized) errors.push({ buildingId: b.id, floor: part.floor, issue: `${lod}:${part.purpose}: not on .2m lattice` }); else quantizedParts++;
    if (!proof.orientationConsistent || proof.signedVolume <= 1e-7) errors.push({ buildingId: b.id, floor: part.floor, issue: `${lod}:${part.purpose}: inverted or inconsistent face winding` });
    if (lod === 'far') farTriangles += proof.triangles; else nearTriangles += proof.triangles;
    if (lod === 'far') candidateFarUnmergedGeometryBytes += part.mesh.positions.length * 4 + part.mesh.indices.length * 4;
    if (lod === 'far') {
      assert(part.instance, 'far needs a real instance descriptor'); const t = part.instance, x = (t.rect.x0 + t.rect.x1) / 2 + b.position.x, z = (t.rect.z0 + t.rect.z1) / 2 + b.position.z;
      const key = ({ plaster: 'wall', tile: 'roof', timber: 'wood', glass: 'glass', stone: 'stone' })[part.material], geometry = t.geometry;
      const geometryBytes = geometry ? geometry.bytes : boxGeometryBytes;
      if(geometry) {
        assert.equal(geometry.normals.length,geometry.positions.length); assert.equal(geometry.uvs.length,geometry.positions.length/3*2);
        const sx=t.rect.x1-t.rect.x0,sy=t.top-t.bottom,sz=t.rect.z1-t.rect.z0;
        for(let i=0;i<part.mesh.positions.length;i++) {
          const axis=i%3, v=geometry.positions[i]*(axis===0?sx:axis===1?sy:sz)+(axis===0?t.rect.x0:axis===1?t.bottom:t.rect.z0);
          assert(Math.abs(v-part.mesh.positions[i])<1e-7,'far normalized template must recreate actual occupied roof vertices');
        }
      }
      const id = `${key}:${Math.floor(x / 384)}:${Math.floor(z / 384)}:${geometry?.key ?? 'box'}`, group = candidateGroups.get(id) ?? { key, geometryBytes, instances: 0 }; group.instances++; candidateGroups.set(id, group);
    }
  }
  candidateFarTriangles += farTriangles; candidateNearTriangles += nearTriangles;
  if (representative.includes(b)) rows.push({ id: b.id, kind: b.kind, family: body.family, dimensions: body.immutableDimensions, floorPlans: body.floorPlans.length, oldFar, farTriangles, nearTriangles, groundRoomArea: unionArea(ground.interior), groundPlatformArea: unionArea([...ground.interior, ...ground.courtyard]), upperRoomArea: unionArea(body.floorPlans.at(-1)!.interior), groundEnvelopeArea: rectArea(ground.broadphase), mainSilhouetteSha256: sha(JSON.stringify(body.floorPlans.map(p => [p.floor, p.interior]))), doorClear: true, useAndShaftReachable: !errors.some(e => e.buildingId === b.id), floorPlansModel: body.floorPlans });
}

// Four legacy recipes remain actual frozen generator output, with no prototype
// state injected. v3/r5/v2 fixtures are CPU-frozen full-world bodies, not labels.
const oldRecipeProofs = [];
for (const seed of [20261001, 7, 2024]) for (const [recipe, fixture] of [['current-v3', `current-v3-${seed}`], ['current-v2', `current-v2-${seed}`], ['current-v2-r5', `current-v2-r5-${seed}`]] as const) {
  const frozen = JSON.parse(gunzipSync(await readFile(`/workspace/yunshan/tests/fixtures/world-layout/${fixture}.json.gz`)).toString('utf8'));
  const generated = createWorld(seed, recipe), raw = JSON.stringify(generated);
  assert.deepEqual(generated, frozen.world); assert.equal(sha(raw), frozen.worldSha256); assert.equal(savedWorldFingerprint(generated), frozen.fingerprint);
  for (const b of generated.buildings) makeBody(b, 'existing-envelope');
  assert.equal(JSON.stringify(generated), raw);
  oldRecipeProofs.push({ seed, recipe, exactFrozenWorld: true, worldSha256: sha(raw), fingerprint: frozen.fingerprint });
}
const legacyProofs = JSON.parse(gunzipSync(await readFile('/workspace/yunshan/tests/fixtures/world-layout/legacy-main-proofs.json.gz')).toString('utf8'));
for (const seed of [20261001, 7, 2024]) {
  const legacy = createWorld(seed, 'legacy-ee3e7a1'), legacyBefore = JSON.stringify(legacy), { layoutVersion, ...legacyBody } = legacy;
  const trusted = legacyProofs.records.find((r: { seed: number }) => r.seed === seed);
  assert.equal(sha(JSON.stringify(legacyBody)), trusted.mainWorldSha256); assert.equal(savedWorldFingerprint(legacy), trusted.fingerprint);
  for (const b of legacy.buildings) makeBody(b, 'existing-envelope');
  assert.equal(JSON.stringify(legacy), legacyBefore);
  oldRecipeProofs.push({ seed, recipe: 'legacy-ee3e7a1', exactFrozenOriginalBody: true, worldSha256: sha(legacyBefore), originalBodySha256: trusted.mainWorldSha256, fingerprint: savedWorldFingerprint(legacy) });
}
const core = world.buildings.find(b => b.id === 'core-main')!, coreModel = makeBody(core, 'v4-wings');
assert(coreModel.preserveExistingMesh); assert.equal(coreModel.floorPlans.length, 32);
assert(canAccessFloor(core, 29, { role: 'traveler', identities: ['traveler'] }));
assert.equal(canAccessFloor(core, -2, { role: 'traveler', identities: ['traveler'] }), false);
assert.equal(JSON.stringify(world), originalWorld);
const inventory = (groups: typeof oldGroups) => ({ nominalSpatialMaterialGeometryGroups: groups.size, geometryAttributeAndIndexBytes: [...groups.values()].reduce((sum, g) => sum + g.geometryBytes, 0), instanceAttributeBytes: [...groups.values()].reduce((sum, g) => sum + g.instances * (76 + (g.key === 'wall' ? 16 : 0)), 0), instances: [...groups.values()].reduce((sum, g) => sum + g.instances, 0) });
const oldGpuInventory = inventory(oldGroups), candidateGpuInventory = inventory(candidateGroups);
const prototypeHashesAfter = Object.fromEntries(await Promise.all(prototypePaths.map(async path => [path, sha(await readFile(path))]))); assert.deepEqual(prototypeHashesAfter, prototypeHashesBefore);
const result = { scope: 'CPU isolated geometry prototype only; no GL/renderer construction/input walk/FPS', checkpoint: source.commit, seed, prototypeHashesBefore, prototypeHashesAfter, prototypeSourceStable: true, buildings: world.buildings.length, floorPlans: floors, closedParts, quantizedParts, errors, actualFrozenRendererFarTriangleInventory: actualFarTriangles, actualFarInstances, actualFarInstanceAttributeBytes, candidateFarTriangles, candidateFarUnmergedPositionAndIndexBytes: candidateFarUnmergedGeometryBytes, oldGpuInventory, candidateGpuInventory, candidateNearAllCityTrianglesForAccountingOnly: candidateNearTriangles, farTriangleRatio: candidateFarTriangles / actualFarTriangles, bufferRatio: (candidateGpuInventory.geometryAttributeAndIndexBytes + candidateGpuInventory.instanceAttributeBytes) / (oldGpuInventory.geometryAttributeAndIndexBytes + oldGpuInventory.instanceAttributeBytes), nominalBatchRatio: candidateGpuInventory.nominalSpatialMaterialGeometryGroups / oldGpuInventory.nominalSpatialMaterialGeometryGroups, oldRecipeProofs, coreOriginalRendererRetained: true, sixRepresentatives: rows };
await writeFile(`./results-${seed}.json`, JSON.stringify(result, null, 2));
if (seed === 20261001) await writeFile('./results.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify({ ...result, sixRepresentatives: rows.map(({ floorPlansModel, ...row }) => row) }, null, 2));
assert.equal(errors.length, 0, JSON.stringify(errors.slice(0, 8)));
assert.equal(new Set(rows.map(r => r.mainSilhouetteSha256)).size, 6);
// This is component inventory, never an observed renderer submission count.
assert(candidateFarTriangles <= actualFarTriangles * 1.15, 'candidate exceeds frozen far-building component triangle inventory by more than 15%');
assert(result.bufferRatio <= 1.15, 'candidate far-buffer component exceeds 15% inventory budget');
for (const [path, expected] of Object.entries(source.frozenSourceHashes)) assert.equal(sha(await readFile(`./frozen/${path}`)), expected, path);
console.log('PASS: CPU prototype contracts, four frozen recipes, geometry, entrances and component budget.');

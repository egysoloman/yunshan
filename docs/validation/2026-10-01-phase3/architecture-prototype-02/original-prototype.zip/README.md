# 按用途分化的真实体量候选 02（仅 CPU 原型）

状态：`/tmp` 可复查候选。原 01 没有覆盖，生产源码、生产测试、根备忘录和 GL 均未修改或运行。**这是新的物理/几何候选，不是六类建筑已发布、浏览器可玩、视觉参考达到或性能验收。utilities 仍仅计划。**

根实际看过 01 两张 PNG 后指出其四种地面图同 U 形加中轴、远景仍重复盒体；本候选按这个问题另做布局。现在地面拓扑确有差别，原始数据和真实 CPU 图可直接比较。它仍保留原建筑全部楼层和 shaft，因此医院和车站高服务翼较大；三维图仍有简化的直立墙面和盒状体量。没有完成窗檐、斗拱、近景家具、材质纹理、城市庭院布置或完整光照气氛，不能以本图声称用途已可从游戏远景可靠辨认、或已符合五张参考图。

## 原始交付与六代表

- `six-family-bodies.png` 与 `six-family-ground-plans.png`：实际模型生成的 CPU 图，图内明确标注 CPU diagram / not a browser render。交付前实际打开查看。
- `preview-geometry.json`：六代表的实际 far mesh、ground FloorPlan、尺寸/门/楼层数据。
- `prototype/floor-plan.ts`：可编译原型，房间/廊/院并集、门墙碰撞、真实楼梯孔与平台、near/far body 和低坡屋顶来自同一楼层模型。
- `results-{20261001,7,2024}.json` 与 `check-frozen-{seed}.log`：三次实际完整 CPU 检查，非运行计数推测。
- `gpu-template-proof.json` / `.log`：实际 Float32 template、单位法线、属性字节和正确锚点矩阵的额外 CPU 验证。
- `guards-results.json` / `guards-frozen.log`：12 项具名正/负检查。
- `strict-delivery.log`：严格编译原始输出。
- `source-manifest.json`：冻结 checkpoint `3f01707581eef697572ffa58bdb994bef037e98d` 33 文件以及实际看过的五参考、六 Macro6 图 SHA。

|用途|代表|本版真实体量|
|---|---|---|
|住宅|west-b0|不等宽主翼/侧翼/前翼，连接廊；低侧翼在较低楼层结束|
|市集|market-b0|三个独立底层铺面、真实间隙与通廊、背面后厅；三个在房间内的实际 usePoints|
|工坊|workshop-b0|宽生产厅、前装卸廊、较浅的上层生产翼|
|书院|academy-b0|前门院、两翼、后堂，上层留在后堂/shaft 一侧|
|诊疗|academy-b2|横向诊疗联系部加 H 型不等高病房翼；finance bank 分支仍可金融塔|
|交通|core-interchange|实物开放候车地面与两侧低棚；原上层集中到既有 shaft 服务翼，移除无必要的第二中轴高塔|

所有上述位置使用原 building 尺寸和原门；不能把名字或 usePoint 数量当作新的经营制度或完整游戏玩法。未来 NPC/玩家使用它们仍需真实路线接入。

## 实际 CPU 验证

每个 seed：612 建筑 / 3516 FloorPlans，33 frozen 源 SHA 起止一致，运行期间 floor-plan/check 两文件 SHA 相同；原 world JSON 不变。全部房间范围保留原 immutable broadphase，原层数、高度、门和固定 shaft 不变；所有 MeshPart 正体积、闭合、面朝向一致且最终顶点在 0.2m 格。所有楼层检验 shaft/usePoint 可站立、至少 2.4m 净高与 far occupied union 等价。仅六代表逐层执行 0.8m 分辨率、0.35m 身体轴向采样 BFS，真实入口/使用点/shaft 可达。

完整三 seed 数值见 `summary.json`。三角、buffer 及名义 spatial/material/geometry group 库存都以 15% 为守卫，最终全部通过。旧组件计数直接调用 frozen `CityRenderer.prototype.buildHouse` 的记录 batch，没有 CityRenderer constructor 或 GL。候选低坡顶使用实际 THREE BufferGeometry pos/normal/uv/index 字节及 min-corner anchored shared instance；与原 centered BoxGeometry 的矩阵合同不同，集成时必须明确锚点。奇数 0.2m 跨宽有真实 0.2m 平檐封条，剩余 0.4m 整跨保证坡顶 ridge 位于格上，实际只需两种 normalized roof profile。

**名义空间/材质/模板组库存不是观测 draw calls。** 这里没有 frustum 提交、全场景/阴影 draw、近景常驻量、FPS、hardware benchmark。near/far 的实占体量和坡顶一致，但没有实际浏览器镜头连续切换检验。

旧 12 case：current-v3/current-v2/current-v2-r5 各三 seed 与可信 fixture 的完整 world deepEqual + JSON SHA + 实际 savedWorldFingerprint 一致；legacy-ee3e7a1 三 seed 去新增 layoutVersion 后与原 main body SHA 一致、fingerprint 一致。生成后运行 existing-envelope helper 的世界 JSON 字节完全不变。这里不声称 legacy 含新 label 的 entire JSON 等于原 main；不声称十二次完整模拟存档续演。

天枢主阁和全部 pavilion 原 renderer/body 不变；天枢原30地上层/2地下层与权限模型保留。权限 metadata 原样记录，核心 public29 可访问、无权限地下-2 被原 canAccessFloor 拒绝。本 helper 没有绕过原权限。

## 物理与验收边界

真实 ground 庭院有 slab；墙与 opening、collision panel 同源；stairHole 空气无支持，原 shaft 平台有独立 slab；廊底净空 2.6m，屋顶不会被当作假地面。

`canStand` 仍只有中心+四轴支持采样，不是完整圆盘 sweep；closedMesh 是单个 MeshPart 索引流形，不能证明交叠多件全局无缝。六代表逐层 BFS 不等于 612 建筑真实 Controller 行走。外 door 只检测实际 terrain/getWalkHeight 有限、门内落脚；未连续接道路。没有 Controller rotation/permissions/stair action/WASD 连续台阶接入，没有完整 v4 存档恢复或 NPC 路线。候车廊等只提供建筑物理代理，尚没有结构柱、设施操作与全部服务演算。

## 集成依赖与可逆部分

可逆 renderer-only 改善可以在原矩形 envelope 内处理实际家具尺寸、门窗节奏与立面细部。根正在做的 1m 市场 counter+共享碰撞另由根持有；本候选不修改该工作。只改 roof 颜色不能实现本版 courtyard 或 void。

真正的翼楼/院落/H诊疗/开放候车必须新 v4 recipe：trusted world descriptor 和 fingerprint 需含所选物理 floorPlan 版本；world floorSupport/getWalkHeight、access、Controller 旋转/身体/楼梯、near/far residency、真实 usePoints/NPC 路线与 persistence recipe 选择共同接入。原四 recipe 保留完整，不对老 save 静默套用新 void。v4 bad/unknown descriptor 必须原子拒绝。合法旧位置不能被 renderer 改形后悬空或被默移。

最适合先集成的强一步是新 v4 市集三铺后厅/住宅不等宽翼楼的真实物理共享计划；书院/医疗/交通作为同一 contract 下的下一批。仍需 root 实际像素 review 和完整依赖接线，不能把 CPU 检查升级为视觉 acceptance。

## 保留失败与修正

- `check-first.log`：river 上层 usePoint 落入 stair 孔边，改成真实服务翼落脚位置，门/shaft 不移动。
- `check-second.log`：每露出翼楼堆叠多 roof boxes，far triangle 与 buffer 约 +69%；没有放宽预算。
- `history/gable-unique-profile/`：闭合 low-gable 几何通过 triangle/buffer，但奇数跨宽产生1372名义 groups 对原377，不能按此稿报告可集成。源码与三 seed 原始日志/JSON保留；改成真实平檐条和两共享 profile，并新增 group15%守卫。
- `history/transport-extra-spine/`：有多余上层中轴塔的完整稿/图/日志保留；最后删除这个无用途的上层体量，再跑同样三 seed 检查。

## 复跑

在此目录：`npx tsc -p tsconfig.json`；各 seed `YUNSHAN_ARCHITECTURE_SEED=20261001 npx tsx prototype/check.ts`（或7/2024）；`npx tsx prototype/guards.ts`；`npx tsx prototype/gpu-template-proof.ts`；`npx tsx prototype/export-geometries.ts`；`MPLCONFIGDIR=./mpl-config python prototype/plot-geometries.py`。实际依赖 node_modules 来自工作区，冻结 source 为已提交 checkpoint。

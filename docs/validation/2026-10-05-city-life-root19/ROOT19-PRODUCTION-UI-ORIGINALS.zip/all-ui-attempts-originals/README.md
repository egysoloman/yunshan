# ROOT19 自然成年课程 UI / GPU 采图：静态模板

状态：STATIC_TEMPLATE_NOT_BOUND / NOT_RUN。本次只准备文件；0 browser、0 build、0 Simulation构造、0 step、0 GPU。没有PNG或采图PASS。本目录不发布、不分享、不上传Library。

参考原件为 /tmp/ROOT18-final-gpu-20261005-01/capture-integrated.mjs。运行使用原372生产bundle、原controller、原renderer和真实rAF；不注入替代场景、DOM、render函数、motor dt或PNG编辑。Linux Chromium SwiftShader仅证明软件GPU功能，不是Mac硬件或参考美术完成证据。

根代理须先真实完成 natural128、取得World291 JSON、完整终档与run receipt，以及最新372生产build。写新 BINDINGS.json（保留template），填实际绝对路径；可选courseId必须是同actor/school实际UI会显示的在办或最新课，且已有真实teacher分钟。未产生真实课或只有0分钟时绑定拒绝，不能造课。sourceManifestPath须有372项裸SHA map、candidateSHA256或inputs；每一项实际文件SHA都核对，manifest本身也封存。

静态绑定命令（只读输入并写私有PLAN，不启动浏览器）：

    node /tmp/ROOT19-education-ui-gpu-20261005-01/bind-inputs.mjs /tmp/ROOT19-education-ui-gpu-20261005-01/BINDINGS.json

然后root封存实际PLAN、driver、bind helper与全输入SHA；由root的独占cap600外层启动新actual目录。模板内部550秒watchdog留cleanup时间，但不取代root资源窗口及独立cap：

    node /tmp/ROOT19-education-ui-gpu-20261005-01/capture-education.mjs /tmp/ROOT19-education-ui-gpu-20261005-01/PLAN.json /tmp/ROOT19-education-ui-gpu-20261005-01/actual01/artifacts

actual01父目录由root外层新建；artifacts不得已存在。失败的目录、日志、当前save和首个失败JSON保留，下一次用新actualNN，不能覆写旧FAIL。

两图流程：

1. 原生new game真正启动，核顶层/runtime resident-formal-tuition-v1 双声明和browser World JSON SHA；保原生birth全档。同步import genuine natural终档，完整export bytes等于输入，在同一任务中调用原actions的普通pause避免任何post-import step。按原始player位置先settle并核authority。
2. 单独明示一次合法原学校public servicepoint玩家body视觉夹具，先检查现有voxel身体及头部空间，原controller.setMode自动查真实geometry/support并确认inside学校ID、原floor及production function point。只通过真实 [data-context=building] 与原课程DOM进入card，不调用玩家exam、采购、退款、任职或NPC命令。原源课程无编辑。滚动真实context aside到actor卡并核卡片完整可见，保存原DOM文字/HTML、原course/teacher/receipt及全城totals JSON，再截 classroom-native-course-ui.png。
3. 再完整import同一自然终档，export仍逐字相等、普通pause、原controller回原始玩家身体位置，截 city-native-street.png。没有额外街景身体传送或替换camera。若原终档玩家实际在室内，应FAIL并由root解决真实街景输入，不能把室内冒街景。

每PNG前后保存完整raw save并assert bytes exact；drawCalls/triangles>0、GL error0、至少一个真实program且全部link成功、diagnostics runnable非false。检查前后source372、source manifest、全部dist文件、driver、PLAN、World、自然run receipt及原终档SHA未漂移。所有课来源raw数据精确，UI金额和分钟遵循原显示截断，教师姓名/分钟及教材来源核真实DOM；截图文字只称actor/当前school完成数，不把该数冒全城totals。UI没有全城totals或独立payer行，全城汇总与payerId==actorId证据另存JSON，绝不注入页面。

暂停的真实main仍调用setFocus→updateTiers。根代理已明确允许这些表现分级元数据并要求全记录diff：仅普通paused、声明的player.position、runtime.focus/mode及按原420/1500×detail距离计算的NPC/district tier允许不同。NPC位置/route/role/workId/homeId/needs/education/money、所有业务模块/原课程/clock/RNG以及其它字段必须精确相同。模板不写tier；任何其它authority漂移即FAIL，不新增宽泛白名单。

根代理的范围指示：允许原production rAF自身真实推导focus/NPC与district视距tier元数据，全记录diff，不称完全NPC对象字节同；课程本身仍来自128真实自然纪录。视觉夹具范围是controlled legal viewer reposition，不能称连续自然步行或自然玩家已抵课堂。

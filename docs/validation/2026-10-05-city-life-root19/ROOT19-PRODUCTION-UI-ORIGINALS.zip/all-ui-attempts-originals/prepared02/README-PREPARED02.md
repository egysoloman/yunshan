# ROOT19 prepared02 精确 native pause 基线

状态：实际输入已只读绑定，prepared02 浏览器 / GPU 尚 NOT_RUN。原 actual01 FAIL、原 driver / PLAN / BINDINGS / 源372文件全部保留。

原 driver 漏计普通 pause 命令通过 success()→notice() 产生的一次事件。原失败有399处叶子diff；精确解释 paused=true、eventId114→115、tick1536新pause事件以及100条FIFO仅移除最老一条后，剩余业务diff为0。纯JSON证据为 OLD-FAILURE-PAUSE-RECOMPUTE.json；独立只读代理复算同样为0。

新 driver 根据冻结原档独立构造完整预期暂停JSON，不把预期对象写入simulation。原import/export仍先要求全bytes exact，再调用一次原native pause，首个postframe前将完整export文档与预期baseline deepEqual。后续完整events与eventId仍严格deepEqual，业务diff以这一次完整pause baseline为起点，只允许原已声明的typed focus/player/mode/tier表现变化。报告继续保留原档→当前完整diff、baseline→当前业务diff以及原notice/success/pause来源。不添加events[*]白名单。

新 PLAN 由原 binder 的私有副本真实纯文件绑定产生；与原 PLAN 只差 boundAt 和新driverSHA。source372、World、build、自然128终档/receipt、course2/citizen367/academy-b7/60真实教师分钟全部相同。SCREEN-COURSE-REPORT.template.json 的源课程值为原真实JSON，屏幕证据仍为null，不能误报截图PASS。

两脚本 node --check exit0。此轮0 browser/build/Simulation构造/step/native tests/GPU。根代理须审查 PREPARED02-FROZEN.json 后，在资源窗口独占、独立外层cap600下另开新输出目录运行；不能覆盖原 actual01 或任何旧FAIL。内部550秒watchdog仅辅助cleanup。

若root选 prepared02/actual02/artifacts，先由root外层新建其actual02父目录，artifacts不得已存在。运行命令：

    node /tmp/ROOT19-education-ui-gpu-20261005-01/prepared02/capture-education.mjs /tmp/ROOT19-education-ui-gpu-20261005-01/prepared02/PLAN.json /tmp/ROOT19-education-ui-gpu-20261005-01/prepared02/actual02/artifacts

其它真实DOM、原controller/renderer/main rAF、每PNG前后fullsave exact、GL0 / linkedprograms、原生newgame双policy、school公共servicepoint支持及voxel头部空间、街景原室外body、源SHA前后复验等保持原冻结driver规则。无公开分享 / Library / 上传。

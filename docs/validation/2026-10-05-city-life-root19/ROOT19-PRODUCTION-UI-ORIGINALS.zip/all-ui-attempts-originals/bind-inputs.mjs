import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, writeFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Pure filesystem/JSON binding only. This helper never imports Simulation,
// World construction, browser, renderer, test or build code.
const home = path.dirname(fileURLToPath(import.meta.url));
const bindingsPath = path.resolve(process.argv[2] ?? '');
const destination = path.resolve(process.argv[3] ?? path.join(home, 'PLAN.json'));
assert(bindingsPath.startsWith(home + path.sep));
assert(destination.startsWith(home + path.sep));
const hash = value => createHash('sha256').update(value).digest('hex');
const bindingsBytes = await readFile(bindingsPath), bindings = JSON.parse(bindingsBytes);
assert.equal(bindings.rootDeclaredInputScope, 'genuine-natural-resident-education-128');
for (const name of ['source', 'sourceManifestPath', 'worldPath', 'terminalSavePath', 'naturalReceiptPath']) assert(path.isAbsolute(bindings[name] ?? ''), 'Root must supply actual ' + name);
const manifestBytes = await readFile(bindings.sourceManifestPath), manifest = JSON.parse(manifestBytes);
const inputs = manifest.candidateSHA256 ?? manifest.inputs ?? manifest;
assert.equal(Object.keys(inputs ?? {}).length, 372);
for (const [name, expected] of Object.entries(inputs)) {
  assert(!path.isAbsolute(name) && !name.split('/').includes('..'));
  assert(/^[0-9a-f]{64}$/.test(expected), 'Actual functional SHA required: ' + name);
  assert.equal(hash(await readFile(path.join(bindings.source, name))), expected, 'Functional source drift: ' + name);
}
const worldBytes = await readFile(bindings.worldPath), world = JSON.parse(worldBytes);
const terminalBytes = await readFile(bindings.terminalSavePath), terminal = JSON.parse(terminalBytes);
const naturalReceiptBytes = await readFile(bindings.naturalReceiptPath);
JSON.parse(naturalReceiptBytes); // genuine run evidence file must exist
assert.equal(terminal.residentTuitionPolicyId, 'resident-formal-tuition-v1');
assert.equal(terminal.runtime.residentTuitionPolicyId, 'resident-formal-tuition-v1');
assert(terminal.state.residentEducation, 'Natural terminal must contain real adult course records');
const all = [...terminal.state.residentEducation.pages.flat(), ...terminal.state.residentEducation.active];
const cards = new Map();
for (const course of all) {
  const key = course.actorId + ':' + course.siteId;
  if (!cards.has(key) || !terminal.state.residentEducation.active.some(c => c.id === cards.get(key).id)) cards.set(key, course);
}
const eligible = [...cards.values()].filter(c => c.workedMinutes > 0 && c.actorId === c.payerId);
eligible.sort((a, b) => b.workedMinutes - a.workedMinutes || b.refunded - a.refunded || a.id.localeCompare(b.id));
const selected = bindings.courseId ? eligible.find(c => c.id === bindings.courseId) : eligible[0];
assert(selected, 'No genuine active/latest course with actual teacher minutes: preserve NOT_READY; never fabricate one');
const school = world.buildings.find(b => b.id === selected.siteId);
assert.equal(school?.kind, 'school');
const publicFloor = school.floorPermissions?.[selected.floor] ? school.floorPermissions[selected.floor] === 'public' : school.publicFloors === undefined || selected.floor < school.publicFloors;
assert(publicFloor, 'Actual course point must be on original public floor');
const dist = path.join(bindings.source, 'dist'), buildFiles = {};
async function walk(relative = '') {
  const entries = await readdir(path.join(dist, relative), { withFileTypes: true });
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const name = relative ? relative + '/' + entry.name : entry.name;
    if (entry.isDirectory()) await walk(name);
    else if (entry.isFile()) buildFiles[name] = hash(await readFile(path.join(dist, name)));
    else throw Error('Unexpected build symlink/special file: ' + name);
  }
}
await walk();
const indexBytes = await readFile(path.join(dist, 'index.html')), buildEntry = indexBytes.toString('utf8').match(/src="([^"]+\.js)"/)?.[1];
assert(/^\/assets\/[^/]+\.js$/.test(buildEntry ?? ''), 'Actual completed production build required');
const plan = {
  status: 'BOUND_INPUTS_RUNTIME_NOT_RUN', boundAt: new Date().toISOString(),
  source: bindings.source, sourceManifestPath: bindings.sourceManifestPath, sourceManifestSHA256: hash(manifestBytes),
  inputs, inputCount: 372, graphSHA256StoredOrder: hash(JSON.stringify(inputs)),
  buildEntry, buildSHA256: buildFiles[buildEntry.slice(1)], indexSHA256: hash(indexBytes), buildFiles,
  worldPath: bindings.worldPath, worldFileSHA256: hash(worldBytes), worldJSONSHA256: hash(JSON.stringify(world)),
  worldBuildings: world.buildings.length, worldDistricts: world.districts.length,
  terminalSavePath: bindings.terminalSavePath, terminalSaveSHA256: hash(terminalBytes),
  terminalTick: terminal.state.tick, terminalClock: terminal.state.extension.lastUpdate,
  naturalReceiptPath: bindings.naturalReceiptPath, naturalReceiptSHA256: hash(naturalReceiptBytes),
  rootDeclaredInputScope: bindings.rootDeclaredInputScope,
  courseId: selected.id, schoolId: selected.siteId, actorId: selected.actorId, classroomBodyPosition: selected.point,
  selectedCourseWorkedMinutes: selected.workedMinutes, selectedCourseRefunded: selected.refunded,
  originalStreetPlayerPosition: terminal.state.player.position,
  driverSHA256: hash(await readFile(path.join(home, 'capture-education.mjs'))),
  port: bindings.port ?? 5187, chromiumPath: bindings.chromiumPath ?? '/usr/bin/chromium', externalCapSeconds: 600,
  allowedVisualChanges: ['normal native pause', 'single declared legal school service-point player viewer fixture', 'original production rAF-derived focus and NPC/district visibility tiers'],
  forbiddenAuthorityChanges: 'All other save fields: clock, RNG, NPC positions/routes/needs/money/role/qualification/work/home, every business module and course/source record',
  execution: 'NOT_RUN; root must approve/freeze this exact plan and execute in its exclusive cap600 window',
};
assert(Number.isInteger(plan.port) && plan.port > 1024 && plan.port < 65536);
await writeFile(destination, JSON.stringify(plan, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: plan.status, plan: destination, planSHA256: hash(await readFile(destination)), sourceCount: 372, courseId: plan.courseId, courseMinutes: plan.selectedCourseWorkedMinutes }));

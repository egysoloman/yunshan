import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFile, writeFile, mkdir, readdir } from 'node:fs/promises';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// STATIC TEMPLATE. Root must bind the actual final production build, World291
// and genuine natural-128 terminal before the separately authorized run.
const home = path.dirname(fileURLToPath(import.meta.url));
const planPath = path.resolve(process.argv[2] ?? path.join(home, 'PLAN.json'));
const output = path.resolve(process.argv[3] ?? '');
assert(output.startsWith(home + path.sep) && output !== home, 'Private new output directory required');
await mkdir(output, { recursive: false });
const put = (name, value) => writeFile(path.join(output, name), typeof value === 'string' ? value : JSON.stringify(value, null, 2) + '\n', { flag: 'wx' });
const hash = value => createHash('sha256').update(value).digest('hex');
const planBytes = await readFile(planPath);
const plan = JSON.parse(planBytes);
const receipt = {
  status: 'STARTED', startedAt: new Date().toISOString(),
  planSHA256: hash(planBytes), driverSHA256: hash(await readFile(fileURLToPath(import.meta.url))),
  scope: 'Actual production browser, controller, renderer and rAF. Genuine natural-128 resident courses; separate controlled legal classroom viewer reposition. No claim of continuous natural player travel.',
  platform: 'Linux headless Chromium, ANGLE SwiftShader software GPU',
  macHardwareEvidence: false, referenceArtCompletionEstablished: false, captures: [],
};
const errors = [];
const browserConsole = [];
let browser, server, serverIdentity, page, startup = '', raw, original, world, pauseBaseline, pauseExpected;
const checkSHA = value => assert(/^[0-9a-f]{64}$/.test(value ?? ''), 'Missing actual lowercase SHA256 binding');

async function identity(pid) {
  try {
    const text = await readFile('/proc/' + pid + '/stat', 'utf8');
    const fields = text.slice(text.lastIndexOf(')') + 2).split(' ');
    return { pid, parent: Number(fields[1]), state: fields[0], ticks: Number(fields[19]) };
  } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}
async function stopOwnedPreview() {
  if (!serverIdentity) return;
  const current = await identity(serverIdentity.pid);
  if (current?.parent === process.pid && current.ticks === serverIdentity.ticks && current.state !== 'Z') server.kill('SIGTERM');
}
async function verifySource() {
  const manifestBytes = await readFile(plan.sourceManifestPath);
  assert.equal(hash(manifestBytes), plan.sourceManifestSHA256, 'Source manifest drift');
  const manifest = JSON.parse(manifestBytes);
  assert.deepEqual(manifest.candidateSHA256 ?? manifest.inputs ?? manifest, plan.inputs, 'Manifest must bind these exact functional inputs');
  assert.equal(Object.keys(plan.inputs).length, 372, 'Exact latest 372 functional inputs required');
  for (const [name, expected] of Object.entries(plan.inputs)) {
    checkSHA(expected);
    assert(!path.isAbsolute(name) && !name.split('/').includes('..'));
    assert.equal(hash(await readFile(path.join(plan.source, name))), expected, 'Source drift: ' + name);
  }
  assert.equal(hash(JSON.stringify(plan.inputs)), plan.graphSHA256StoredOrder);
  const html = await readFile(path.join(plan.source, 'dist/index.html'), 'utf8');
  assert.equal(hash(html), plan.indexSHA256);
  assert.equal(html.match(/src="([^"]+\.js)"/)?.[1], plan.buildEntry);
  assert(/^\/assets\/[^/]+\.js$/.test(plan.buildEntry));
  const actualBuildNames = [];
  async function inventory(relative = '') {
    for (const entry of await readdir(path.join(plan.source, 'dist', relative), { withFileTypes: true })) {
      const name = relative ? relative + '/' + entry.name : entry.name;
      if (entry.isDirectory()) await inventory(name);
      else if (entry.isFile()) actualBuildNames.push(name);
      else throw Error('Unexpected build symlink/special file: ' + name);
    }
  }
  await inventory();
  assert.deepEqual(actualBuildNames.sort(), Object.keys(plan.buildFiles).sort(), 'Whole production build inventory drift');
  for (const [name, expected] of Object.entries(plan.buildFiles)) {
    checkSHA(expected);
    assert(!path.isAbsolute(name) && !name.split('/').includes('..'));
    assert.equal(hash(await readFile(path.join(plan.source, 'dist', name))), expected, 'Build drift: ' + name);
  }
  assert.equal(hash(await readFile(path.join(plan.source, 'dist', plan.buildEntry.slice(1)))), plan.buildSHA256);
}
async function verifyBoundFiles() {
  assert.equal(hash(await readFile(fileURLToPath(import.meta.url))), plan.driverSHA256, 'Driver freeze drift');
  assert.equal(hash(await readFile(planPath)), receipt.planSHA256, 'Plan drift');
  assert.equal(hash(await readFile(plan.worldPath)), plan.worldFileSHA256, 'Original world drift');
  assert.equal(hash(await readFile(plan.naturalReceiptPath)), plan.naturalReceiptSHA256, 'Natural run receipt drift');
  assert.equal(hash(await readFile(plan.terminalSavePath)), plan.terminalSaveSHA256, 'Original terminal drift');
}
function snapshot() {
  const d = window.__YUNSHAN__, s = d.simulation.state, renderer = d.city.renderer, gl = renderer.getContext();
  const glErrors = [];
  for (let i = 0; i < 20; i++) { const error = gl.getError(); if (error === gl.NO_ERROR) break; glErrors.push(error); }
  return {
    save: d.simulation.exportSave(), tick: s.tick, day: s.day, hour: s.hour, paused: s.paused,
    body: d.controller.position, player: s.player.position, insideId: d.controller.inside?.id ?? null,
    floor: d.controller.floor, mode: d.controller.mode,
    camera: { position: d.city.camera.position.toArray(), quaternion: d.city.camera.quaternion.toArray(), fov: d.city.camera.fov },
    drawCalls: renderer.info.render.calls, triangles: renderer.info.render.triangles, glErrors,
    gl: { vendor: gl.getParameter(gl.VENDOR), renderer: gl.getParameter(gl.RENDERER), version: gl.getParameter(gl.VERSION) },
    programs: (renderer.info.programs ?? []).map(p => ({
      name: p.name, linked: gl.getProgramParameter(p.program, gl.LINK_STATUS),
      log: gl.getProgramInfoLog(p.program), runnable: p.diagnostics?.runnable ?? null,
    })),
  };
}
function diff(a, b, prefix = '') {
  if (Object.is(a, b)) return [];
  if (!a || !b || typeof a !== 'object' || typeof b !== 'object' || Array.isArray(a) !== Array.isArray(b)) return [{ path: prefix, before: a, after: b }];
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  return [...keys].flatMap(key => diff(a[key], b[key], Array.isArray(a) ? prefix + '[' + key + ']' : prefix ? prefix + '.' + key : key));
}
function expectedNativePause(document) {
  // Independent JSON expectation of the one real command used after each
  // whole-original restore. Source-bound command pause -> success -> notice
  // appends exactly one event, increments eventId once and shifts once at 100.
  // This creates no game state and calls no Simulation function.
  const baseline = structuredClone(document);
  assert(Array.isArray(baseline.state.events) && baseline.state.events.length <= 100);
  assert(Number.isSafeInteger(baseline.runtime.eventId) && Number.isSafeInteger(baseline.state.tick));
  const event = { id: baseline.runtime.eventId + 1, tick: baseline.state.tick, type: 'pause', text: '时间已暂停。' };
  const eventIdBefore = baseline.runtime.eventId, eventsBefore = baseline.state.events.length;
  baseline.state.paused = true;
  baseline.runtime.eventId = event.id;
  baseline.state.events.push(event);
  const removedOldest = baseline.state.events.length > 100 ? baseline.state.events.shift() : null;
  return {
    baseline,
    proof: {
      command: { type: 'pause', value: 1 }, appliedCommandCountAfterEachOriginalRestore: 1,
      event, removedOldest, eventIdBefore, eventIdAfter: event.id, eventsBefore, eventsAfter: baseline.state.events.length,
      source: { file: path.join(plan.source, 'src/simulation.ts'), SHA256: plan.inputs['src/simulation.ts'], noticeLine: 2173, successLine: 2278, pauseLine: 2291 },
      scope: 'Expected whole JSON baseline derived independently from the frozen original terminal and exact native pause source. No wildcard event permission.',
    },
  };
}
function authorityCheckpoint(save, label, bodyPosition) {
  const current = JSON.parse(save), changes = diff(original, current), businessChanges = diff(pauseBaseline, current);
  assert.equal(current.state.paused, true);
  assert.deepEqual(current.state.events, pauseBaseline.state.events, 'Complete event FIFO must equal exactly one original native pause');
  assert.equal(current.runtime.eventId, pauseBaseline.runtime.eventId, 'Exactly one original native pause eventId increment required');
  assert.equal(current.runtime.detail, original.runtime.detail, 'Viewer must retain original simulation detail');
  assert.deepEqual(current.state.player.position, bodyPosition);
  assert.deepEqual(current.runtime.focus, bodyPosition);
  assert.equal(current.runtime.mode, 'walk');
  const allowed = new Set(['runtime.mode']);
  for (const axis of ['x', 'y', 'z']) { allowed.add('state.player.position.' + axis); allowed.add('runtime.focus.' + axis); }
  const tier = position => {
    const distance = Math.hypot(position.x - bodyPosition.x, position.y - bodyPosition.y, position.z - bodyPosition.z);
    return distance < 420 * current.runtime.detail ? 'active' : distance < 1500 * current.runtime.detail ? 'regional' : 'statistical';
  };
  for (const change of businessChanges) {
    if (allowed.has(change.path)) continue;
    const npc = change.path.match(/^state\.citizens\[(\d+)\]\.tier$/);
    const district = change.path.match(/^state\.districts\[(\d+)\]\.tier$/);
    if (npc) {
      const i = Number(npc[1]);
      assert.equal(current.state.citizens[i].id, original.state.citizens[i].id);
      assert.equal(change.after, tier(current.state.citizens[i].position)); continue;
    }
    if (district) {
      const i = Number(district[1]), row = current.state.districts[i];
      assert.equal(row.id, original.state.districts[i].id);
      assert.equal(change.after, tier(world.districts.find(d => d.id === row.id).center)); continue;
    }
    throw Error('Authority drift at ' + change.path + ' during ' + label);
  }
  return { label, saveSHA256: hash(save), changes, businessChanges, expectedNativePause: pauseExpected, allowedChangeScope: 'Exact one native pause baseline; declared player body/controller/focus; only production rAF-derived NPC/district visibility tiers. Complete events and eventId exact. All other authority fields exact.' };
}
async function checkedAuthority(save, label, bodyPosition) {
  try { return authorityCheckpoint(save, label, bodyPosition); }
  catch (error) {
    const current = JSON.parse(save);
    await put(label + '-authority-failure.json', { label, message: error.message, saveSHA256: hash(save), changes: diff(original, current), businessChanges: diff(pauseBaseline, current), expectedNativePause: pauseExpected, expectedBody: bodyPosition, scope: 'FAIL preserved; no new authority exceptions added. Complete events must match exactly one native pause, never events[*] permission.' });
    throw error;
  }
}
async function settle() {
  for (let i = 0; i < 6; i++) {
    const before = await page.evaluate(() => window.__YUNSHAN__.simulation.exportSave());
    await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))));
    const after = await page.evaluate(() => window.__YUNSHAN__.simulation.exportSave());
    if (before === after) return { observedRealFramePairs: i + 1, saveSHA256: hash(after) };
  }
  throw Error('Paused production main loop did not settle within six real frame pairs');
}
async function restoreAndPause(label) {
  const result = await page.evaluate(raw => {
    const d = window.__YUNSHAN__, imported = d.simulation.importSave(raw);
    if (!imported.ok) throw Error(imported.message);
    const exact = d.simulation.exportSave();
    // One synchronous task prevents a post-import simulation tick before the
    // ordinary native pause command. No clock or pause property is assigned.
    d.controller.setMode('walk', d.simulation.state.player.position);
    d.actions.setSetting('simulationDetail', JSON.parse(raw).runtime.detail);
    d.actions.command({ type: 'pause', value: 1 });
    return { imported, exact, paused: d.simulation.state.paused, afterNativePause: d.simulation.exportSave() };
  }, raw);
  assert.equal(result.exact, raw, 'Whole original terminal must re-export byte-exact before normal pause');
  assert(result.paused);
  const immediatelyPaused = JSON.parse(result.afterNativePause);
  try { assert.deepEqual(immediatelyPaused, pauseBaseline, 'Synchronous native pause must match the complete independently expected JSON baseline'); }
  catch (error) {
    await put(label + '-native-pause-authority-failure.json', { label, message: error.message, saveSHA256: hash(result.afterNativePause), changes: diff(original, immediatelyPaused), businessChanges: diff(pauseBaseline, immediatelyPaused), expectedNativePause: pauseExpected, beforeFirstPostImportStep: true, scope: 'Complete synchronous native pause expectation failed; original-current full diff retained. No wildcard event permission.' });
    throw error;
  }
  const checkpoint = await settle();
  const save = await page.evaluate(() => window.__YUNSHAN__.simulation.exportSave());
  await put(label + '-restore.json', { result: result.imported, importSHA256: hash(result.exact), afterNativePauseSHA256: hash(result.afterNativePause), expectedNativePause: pauseExpected, completePauseBaselineMatchedBeforeFirstPostImportStep: true, beforeFirstPostImportStep: true, checkpoint, authority: await checkedAuthority(save, label + '-restore', original.state.player.position) });
}
async function capture(name, bodyPosition, extra) {
  const canonicalMinute = Math.floor(plan.terminalClock + 1e-7) % 1440;
  const expectedClock = String(Math.floor(canonicalMinute / 60)).padStart(2, '0') + ':' + String(canonicalMinute % 60).padStart(2, '0');
  assert(Math.abs(original.state.hour * 60 - canonicalMinute) < 1e-7, 'Original saved hour and authoritative clock agree');
  const clockLabel = (await page.locator('[data-ref="clock"]').innerText()).trim();
  const timeLabel = (await page.locator('[data-ref="time-label"]').innerText()).trim();
  assert.equal(clockLabel, expectedClock, 'Real header clock follows the unchanged authoritative minute');
  assert.equal(timeLabel, expectedClock, 'Real time control label follows the unchanged authoritative minute');
  await put(name + '.clock-labels.json', { canonicalMinute, expectedClock, clockLabel, timeLabel, sourceHour: original.state.hour, sourceClock: plan.terminalClock, realDOMReadOnly: true });

  const before = await page.evaluate(snapshot);
  await put(name + '.before.save.json', before.save);
  const authority = await checkedAuthority(before.save, name, bodyPosition);
  await put(name + '.authority-diff.json', authority);
  await page.screenshot({ path: path.join(output, name + '.png'), timeout: 90000 });
  const after = await page.evaluate(snapshot);
  await put(name + '.after.save.json', after.save);
  assert.equal(after.save, before.save, 'Each PNG must keep the entire paused save byte-exact');
  for (const frame of [before, after]) {
    assert(frame.paused && frame.drawCalls > 0 && frame.triangles > 0);
    assert.equal(frame.glErrors.length, 0);
    assert(frame.programs.length > 0, 'Actual linked renderer programs required');
    for (const program of frame.programs) { assert(program.linked); assert.notEqual(program.runnable, false); }
  }
  const png = await readFile(path.join(output, name + '.png')), saveSHA256 = hash(before.save);
  delete before.save; delete after.save;
  const item = { name, saveSHA256, pngSHA256: hash(png), pngBytes: png.length, before, after, ...extra };
  await put(name + '.json', item); receipt.captures.push(item);
  console.log(JSON.stringify({ name, wholeSaveStable: true, pngBytes: png.length }));
}

// The root owns the independent cap600 process wrapper. This watchdog reserves
// cleanup time and never waits on a substituted simulation or render callback.
const watchdog = setTimeout(() => {
  errors.push({ scope: 'wall-cap', message: '550-second driver budget reached; external root cap is 600 seconds' });
  browser?.close().catch(() => {});
  stopOwnedPreview().catch(() => {});
}, 550000);
try {
  assert.equal(plan.status, 'BOUND_INPUTS_RUNTIME_NOT_RUN', 'Unbound static template cannot start a browser');
  assert.equal(plan.externalCapSeconds, 600);
  assert.equal(plan.driverSHA256, receipt.driverSHA256, 'Driver freeze drift');
  assert.equal(plan.rootDeclaredInputScope, 'genuine-natural-resident-education-128');
  for (const value of [plan.sourceManifestSHA256, plan.indexSHA256, plan.buildSHA256, plan.worldFileSHA256, plan.worldJSONSHA256, plan.terminalSaveSHA256, plan.naturalReceiptSHA256, plan.graphSHA256StoredOrder]) checkSHA(value);
  await verifySource();
  await verifyBoundFiles();
  const worldBytes = await readFile(plan.worldPath);
  assert.equal(hash(worldBytes), plan.worldFileSHA256); world = JSON.parse(worldBytes);
  assert.equal(hash(JSON.stringify(world)), plan.worldJSONSHA256);
  assert.equal(hash(await readFile(plan.naturalReceiptPath)), plan.naturalReceiptSHA256);
  raw = await readFile(plan.terminalSavePath, 'utf8'); assert.equal(hash(raw), plan.terminalSaveSHA256);
  original = JSON.parse(raw);
  ({ baseline: pauseBaseline, proof: pauseExpected } = expectedNativePause(original));
  await put('expected-native-pause-baseline.document.json', { expectedNativePause: pauseExpected, document: pauseBaseline, scope: 'Independently calculated expectation only; not a fabricated native save or a replacement game state.' });
  assert.equal(original.residentTuitionPolicyId, 'resident-formal-tuition-v1');
  assert.equal(original.runtime.residentTuitionPolicyId, 'resident-formal-tuition-v1');
  assert(!original.state.player.vehicleId && !original.state.aviation?.activeAircraftId, 'No hidden deboarding or vehicle mutation permitted');
  const allCourses = [...original.state.residentEducation.pages.flat(), ...original.state.residentEducation.active];
  const selected = allCourses.find(c => c.id === plan.courseId);
  assert(selected && selected.workedMinutes > 0 && selected.actorId === selected.payerId, 'A genuine natural paid lesson source is required');
  const school = world.buildings.find(b => b.id === selected.siteId);
  assert.equal(school?.kind, 'school');
  assert.equal(plan.schoolId, school.id);
  assert.equal(plan.actorId, selected.actorId);
  assert.deepEqual(plan.classroomBodyPosition, selected.point);
  receipt.inputs = { source: plan.source, functionalCount: 372, graphSHA256StoredOrder: plan.graphSHA256StoredOrder, buildEntry: plan.buildEntry, buildSHA256: plan.buildSHA256, worldFileSHA256: plan.worldFileSHA256, worldJSONSHA256: plan.worldJSONSHA256, terminalSaveSHA256: plan.terminalSaveSHA256, naturalReceiptPath: plan.naturalReceiptPath, naturalReceiptSHA256: plan.naturalReceiptSHA256 };
  server = spawn(process.execPath, [path.join(plan.source, 'node_modules/vite/bin/vite.js'), 'preview', '--host', '127.0.0.1', '--port', String(plan.port), '--strictPort'], { cwd: plan.source, stdio: ['ignore', 'pipe', 'pipe'] });
  serverIdentity = await identity(server.pid); assert.equal(serverIdentity.parent, process.pid); receipt.previewIdentity = serverIdentity;
  server.stdout.on('data', data => { startup += data; }); server.stderr.on('data', data => { startup += data; });
  for (let i = 0; i < 100 && !startup.includes('http://127.0.0.1:' + plan.port); i++) { assert.equal(server.exitCode, null); await new Promise(resolve => setTimeout(resolve, 100)); }
  const origin = 'http://127.0.0.1:' + plan.port;
  assert(startup.includes(origin));
  assert.equal(hash(Buffer.from(await (await fetch(origin + plan.buildEntry)).arrayBuffer())), plan.buildSHA256);
  const require = createRequire(path.join(plan.source, 'package.json'));
  const { chromium } = require('playwright-core');
  browser = await chromium.launch({ executablePath: plan.chromiumPath, headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
  page = await browser.newPage({ viewport: { width: 1600, height: 1100 }, deviceScaleFactor: 1 });
  page.on('pageerror', error => errors.push({ scope: 'pageerror', message: error.message }));
  page.on('console', message => {
    browserConsole.push({ type: message.type(), text: message.text(), location: message.location() });
    if (message.type() === 'error') errors.push({ scope: 'console-error', message: message.text() });
  });
  await page.goto(origin + '/?debug=1', { waitUntil: 'networkidle', timeout: 120000 });
  await page.waitForFunction(() => !!window.__YUNSHAN__?.city && window.__YUNSHAN__.simulation.state.tick >= 1, undefined, { timeout: 90000 });
  const birth = await page.evaluate(snapshot), birthDocument = JSON.parse(birth.save);
  await put('native-new-game-before-restore.save.json', birth.save);
  assert.equal(birthDocument.residentTuitionPolicyId, 'resident-formal-tuition-v1');
  assert.equal(birthDocument.runtime.residentTuitionPolicyId, 'resident-formal-tuition-v1');
  assert.equal(hash(await page.evaluate(() => JSON.stringify(window.__YUNSHAN__.world))), plan.worldJSONSHA256);
  receipt.nativeFreshBoot = { saveSHA256: hash(birth.save), tick: birth.tick, topPolicy: birthDocument.residentTuitionPolicyId, runtimePolicy: birthDocument.runtime.residentTuitionPolicyId };
  const welcome = page.locator('[data-action="dismiss-welcome"]');
  if (await welcome.isVisible()) await welcome.click();
  await restoreAndPause('classroom');
  const fixture = await page.evaluate(target => {
    const d = window.__YUNSHAN__, b = d.world.buildings.find(b => b.id === target.siteId), s = d.simulation.state;
    if (!b || b.kind !== 'school' || !d.canAccessBuilding(b, target.floor)) throw Error('Original actor cannot access actual classroom');
    const publicFloor = b.floorPermissions?.[target.floor] ? b.floorPermissions[target.floor] === 'public' : b.publicFloors === undefined || target.floor < b.publicFloors;
    if (!publicFloor) throw Error('Classroom fixture must remain an actual public floor');
    // Same voxel body/headroom bounds as the original controller. Existing
    // construction must not be ignored when declaring this viewer point legal.
    const blockedVoxel = s.voxels.find(block => Math.abs(target.point.x - block.position.x) < .1 + .35 && Math.abs(target.point.z - block.position.z) < .1 + .35 && block.position.y < target.point.y + 1.72 && block.position.y + .2 > target.point.y + .01);
    if (blockedVoxel) throw Error('Actual saved construction blocks the original classroom viewer point');
    const before = d.controller.position;
    // Only direct game-state assignment authorized for this separate visual
    // fixture. No NPC, money, needs, clock, qualification or course is assigned.
    s.player.position = { ...target.point }; d.controller.setMode('walk', target.point);
    if (d.controller.inside?.id !== b.id || d.controller.floor !== target.floor || d.getView().nearbyBuilding?.id !== b.id || !d.simulation.isAtBuildingFunctionPoint(b, s.player.position, 'service', s.player)) throw Error('Native supported service point/actual school detection failed');
    return { before, after: d.controller.position, siteId: b.id, floor: target.floor, pointId: target.pointId, point: target.point, scope: 'Disclosed controlled legal classroom viewer reposition only; no continuous walking or natural player arrival claim.' };
  }, selected);
  await put('classroom-viewer-fixture.json', fixture);
  const closedPanel = page.locator('[data-ref="panel"]');
  if (await closedPanel.isVisible()) await page.locator('[data-testid="panel-toggle"]').click();
  await page.locator('[data-context="building"]').waitFor({ state: 'visible', timeout: 30000 });
  await page.locator('[data-context="building"]').click();
  const card = page.locator('[data-ref="context-body"] .resident-education [data-resident-education-actor="' + selected.actorId + '"]');
  await card.waitFor({ state: 'visible', timeout: 30000 });
  await card.scrollIntoViewIfNeeded();
  const actorRecords = allCourses.filter(c => c.actorId === selected.actorId && c.siteId === selected.siteId);
  const displayed = actorRecords.find(c => original.state.residentEducation.active.some(a => a.id === c.id)) ?? actorRecords.at(-1);
  assert.equal(displayed.id, selected.id, 'Plan must select the actual active/latest school card, not a hidden earlier history');
  const dom = await card.evaluate(node => ({ text: node.innerText, html: node.outerHTML, rows: [...node.querySelectorAll(':scope > .data-row')].map(row => ({ label: row.firstElementChild?.textContent ?? '', value: row.lastElementChild?.textContent ?? '' })), historySummary: node.querySelector(':scope > details > summary')?.textContent ?? '', rect: node.getBoundingClientRect().toJSON(), paneRect: node.closest('[data-ref="context"]').getBoundingClientRect().toJSON(), contextText: node.closest('[data-ref="context-body"]').innerText, viewport: { width: innerWidth, height: innerHeight } }));
  await put('classroom-dom.json', { ...dom, scope: 'Unmodified actual DOM; amounts truncate to cents and minutes truncate to one decimal. This actor/school card is not a global course total.' });
  assert(dom.rect.top >= dom.paneRect.top && dom.rect.bottom <= dom.paneRect.bottom && dom.rect.left >= 0 && dom.rect.right <= dom.viewport.width && dom.rect.bottom <= dom.viewport.height, 'Actual selected course card must fit visibly in the genuine context pane');
  const uiMoney = n => (Math.trunc(n * 100) / 100).toLocaleString('zh-CN', { maximumFractionDigits: 2 }) + ' 云币';
  const uiMinutes = n => (Math.floor(n * 10) / 10).toFixed(1);
  const statusNames = { awaitingSupply: '等待真实教材', waiting: '等待教师与课堂条件', studying: '正在共同课堂授课', paused: '离场暂停', refundPending: '未赚退款仍托管', completed: '正式课程已完成', cancelled: '已取消并保留原记录' };
  const resident = original.state.citizens.find(c => c.id === selected.actorId);
  const assertRow = (label, value) => assert(dom.rows.some(row => row.label === label && row.value === value), 'Actual source DOM row mismatch: ' + label);
  assertRow('正式学历 / 完成自费课程', (resident?.education ?? 0) + ' 级 / ' + actorRecords.filter(c => c.status === 'completed').length + ' 份');
  assertRow('本人签约的原课堂', school.name);
  assertRow('本课状态 / 实际授课', statusNames[selected.status] + ' / ' + uiMinutes(selected.workedMinutes) + ' / 60 分钟');
  assertRow('剩余托管 / 实购教材 / 已赚服务 / 已退', [selected.escrow, selected.purchasePaid, selected.serviceFees, selected.refunded].map(uiMoney).join(' / '));
  assert.equal(dom.historySummary, '全部 ' + actorRecords.length + ' 份原课程记录');
  for (const [teacherId, minutes] of Object.entries(selected.staffMinutes)) {
    const teacher = original.state.citizens.find(c => c.id === teacherId);
    assertRow('实际授课教师', (teacher?.name ?? teacherId) + ' · ' + uiMinutes(minutes) + ' 分钟');
  }
  assert.equal(dom.rows.filter(row => row.label === '实际授课教师').length, Object.keys(selected.staffMinutes).length);
  if (selected.receipt) {
    const supplier = original.state.shops.find(shop => shop.id === selected.receipt.shopId);
    const supplierSite = world.buildings.find(b => b.id === supplier?.buildingId);
    assertRow('实际教材来源', (supplierSite?.name ?? selected.receipt.shopId) + ' · 1份 × ' + uiMoney(selected.receipt.unitPrice));
  }
  await put('natural-resident-source.json', {
    selected, actorRecords, school: { id: school.id, name: school.name }, actor: original.state.citizens.find(c => c.id === selected.actorId),
    globalTotals: original.state.residentEducation.totals, globalHeldCash: original.state.residentEducation.active.reduce((n, c) => n + c.escrow, 0),
    scope: 'Exact genuine natural terminal source. Global totals and payerId/actorId linkage are saved JSON evidence; they are not injected into the production DOM.',
    teacherWageMeaning: 'Canonical funded wage-earned work intervals. Actual wage payment retains the original payroll schedule.',
  });
  await capture('classroom-native-course-ui', selected.point, { checkpoint: await settle(), fixture, actualDOM: dom.text, sourceCourseId: selected.id });
  // Re-import the same whole natural terminal to remove the classroom fixture.
  // The second street shot uses the original saved player body, original
  // controller and real rAF. There is no extra city camera/body teleport.
  await restoreAndPause('street');
  assert.equal(await page.evaluate(() => window.__YUNSHAN__.controller.inside?.id ?? null), null, 'Original natural saved player must actually be outdoors for the street shot');
  await page.mouse.move(1000, 300); // harmless genuine mouse event, no dragging
  await capture('city-native-street', original.state.player.position, { checkpoint: await settle(), scope: 'Actual street/scene from original saved player position; original production controller and rAF; no scene or PNG edits.' });
  await verifySource();
  await verifyBoundFiles();
  assert.equal(receipt.captures.length, 2);
  receipt.status = errors.length ? 'FAIL' : 'PASS_TECHNICAL_READONLY_NATIVE_UI';
} catch (error) {
  errors.push({ scope: 'fatal', message: error.message, stack: error.stack }); receipt.status = 'FAIL';
  if (page && !page.isClosed()) { try { await put('failure-current.save.json', await page.evaluate(() => window.__YUNSHAN__?.simulation.exportSave() ?? '')); } catch {} }
  console.error(error.stack);
} finally {
  clearTimeout(watchdog);
  if (browser) await browser.close().catch(error => errors.push({ scope: 'browser-cleanup', message: error.message }));
  await stopOwnedPreview().catch(error => errors.push({ scope: 'preview-cleanup', message: error.message }));
  if (errors.length) receipt.status = 'FAIL';
  receipt.errors = errors; receipt.endedAt = new Date().toISOString();
  await put('preview.stdout-stderr.txt', startup); await put('browser-console.json', browserConsole); await put('RESULTS.json', receipt);
  console.log(JSON.stringify({ status: receipt.status, shots: receipt.captures.length, errors: errors.length }));
  process.exitCode = errors.length ? 1 : 0;
}

Official frozen-10 DOM original evidence

Actual command: env YUNSHAN_UI_PORT=4195 npm run test:ui
Working directory: /tmp/yunshan-system-coherent-10/source
UTC: 2026-10-02T14:10:46.960724+00:00 to 2026-10-02T14:16:49.431324+00:00
Exit0; official results 35 checks/errors[]. All103 inputs match copiedHashes
before and after; original script/fixtures/assertions/defaulttimeouts unchanged.
Scope: DOM with generated world and real Simulation/Controller, with the
script's declared controlled resources/table/bed positions. No CityRenderer,
WebGL/GPU, normal physical journey, native IndexedDB buttons or performance
validation. This package is not the separate frozen09 full496 result, nor a
frozen10 full-suite result. Active/paused/completed original screenshots viewed.
Port4195 released; own npm exited and original script closed its browser/server.

Contains all103 as-run source inputs, all12 new UI artifacts, raw combined
stdout/stderr, complete run receipt, source snapshot, outside-source runner and
its provenance. Existing world-layout-results and parallel related/full run
artifacts are outside this DOM package. No node_modules/build outputs.
package-manifest.json records each other member's bytes/SHA256/CRC32.

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

root = Path('/tmp/yunshan-system-coherent-10')
source = root / 'source'
snapshot = json.loads((root / 'source-snapshot.json').read_text())
baseline = snapshot['copiedHashes']
stamp = lambda: datetime.now(timezone.utc).isoformat()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
hash_inputs = lambda: {relative: digest(source / relative) for relative in baseline}
artifact_files = lambda: {str(path.relative_to(source / 'artifacts')): {'bytes': path.stat().st_size, 'sha256': digest(path)} for path in sorted((source / 'artifacts').rglob('*')) if path.is_file()}
receipt_path = root / 'ui-run-status.json'
log_path = root / 'dom10.log'
if receipt_path.exists() or log_path.exists():
    raise RuntimeError('Refuse to overwrite an existing DOM receipt or log')
port_check = subprocess.run(['ss', '-ltnp', '( sport = :4195 )'], capture_output=True, text=True, check=True)
if len(port_check.stdout.strip().splitlines()) != 1:
    raise RuntimeError('Port 4195 is already occupied')
initial = hash_inputs()
if initial != baseline:
    raise RuntimeError('The frozen 103 inputs differ from copiedHashes')
preexisting = artifact_files()
if any(name.startswith('ui-') for name in preexisting):
    raise RuntimeError('Refuse to overwrite preexisting UI artifacts')
command = ['env', 'YUNSHAN_UI_PORT=4195', 'npm', 'run', 'test:ui']
receipt = {
    'status': 'RUNNING', 'startedAt': stamp(), 'cwd': str(source), 'command': command,
    'environmentOverrides': {'YUNSHAN_UI_PORT': '4195'}, 'timeouts': 'Unmodified official script and Playwright defaults; no runner deadline',
    'scope': 'Official DOM with real generated world and Simulation; no CityRenderer/WebGL/GPU/benchmark/macOS performance claim',
    'sourceSnapshot': str(root / 'source-snapshot.json'), 'inputCount': len(initial), 'hashesBefore': initial,
    'baselineDifferencesBefore': [], 'port4195Before': port_check.stdout, 'preexistingArtifacts': preexisting,
    'log': str(log_path), 'pid': None,
}
with receipt_path.open('x') as handle:
    handle.write(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
with log_path.open('xb') as log:
    process = subprocess.Popen(command, cwd=source, stdout=log, stderr=subprocess.STDOUT)
    receipt['pid'] = process.pid
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    exit_code = process.wait()
final = hash_inputs()
artifacts_after = artifact_files()
receipt.update({
    'status': 'COMPLETED', 'endedAt': stamp(), 'exitCode': exit_code, 'logBytes': log_path.stat().st_size, 'logSha256': digest(log_path),
    'hashesAfter': final, 'inputDifferencesAfter': [relative for relative in baseline if final[relative] != initial[relative]],
    'baselineDifferencesAfter': [relative for relative in baseline if final[relative] != baseline[relative]],
    'artifactsAfter': artifacts_after, 'newArtifacts': [name for name in artifacts_after if name not in preexisting],
    'preexistingArtifactDifferences': [name for name, detail in preexisting.items() if artifacts_after.get(name) != detail],
    'port4195After': subprocess.run(['ss', '-ltnp', '( sport = :4195 )'], capture_output=True, text=True).stdout,
})
result_path = source / 'artifacts/ui-results.json'
receipt['uiResults'] = json.loads(result_path.read_text()) if result_path.is_file() else None
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ['status', 'startedAt', 'endedAt', 'exitCode', 'logBytes', 'logSha256', 'inputDifferencesAfter', 'preexistingArtifactDifferences', 'newArtifacts', 'uiResults']}, ensure_ascii=False), flush=True)

import assert from 'node:assert/strict';
import { readFile, writeFile, readdir, realpath } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Pure file binding only. Does not import game code, construct a Simulation,
// start a server/browser, run a build, or modify any source/build/original.
const home = path.dirname(fileURLToPath(import.meta.url));
const [sourceArg, buildReceiptArg, outputArg, buildingIdArg] = process.argv.slice(2);
assert(sourceArg && buildReceiptArg && outputArg,
  'Usage: node prepare-plan.mjs SOURCE ACTUAL_PASS_BUILD_RECEIPT NEW_PLAN_PATH [MARKET_BUILDING_ID]');
const source = await realpath(sourceArg), output = path.resolve(outputArg);
assert(output.startsWith(home + path.sep), 'Write the new plan under this private ui-plan directory');
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
async function inventory(base, relative = '') {
  const result = {};
  for (const entry of (await readdir(path.join(base, relative), { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    const name = relative ? relative + '/' + entry.name : entry.name;
    if (entry.isDirectory()) Object.assign(result, await inventory(base, name));
    else if (entry.isFile()) result[name] = hash(await readFile(path.join(base, name)));
    else throw Error('Unexpected symlink/special functional input: ' + name);
  }
  return result;
}
const inputs = {};
for (const directory of ['src', 'tests', 'scripts', 'adapters', 'public']) {
  try { Object.assign(inputs, await inventory(source, directory)); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
}
for (const name of ['package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts', 'index.html'])
  inputs[name] = hash(await readFile(path.join(source, name)));
const sortedInputs = Object.fromEntries(Object.entries(inputs).sort(([a], [b]) => a.localeCompare(b)));
const buildFiles = await inventory(path.join(source, 'dist'));
const html = await readFile(path.join(source, 'dist/index.html'), 'utf8');
const buildEntry = html.match(/src="([^"]+\.js)"/)?.[1];
assert(/^\/assets\/[^/]+\.js$/.test(buildEntry ?? ''), 'Production bundle entry missing');
const buildReceiptPath = await realpath(buildReceiptArg), buildReceiptBytes = await readFile(buildReceiptPath);
const buildReceipt = JSON.parse(buildReceiptBytes);
assert(['PASS', 'PASSED'].includes(buildReceipt.status), 'An actual completed PASS build receipt is required');
assert.equal(buildReceipt.exitCode, 0); assert.equal(buildReceipt.timedOut, false);
assert.equal(buildReceipt.inputsStable, true); assert.deepEqual(buildReceipt.activeDescendants, []);
assert.equal(buildReceipt.inputCount, Object.keys(sortedInputs).length);
const buildGateFiles = {};
for (const name of ['inputs-before.json', 'inputs-after.json', 'raw.log']) {
  const boundPath = path.join(path.dirname(buildReceiptPath), name), bytes = await readFile(boundPath);
  buildGateFiles[boundPath] = hash(bytes);
  if (name.endsWith('.json')) assert.deepEqual(JSON.parse(bytes), sortedInputs, 'Actual build input graph does not match current source: ' + name);
  else assert.equal(hash(bytes), buildReceipt.rawSHA256, 'Actual build raw log SHA mismatch');
}
const plan = {
  schema: 'ROOT27-bounded-native-city-visual-v1', status: 'BOUND_NOT_RUN', boundAt: new Date().toISOString(),
  source, inputCount: Object.keys(sortedInputs).length, inputs: sortedInputs, inputGraphSHA256: hash(JSON.stringify(sortedInputs)),
  buildFiles, buildEntry, indexSHA256: hash(html), buildSHA256: buildFiles[buildEntry.slice(1)],
  buildReceiptPath, buildReceiptSHA256: hash(buildReceiptBytes),
  buildGateFiles,
  driverPath: path.join(home, 'bounded-native-city-visual.mjs'),
  driverSHA256: hash(await readFile(path.join(home, 'bounded-native-city-visual.mjs'))),
  root20OriginalArchive: path.join(source, 'docs/validation/2026-10-05-city-life-root20/ROOT20-ORIGINAL-VALIDATION.zip'),
  root20OriginalArchiveSHA256: hash(await readFile(path.join(source, 'docs/validation/2026-10-05-city-life-root20/ROOT20-ORIGINAL-VALIDATION.zip'))),
  references: Object.fromEntries(await Promise.all([1, 2, 3, 4, 5].map(async number => {
    const name = '参考图/参考图' + number + '.png';
    return [name, hash(await readFile(path.join(source, name)))];
  }))),
  expectedLayout: 'current-v8', pagePath: '/?debug=1', expectedSeed: 20261001,
  buildingId: buildingIdArg ?? null, marketSelection: 'Explicit plan buildingId, else actual world.referenceCityRecipe.arrival.buildingId; no unrelated nearest-market fallback',
  viewport: { width: 1672, height: 941 }, deviceScaleFactor: 1,
  port: 43727, chromium: process.env.YUNSHAN_CHROMIUM ?? '/usr/bin/chromium',
  softwareGPU: true, actionTimeoutMs: 120000, runDeadlineMs: 900000,
  maximumWSeconds: 120, maximumWPulses: 700, pulseMinMs: 150, pulseMaxMs: 200,
  waypointThresholdMetres: 1.8, interiorThresholdMetres: 1.2,
  maximumEvidenceBytes: 134217728,
  outputParent: '/workspace/yunshan-work/ROOT27-night-food-20261007-01/ui-originals',
  notes: 'ROOT20 production preview/Playwright/rAF approach. Fresh isolated nonpersistent browser context; no storage seeding or clearing. Real W/E, native mouse drag, actual born/counter captures only; purchase/exit/reload not repeated. No body/camera/clock/money/needs/focus injection, no Controller or Simulation method replacement. Linux SwiftShader is image/function evidence only. Art result needs human inspection.',
};
await writeFile(output, JSON.stringify(plan, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify({ status: 'BOUND_NOT_RUN', path: output, SHA256: hash(await readFile(output)), inputCount: plan.inputCount, inputGraphSHA256: plan.inputGraphSHA256 }));

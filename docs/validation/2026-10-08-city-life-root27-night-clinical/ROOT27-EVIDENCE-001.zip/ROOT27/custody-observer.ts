import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createReadStream, existsSync, mkdirSync, openSync, closeSync, readSync, readFileSync, readdirSync, statSync, statfsSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createGunzip, gunzipSync, gzipSync } from 'node:zlib';
import { Simulation, getCanonicalNpcFullSettlement, isCanonicalNpcWage } from '/workspace/yunshan/src/simulation';
import type { Citizen, WorldDefinition } from '/workspace/yunshan/src/types';
import { assembleSave, partitionSave } from '/workspace/yunshan/src/persistence/partition';
import { CIVIC_ARCHIVE_BYTE_LIMIT, FULL_SAVE_CHARACTER_LIMIT, LIVE_SAVE_CHARACTER_LIMIT, validateSaveResources } from '/workspace/yunshan/src/persistence/save-resource';
import { cashSnapshot, debtSnapshot, foodCustodySnapshot } from '/workspace/yunshan/scripts/economy-resume-custody';
import { foodSnapshot } from '/workspace/yunshan/scripts/economy-observations';

const ROOT = '/workspace/yunshan';
const ORDER = ['time', 'environment', 'energy', 'traffic', 'people', 'commerce', 'finance', 'security', 'politics', 'feedback'] as const;
const WORLD_SHA = '2912839d3a854202d45fd1585d24d367ff6c15e8f5399bc8a669b1c91b4c8512';
const SAVE_SHA = '4610ab1059b52cfd4bbfa17badf209a7a33ab986735d83b8a5da8c8a9e5ddf6a';
const NATIVE03_CHECKPOINT_344_SHA = 'f0ea97daef48d4e2357536a3d1ce4b9222dbcbaaa4d5205677bde9483c5a95b6';
const MAX_BYTES = 2 * 1024 * 1024 * 1024, NEXT_STEP_RESERVE = 256 * 1024 * 1024;
const WALL_MS = 1800_000, ORDINARY_WALL_MS = 1740_000, MAX_WINDOWS = 360, EPS = 1e-6;
type Data = Record<string, any>;
type RawEvent = { type: string; [key: string]: unknown };
type Original = { file: string; encoding: 'gzip-utf8'; rawBytes: number; rawChars: number; rawSHA256: string; encodedBytes: number; encodedSHA256: string };
type DirectCash = { treasury: number; taxes: number; player: number; wallets: Record<string, number>; shops: Record<string, { funds: number; inventory: number }> };
type Frame = { label: string; tick: number; clock: number; completeWindow: boolean; save: Original | null; bus: Original | null; phases: Original | null; eventCount: number; missing: string[]; reader?: unknown; resources?: unknown };
class ResourceStop extends Error {}
const sha = (raw: string | Buffer) => createHash('sha256').update(raw).digest('hex');
const minute = (sim: Simulation) => sim.state.day * 1440 + sim.state.hour * 60;
const runtime = (sim: Simulation): Data => Reflect.get(sim, 'runtime') as Data;
const clone = <T>(value: T): T => structuredClone(value);
const errorText = (error: unknown) => error instanceof Error ? error.stack ?? error.message : String(error);
function close(actual: number, expected: number, label: string) {
  assert(Number.isFinite(actual) && Number.isFinite(expected) && Math.abs(actual - expected) < EPS, `${label}: ${actual} != ${expected}`);
}
function positive(value: unknown, label: string): number { assert(typeof value === 'number' && Number.isFinite(value) && value > 0, label); return value; }
function treeSize(value: unknown) {
  const pending = [{ value, depth: 0 }]; let visited = 0, depth = 0;
  while (pending.length) { const row = pending.pop()!; visited++; depth = Math.max(depth, row.depth);
    if (row.value !== null && typeof row.value === 'object') for (const child of Object.values(row.value)) pending.push({ value: child, depth: row.depth + 1 }); }
  return { visited, depth };
}

/** Reversible own-property encoding preserves undefined, -0, descriptors,
 * ordering, shared object identities and frozen original payloads. No getter is
 * executed. The ordinary JSON event beside it is only a convenient view. */
function typedOriginal(value: unknown): unknown {
  const seen = new Map<object, number>();
  const encode = (item: unknown): unknown => {
    if (item === undefined) return { kind: 'undefined' };
    if (item === null || typeof item === 'string' || typeof item === 'boolean') return { kind: typeof item, value: item };
    if (typeof item === 'number') return { kind: 'number', value: Object.is(item, -0) ? '-0' : Number.isNaN(item) ? 'NaN' : item === Infinity ? '+Infinity' : item === -Infinity ? '-Infinity' : item };
    if (typeof item === 'bigint') return { kind: 'bigint', value: String(item) };
    assert(typeof item === 'object', 'native event contains an unsupported function or symbol');
    if (seen.has(item)) return { kind: 'reference', id: seen.get(item) };
    const id = seen.size; seen.set(item, id); const prototype = Object.getPrototypeOf(item);
    assert(prototype === Object.prototype || prototype === Array.prototype || prototype === null, 'native event has an unsupported prototype');
    return { kind: Array.isArray(item) ? 'array' : 'object', id, prototype: prototype === null ? null : Array.isArray(item) ? 'Array' : 'Object',
      extensible: Object.isExtensible(item), frozen: Object.isFrozen(item), properties: Reflect.ownKeys(item).map(key => {
        assert(typeof key === 'string', 'native event contains a symbol key'); const descriptor = Object.getOwnPropertyDescriptor(item, key)!;
        assert('value' in descriptor, 'native event contains an accessor');
        return { key, enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: encode(descriptor.value) };
      }) };
  };
  return encode(value);
}
function sourceHashes() {
  const walk = (directory: string): string[] => readdirSync(join(ROOT, directory), { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name)).flatMap(entry => {
    assert(entry.isFile() || entry.isDirectory(), 'source provenance cannot follow a symlink'); const file = directory + '/' + entry.name;
    return entry.isDirectory() ? walk(file) : [file];
  });
  return Object.fromEntries([...walk('src'), ...walk('tests'), ...walk('scripts'), ...walk('adapters'), ...walk('public'), 'index.html', 'package.json', 'package-lock.json', 'tsconfig.json', 'vite.config.ts'].sort()
    .map(file => { const raw = readFileSync(join(ROOT, file)); return [file, { bytes: raw.byteLength, sha256: sha(raw) }]; }));
}
function directCash(sim: Simulation): DirectCash {
  return { treasury: sim.state.treasury, taxes: runtime(sim).taxes, player: sim.state.player.money,
    wallets: Object.fromEntries(sim.state.citizens.map(actor => [actor.id, actor.money])),
    shops: Object.fromEntries(sim.state.shops.map(shop => [shop.id, { funds: sim.shopFunds(shop), inventory: shop.inventory }])) };
}
function body(sim: Simulation, actor: Citizen) {
  const profile = sim.state.extension!.actorProfiles[actor.id];
  return { id: actor.id, name: actor.name, workId: actor.workId, homeId: actor.homeId, role: actor.role, state: actor.state, destinationId: actor.destinationId,
    position: clone(actor.position), needs: clone(actor.needs), money: actor.money, food: actor.food ?? 0, education: actor.education ?? 0,
    profile: { alive: profile.alive, age: profile.age, health: profile.health, skill: profile.skill, stress: profile.stress, mood: profile.mood } };
}
function naturalState(sim: Simulation) {
  const r = runtime(sim), e = sim.state.extension!;
  return { at: minute(sim), extensionAt: e.lastUpdate, schedule: { commerceAt: r.commerceAt, financeAt: r.financeAt, payrollAt: r.payrollAt }, citizens: sim.state.citizens.map(actor => body(sim, actor)),
    publicLabor: clone(r.publicLabor ?? null), privateLabor: clone(r.privateLabor ?? null), publicBudgets: clone(r.publicBudgets ?? []),
    publicBudget: sim.publicBudgetSnapshot(), researchJobs: clone(Reflect.get(e, 'runtime').researchJobs), technologies: clone(e.technologies), districts: clone(sim.state.districts),
    shops: sim.state.shops.map(shop => ({ ...clone(shop), funds: sim.shopFunds(shop), debt: sim.shopPayrollDebt(shop), committed: sim.shopCommittedPayroll(shop), protected: sim.shopProtectedFunds(shop),
      labor: r.shopLabor?.[shop.id] ?? 0, poweredLabor: r.poweredShopLabor?.[shop.id] ?? null, buildingKind: sim.worldDefinition.buildings.find(site => site.id === shop.buildingId)!.kind })) };
}

/** Pure audit of detached observations. This returns no gameplay capability;
 * the live caller must obtain canonical=true from the original event/current
 * Simulation, never from a copied payload or this diagnostic function. */
export function auditPublicResponseEarned(witness: Data): Data {
  const { event, actor, before, dispatch, crime, claim, at } = witness;
  assert(witness.canonical === true && event.type === 'wage-earned', 'response requires original current canonical NPC earned event');
  assert(event.citizenId === actor.id && claim.citizenId === actor.id && before?.actor.id === actor.id, 'response keeps original citizen/claim identity');
  assert(event.shopId === undefined && claim.shopId === null && actor.workId === event.siteId && claim.workId === event.siteId, 'response keeps original public employer');
  assert(['警察', 'police'].includes(actor.role) && actor.profile.alive === true, 'response requires real living police identity');
  assert(before && before.dispatch && dispatch && before.dispatch.crimeId === dispatch.crimeId && crime?.id === dispatch.crimeId && crime.status === 'responding', 'response requires the same actual active dispatch/incident');
  assert(actor.needs.hunger >= 20 && actor.needs.fatigue >= 15 && actor.profile.health >= 35 && before.allowance > 0, 'original response body/allowance qualification');
  assert(witness.roadRejected === false && actor.state !== 'roadWaiting', 'original response road movement rejection');
  assert(Number.isFinite(before.pendingMinutes) && before.pendingMinutes >= 0 && Number.isFinite(before.attendance) && before.attendance >= 0, 'original finite deferred time/attendance');
  const elapsed = Number(before.pendingMinutes) + positive(witness.nativeMinutes, 'original phase minutes');
  positive(event.minutes, 'response credited minutes'); positive(event.amount, 'response earned amount'); positive(event.ratePerMinute, 'response frozen rate');
  close(event.creditedWorkStartAt, at - elapsed, 'response inherited deferred interval start');
  close(event.creditedWorkEndAt - event.creditedWorkStartAt, event.minutes, 'response actual credited interval');
  assert(event.minutes <= Math.min(elapsed, before.allowance, 480 - before.attendance) + EPS, 'original response work caps');
  close(witness.attendance - before.attendance, event.minutes, 'original response attendance writer');
  assert(witness.attendance <= 480 + EPS, 'original response daily attendance cap');
  close(claim.minutes - (before.claim?.minutes ?? 0), event.minutes, 'original public response claim minutes writer');
  close(claim.amount - (before.claim?.amount ?? 0), event.amount, 'original public response claim amount writer');
  close(claim.ratePerMinute, event.ratePerMinute, 'original public response frozen claim rate');
  close(event.amount, event.minutes * event.ratePerMinute, 'actual public response earned amount');
  const pointDistance = (a: Data, b: Data) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
  const route = witness.route as Data[], index = witness.routeIndex as number;
  assert(Array.isArray(route) && route.length > 0 && Number.isInteger(index) && index >= 0 && index <= route.length, 'actual response route and progress');
  assert([actor.position, crime.position, ...route].every(point => point && [point.x, point.y, point.z].every(Number.isFinite)), 'finite actual response body/route/incident');
  const arrived = index >= route.length, atCrime = arrived && pointDistance(actor.position, crime.position) <= 3;
  assert(!arrived || atCrime, 'a facility/exit route endpoint is not actual incident arrival');
  assert(['responding', 'physicalWaiting'].includes(actor.state), 'original response state at earned notification');
  const sameRoute = JSON.stringify(before.route) === JSON.stringify(route), displacement = pointDistance(before.actor.position, actor.position);
  let routeArcDistance: number | null = null;
  if (sameRoute && index >= before.routeIndex) {
    let position = before.actor.position; routeArcDistance = 0;
    for (let i = before.routeIndex; i < index; i++) { routeArcDistance += pointDistance(position, route[i]); position = route[i]; }
    routeArcDistance += pointDistance(position, actor.position);
  }
  // Waiting is recorded as waiting. Original dispatch policy can credit a
  // physical wait; neither canonical wage nor that policy proves movement or
  // incident arrival. It must never become an invented onsite/task receipt.
  const activity = atCrime ? 'public-response-at-actual-incident' : actor.state === 'physicalWaiting' ? 'public-response-physical-wait' : 'public-response-in-transit';
  return { ...clone(witness), activity, elapsed, sameRoute, displacement, routeArcDistance,
    nativeDistanceBudget: elapsed * witness.walkingSpeed, actualIncidentArrival: atCrime, employerArrivalRequiredByThisSource: false,
    sourceContract: 'Original people dispatch branch credits eligible public response elapsed, including deferred source time. It does not require presence at the employing police building.',
    inheritedTimeObservation: 'The original pending time and dispatch are retained; earlier source minutes are not claimed as newly observed minute-by-minute movement.' };
}

function observe(sim: Simulation, world: WorldDefinition) {
  let events: Data[] = [], phases: Data[] = [], beforePhase: Data | null = null, activePhase = 'outside-phase', previous = directCash(sim), started = false;
  let sequence = 0; const violations: Data[] = [], captureFailures: Data[] = [], seenLedger = new WeakSet<object>(), seenLifecycle = new WeakSet<object>();
  const newLedger: Data[] = [], earned = new Map<string, number>(), paid = new Map<string, number>();
  let baseline: { cash: ReturnType<typeof cashSnapshot>; food: ReturnType<typeof foodCustodySnapshot>; debt: ReturnType<typeof debtSnapshot>; fiscal: number; aliveIds: string[] };
  const totals = { foodProduced: 0, materialProduced: 0, storedMeals: 0, counterMeals: 0, playerMeals: 0, npcEarned: 0, npcPaid: 0,
    publicNpcPaid: 0, privateNpcPaid: 0, npcPaymentCount: 0, canonicalEarnedCount: 0, fullSettlementCount: 0, fiscalEvents: 0, fiscalLedger: 0, fiscalLifecycle: 0 };
  const maxima = { cash: 0, food: 0, debt: 0, fiscal: 0 };
  const shops = new Map(sim.state.shops.map(shop => [shop.id, shop.buildingId])), sites = new Map(world.buildings.map(site => [site.id, site]));
  let beforePeople: Data | null = null;
  const foodSite = (shopId: unknown) => typeof shopId === 'string' && ['farm', 'dock', 'market'].includes(sites.get(shops.get(shopId) ?? '')?.kind ?? '');
  const failObservation = (where: string, error: unknown, missing = false) => { const row = { where, tick: sim.state.tick, clock: minute(sim), error: errorText(error) }; violations.push(row); if (missing) captureFailures.push(row); };
  const safely = (where: string, action: () => void, missing = false) => { try { action(); } catch (error) { failObservation(where, error, missing); } };
  function collectLedger() {
    if (!started) return;
    for (const row of sim.state.extension!.publicLedger) if (!seenLedger.has(row)) {
      seenLedger.add(row); const retained = { ...clone(row), observedAt: minute(sim), phase: activePhase }; newLedger.push(retained);
      if (row.account === 'public' && !row.purpose.startsWith('城市') && row.sourceEvent !== 'transit-fare' && row.sourceEvent !== 'utility-payment'
        && row.purpose !== '能源维修实际工业材料采购') totals.fiscalLedger += row.amount;
    }
    for (const row of sim.state.shopLifecycle?.receipts ?? []) if (!seenLifecycle.has(row)) {
      seenLifecycle.add(row); if (row.payeeId === 'public') { assert(row.kind === 'capital', 'unexpected lifecycle public source'); totals.fiscalLifecycle += row.amount; }
    }
  }
  function stable(phase: string) {
    collectLedger(); const cash = cashSnapshot(sim, world), food = foodCustodySnapshot(sim, world), debt = debtSnapshot(runtime(sim));
    const fiscal = sim.state.treasury + runtime(sim).taxes;
    const residual = { cash: cash.total - baseline.cash.total, food: food.total - (baseline.food.total + totals.foodProduced - totals.storedMeals - totals.counterMeals - totals.playerMeals),
      debt: debt.total - (baseline.debt.total + totals.npcEarned - totals.npcPaid), fiscal: fiscal - baseline.fiscal - totals.fiscalEvents - totals.fiscalLedger - totals.fiscalLifecycle };
    const current = beforePhase ? naturalState(sim) : null, workChanges = beforePhase && current ? current.citizens.flatMap(actor => {
      const old = beforePhase!.citizens.find((item: Data) => item.id === actor.id); return old && old.workId !== actor.workId ? [{ before: old, after: actor }] : [];
    }) : [];
    const batches = phase === 'commerce' && beforePhase && current && beforePhase.at >= beforePhase.schedule.commerceAt ? beforePhase.shops.filter((shop: Data) => ['farm', 'dock', 'workshop'].includes(shop.buildingKind)).map((shop: Data) => ({
      shopId: shop.id, kind: shop.buildingKind, laborTakenByOriginalDueBatch: shop.labor, poweredLaborBeforeBatch: shop.poweredLabor, inventoryBeforeWholeCommerce: shop.inventory,
      originalTargetInventory: 120, stockAtLeastTargetBeforeCommerce: shop.inventory >= 120, actualAfter: current.shops.find(item => item.id === shop.id),
      actualPositiveProductionReceipts: events.filter(item => item.phase === phase && item.event?.type === 'production' && item.event.shopId === shop.id).map(item => item.production),
      attribution: 'Original due commerce deletes each labor entry; whole-phase stock may also move in real supply/retail transactions. No inferred positive output or claim that stock>=120 forbids all hiring.' })) : [];
    const row = { phase, tick: sim.state.tick, clock: minute(sim), cash, food, debt, fiscal, residual, totals: { ...totals },
      publicBudget: sim.publicBudgetSnapshot(), publicBudgets: clone(runtime(sim).publicBudgets ?? []), before: beforePhase, after: current,
      newLedger: newLedger.splice(0), workChanges, productionBatches: batches, peopleWorkBefore: phase === 'people' ? beforePeople : null, completeOriginalPhaseReturned: true };
    phases.push(row); for (const key of Object.keys(maxima) as (keyof typeof maxima)[]) maxima[key] = Math.max(maxima[key], Math.abs(residual[key]));
    // These errors are retained until after the ordinary step and its originals.
    safely('stable-' + phase + '-conservation', () => {
      for (const [name, value] of Object.entries(residual)) close(value, 0, 'complete stable ' + name);
      const initialDebt = new Map(baseline.debt.byEmployer.map(item => [JSON.stringify([item.citizenId, item.shopId]), item.total]));
      const actualDebt = new Map(debt.byEmployer.map(item => [JSON.stringify([item.citizenId, item.shopId]), item.total]));
      for (const key of new Set([...initialDebt.keys(), ...actualDebt.keys(), ...earned.keys(), ...paid.keys()])) close(actualDebt.get(key) ?? 0,
        (initialDebt.get(key) ?? 0) + (earned.get(key) ?? 0) - (paid.get(key) ?? 0), 'saved-employer debt ' + key);
      for (const id of baseline.aliveIds) assert(sim.state.extension!.actorProfiles[id]?.alive === true, 'baseline resident died: ' + id);
    });
  }
  const bus = Reflect.get(sim, 'bus') as { emit(event: RawEvent): void }, originalEmit = bus.emit;
  bus.emit = event => {
    const parentPhase = activePhase; let systemPhase: string | null = null, originalCaptured = false;
    const receipt: Data = { sequence: sequence++, phase: activePhase, tick: sim.state.tick, clock: minute(sim), extensionClock: sim.state.extension?.lastUpdate };
    events.push(receipt);
    safely('event-original-' + receipt.sequence, () => { receipt.typedOriginal = typedOriginal(event); receipt.event = clone(event); originalCaptured = true;
      const type = Object.getOwnPropertyDescriptor(event, 'type')!.value; assert(typeof type === 'string'); systemPhase = type.startsWith('system:') ? type.slice(7) : null;
      if (systemPhase) activePhase = systemPhase; receipt.phase = activePhase;
    }, true);
    safely('event-source-' + receipt.sequence, () => {
      if (!originalCaptured) return;
      collectLedger(); const now = directCash(sim), amount = Number(event.amount ?? 0), taxRate = sim.state.taxRate;
      receipt.taxRate = taxRate; receipt.taxQueueBeforeForward = now.taxes; receipt.treasuryBeforeForward = now.treasury;
      receipt.canonicalNpcWage = isCanonicalNpcWage(event, sim); const full = getCanonicalNpcFullSettlement(event, sim); receipt.fullSettlement = full ? clone(full) : null;
      if (started && event.type === 'wage-earned' && event.citizenId !== 'player') {
        assert(receipt.canonicalNpcWage, 'uncertified NPC earned event'); positive(event.amount, 'earned gross'); positive(event.minutes, 'earned minutes');
        close(amount, Number(event.minutes) * Number(event.ratePerMinute), 'frozen earned rate');
        close(Number(event.creditedWorkEndAt) - Number(event.creditedWorkStartAt), Number(event.minutes), 'actual earned interval');
        const actor = sim.state.citizens.find(item => item.id === event.citizenId)!; assert(actor && actor.workId === event.siteId);
        const site = sites.get(actor.workId)!; assert(site, 'earned original employer entity');
        const assignment = event.shopId ? runtime(sim).privateLabor?.shifts[event.shopId as string]?.assignments.find((item: Data) => item.citizenId === actor.id)
          : runtime(sim).publicLabor?.shifts.find((shift: Data) => shift.day === sim.state.day)?.assignments.find((item: Data) => item.citizenId === actor.id);
        receipt.attendance = { actor: body(sim, actor), siteId: site.id, siteKind: site.kind, assignment: clone(assignment ?? null), attendance: runtime(sim).attendance[actor.id], shopLabor: runtime(sim).shopLabor?.[event.shopId as string] ?? null };
        const key = JSON.stringify([actor.id, typeof event.shopId === 'string' ? event.shopId : null]); earned.set(key, (earned.get(key) ?? 0) + amount);
        totals.npcEarned += amount; totals.canonicalEarnedCount++;
        // Account the actual canonical debt writer even if an independent
        // presence audit fails. Its latched violation still fails the run;
        // omitting a real earned row would manufacture a second debt residual.
        const dispatch = runtime(sim).dispatches[actor.id];
        if (dispatch) {
          const claim = runtime(sim).wageAccruals.find((item: Data) => item.citizenId === actor.id && item.workId === actor.workId);
          const responseWitness: Data = { canonical: receipt.canonicalNpcWage, event: clone(event), actor: body(sim, actor), employer: clone(site),
            at: sim.state.extension!.lastUpdate, nativeMinutes: Reflect.get(sim, 'minutes'), before: beforePeople?.dispatchActors[actor.id],
            dispatch: clone(dispatch), crime: clone(sim.state.crimes.find(item => item.id === dispatch.crimeId)), kit: clone(runtime(sim).policeSupplies?.kits[dispatch.crimeId] ?? null),
            attendance: runtime(sim).attendance[actor.id], claim: clone(claim), route: clone(actor.route ?? []), routeIndex: actor.routeIndex ?? 0,
            roadRejected: (Reflect.get(sim, 'citizenRoadMovementRejected') as WeakSet<Citizen>).has(actor), walkingSpeed: sim.state.weather === '雨' ? 3.1 : 4.2,
            npcStairCursor: clone(runtime(sim).npcStairCursors?.[actor.id] ?? null), rider: clone(runtime(sim).riders?.[actor.id] ?? null) };
          receipt.publicResponseSource = clone(responseWitness); receipt.publicResponse = auditPublicResponseEarned(responseWitness);
        } else assert(sim.isNearBuilding(site, actor.position, 2), 'earned actual onsite arrival');
      }
      if (started && event.type === 'wage-paid' && event.citizenId !== 'player' && amount > 0) {
        positive(event.amount, 'paid gross'); const actorId = String(event.citizenId), shopId = typeof event.shopId === 'string' ? event.shopId : null;
        const tax = amount * taxRate, net = amount - tax, payerBefore = shopId ? previous.shops[shopId].funds : previous.treasury, payerAfter = shopId ? now.shops[shopId].funds : now.treasury;
        close(now.wallets[actorId] - previous.wallets[actorId], net, 'original NPC net wallet writer'); close(payerBefore - payerAfter, amount, 'original employer gross writer');
        close(now.taxes - previous.taxes, tax, 'original wage tax writer'); assert(amount <= Number(event.requestedAmount) + EPS);
        receipt.payment = { citizenId: actorId, shopId, gross: amount, requested: event.requestedAmount, net, tax, taxRate,
          payerBefore, payerAfter, walletBefore: previous.wallets[actorId], walletAfter: now.wallets[actorId], taxQueueBefore: previous.taxes, taxQueueAfter: now.taxes };
        if (full) { assert.equal(full.amount, amount); assert.equal(full.requestedAmount, amount); totals.fullSettlementCount++; }
        const key = JSON.stringify([actorId, shopId]); paid.set(key, (paid.get(key) ?? 0) + amount); totals.npcPaid += amount; totals.npcPaymentCount++;
        if (shopId) totals.privateNpcPaid += amount; else totals.publicNpcPaid += amount;
        totals.fiscalEvents += tax - (shopId ? 0 : amount);
      }
      if (started && event.type === 'production') {
        positive(event.amount, 'positive original production'); positive(event.minutes, 'positive original production labor');
        const shopId = String(event.shopId), site = sites.get(shops.get(shopId) ?? '')!; assert(site, 'classified producer');
        receipt.production = { siteId: site.id, kind: site.kind, laborMinutes: event.minutes, inventoryAfter: now.shops[shopId].inventory,
          inventoryBeforeActualPositiveWriter: now.shops[shopId].inventory - amount, amount };
        if (foodSite(shopId)) totals.foodProduced += amount; else { assert.equal(site.kind, 'workshop'); totals.materialProduced += amount; }
      }
      if (started && event.type === 'stored-meal') totals.storedMeals += positive(event.amount, 'actual carried meal');
      if (started && event.type === 'food-consumed') { assert.equal(event.citizenId, 'player'); totals.playerMeals += positive(event.amount, 'actual player meal'); }
      if (started && event.type === 'sale') { if (foodSite(event.shopId) && typeof event.citizenId === 'string' && event.citizenId !== 'player') totals.counterMeals++; totals.fiscalEvents += amount * taxRate; }
      if (started && event.type === 'wholesale') { totals.fiscalEvents += amount * taxRate;
        const shopId = String(event.shopId); positive(event.amount, 'original wholesale gross'); close(now.shops[shopId].funds - previous.shops[shopId].funds, amount * (1 - taxRate), 'actual wholesale supplier net writer');
        positive(event.quantity, 'original wholesale quantity');
        // Consignment settlements preserve their actual gross and quantity but
        // do not publish a unitPrice field. Never supply a synthetic quote.
        if (event.unitPrice !== undefined) close(amount, Number(event.quantity) * positive(event.unitPrice, 'original wholesale quote'), 'original wholesale gross/quantity/quote');
        receipt.supplier = { shopId, gross: amount, net: amount * (1 - taxRate), quantity: event.quantity, unitPrice: event.unitPrice, observedGrossPerUnit: amount / Number(event.quantity),
          fundsBeforeLastBusBoundary: previous.shops[shopId]?.funds, fundsAfterWriter: now.shops[shopId]?.funds, stockBeforeLastBusBoundary: previous.shops[shopId]?.inventory, stockAfterWriter: now.shops[shopId]?.inventory,
          attribution: 'Original seller receipt; this payload has no universal buyer or vehicle-delivery ID.' }; }
      if (started && event.type === 'business-expense') totals.fiscalEvents += amount;
      if (started && event.type === 'transit-fare') totals.fiscalEvents += amount;
      if (started && ['public-procurement', 'security-procurement', 'emergency-procurement', 'medical-procurement', 'civic-procurement'].includes(event.type)) {
        const shopId = String(event.shopId), tax = amount * taxRate; positive(event.amount, 'actual public procurement');
        close(previous.treasury - now.treasury, amount, 'actual public payer'); close(now.shops[shopId].funds - previous.shops[shopId].funds, amount - tax, 'actual aliased supplier net');
        close(now.taxes - previous.taxes, tax, 'actual procurement tax'); close(previous.shops[shopId].inventory - now.shops[shopId].inventory, Number(event.quantity), 'actual supplier material');
        close(amount, Number(event.quantity) * Number(event.unitPrice), 'actual original procurement quote');
        receipt.procurement = { payerBefore: previous.treasury, payerAfter: now.treasury, supplierBefore: previous.shops[shopId], supplierAfter: now.shops[shopId], taxQueueBefore: previous.taxes, taxQueueAfter: now.taxes, taxRate,
          budget: clone(runtime(sim).publicBudgets?.find((item: Data) => item.id === event.budgetId) ?? null) };
        totals.fiscalEvents += tax - amount;
      }
      if (started && (event.type === 'roadwork-wage-paid' || event.type === 'wage-paid' && event.citizenId === 'player')) totals.fiscalEvents += amount * taxRate;
      if (started && systemPhase && ['people', 'commerce', 'finance', 'security', 'politics'].includes(systemPhase)) beforePhase = naturalState(sim);
      if (started && systemPhase === 'people') {
        const r = runtime(sim); beforePeople = { at: sim.state.extension!.lastUpdate, nativeMinutes: Reflect.get(sim, 'minutes'), dispatchActors: Object.fromEntries(sim.state.citizens.flatMap(actor => {
          const dispatch = r.dispatches[actor.id]; if (!dispatch) return [];
          return [[actor.id, { actor: body(sim, actor), dispatch: clone(dispatch), crime: clone(sim.state.crimes.find(item => item.id === dispatch.crimeId)),
            kit: clone(r.policeSupplies?.kits[dispatch.crimeId] ?? null), pendingMinutes: r.peopleElapsed?.[actor.id] ?? 0, attendance: r.attendance[actor.id] ?? 0,
            allowance: (Reflect.get(sim, 'policeWorkAllowance') as (actor: Citizen) => number).call(sim, actor),
            claim: clone(r.wageAccruals?.find((item: Data) => item.citizenId === actor.id && item.workId === actor.workId) ?? null),
            route: clone(actor.route ?? []), routeIndex: actor.routeIndex ?? 0, npcStairCursor: clone(r.npcStairCursors?.[actor.id] ?? null), rider: clone(r.riders?.[actor.id] ?? null) }]];
        })) };
      }
      previous = now;
    });
    // Observational failures never interrupt a native writer. Native exceptions
    // retain their original object/stack and propagate unchanged.
    let returned = false;
    try { originalEmit.call(bus, event); returned = true; }
    finally {
      safely('event-after-' + receipt.sequence, () => { receipt.originalEmitReturned = returned; receipt.typedAfterOriginalHandlers = typedOriginal(event); collectLedger(); const now = directCash(sim);
        if (started && originalCaptured && returned && ['sale', 'wholesale'].includes(event.type)) {
          receipt.nativeTaxHandler = { before: receipt.taxQueueBeforeForward, after: now.taxes, expected: Number(event.amount) * receipt.taxRate };
          close(now.taxes - receipt.taxQueueBeforeForward, Number(event.amount) * receipt.taxRate, 'original sale/wholesale tax queue handler');
        }
        if (started && originalCaptured && returned && ['business-expense', 'transit-fare'].includes(event.type)) close(now.treasury - receipt.treasuryBeforeForward, Number(event.amount), 'original public receipt handler');
        previous = now;
      }, true);
      if (returned && started && systemPhase) { const phase = systemPhase; safely('stable-' + phase, () => stable(phase), true); }
      if (systemPhase) { activePhase = parentPhase; beforePhase = null; }
    }
  };
  return {
    totals, maxima, violations, captureFailures,
    start() { started = true; for (const row of sim.state.extension!.publicLedger) seenLedger.add(row); for (const row of sim.state.shopLifecycle?.receipts ?? []) seenLifecycle.add(row);
      previous = directCash(sim); baseline = { cash: cashSnapshot(sim, world), food: foodCustodySnapshot(sim, world), debt: debtSnapshot(runtime(sim)), fiscal: sim.state.treasury + runtime(sim).taxes,
        aliveIds: sim.state.citizens.filter(actor => sim.state.extension!.actorProfiles[actor.id].alive).map(actor => actor.id) }; return clone(baseline); },
    current() { return { events, phases, violations: clone(violations), captureFailures: clone(captureFailures), totals: { ...totals }, maxima: { ...maxima } }; },
    clearFrame() { events = []; phases = []; beforePhase = null; beforePeople = null; },
  };
}

export { observe as attachEconomyCustodyObserver };

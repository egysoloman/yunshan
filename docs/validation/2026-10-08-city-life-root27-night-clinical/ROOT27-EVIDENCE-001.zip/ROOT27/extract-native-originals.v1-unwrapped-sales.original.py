from pathlib import Path
import gzip, hashlib, json

private = Path('/workspace/yunshan-work/ROOT27-night-food-20261007-01')
originals = Path('/tmp/ROOT27-night-food-20261007-01')
runs = []
for label in ['native01', 'native02', 'native03']:
    base = originals / label
    world = json.loads((base / 'WORLD.original.json').read_bytes())
    kinds = {b['id']: b['kind'] for b in world['buildings']}
    frames = json.loads((base / 'FRAMES.json').read_bytes())
    points = []
    for frame in frames:
        save_bytes = gzip.decompress((base / frame['save']['file']).read_bytes())
        assert hashlib.sha256(save_bytes).hexdigest() == frame['save']['rawSHA256']
        bus_bytes = gzip.decompress((base / frame['bus']['file']).read_bytes())
        assert hashlib.sha256(bus_bytes).hexdigest() == frame['bus']['rawSHA256']
        save, bus = json.loads(save_bytes), json.loads(bus_bytes)
        state = save['state']
        points.append({'clock': frame['clock'], 'tick': frame['tick'], 'complete': frame['complete'],
            'saveSHA256': frame['save']['rawSHA256'],
            'low': sum(c['needs']['hunger'] < 30 and state['extension']['actorProfiles'][c['id']]['alive'] for c in state['citizens']),
            'openMarketCount': sum(shop['open'] for shop in state['shops'] if kinds[shop['buildingId']] == 'market'),
            'jobs': state.get('nightRetail', {}).get('jobs', []),
            'sales': [event for event in bus if event.get('type') == 'sale']})
    runs.append({'run': label, 'result': json.loads((base / 'RESULT.json').read_bytes()), 'frames': points})
result = {'mode': 'pure original SAVE/BUS SHA readback; no Simulation/import/step',
    'Simulations': 0, 'steps': 0, 'earlierInefficientReadback': 'own process terminated before output or memo write; World now parsed once per run', 'runs': runs}
target = private / 'NATIVE01-03-PURE-COMPARISON.json'
target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
last = originals / 'native03'
frame = json.loads((last / 'FRAMES.json').read_bytes())[-1]
raw = gzip.decompress((last / frame['save']['file']).read_bytes())
assert hashlib.sha256(raw).hexdigest() == runs[-1]['result']['terminalSaveSHA256']
(private / 'INPUT-5672-night03.original.save.json').write_bytes(raw)
print(json.dumps({'output': str(target), 'bytes': target.stat().st_size, 'night03': runs[-1]['result']}))

# ROOT27 最终只读源码审查（2026-10-08）

结论：本轮审查未发现需要阻断提交的确定新缺陷。此结论仅为静态源码审查；不代替 root 的429图构建、规则、GPU或native06结果。本审查没有运行 Node、Simulation、测试、构建或浏览器，没有修改共享代码，没有新增测试。

审查范围：当前 git diff 的生产源码、README，以及新增 night-retail、clinical-paid-triage、roof-end-finish 与对应测试文本。精确 HEAD、输入SHA和tracked源码diff见同目录 FINAL-REVIEW-INPUTS.json / FINAL-REVIEW-TRACKED-SOURCE.diff。

1. 夜间经营与首负荷：night-retail.ts:79–98仍要求原商人本人、真实工作点、现货、可达有钱饥饿居民、原本日已资助剩余工时；beginNightRetail仅声明有截止时间的任务，不改钱包、库存、工资额度。power-grid.ts:139–154仅允许当前、连通、零需求表且存在可用源申请首负荷；实际nightRetailTask仍走未放宽的供电检查（night-retail.ts:101–106）。声明本相没有工资，下一energy相根据计划计算真实需求后才能服务。该接线未发现免供电服务或额外资产来源。
2. 工时与营业权威：simulation.ts:2006–2012把工作限制在实际到达、本相、声明后的原时间窗；原registerAttendance继续执行480分钟和已签private assignment限制。night-retail.ts:186–208只接本城本state/tick/clock的canonical wage、去重并截取原合同时间。只有私有服务见证能开放夜柜台；保存的lastServedAt/lastObservedAt不是权限。反馈到期/取消与time/onLoad清除见证。标记店铺的玩家purchase在simulation.ts:2512重新核retailOpenAtPhase，不能只靠恢复后的shop.open购买。
3. 持久化与旧档：night模块/运行marker/店铺marker双向检查，所有新增对象字段严格限定；活跃合同还校验原private labor与attendance。新增持久模块会让不支持的旧reader拒读，而非悄悄按日间合同解释。新增hydro计划stamp保留当时的店、经营者和期限；全历史同jobId一致性与保留任务对账俱在，旧无stamp形状保留。剪裁后的终态任务只留受限声明历史，不应宣传为不可篡改签名。
4. 付费分诊：clinical.ts:361–370的derived顺序真实接入原治疗循环；v1传undefined保原数组/旧顺序。v2只排序已付30、备齐1材料、未完20分钟且主体存活的所选诊所订单，保留原存档插入顺序、到场/医生工资/两患者每医生/公共先占/费用/退款守卫。新factory稳定按实际clinic ID选首个，无clinic回到原recipe，main仅无旧档启用；本轮strict custody已补齐paidTriage两字段，之前指出的分类阻碍已解决。
5. 其它差异：食物观察新增记录明确NOT_LIVE_CERTIFIED；屋顶helper只按既有曲檐profile为原实例选择材质端面细节，未在所审差异中新增几何、碰撞或库存来源。视觉与性能结论仍以root原件为准。

边界须准确保留：

- “旧档兼容”不等于所有旧档以后永久保持旧行为：临床v1不自动升级；夜营安装于所有Simulation，旧档仍可能在后续满足真实条件时首次惰性声明，正是native05/06使用的路径。
- 分诊仅一家医馆的付费队列；公共患者仍先取原共享容量。登记年龄包含离院时间，低严重度没有最长等待保证。不能称全城或公费+付费统一公平候诊。
- 首负荷现有新增测试为synthetic module host/参数电网；已知自然续跑使用无有限电网的旧World291且临床v1，不能据此宣称自然大城首负荷或自然分诊已验证。新factory无clinic/顺序不变及完整parts临床v2的专门执行证据不在本审查中。
- 最终native06结果、完整38域、美术ART_FAIL、长期经济稳态与macOS实机仍由root按实际证据报告，不从静态审查推导通过。

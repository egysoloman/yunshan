# Frozen11 pre-navigation startup CPU diagnostic — READY_NOT_RUN

This is prepared for `/tmp/yunshan-system-coherent-11/source`,105 immutable inputs and100 shared executable inputs (the same five text-file exclusions as the previous diagnostic). Source manifest SHA256 `72dd109f5ba725ed8f02646f87d99d1d6046d8f18a9bf91a34c43710c6f780c6`. Actual built entry is `/assets/index-CxfucW3u.js`,647107B,SHA256 `7ed91565c741671b4f25571118bc07d515d4ff1e42b0e3c55b6044077b2a2da9`. Both corresponding immutable JS source maps have separate SHA contracts. No source, build, world, actor or setting is changed.

**Do not run until root reports completion of actual105+24 validation and explicitly grants this single GPU/CPU-diagnostic slot.** Preparation, syntax checks and hash reads do not constitute a started profile. The original frozen10 browser11 remains0/11; the separate frozen10 diagnostic observed debug/tick progress but had screenshot/close timeouts. Those originals and their later cleanup are preserved at `/tmp/yunshan-coherent10-boot-diagnostic-01/`. Prepared10 native-home remainsNOT_RUN and does not validate11.

The new script owns strict vacant port4191, uses existing playwright-core and `/usr/bin/chromium` with the original1440×900/SwiftShader options, fresh nonpersistent context and normal1× application settings. Before navigation it awaits successful **CDP Profiler.enable and Profiler.start**. Sampling interval remains the actual CDP default. There is no Debugger enable/pause, source instrumentation, wrapper of production methods, or business command.

The observer retains console/pageerror/requestfailed, lifecycle/resources, exact independent HTTP and actual browser-loaded entry SHA, stage/canvas/UI, hidden/paused/debug/tick/phase/accumulator snapshots and its own rAF heartbeat. Observation-only timers add overhead. No clock, actor, position, feet, needs, weather, money, identity or settings are assigned, and no Simulation.step or API business operation is invoked.

The navigation observation has the same90s ceiling. A Node timer requests Profiler.stop once at90s; ending observation earlier requests the same single stop task. The actual stop response may itself be delayed: its requested/returned times and raw profile start/endTime are recorded honestly, and sampling extent is not clipped to manufacture an exact90s profile. Stop response has a5s bound. A failed enable/start/stop is preserved as an incomplete diagnostic and **does not produce a substitute profile**. Raw `startup-main-thread.cpuprofile` preserves all actual nodes/samples/timeDeltas, including negative deltas; no clamp or repair is performed.

Normal cleanup awaits `browser.close()` for10s and TERM only its own preview child. Exact process identity is recorded. It never broad-kills any Chromium/Node, does not retry, and does not declare release after an unresolved close. Later targeted cleanup requires separate ownership verification/authorization. Port4173 must also be vacant to prevent overlap with the original compiled scope.

Once root grants GO:

```sh
YUNSHAN_BOOT11_PROFILE_APPROVED=1 node /tmp/yunshan-coherent11-boot-profile-ready-01/boot-profile.mjs
```

Outputs are in the initially empty `probe-evidence/`. The result is diagnostic-only, never a browser11/native/visual/Mac/FPS or pure elapsed benchmarkPASS.

`summarize-profile.mjs` is an offline data reader, not a simulation/test. After an actual profile exists, it can produce sample-count self/inclusive attribution using the exact frozen source-map bytes:

```sh
node /tmp/yunshan-coherent11-boot-profile-ready-01/summarize-profile.mjs
```

It leaves the original profile untouched and reports negative-delta counts. Application/Three/GC/idle/program categories are sample classifications, not elapsed or native/GPU measurements. A program/unattributed sample does not resolve CPU-versus-GPU cause. Source positions support investigation; they do not by themselves prove a semantic defect.

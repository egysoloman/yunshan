import { readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

// Offline data analysis only. Never imports the application or executes a world.
const here = dirname(new URL(import.meta.url).pathname);
const contract = JSON.parse(await readFile(join(here, 'source-contract.json'), 'utf8'));
const profilePath = process.argv[2] ?? join(here, 'probe-evidence/startup-main-thread.cpuprofile');
const outputPath = process.argv[3] ?? join(here, 'probe-evidence/cpu-attribution.json');
const bytes = await readFile(profilePath), profile = JSON.parse(bytes);
assert(Array.isArray(profile.nodes) && Array.isArray(profile.samples), 'Actual profile nodes/samples are required; no synthetic profile');
const hash = value => createHash('sha256').update(value).digest('hex');
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const decode = token => {
  const output = []; let value = 0, shift = 0;
  for (const char of token) {
    const digit = alphabet.indexOf(char); assert(digit >= 0, 'Invalid source-map VLQ');
    value += (digit & 31) * 2 ** shift;
    if (digit & 32) { shift += 5; continue; }
    output.push((value & 1 ? -1 : 1) * Math.floor(value / 2)); value = 0; shift = 0;
  }
  return output;
};
const mappings = new Map();
for (const declared of contract.sourceMaps) {
  const raw = await readFile(join(contract.sourceRoot, 'dist', declared.assetPath.slice(1)));
  assert.equal(hash(raw), declared.sha256, 'Only the immutable corresponding source map may be used');
  const map = JSON.parse(raw); let source = 0, originalLine = 0, originalColumn = 0, name = 0;
  const lines = map.mappings.split(';').map(line => {
    let generatedColumn = 0;
    return line.split(',').filter(Boolean).map(token => {
      const item = decode(token); generatedColumn += item[0];
      if (item.length === 1) return { generatedColumn, mapped: null };
      source += item[1]; originalLine += item[2]; originalColumn += item[3]; if (item.length >= 5) name += item[4];
      return { generatedColumn, mapped: { source: map.sources[source], line: originalLine + 1, column: originalColumn + 1, name: item.length >= 5 ? map.names?.[name] ?? null : null } };
    });
  });
  mappings.set(declared.assetPath.replace(/\.map$/, ''), lines);
}
const position = frame => {
  let pathname; try { pathname = new URL(frame.url).pathname; } catch { return null; }
  const line = mappings.get(pathname)?.[frame.lineNumber]; if (!line) return null;
  let lo = 0, hi = line.length - 1, found = null;
  while (lo <= hi) { const mid = (lo + hi) >> 1; if (line[mid].generatedColumn <= frame.columnNumber) { found = line[mid].mapped; lo = mid + 1; } else hi = mid - 1; }
  return found;
};
const nodes = new Map(profile.nodes.map(node => [node.id, node])), parent = new Map();
for (const node of profile.nodes) for (const child of node.children ?? []) parent.set(child, node.id);
const self = new Map(), inclusive = new Map(), categories = {};
const category = frame => {
  if (frame.functionName === '(idle)') return 'idle';
  if (frame.functionName === '(garbage collector)') return 'garbage-collector';
  if (frame.functionName === '(program)' || frame.functionName === '(root)') return 'program-or-unattributed';
  if (frame.url?.includes(contract.distEntry)) return 'application-JS';
  if (frame.url?.includes('/assets/three-')) return 'Three-JS';
  return 'other-or-observer-JS';
};
for (const id of profile.samples) {
  const node = nodes.get(id); assert(node, 'A sample references a missing actual node');
  self.set(id, (self.get(id) ?? 0) + 1); const key = category(node.callFrame); categories[key] = (categories[key] ?? 0) + 1;
  const visited = new Set(); let current = id;
  while (current !== undefined && !visited.has(current)) { visited.add(current); inclusive.set(current, (inclusive.get(current) ?? 0) + 1); current = parent.get(current); }
}
const rows = counts => [...counts].sort((a, b) => b[1] - a[1]).slice(0, 50).map(([id, count]) => ({
  id, samples: count, shareOfAllSamples: profile.samples.length ? count / profile.samples.length : 0,
  callFrame: nodes.get(id).callFrame, mapped: position(nodes.get(id).callFrame) }));
const deltas = profile.timeDeltas ?? [];
const report = { profilePath, profileBytes: bytes.length, profileSHA256: hash(bytes), sampleCount: profile.samples.length, nodeCount: profile.nodes.length,
  rawTimeDeltas: { count: deltas.length, negativeCount: deltas.filter(n => n < 0).length, zeroCount: deltas.filter(n => n === 0).length, valuesEdited: false },
  profileStartTime: profile.startTime, profileEndTime: profile.endTime, categoryExclusiveSampleCounts: categories, topExclusive: rows(self), topInclusive: rows(inclusive),
  scope: 'Sample-count attribution only, with exact immutable JS source maps; not elapsed-time attribution or benchmark. Original CPU profile and all timeDeltas untouched.',
  limitations: ['V8 main-thread samples do not measure GPU execution or native driver/C++ functions', 'program-or-unattributed cannot establish CPU-vs-GPU cause', 'Sampling/timers/CDP introduce observation overhead', 'Mapped source positions are evidence references, not proof of a semantic defect', 'No formal browser11/native/Mac/art acceptance'] };
await writeFile(outputPath, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({ outputPath, samples: report.sampleCount, negativeTimeDeltas: report.rawTimeDeltas.negativeCount, profileSHA256: report.profileSHA256 }));

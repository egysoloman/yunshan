import { readFile, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';

// Offline data analysis only. Never imports the application or executes a world.
const here = dirname(new URL(import.meta.url).pathname);
const contract = JSON.parse(await readFile(join(here, 'source-contract.json'), 'utf8'));
const profilePath = process.argv[2] ?? join(here, 'probe-evidence/startup-main-thread.cpuprofile');
const outputPath = process.argv[3] ?? join(here, 'probe-evidence/cpu-attribution.json');
const bytes = await readFile(profilePath), profile = JSON.parse(bytes);
assert(Array.isArray(profile.nodes) && Array.isArray(profile.samples), 'Actual profile nodes/samples are required; no synthetic profile');
const hash = value => createHash('sha256').update(value).digest('hex');
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const decode = token => {
  const output = []; let value = 0, shift = 0;
  for (const char of token) {
    const digit = alphabet.indexOf(char); assert(digit >= 0, 'Invalid source-map VLQ');
    value += (digit & 31) * 2 ** shift;
    if (digit & 32) { shift += 5; continue; }
    output.push((value & 1 ? -1 : 1) * Math.floor(value / 2)); value = 0; shift = 0;
  }
  return output;
};
const mappings = new Map();
for (const declared of contract.sourceMaps) {
  const raw = await readFile(join(contract.sourceRoot, 'dist', declared.assetPath.slice(1)));
  assert.equal(hash(raw), declared.sha256, 'Only the immutable corresponding source map may be used');
  const map = JSON.parse(raw); let source = 0, originalLine = 0, originalColumn = 0, name = 0;
  const lines = map.mappings.split(';').map(line => {
    let generatedColumn = 0;
    return line.split(',').filter(Boolean).map(token => {
      const item = decode(token); generatedColumn += item[0];
      if (item.length === 1) return { generatedColumn, mapped: null };
      source += item[1]; originalLine += item[2]; originalColumn += item[3]; if (item.length >= 5) name += item[4];
      return { generatedColumn, mapped: { source: map.sources[source], line: originalLine + 1, column: originalColumn + 1, name: item.length >= 5 ? map.names?.[name] ?? null : null } };
    });
  });
  mappings.set(declared.assetPath.replace(/\.map$/, ''), lines);
}
const position = frame => {
  let pathname; try { pathname = new URL(frame.url).pathname; } catch { return null; }
  const line = mappings.get(pathname)?.[frame.lineNumber]; if (!line) return null;
  let lo = 0, hi = line.length - 1, found = null;
  while (lo <= hi) { const mid = (lo + hi) >> 1; if (line[mid].generatedColumn <= frame.columnNumber) { found = line[mid].mapped; lo = mid + 1; } else hi = mid - 1; }
  return found;
};
const nodes = new Map(profile.nodes.map(node => [node.id, node])), parent = new Map();
for (const node of profile.nodes) for (const child of node.children ?? []) parent.set(child, node.id);
const self = new Map(), inclusive = new Map(), categories = {};
const category = frame => {
  if (frame.functionName === '(idle)') return 'idle';
  if (frame.functionName === '(garbage collector)') return 'garbage-collector';
  if (frame.functionName === '(program)' || frame.functionName === '(root)') return 'program-or-unattributed';
  if (frame.url?.includes(contract.distEntry)) return 'application-JS';
  if (frame.url?.includes('/assets/three-')) return 'Three-JS';
  return 'other-or-observer-JS';
};
for (const id of profile.samples) {
  const node = nodes.get(id); assert(node, 'A sample references a missing actual node');
  self.set(id, (self.get(id) ?? 0) + 1); const key = category(node.callFrame); categories[key] = (categories[key] ?? 0) + 1;
  const visited = new Set(); let current = id;
  while (current !== undefined && !visited.has(current)) { visited.add(current); inclusive.set(current, (inclusive.get(current) ?? 0) + 1); current = parent.get(current); }
}

// Derived offline count tables. Function identity is the actual generated callFrame
// location; mapped location is the nearest source-map segment for that function
// begin, not an exact sampled instruction / execution PC.
const functionKey = frame => JSON.stringify([frame.url,frame.lineNumber,frame.columnNumber,frame.functionName]);
const groups = new Map(), byNode = new Map();
for (const node of profile.nodes) {
  const key = functionKey(node.callFrame);
  if (!groups.has(key)) groups.set(key, { callFrame:node.callFrame, functionBeginNearestOriginalPosition:position(node.callFrame), nodeIDs:[], exclusiveSamples:0, inclusiveSamples:0 });
  groups.get(key).nodeIDs.push(node.id); byNode.set(node.id,key);
}
const ancestry = { frame:0, people:0, floorPlanRoute:0, rendererConstructor:0, controller:0, nearChunk:0, threeRender:0 };
const match = (row,name,source) => row.functionBeginNearestOriginalPosition?.source?.endsWith(source) && row.callFrame.functionName===name;
for (const id of profile.samples) {
  groups.get(byNode.get(id)).exclusiveSamples++;
  let current=id; const visited=new Set(), visitedGroups=new Set(), flags={};
  while(current!==undefined&&!visited.has(current)) {
    visited.add(current); const row=groups.get(byNode.get(current)), key=byNode.get(current);
    if(!visitedGroups.has(key)){row.inclusiveSamples++;visitedGroups.add(key);}
    const src=row.functionBeginNearestOriginalPosition?.source??'';
    if(row.functionBeginNearestOriginalPosition?.source?.endsWith('/src/main.ts')&&row.functionBeginNearestOriginalPosition.line===180&&row.functionBeginNearestOriginalPosition.column===10)flags.frame=true;
    if(match(row,'people','/src/simulation.ts'))flags.people=true;
    if(match(row,'floorPlanRoute','/src/simulation.ts'))flags.floorPlanRoute=true;
    if(row.functionBeginNearestOriginalPosition?.source?.endsWith('/src/renderer.ts')&&row.functionBeginNearestOriginalPosition.line===132&&row.functionBeginNearestOriginalPosition.column===3)flags.rendererConstructor=true;
    if(src.endsWith('/src/controller.ts'))flags.controller=true;
    if(src.endsWith('/src/rendering/chunk-residency.ts'))flags.nearChunk=true;
    if(src.includes('three')&&/^(render|renderScene|renderObjects|renderObject|renderBufferDirect)$/.test(row.callFrame.functionName))flags.threeRender=true;
    current=parent.get(current);
  }
  for(const key of Object.keys(ancestry))if(flags[key])ancestry[key]++;
}
const all=[...groups.values()];
const moduleCounts={};
for(const row of all){const src=row.functionBeginNearestOriginalPosition?.source??'(not mapped)';moduleCounts[src]=(moduleCounts[src]??0)+row.exclusiveSamples;}
const negativeTimeDeltas=(profile.timeDeltas??[]).flatMap((value,index)=>value<0?[{index,value}]:[]);
const output={ profileSHA256:hash(bytes),sampleCount:profile.samples.length,nodeCount:profile.nodes.length,
  generatedFunctionGroupCount:all.length,rawTimeDeltas:{negativeCount:negativeTimeDeltas.length,negativeEntries:negativeTimeDeltas,edited:false},
  method:{exclusive:'Each actual leaf sample is counted once. Generated function identity uses URL + function begin line/column + name, merged across stack contexts.',
  inclusive:'Count each logical function at most once per actual ancestor chain; nested function and ancestry totals overlap and are non-additive.',
  sourceMap:'Nearest preceding generated mapping segment at callFrame function-begin location (0-based V8 -> 1-based source reference), not an exact executing instruction/PC. No name-only source attribution.',
  chronology:'Only sample counts. No timeDelta sum, clamping, elapsed percentages, or temporal phase duration reconstruction.'},
  topExclusive:all.filter(r=>r.exclusiveSamples).sort((a,b)=>b.exclusiveSamples-a.exclusiveSamples).slice(0,50),
  topInclusive:all.filter(r=>r.inclusiveSamples).sort((a,b)=>b.inclusiveSamples-a.inclusiveSamples).slice(0,50),
  exclusiveByMappedSource:Object.fromEntries(Object.entries(moduleCounts).sort((a,b)=>b[1]-a[1])),
  ancestrySampleCounts:ancestry,
  focusedFunctions:all.filter(r=>/\/(controller|simulation|renderer)\.ts$|\/rendering\/chunk-residency\.ts$|\/architecture-floor-plan\.ts$/.test(r.functionBeginNearestOriginalPosition?.source??'')).sort((a,b)=>b.exclusiveSamples-a.exclusiveSamples),
  limitations:['No program/native/GC/GPU leaf sample is reassigned to JavaScript exclusive counts','Sampling and observation overhead; not formal browser11/native/Mac or FPS/throughput acceptance','No measured route-cache hits/misses; source cache keys are only static facts']};
const derivedPath=join(here,'probe-evidence/cpu-attribution-functions.json');
await writeFile(derivedPath,JSON.stringify(output,null,2)+'\n');
console.log(JSON.stringify({outputPath:derivedPath,samples:output.sampleCount,negativeTimeDeltas:negativeTimeDeltas.length,ancestrySampleCounts:ancestry}));

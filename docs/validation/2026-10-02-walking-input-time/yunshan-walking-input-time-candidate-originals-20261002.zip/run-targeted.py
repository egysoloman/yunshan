from pathlib import Path
import datetime as dt
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'evidence' / (sys.argv[1] if len(sys.argv) > 1 else 'run01')
OUT.mkdir(exist_ok=False)

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def snapshot(tree, expected):
    return {name: digest(ROOT / tree / name) for name in expected}

before = json.loads((ROOT / 'evidence/before-manifest.json').read_text())['hashes']
candidate = json.loads((ROOT / 'evidence/candidate-manifest.json').read_text())['hashes']
inputs = ['candidate.patch', 'run-targeted.py', 'evidence/baseline-controller-input-time.test.mts']
input_start = {name: digest(ROOT / name) for name in inputs}
status = {'state': 'RUNNING', 'startedAtUTC': now(), 'launcherPid': os.getpid(),
          'beforeStart': snapshot('before', before), 'candidateStart': snapshot('candidate', candidate),
          'runnerInputsStart': input_start, 'runs': [],
          'scope': 'Expected old-main motor negatives, strict tsc, new input regression, original controller tests, build only. No Simulation/native save/performance/GPU run.'}
assert status['beforeStart'] == before
assert status['candidateStart'] == candidate

def save():
    (OUT / 'run-status.json').write_text(json.dumps(status, ensure_ascii=False, indent=2) + '\n')

def summary(text):
    return {k: int(v) for k, v in re.findall(r'(?m)^\s*(?:#|ℹ)\s+(tests|pass|fail|cancelled|skipped|todo)\s+(\d+)\s*$', text)}

pattern = 'late W in a slow frame|a completed 200ms pulse|pre-reset queued presses'
stages = [
    ('strict-tsc', ['node', 'node_modules/typescript/bin/tsc', '--noEmit'], ROOT / 'candidate', False),
    ('before12-expect-fail', ['node', '--import', 'tsx', '--test', '--test-isolation=none', '--test-name-pattern=' + pattern,
                            str(ROOT / 'evidence/baseline-controller-input-time.test.mts')], ROOT / 'before', True),
    ('candidate-input-time', ['node', '--import', 'tsx', '--test', '--test-isolation=none', 'tests/controller-input-time.test.ts'], ROOT / 'candidate', False),
    ('original-controller', ['node', '--import', 'tsx', '--test', '--test-isolation=none', 'tests/controller.test.ts', 'tests/controller-v4.test.ts'], ROOT / 'candidate', False),
    ('build', ['npm', 'run', 'build'], ROOT / 'candidate', False),
]

exit_code = 1
save()
try:
    for label, command, cwd, expected_failure in stages:
        path = OUT / (label + '.log')
        row = {'label': label, 'command': command, 'cwd': str(cwd), 'startedAtUTC': now(),
               'expectedOldRegressionFailure': expected_failure, 'log': str(path)}
        with path.open('wb') as log:
            process = subprocess.Popen(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT)
            row['pid'] = process.pid
            status['runs'].append(row)
            save()
            print(json.dumps({'started': label, 'pid': process.pid, 'atUTC': row['startedAtUTC'], 'log': str(path)}), flush=True)
            row['exitCode'] = process.wait()
        row['endedAtUTC'] = now()
        row['logBytes'] = path.stat().st_size
        row['logSHA256'] = digest(path)
        text = path.read_text(errors='replace')
        row['summary'] = summary(text)
        if expected_failure:
            observed = [(float(a), float(b)) for a, b in re.findall(r': (-?[\d.]+(?:e[+-]?\d+)?) != (-?[\d.]+(?:e[+-]?\d+)?)', text)]
            expected = [(-4.8, -.96), (0, -.96), (-9, 0)]
            row['observedActualAndExpected'] = observed
            row['verifiedOldDisplacements'] = len(observed) == len(expected) and all(abs(a - x) < 1e-7 and abs(b - y) < 1e-7 for (a, b), (x, y) in zip(observed, expected))
            row['acceptedResult'] = row['exitCode'] == 1 and row['summary'].get('fail') == 3 and row['summary'].get('pass') == 0 and 'TypeError' not in text and row['verifiedOldDisplacements']
            row['state'] = 'EXPECTED_OLD_BEHAVIOR_FAIL' if row['acceptedResult'] else 'UNEXPECTED_BASELINE_RESULT'
        else:
            row['acceptedResult'] = row['exitCode'] == 0
            if label == 'candidate-input-time':
                row['acceptedResult'] = row['acceptedResult'] and row['summary'].get('tests') == 13 and row['summary'].get('pass') == 13 and row['summary'].get('fail') == 0
            row['state'] = 'PASS' if row['acceptedResult'] else 'FAIL_STOP'
        save()
        print(json.dumps({'finished': label, 'pid': row['pid'], 'exitCode': row['exitCode'], 'atUTC': row['endedAtUTC'], 'state': row['state'], 'summary': row['summary']}), flush=True)
        if not row['acceptedResult']:
            raise RuntimeError('Fail-stop at ' + label)
    status['state'] = 'PASS_TARGETED_AND_BUILD'
    exit_code = 0
except Exception as error:
    status['state'] = 'FAIL_STOP'
    status['error'] = str(error)
finally:
    status['beforeEnd'] = snapshot('before', before)
    status['candidateEnd'] = snapshot('candidate', candidate)
    status['runnerInputsEnd'] = {name: digest(ROOT / name) for name in inputs}
    status['sourcesStable'] = status['beforeStart'] == status['beforeEnd'] and status['candidateStart'] == status['candidateEnd']
    status['runnerInputsStable'] = input_start == status['runnerInputsEnd']
    if not status['sourcesStable'] or not status['runnerInputsStable']:
        status['state'] = 'FAIL_SOURCE_OR_RUNNER_CHANGED'
        exit_code = 1
    status['endedAtUTC'] = now()
    status['exitCode'] = exit_code
    save()
print(json.dumps({'completed': status['state'], 'exitCode': exit_code, 'atUTC': status['endedAtUTC'], 'status': str(OUT / 'run-status.json')}), flush=True)
sys.exit(exit_code)

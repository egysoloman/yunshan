#!/usr/bin/env python3
"""Package only preserved candidate originals; never execute app/test code."""
import datetime, hashlib, json, pathlib, re, zipfile, os

ROOT = pathlib.Path('/tmp/yunshan-walking-input-time-candidate-01')
NATIVE = pathlib.Path('/tmp/yunshan-coherent12-compiled-validation-ready-01')
FREEZE = pathlib.Path('/tmp/yunshan-system-coherent-12')
DELIVERY = ROOT / 'delivery'
ZIP = DELIVERY / 'yunshan-walking-input-time-candidate-originals-20261002.zip'
INDEX = DELIVERY / 'payload-index.json'
VALIDATION = DELIVERY / 'zip-validation.json'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

def main():
    DELIVERY.mkdir(exist_ok=True)
    if ZIP.exists() or INDEX.exists() or VALIDATION.exists():
        raise RuntimeError('Do not overwrite an existing original package attempt')
    review = ROOT / 'evidence/independent-review-final.md'
    if not review.is_file():
        raise RuntimeError('Final independent review original is required')
    status = json.loads((ROOT / 'evidence/run03/run-status.json').read_text())
    assert status['state'] == 'PASS_TARGETED_AND_BUILD'
    assert status['sourcesStable'] and status['runnerInputsStable']
    assert status['beforeStart'] == status['beforeEnd']
    assert status['candidateStart'] == status['candidateEnd']
    assert status['runnerInputsStart'] == status['runnerInputsEnd']
    freeze = json.loads((FREEZE / 'source-snapshot.json').read_text())
    expected_before = json.loads((ROOT / 'evidence/before-manifest.json').read_text())['hashes']
    expected_candidate = json.loads((ROOT / 'evidence/candidate-manifest.json').read_text())['hashes']
    assert len(expected_before) == 106 and len(expected_candidate) == 107
    assert freeze['copiedHashes'] == expected_before == status['beforeStart']
    assert expected_candidate == status['candidateStart']
    changed = sorted(p for p in expected_candidate if expected_candidate[p] != expected_before.get(p))
    assert changed == ['src/controller.ts', 'src/main.ts', 'tests/controller-input-time.test.ts']
    entries = []
    names = set()
    def add(source, member, kind):
        assert source.is_file() and not source.is_symlink(), str(source)
        assert member not in names, member
        names.add(member)
        data = source.read_bytes()
        entries.append({'member': member, 'originalPath': str(source), 'bytes': len(data), 'sha256': sha(data), 'kind': kind})
    for folder, expected in [('before', expected_before), ('candidate', expected_candidate)]:
        for name, digest in sorted(expected.items()):
            source = ROOT / folder / name
            assert sha(source.read_bytes()) == digest, str(source)
            add(source, folder + '/' + name, 'original_source_input')
    for path in sorted((ROOT / 'candidate/dist').rglob('*')):
        if path.is_file():
            add(path, path.relative_to(ROOT).as_posix(), 'run03_actual_build_output')
    for name in ['DESIGN.md', 'README-final.md', 'candidate.patch', 'run-targeted.py', 'package-originals.py']:
        add(ROOT / name, name, 'producer_or_design_original')
    for path in sorted((ROOT / 'evidence').rglob('*')):
        if path.is_file():
            add(path, path.relative_to(ROOT).as_posix(), 'candidate_attempt_or_validation_original')
    for name in ['native-home-rest.mjs', 'home-plan-readonly.mjs', 'source-contract.json', 'source-snapshot-original.json', 'static-rebind-comparison.json']:
        add(NATIVE / name, 'original-native12-failure/' + name, 'original_failed_native12_context')
    for path in sorted((NATIVE / 'native-home-evidence').rglob('*')):
        if path.is_file():
            add(path, 'original-native12-failure/native-home-evidence/' + path.relative_to(NATIVE / 'native-home-evidence').as_posix(), 'original_failed_native12_context')
    add(FREEZE / 'source-snapshot.json', 'original-native12-failure/freeze12-source-snapshot.json', 'original_freeze12_binding')
    for item in entries:
        parts = pathlib.PurePosixPath(item['member']).parts
        assert all(p not in ['node_modules', '.git', '.aws', '.codex', 'browser-user-data', 'userdata'] for p in parts)
        assert all(not p.startswith('.env') for p in parts)
        assert 'library_file_transfer' not in item['member'] and 'library_upload' not in item['member']
    index = {'createdAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'scope': 'BEFORE106_CANDIDATE107_33_TARGETED_TESTS_STRICT_BUILD_3_VERIFIED_OLD_NEGATIVES_NOT_GPU_NOT_MAC_NOT_NATIVE_ACCEPTANCE',
        'beforeInputCount': 106, 'candidateInputCount': 107, 'runtimeAndTestChangedPaths': changed,
        'run03State': status['state'], 'run03StatusSHA256': sha((ROOT / 'evidence/run03/run-status.json').read_bytes()),
        'run02OldNegatives': 'INVALID_NEGATIVE_UNSUPPORTED_FIXTURE_PRESERVED_NOT_ACCEPTED_AS_BUG_REPRODUCTION',
        'memberCountExcludingThisIndex': len(entries), 'bytesExcludingThisIndex': sum(x['bytes'] for x in entries), 'members': entries}
    write_json(INDEX, index)
    all_entries = entries + [{'member': 'payload-index.json', 'originalPath': str(INDEX), 'bytes': INDEX.stat().st_size, 'sha256': sha(INDEX.read_bytes()), 'kind': 'producer_index'}]
    patterns = {
        'private_key_pem': re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----'),
        'aws_access_key': re.compile(rb'(?:AKIA|ASIA)[A-Z0-9]{16}'),
        'slack_token': re.compile(rb'xox[baprs]-[A-Za-z0-9-]{20,}'),
        'github_token': re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})'),
        'api_secret_token': re.compile(rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{20,}'),
        'bearer_secret': re.compile(rb'Bearer\s+[A-Za-z0-9._~+/-]{24,}'),
        'signed_url': re.compile(rb'(?:X-Amz-Signature=|X-Goog-Signature=|[?&]Signature=[A-Za-z0-9%+/]{20,})', re.I),
        'jwt_secret': re.compile(rb'eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}'),
    }
    hits = []
    for item in all_entries:
        data = pathlib.Path(item['originalPath']).read_bytes()
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
        for label, pattern in patterns.items():
            if pattern.search(data):
                hits.append({'member': item['member'], 'pattern': label})
    if hits:
        write_json(VALIDATION, {'state': 'FAIL_SENSITIVE_PATTERN', 'matches': hits})
        raise RuntimeError('Sensitive pattern check failed; inspect local report without exposing values')
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with zipfile.ZipFile(ZIP, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for item in all_entries:
            archive.write(item['originalPath'], item['member'])
    verified = []
    with zipfile.ZipFile(ZIP, 'r') as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(all_entries)
        assert len(set(archive.namelist())) == len(all_entries)
        assert set(archive.namelist()) == {x['member'] for x in all_entries}
        for item in all_entries:
            original = pathlib.Path(item['originalPath']).read_bytes()
            archived = archive.read(item['member'])
            assert original == archived and len(archived) == item['bytes'] and sha(archived) == item['sha256']
            assert all(not pattern.search(archived) for pattern in patterns.values())
            verified.append(item['member'])
    zipped = ZIP.read_bytes()
    assert len(zipped) < 50 * 1024 * 1024
    validation = {'state': 'PASS_CRC_ALL_MEMBERS_EXACT_SENSITIVE_ZERO', 'pid': os.getpid(), 'zipStartedAtUTC': started,
        'endedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'zipPath': str(ZIP), 'zipBytes': len(zipped), 'zipSHA256': sha(zipped),
        'memberCount': len(all_entries), 'uncompressedBytes': sum(x['bytes'] for x in all_entries), 'crcFailures': 0,
        'originalByteMismatches': 0, 'sensitivePatternMatches': 0, 'sensitivePatternsChecked': list(patterns),
        'indexSHA256': sha(INDEX.read_bytes()), 'verifiedMembers': verified, 'allSourceManifestHashesVerified': True,
        'excluded': ['node_modules symlinks', 'Git data', 'environment files', 'browser user data', 'Library helpers and receipts', 'integrated freeze13 outputs'],
        'uploadAttemptsBeforePackaging': 0}
    write_json(VALIDATION, validation)
    print(json.dumps({k: v for k, v in validation.items() if k != 'verifiedMembers'}, ensure_ascii=False))

if __name__ == '__main__':
    main()

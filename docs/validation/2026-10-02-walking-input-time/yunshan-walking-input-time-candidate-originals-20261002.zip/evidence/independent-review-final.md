# 步行输入时间修复：独立最终审读

审读时间：2026-10-02 18:03:27 UTC。审读者：`/root/floor_geometry_cache/mutable_contract_review`。结论：按已批准的 STRICT reset / 最新有效移动 1 秒合同，最终候选静态未见阻塞缺陷；下列 CPU 结果来自读取已有 run03 原回执和日志，不是本审读者运行的测试。

本轮只读源码、测试、桥接器、runner 和已有运行证据，仅新建本审读文件；未运行测试、tsc、build、World/Simulation、browser、GPU 或 profile，未改源码、日志、历史回执或 ZIP。本审读不是 security scan，也不构成 GPU、macOS、原生输入或完整旅程验收。

## 最终文件的实际读取 SHA-256

以下为本审读者对当前文件直接读取所得的完整 SHA-256，根目录为 `/tmp/yunshan-walking-input-time-candidate-01/`。

| 文件 | SHA-256 |
| --- | --- |
| `candidate/src/controller.ts` | `4b87cee45e7ab1cc143173a2c011b33692c56f72d48922d4abd7e262cfda0f35` |
| `candidate/src/main.ts` | `224326cc8d0d1c71f6e7f51ae9c66a42fb305f469dcd834966555ad9f16f6f86` |
| `candidate/tests/controller-input-time.test.ts` | `0bede9235981e4f32b140b19fb5c2060083a85de754ff86514c5b3974ef8384f` |
| `candidate.patch` | `b61d21d79d20627e22dc154ec3dfb9e6e3ce4d78515676b111736cee700b4a6a` |
| `run-targeted.py` | `a89e24b15d228d13b67f86f15bb8f713953ef235f9fab6f36e7d092f02a7da0d` |
| `evidence/baseline-controller-input-time.test.mts` | `5737c3cb390ff4fff041942d054c0d548be6b19372c1627ccc2156314f568996` |
| `candidate/src/world.ts`、`before/src/world.ts`，两者逐 SHA 相同 | `2c9703f864b0f8c349e1428e4858adc2f28baa703cb5887d936f1a747d68ab4f` |
| `evidence/run03/run-status.json` | `2bbea6675fa71ef01be68f3b8bc44370eef116b87514fe63be9ccdca1fabec8b` |

## 静态合同核对

- `main.ts:182–202` 保留非负 rawDelta 和 Simulation 的 cap 1 秒 delta，仅将步行调用改为一次 `stepWalkingFrame(now, rawDelta, passenger, paused)`。车辆、航空仍读取当前全局 keys，相关历史输入精确计时未在本改动中实现。
- `controller.ts:217–255` 以毫秒读取完整窗口 `[max(now - rawSeconds * 1000, lastConsumed, resetCutoff), now]`。窗口前的已送达记录仅折叠起始状态，未来于本帧 now 的记录留队；重复或较旧帧没有额外移动预算。收集方向非零的区间，idle、仅 Shift、对向抵消不耗有效预算；从尾部选最多最新 1 秒有效移动，再按原序回放，每碰撞步不超过 1/30 秒。
- `controller.ts:258–292` 归一化 DOM 相对/epoch 时间戳，不能归一化时用接受时间，并保 dispatch 时间非递减。STRICT reset 在修改独立 walkingKeys 前拒绝 `normalized down.at < resetCutoff`；相对 timestamp=0 保持合法旧事件含义。旧 keyup 仍释放保留的 held 状态。快照和姿态基线只取 walkingKeys，stale global W 不会经 fresh Shift 或姿态同步重新导入；fresh W 不因 global stale key 已存在而被吞掉。
- blur、visibility、成功 setMode 清除两层按键和历史；成功门/楼梯/乘客同步丢弃旧预算但保留合法 walking held。失败 setMode、门或楼梯不清有效历史。passenger/非步行帧消费输入时间但不移动；暂停仍允许步行，保持旧 `_paused` 合同。
- legacy `step` 仍从全局 live keys 调用原 helper；4.8/10 速度、对角归一化、X 后 Z、1.72 眼高及原墙体/支撑/权限/净空/体素碰撞路径保留。新旧 step API 混用不共同结算时间轴；生产 main 只调用新入口。
- 最终 formal fixture 为默认场景添加真实的两条 `spawn.y` 正交道路，并在运行断言前检查 `getWalkHeight(world, spawn) == spawn.y`。它补足测试前提，没有放宽生产 `>2.6` 高差、墙体或身体守卫；actual-home 继续使用自己的原斜坡 door road。旧数值期望、`1e-7` 精度、每 fixture World JSON 前后相等检查保留。`insideId` 仅避免 TypeScript 跨方法调用保持 null 窄化，仍验证同一 `home.id`。
- 最终 formal 与 baseline `.mts` 的直接 diff 只有 4 个 before imports 和 frame bridge。bridge 使用 before controller 已有 `step(dt, passenger, paused)`，复刻原 main cap 1 秒、1/30 秒、`remaining > 1e-8` 循环，没有调用旧 controller 不存在的新 API。runner 不只数失败，还要求 3 个真实 actual/expected 位移、exit 1、3 fail/0 pass 且无 TypeError。

## 已有 run03 原回执的实际结果

本审读直接读取 `evidence/run03/run-status.json` 和对应日志；run03 为 2026-10-02 17:55:07.979965 → 17:55:35.820390 UTC，最终 `PASS_TARGETED_AND_BUILD`、exit 0，原回执报告 `sourcesStable=true`、`runnerInputsStable=true`。这些稳定性字段是原 runner 的完整输入核对结果；本审读另行直接读回上表列出的最终文件及日志 SHA。

| 顺序 / 阶段 | 实际 exit | 实际计数 / 结果 |
| --- | ---: | --- |
| strict-tsc | 0 | `--noEmit` 成功，日志 0 B |
| before12-expect-fail | 1 | 3 tests、0 pass、3 fail；实际行为负例符合预期 |
| candidate-input-time | 0 | 13 tests、13 pass、0 fail |
| original-controller | 0 | 20 tests、20 pass、0 fail |
| build | 0 | `npm run build` 成功 |

before12 的三组实际/期望位移原值分别为 `[-4.800000000000002, -0.96]`、`[0, -0.96]`、`[-8.999999999999998, 0]`。原 runner 的 `verifiedOldDisplacements=true`，匹配预期 `[-4.8, -.96]`、`[0, -.96]`、`[-9, 0]` 的 `1e-7` 容差；本审读也读取了日志中的三个 AssertionError 数值。

日志实际 SHA-256 与 run03 回执字段相同：

| 日志 | SHA-256 |
| --- | --- |
| `run03/strict-tsc.log` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `run03/before12-expect-fail.log` | `cca74abf8b3c9ad5201037edbbe293efc3faa677e69c5ae06c35cf316534a1ec` |
| `run03/candidate-input-time.log` | `7f45c6e5af4e7b180d9ad01c9692c80fd5af3da8a941a3343e594d7589ca2871` |
| `run03/original-controller.log` | `1b1d1242635ea4b530f9dfb9b9765b00a7ad47c7e33287b4b494b2c7274e9269` |
| `run03/build.log` | `aec9083ec8fe00a3103d36c8f705761fcf667e7d113d9677bf8a569aa25a22be` |

## 历史失败与 INVALID_NEGATIVE 的区别

run01 的真实 tsc 失败是 fixture 中 `c.inside` 被前面的 null 断言窄化，跨 `useDoor` 后读取 `.id` 得到 TS2339；原件保留，随后仅用读取 helper 修正类型，不改断言期望。

run02 原回执为 17:48:49.007173 → 17:48:55.696580 UTC、`FAIL_STOP`、exit 1：strict exit 0，before 3 fail/0 pass，candidate 13 tests 中仅 actual-home 1 pass、其余 12 fail，后续原 controller 和 build 未运行。默认 fixture 没有 road，却宣告 spawn.y=0；该世界原 naturalHeight 从 5 起，原高差守卫正确拒绝移动。before 第一项实际是 `0 != -0.96`，不是 `-4.8 != -0.96`；第三项实际在 fresh pulse 处 `0 != -0.48`，不是预期 stale-input 处 `-9 != 0`。

因此 run02 的 before 行虽然被当时只核失败数的旧 wrapper 原样标为 `EXPECTED_OLD_BEHAVIOR_FAIL` / accepted=true，其负例归因必须记为 **INVALID_NEGATIVE**，不能用作输入时间缺陷复现。此澄清不重写原 run02 状态或日志。`attempt04-unsupported-fixture/` 保存当时源码、测试、patch、runner；最终只补 fixture 支撑与前提，并加强旧位移核验，controller/main 的运行字节未改变。run03 才是支撑前提成立且旧位移被核实后的实际通过结果。

## 仍有的范围限制

历史区间使用回放时的当前 yaw，没有鼠标朝向历史。早于已消费帧而之后才送达的事件只改变未来状态，不回滚或补偿旧位移。有限非负的小值时间戳按相对 DOM 时钟解释，无法仅靠数值鉴别所有不兼容时钟；超出最新有效 1 秒预算的早段被明确丢弃。

13 项新测试为受控 EventTarget occurrence/acceptance 时钟和真实生产碰撞路径，actual-home 项是该住宅几何的 CPU fixture；它们不等于真实浏览器 W/E、原生 200ms 输入、完整住宅床边旅程、IndexedDB、GPU、Mac 或性能验收。本轮未做 ZIP/CRC 独立核对，待包完成另行进行。

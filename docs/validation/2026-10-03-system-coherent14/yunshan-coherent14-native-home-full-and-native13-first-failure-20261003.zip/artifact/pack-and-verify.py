from pathlib import Path
import json, hashlib, zipfile, datetime, re, time, os

ROOT = Path('/tmp/yunshan-coherent14-native-artifact-01')
ZIP = ROOT / 'yunshan-coherent14-native-home-full-and-native13-first-failure-20261003.zip'
if ZIP.exists():
    raise SystemExit('Refuse to overwrite an existing artifact ZIP')
STARTED = datetime.datetime.now(datetime.timezone.utc).isoformat()
BEGIN = time.monotonic()
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def read_json(path):
    return json.loads(Path(path).read_text())

freeze = Path('/tmp/yunshan-system-coherent-14')
manifest_path = freeze / 'source-snapshot.json'
manifest = read_json(manifest_path)
receipt_path = freeze / 'build-receipt.json'
receipt = read_json(receipt_path)
assert sha(manifest_path.read_bytes()) == '384868f893b09f2d58bef12599c818d1ae0265dae5064b8078749dfd991c17bb'
assert sha(receipt_path.read_bytes()) == '7125b5046ff201c57afb174ebd209594e5a262320a344afdde28c8b08456e917'
assert manifest['inputCount'] == len(manifest['copiedHashes']) == 108
assert manifest['sharedExecutableInputCount'] == 103
assert receipt['exitCode'] == 0 and receipt['sourceStable'] and receipt['sharedExecutableStable']
related = read_json(freeze / 'root-related-result-verification.json')
assert related['actualRelatedSummary']['tests'] == related['actualRelatedSummary']['pass'] == 43
assert related['actualRelatedSummary']['fail'] == 0
assert sha((freeze / 'related-controller-retail.log').read_bytes()) == related['rawSHA256']
native_root = Path('/tmp/yunshan-coherent14-native-frame-barrier-01')
native_result = read_json(native_root / 'native-home-evidence/native-home-results.json')
assert native_result['exitCode'] == 0 and len(native_result['results']) == 7 and not native_result['errors']
assert native_result['setupCount'] == 1
for key in ['sourceStable', 'sharedExecutableStable', 'externalStable', 'entryStable', 'sourceMapsStable']:
    assert native_result[key] is True
old_summary = read_json('/tmp/yunshan-native13-static-diagnosis-20261003/native13-static-summary.json')
old_root = Path('/tmp/yunshan-coherent13-compiled-validation-ready-01')
old_result = read_json(old_root / 'native-home-evidence/native-home-results.json')
assert old_result['exitCode'] == 1 and len(old_result['results']) == 1 and old_result['setupCount'] == 1
for name, info in old_summary['rawEvidenceHashes'].items():
    raw = (old_root / 'native-home-evidence' / name).read_bytes()
    assert sha(raw) == info['sha256'] and len(raw) == info['bytes']

payload = {}
def add(path, member, category):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), path
    assert member not in payload and not member.startswith('/') and '..' not in Path(member).parts
    raw = path.read_bytes()
    payload[member] = {'sourcePath': str(path), 'category': category,
                       'bytes': len(raw), 'sha256': sha(raw), 'raw': raw}
def tree(root, prefix, category):
    root = Path(root)
    for path in sorted(root.rglob('*')):
        if path.is_file() and not path.is_symlink():
            add(path, prefix + '/' + path.relative_to(root).as_posix(), category)

source = Path(manifest['sourceRoot'])
for name, expected in sorted(manifest['copiedHashes'].items()):
    path = source / name
    assert sha(path.read_bytes()) == expected
    add(path, 'actual14/frozen-source/' + name, 'actual14-frozen-input-original')
tree(source / 'dist', 'actual14/actual-dist', 'actual14-built-dist-original')
for path in sorted(freeze.iterdir()):
    if path.is_file() and not path.is_symlink():
        add(path, 'actual14/root-build-related/' + path.name, 'actual14-root-build43-original')
tree(native_root, 'actual14/native-bound-run', 'actual14-native-original')
tree(old_root, 'before13/original-bound-run', 'native13-before-original-not14-validation')
tree('/tmp/yunshan-native13-static-diagnosis-20261003', 'before13/static-diagnosis', 'native13-readonly-diagnosis-original')
tree('/tmp/yunshan-controller-static-review-20261003', 'before13/independent-controller-review', 'native13-independent-readonly-original')
tree('/tmp/yunshan-coherent13-native-frame-barrier-01', 'preparations/approved13-not-run', 'approved13-preparation-original-not-run')
tree('/tmp/yunshan-coherent14-native-frame-barrier-template-01', 'preparations/unbound14-not-run', 'unbound14-preparation-original-not-run')

README = '''# 云山 actual14 完整原生住宅证据 + 原13首次失败

actual14 composite:108冻结输入/103shared executable，root实际build exit0，相关controller/retail43/43。原Node spec log Unicode总结符导致runner summary={}的历史事实原样保，root-independent verification另核43/43。不把相关43冒full14 npm。

actual14完整原生住宅：2026-10-03 01:15:03.614868→01:25:05.149424 UTC，wall601.534799s，7/7 PASS、errors[]、raw Node exit0、setupCount1。包含原生W/E/租住80文/桌边rest禁用/床侧W/离场自然暂停/返回显式继续/实际IndexedDB generation7及121引用与完整字节恢复/真实1x20分钟完成/第二partial3分钟native取消。79W/79movement/zero0，外部消费屏障只读等待产品帧，不改72业务/runtimeassert、精度、碰撞、钱/needs/clock或原超时。

actual14 native原件均包含：所有七张PNG、真实完整IDB records/checkpoint/reference证据、movement/input timing、source/entry/maps稳定及PID/startticks/profile/port初尾和正常退出。owned非Z0/profile gone/4189 free；不包含新的formal11/GPU运行。

before13仍为唯一原生住宅1PASS/exit1 service waypoint失败，17raw完整保；其后租住/rest/nativeUI-IDB NOT_RUN。首次4.8m对应多个真实约200ms脉冲累计1594ms后cap1s，不能称单200ms放大。原PNG/save晚于断言，已解释采样时点。完整原bound13模板、诊断、独立yaw静态审查、approved13 NOT_RUN和UNBOUND14 NOT_RUN模板及actual14绑定差异都在包中；旧13/12 scope不冒14验证。

源码yaw历史仍仅keys/current yaw，真实turn未采，未冒全输入历史修复。ART/Mac/FPS、普通spawn全旅程、自然NPC床例与完整城市目标不属于该native通过范围。准备文档中的NOT_RUN是当时状态，actual14最终结论以native-home-results.json/raw-exit.json为准。

artifact/inputs-index.json记录每一输入的绝对原路径、archive member、bytes、SHA256；ZIP内容逐原字节核、CRC全过、七类敏感模式零命中。producer validation receipt及Library回执是外部后续记录，不改此一次性ZIP。node_modules/凭据/浏览器profile均未打包。
'''
(ROOT / 'README.md').write_text(README)
add(ROOT / 'README.md', 'artifact/README.md', 'new-artifact-scope-report')
add(Path(__file__), 'artifact/pack-and-verify.py', 'new-artifact-producer-script')

# Seven actual-secret patterns, applied to every payload byte including binary.
patterns = {
    'private-key-material': rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
    'aws-access-key-id': rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b',
    'openai-api-secret': rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}',
    'github-access-secret': rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,})',
    'slack-access-secret': rb'\bxox[baprs]-[A-Za-z0-9-]{16,}',
    'google-oauth-secret': rb'\b(?:ya29\.[A-Za-z0-9_-]{20,}|GOCSPX-[A-Za-z0-9_-]{20,})',
    'signed-or-credential-url': rb'https?://[^\s\"\x27<>]{0,2048}[?&](?:X-Amz-(?:Signature|Credential|Security-Token)|X-Goog-(?:Signature|Credential)|(?:access_token|refresh_token|api_key|token|sig|signature))=[A-Za-z0-9%+/_-]{8,}',
}
scan = {name: [] for name in patterns}
for member, info in payload.items():
    for name, pattern in patterns.items():
        if re.search(pattern, info['raw'], re.I if name == 'signed-or-credential-url' else 0):
            scan[name].append(member)
assert all(not matches for matches in scan.values()), scan

entries = [{k: v for k, v in info.items() if k != 'raw'} | {'member': member}
           for member, info in sorted(payload.items())]
index = {'version': 1, 'createdAtUTC': STARTED, 'payloadCount': len(entries),
         'frozenSource108': 108, 'actualDistFiles': sum(x['category'] == 'actual14-built-dist-original' for x in entries),
         'original13RawCount': 17, 'entries': entries,
         'indexSelf': 'This index is the sole generated archive member not listed in entries; its SHA is recorded by the external producer receipt.'}
index_raw = (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode()
for name, pattern in patterns.items():
    assert not re.search(pattern, index_raw, re.I if name == 'signed-or-credential-url' else 0)
with zipfile.ZipFile(ZIP, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for member, info in sorted(payload.items()):
        archive.writestr(member, info['raw'])
    archive.writestr('artifact/inputs-index.json', index_raw)

with zipfile.ZipFile(ZIP) as archive:
    bad_crc = archive.testzip()
    assert bad_crc is None
    assert len(archive.infolist()) == len(payload) + 1
    assert len(set(archive.namelist())) == len(archive.namelist())
    for member, info in payload.items():
        actual = archive.read(member)
        assert len(actual) == info['bytes'] and sha(actual) == info['sha256']
        assert actual == Path(info['sourcePath']).read_bytes()
    assert archive.read('artifact/inputs-index.json') == index_raw
assert ZIP.stat().st_size < 50 * 1024 * 1024
zip_sha = sha(ZIP.read_bytes())
validation = {'startedAtUTC': STARTED, 'endedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'producerPID': os.getpid(), 'wallSeconds': time.monotonic() - BEGIN,
              'status': 'ZIP_PRODUCED_CRC_ALL_INPUT_BYTES_MATCH_SENSITIVE7_ZERO',
              'ZIP': str(ZIP), 'bytes': ZIP.stat().st_size, 'sha256': zip_sha,
              'memberCount': len(payload) + 1, 'indexedInputCount': len(payload),
              'CRC': 'ALL_PASS', 'eachIndexedMemberMatchesOriginalCurrentBytes': True,
              'sourcePayloadCount': 108, 'sourceManifestSHA256': sha(manifest_path.read_bytes()),
              'entrySHA256': receipt['entrySHA256'], 'original13RawCount': 17,
              'sensitivePatternCount': len(patterns), 'sensitiveMatches': scan,
              'indexSHA256': sha(index_raw), 'indexBytes': len(index_raw),
              'scope': 'Packaging and validation only. No formal11, browser, GPU, Simulation, tests or build was launched.',
              'Library': 'NOT_SAVED_YET_SINGLE_CREATE_NEXT'}
(ROOT / 'inputs-index.json').write_bytes(index_raw)
(ROOT / 'producer-validation-receipt.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(validation, ensure_ascii=False, indent=2))

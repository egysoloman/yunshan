# 云山 actual14 完整原生住宅证据 + 原13首次失败

actual14 composite:108冻结输入/103shared executable，root实际build exit0，相关controller/retail43/43。原Node spec log Unicode总结符导致runner summary={}的历史事实原样保，root-independent verification另核43/43。不把相关43冒full14 npm。

actual14完整原生住宅：2026-10-03 01:15:03.614868→01:25:05.149424 UTC，wall601.534799s，7/7 PASS、errors[]、raw Node exit0、setupCount1。包含原生W/E/租住80文/桌边rest禁用/床侧W/离场自然暂停/返回显式继续/实际IndexedDB generation7及121引用与完整字节恢复/真实1x20分钟完成/第二partial3分钟native取消。79W/79movement/zero0，外部消费屏障只读等待产品帧，不改72业务/runtimeassert、精度、碰撞、钱/needs/clock或原超时。

actual14 native原件均包含：所有七张PNG、真实完整IDB records/checkpoint/reference证据、movement/input timing、source/entry/maps稳定及PID/startticks/profile/port初尾和正常退出。owned非Z0/profile gone/4189 free；不包含新的formal11/GPU运行。

before13仍为唯一原生住宅1PASS/exit1 service waypoint失败，17raw完整保；其后租住/rest/nativeUI-IDB NOT_RUN。首次4.8m对应多个真实约200ms脉冲累计1594ms后cap1s，不能称单200ms放大。原PNG/save晚于断言，已解释采样时点。完整原bound13模板、诊断、独立yaw静态审查、approved13 NOT_RUN和UNBOUND14 NOT_RUN模板及actual14绑定差异都在包中；旧13/12 scope不冒14验证。

源码yaw历史仍仅keys/current yaw，真实turn未采，未冒全输入历史修复。ART/Mac/FPS、普通spawn全旅程、自然NPC床例与完整城市目标不属于该native通过范围。准备文档中的NOT_RUN是当时状态，actual14最终结论以native-home-results.json/raw-exit.json为准。

artifact/inputs-index.json记录每一输入的绝对原路径、archive member、bytes、SHA256；ZIP内容逐原字节核、CRC全过、七类敏感模式零命中。producer validation receipt及Library回执是外部后续记录，不改此一次性ZIP。node_modules/凭据/浏览器profile均未打包。

# native13 frame-consumption-barrier preparation

State: PREPARED_NOT_RUN_WAITING_ROOT_SEPARATE_GPU_GO.

Root reviewed and approved the minimal external harness patch. The copied harness waits for each actual W release to be consumed by the product frame before the next heading calculation. No product source change is included. All original assertion-containing lines are byte-identical; thresholds,100 attempts,20 no-progress pulses and300s route budget remain unchanged.

The only changed contract field is nativeEvidenceRoot, pointing to this fresh directory's native-home-evidence. No evidence directory or run-start has yet been created. Frozen source107/shared executable102, actual13 manifest, entry and maps remain the same. Actual manifest/build receipt are copied byte-for-byte. External hashes and all static checks are in preparation-readiness.json.

No node-check, browser, GPU, Simulation, test, build or ZIP was run. Original13 and12 files were not edited. Wait for root's separate GPU GO; final artifact ZIP requires a later separate artifact GO.

# Native14 frame-consumption-barrier template

UNBOUND14_NOT_RUN. This is an external harness template, not a freeze14 source or built artifact. Root must provide the actual14 immutable manifest, copied input counts, entry/maps and build receipt before binding. No values are guessed. The existing state guard refuses the unbound contract before sourceRoot is used.

The two expected-count assertions contain explicit ROOT_ACTUAL14 identifiers that must be replaced from root's actual receipt. The only other script change from approved13 is the freeze14 error message. The approved consumption barrier and all business/runtime assertion lines are verbatim preserved. Planner bytes are unchanged.

No13 or14 run, node-check, GPU, Simulation, test, build or ZIP was performed. The original13 first failure remains before evidence unchanged. Wait for separate root exclusiveGPU GO; any final evidence ZIP requires later artifact GO.

# 冻结13静态复核：步行朝向历史与外部消费屏障

复核范围：`/tmp/yunshan-system-coherent-13/source` 的 controller/main、指定测试；少量读取 `/tmp/yunshan-coherent13-compiled-validation-ready-01/native-home-evidence` 原始 JSON。已读取 `/workspace/yunshan/AGENTS.md`、`提示词.md`、`开发备忘录.md` 的18:08入口。本报告只读复核；没有运行浏览器、GPU、Simulation、测试、构建或 ZIP，没有编辑共享文件。以下候选均未实施、未运行、未验证。

## 1. 已确认源码关系

- `src/controller.ts:24,279`：历史节点只包含 `{ at, keys }`；没有 yaw。`walkingFrameKeys` 也只有 keys。
- `src/controller.ts:217–255`：按时间拆出并选取最多最新1秒有效移动区间，随后按最多1/30秒调用旧碰撞推进。
- `src/controller.ts:295–306`：每个旧区间的 dx/dz 均读取回放时的 `this.yaw`。没有给历史区间传方向参数。
- `src/controller.ts:70–80`：原生鼠标接受后即时修改 yaw，没有生成步行时间线节点。
- 外部 `native-home-rest.mjs:105–109`：`orient()` 在 `page.evaluate` 中直接写 `controller.yaw`，再调用只改 pitch 的 `resetView()`。没有先等旧W历史消费。
- 外部 `native-home-rest.mjs:137–163`：每次W结束后只等待 host 100ms，读取脚点后即可开始下一脉冲与下一次 orient；这个等待不能证明产品 RAF 已消费上一脉冲。
- `src/main.ts:180–202`：walking 使用真实 rawDelta 与 rAF supplied timestamp，Simulation 仍使用 cap1秒 delta。二者时钟合同不能互相替换。`controller.ts:229–230` 特意保留晚于当前 rAF timestamp 的已接受事件供后帧使用。

因此，旧W区间在消费前发生转向时，当前实现会把旧移动方向重写为新 yaw。源码能证明这种语义；18:08备忘录明确说“鼠标历史尚未扩展”，所以应报告为尚未覆盖的方向历史能力，而非声称已承诺的鼠标修复退化。

## 2. 原始样本说明的是累计脉冲

`native-input-event-timing.json`：rAF样本16为 raw129809.6ms；样本17为 raw134392.7ms、观察时134469.9ms，gap4583.1ms。两者之间发生以下真实W时段：

| 脉冲序号 | keydown发生ms | keyup发生ms | DOM held ms |
| --- | ---: | ---: | ---: |
| 0 | 131609.2 | 131814.2 | 205.0 |
| 1 | 131962.1 | 132162.3 | 200.2 |
| 2 | 132285.4 | 132487.3 | 201.9 |
| 3 | 132722.0 | 132921.9 | 199.9 |
| 4 | 133044.7 | 133246.0 | 201.3 |
| 5 | 133541.0 | 133741.7 | 200.7 |
| 6 | 133883.4 | 134083.5 | 200.1 |
| 7 | 134207.8 | 134408.2 | 200.4 |

前7段已合计1409.1ms，第8段在 raw134392.7ms 帧端之前另有184.9ms；当前代码合法选择其中最新1秒有效时间，即平地正常步速4.8米。第8keyup的 raw134408.2ms 晚于该 rAF，实际接受134469.6ms，源码会把这个尾段留到下一帧。`native-movement.json[7]` 的脚点 z336.6→331.8，水平4.8米，与这个累计预算相容；它不能单独证明“一个200ms pulse又被扩成1秒”。

`native-movement.json[6]` 与前面多条记录为零位移，是外部脉冲结束时尚无消费帧；记录[7]含之前数次脉冲的位移。后续重复读旧脚点、重复发W并调整yaw，存在过冲反馈和积压输入混用的条件。

证据边界：现观察器只记录键盘事件时点、keys及 rAF，没有 yaw、鼠标转向发生/接受时间、walking history 的消费节点。所以不能仅凭这些 JSON 宣称某个实际失败帧已实测发生 yaw 重写，也不能排除碰撞或外部 before/orient 采样间的异步变化。真实住宅结果仍为 exit1、门前W/E一项PASS、service-table最后路径FAIL；后续租住/床边/rest/完整IDB合同没有通过。

## 3. 最小优先候选：先使原生住宅程序串行消费

先限定为外部程序候选，不修改生产行为：

1. nativeWPulse 完成后，读取本次真实DOM keyup发生及产品handler接受记录，得到与 controller 同域的 cutoff；建议采用keyup后产品handler接受时点作为较严格cutoff，并记录脉冲编号与两种时点。
2. 在下一次 orient、方向/时长计算、after归属之前，只读等待产品 `walkingFrameEnd >= cutoff`，并确认本次W历史已消费。`walkingFrameEnd` 是目前普通 TS private 字段，debug观察可以读取；不调用 step 或改输入队列。不要把观测者自己的 rAF经过、tick变化、host100ms或keys=false当消费证明。
3. 消费完成后再记录该脉冲 after；下一脉冲重新取当前脚点、计算 yaw和时长。避免外层before与orient内部第二次body跨消费帧而不一致。
4. 不改原100次/300秒限制、.18水平阈值、1e−7实际x/z共享支撑、.35身体、1.72眼高、速度、碰撞、权限、Simulation 时钟或禁止位置写入的合同。记录失败仍保留原件。

这使住宅反馈每次针对已消费的真实输入；它不完成生产鼠标方向历史。这里也不是要增加每步固定等待秒数：应等待实际消费状态，现慢帧样本3–6秒，而固定100ms无法保证。

## 4. 若要扩展生产方向历史，候选应完整保存联合状态

仅给每个键盘快照补 yaw 还不足：持W期间鼠标转向若没有键盘transition，旧yaw会贯穿整段。最小完整方向合同可限定在步行：

- 联合节点/帧基线采用 `{ at, keys, yaw }`。按键和有效鼠标转向都写入同一排序时间线，复用 Event.timeStamp 的规范化、乱序clamp、已消费帧不回滚规则。
- 原生鼠标变化使用 MouseEvent.timeStamp；显式程序视图变更经小型 `setViewYaw()` 方法按实际接受performance.now记录。外部住宅程序改用此方法，避免继续直接写公开yaw绕过历史。若保留公开yaw赋值接口，则须定义如何拦截并记录它，不能只修改鼠标listener。
- 历史interval携带yaw，`stepWithKeys(seconds, passenger, keys, yaw = this.yaw)` 对位移使用参数，旧 `step()` 仍读取当前yaw。不临时回写可见camera/current yaw来推进历史。
- clear/mode/门/楼梯/载客的现有reset/discard仍截断旧时段，并把最终合法姿态yaw作为新基线。门当前是discard后才改yaw；加入yaw基线后必须同一reset路径校正这个顺序或基线，保held规则。
- 保最新有效1秒选择与原顺序、≤1/30碰撞步、速度/半径/眼高/权限/paused walking、Simulation delta；不把车辆/航空历史扩展混进该候选。

main不需要为了此问题改成每事件驱动Simulation，也不需要把 rAF timestamp 替换为性能观察时间。这样改时钟会牵动当前已设计的“已接受事件可能晚于rAF端点”合同。

## 5. 有意义的未来回归判据（未运行）

现 `tests/controller-input-time.test.ts:82`验证键盘区间顺序但yaw恒定；旧 `tests/controller.test.ts:139`只设固定yaw后调用旧step。没有积压期间鼠标转向用例。

平地合法支撑、起点(0,0)、普通速度4.8，右转90°按当前符号为yaw=−π/2：

1. W在100–300ms完成，500ms右转，1000ms一次消费：应脚点x0/z−.96，最终视图右转。检出事后朝向重写旧短按。
2. W连续100–500ms，300ms右转：应x.96/z−.96；单慢帧与相同事件序列分帧消费相同。检出只补键盘yaw、漏持键中转向。
3. 朝前800ms，空闲时右转，再向右400ms，一次慢帧：最新有效1秒保前段600ms及后段400ms，应x1.92/z−2.88。检出active预算裁剪丢朝向或顺序。
4. 无转向的多个完成W脉冲在一慢帧累计：预算应是各实际有效时段合计并cap1秒；不能拿某一外部pulse的duration当整个帧预算。一个200ms完成短按加长idle仍只能.96米。
5. reset后的旧key/mouse节点不补走；门/楼梯/载客不把旧yaw移到新姿态；继续held合法基线按原规则推进。旧step/current yaw接口、碰撞与权限负例保留。

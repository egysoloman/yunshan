# native13 原生住宅失败只读诊断

状态：STATIC_DIAGNOSIS_COMPLETE；harness候选 STATIC_CANDIDATE_NOT_RUN。此诊断不运行 browser/GPU/Simulation/test/build/ZIP，不改共享源码或原13/原12证据。工作分支实际为 takeover-city-life。

原run回执 2026-10-02 18:12:18.256→18:16:56.478 UTC，wall278.222s（回执范围，不宣称OS完整进程wall）；原actual Node PID170877，Vite170888，Chrome170907，profile `/tmp/playwright_chromiumdev_profile-sBTWYx`，端口4189。诊断开始核所有原owned PID：170877/170888/170907及其余浏览器子进程ABSENT，170896/170924/170925仅Z；profile不存在、4189无listener、当前无相关非Z。本agent没有任何persistent进程且未发送signal。原browser.close resolved/serverExit143保。

## 结论和证据范围

原13 exit1不可改写。仅 native W approach + native E doorway 的一个结果PASS，setupCount1。室内第一个非平凡waypoint实际到(-397.17932756347346,76.6,318.6909604861446)，水平误差0.0932800068m，支撑检查PASS。service最后目标(-398.8,76.6,307.2)在100次后实际(-400.82029968097766,76.6,305.8758570784435)、tick200、水平误差2.4155672786m；最后一段最小记录误差0.4267726734m仍>.18。租住、桌边rest禁用、床边真实路线、20分钟/暂停续演及nativeUI-IDB全NOT_RUN。

关键已证是harness反馈时序：每pulse请求完成+host100ms后读取body并立即重算方向；这不能证明任何产品RAF已消费pulse。227对原生W中198条movement零、29条非零；连续同body/tick时累计多个真实pulse。首移动帧rawRAF134392.7、observer tick60，前面已有7个完整约200msW加第8按下的184.9ms，共1594.0ms真实有效W。实际一次水平4.8m与现有latest-active cap1s一致，不证明单200ms仍被扩为1s。接近目标仍有同帧9个约49ms短pulse共449.9ms，使一次水平2.15952m越过0.42677m余距。详见227条pulse和55帧关联JSON。

真实时长必须分开：DOM Event.timeStamp held min48.6ms、median200.4ms、p95 209.1ms、max234.3ms，总37.9886s；host请求held median200.201485ms/max231.814265ms，仅是host。handler处理down→up median200.1ms、p95 771.6ms、max5557.6ms；最大capture dispatch lag5339.9ms。当前生产按Event.timeStamp计算，没有把晚处理5.56s当真实持键时间。55个observer RAF含54gap，median3616.5ms、max35431.9ms包含启动；observer在main产品callback之前注册，其tick为产品帧前值，不能拿该observer帧单独当消费确认。所有keyboard458事件isTrusted，keyboard/frames dropped均0。该诊断observer增加callback开销，不属于纯产品wall/FPS/Mac性能证明。

源码独立存在yaw历史缺口：冻结controller:24/279只记录{at,keys}，217–255回放旧keys却在295–306读取当前this.yaw；鼠标78行更新yaw且不创建历史节点，harness108行直接yaw/resetView。旧key时段若转向后才消费，可被新yaw解释。当前observer没有记录yaw或turn发生/处理时点，派生heading不能叫实测yaw，不能将某次方向重写确认为本次独立根因。本轮应先收口harness屏障；生产若进一步扩yaw，需共同keys+yaw时间线与持W中的鼠标turn节点，简单给keydown快照加yaw仍漏同一held内转向。

原静态planner最后目标有共享floorPlanRoute规划，不是实际穿行证明；native E和第一室内段证实入口/部分路由可走。最后段未触发20次noProgress或实际支撑/高度断言，现证据无法确认几何无解，也不能完全排除末端局部碰撞。先去掉输入积压，若屏障候选仍失败再看具体碰撞位置。actualx/z heightoracle三个查询都PASS，不借旧12 fixedtargety错误解释本次失败。

失败截图和save不是断言瞬间：screenshot before tick200、after tick212；其间尚未消费的W自然将脚点移至(-397.5966084350112,76.6,308.5070758731584)，水平误差1.7766819065m、钱包600/homeId null/rest history空。原FAIL-save也是tick212。实际view截图显示“已进入”住宅且租住可用，与后时点吻合，不代表原fail坐标或完整成功。所有原图/原save原字节保。

## 最小静态候选

`native13-frame-barrier-only.patch`和全harness候选文件仅修改外部harness：每nativeWPulse前读取observer cursor；真实down/up请求仍同时安排（keyup不awaitdown），完成后保原hostwait100，再只读等待该对真实keyup的post-product-handler记录，且产品controller.walkingFrameEnd至少到达其处理时间、实时keys已释放W、该消费帧以前的input已耗尽。屏障用keyup处理时间而非仅rawEventTimeStamp是较强的实际产品帧确认，避免observer rAF在产品callback前的假确认。之后才读after并计算下一次yaw；不驱动帧、不写位置/时钟/Simulation、不丢弃输入。

屏障timeout只取当前route原started+300000ms剩余预算；原35..200ms请求、wait100、100次/waypoint、20次noProgress、.18水平、1e-7 actualx/z支撑、.35身体、1.72眼高、4.8速度/碰撞、20分钟rest、全部原UI/IDB/source/maps断言均保。候选本轮无node-check/测试/build/GPU；它读取TS private编译后的运行属性，仅绑定当前明确frozen13，未来运行应放新证据目录重新记录externalSHA，不覆盖原目录。root审查并在食品CPU释放后另外给予唯一GPU GO。

## 待实际运行的意义回归判据

1. 逐pulse记录真实down/up、handler时点、consumedThrough和settled body；第n+1次orient/down的发生不得早于第n次release消费确认。故意slow-RAF且相同脚点的原harness是负例；屏障candidate应始终只允许一对尚未结清的W，不增加尝试数/总时限。
2. 平路单独真实200ms完整pulse在slow frame后约.96m（以actualDOMduration×4.8为准，允许真实事件时间变化）；同帧完成的down/up不丢。晚处理但raw held约200ms不得按5.56s处理间隔计步。重复body读取不得触发回放。此处只是设计，不冒已运行PASS。
3. 原market-b24 exterior→E→service三个waypoint均要维持原.18/1e-7/.35/1.72及same source/entry/map guards。在原100次和300s内收口；即使fail也保原pulse/receipt/actual支持和截图前后时点，不通过放宽精度/位置写/更多staging来过关。
4. 若第3项实际完成才继续原native租住、table-rest禁用、床边W、20分钟rest/暂停/cancel和完整IndexedDB generation/refs/checksum/assembled/live fullbytes。当前这些一律NOT_RUN。
5. yaw作为单独生产后续范围：合法平路持W，100ms yaw0再100ms yaw−π/2且帧末W释放，期望约z−.48+x+.48，而非新yaw下x+.96；要有真实native mouse时间/yaw观察。不能把此后续设计冒已实现或本harness候选解决。

## 完整性

`native13-static-summary.json`包含17原文件bytes/SHA、所有原PASS/FAIL/stability事实；`pulse-movement-correlation.json`含227条关联；`raf-pulse-budget-correlation.json`含55帧只读算术关联，明确非Simulation执行/精确reset回放。原冻结107文件本轮逐SHA对snapshot均同，snapshot SHA591d40bfb15d8826f882dd42eb56b855d88ff28e349612f72bc22d61fff3c6aa，entry b9e8d05be43b2df30ef4cd863051b40baf915444dfc771fcb1ff69626588aa33。原run source107/shared102/entry/maps/external首尾stable均true。没有改共享/原13/原12，没有新GPU/Sim执行，没有对原失败做任何回写。

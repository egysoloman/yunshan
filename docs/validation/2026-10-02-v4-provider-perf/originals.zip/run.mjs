import assert from 'node:assert/strict';
import { writeFileSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createHash } from 'node:crypto';
import { performance } from 'node:perf_hooks';
import { Session } from 'node:inspector';

const label=process.argv[2],root=resolve(process.argv[3]),out=resolve(process.argv[4]);
mkdirSync(out,{recursive:true});
const load=path=>import(pathToFileURL(resolve(root,path)).href);
const api=await load('src/architecture-floor-plan.ts');
const {createWorld}=await load('src/world.ts');
const {Simulation}=await load('src/simulation.ts');
const {savedWorldFingerprint}=await load('src/persistence/world-layout.ts');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const write=(name,value)=>{const text=typeof value==='string'?value:JSON.stringify(value,null,2)+'\n';writeFileSync(resolve(out,name),text);return sha(text);};
const begin=performance.now(),world=createWorld(20261001,'current-v4');
const result={label,worldMs:performance.now()-begin,worldSHA:write('world.json',JSON.stringify(world)),fingerprint:savedWorldFingerprint(world)};
const marked=world.buildings.filter(b=>api.getBuildingBody(b));
result.marked=marked.length;
result.bodyRoofSHA=write('body-roof.json',JSON.stringify(marked.map(b=>({id:b.id,body:api.getBuildingBody(b),roof:api.getFloorPlanRoofRegions(api.getBuildingBody(b))}))));
const families=['home','market','workshop','civic-academy','finance-health','transport-waterfront'];
const fixtures=families.map(family=>marked.find(b=>api.getBuildingBody(b).family===family));
assert(fixtures.every(Boolean));
const geometry=[];
for(const b of fixtures){
 const body=api.getBuildingBody(b),floorChecks=[];
 for(const p of body.floorPlans){
  const points=[...api.getBuildingUsePoints(b,p.floor).map(v=>v.position),api.getFloorPlanStairPosition(b,p.floor)];
  for(const r of [...p.interior,...p.circulation,...p.courtyard,...p.fixtures.map(f=>f.rect)])
   points.push(api.buildingWorldPosition(b,{x:(r.x0+r.x1)/2,y:p.y,z:(r.z0+r.z1)/2}));
  const checks=points.map(point=>({point,support0:api.floorPlanSupport(b,p.floor,point,0),supportBody:api.floorPlanSupport(b,p.floor,point,.35),blocked:api.blocksFloorPlanMovement(b,p.floor,point,{...point,x:point.x+.7},.35),stand:api.canStandInFloorPlan(p,api.buildingLocalPosition(b,point).x,api.buildingLocalPosition(b,point).z,.35)}));
  const target=api.getBuildingUsePoints(b,p.floor)[0].position;
  floorChecks.push({floor:p.floor,checks,route:api.findBuildingFloorPlanRoute(b,0,p.floor,api.getBuildingEntrance(b),target,.35)});
 }
 geometry.push({id:b.id,family:body.family,floorChecks});
}
result.geometrySHA=write('six-family-geometry.json',geometry);

const source=fixtures.find(b=>b.floors>1),mutation=[];
const changes={width:b=>b.width+=.2,depth:b=>b.depth+=.2,height:b=>b.height+=.2,floors:b=>b.floors+=1,basements:b=>b.basements=(b.basements??0)+1,rotation:b=>b.rotation+=.1,x:b=>b.position.x+=.2,y:b=>b.position.y+=.2,z:b=>b.position.z+=.2,kind:b=>b.kind=b.kind==='market'?'bank':'market',publicFloors:b=>b.publicFloors=(b.publicFloors??0)+1,requiredPermission:b=>b.requiredPermission=b.requiredPermission==='merchant'?'teacher':'merchant',facility:b=>b.facility=b.facility==='mayor'?'energy':'mayor',footprints:b=>b.floorFootprints=structuredClone(b.floorFootprints??[]),uses:b=>b.floorUses=structuredClone(b.floorUses??[]),permissions:b=>b.floorPermissions=structuredClone(b.floorPermissions??[])};
for(const [key,change]of Object.entries(changes)){
 const b=structuredClone(source),before=api.getBuildingBody(b);change(b);const after=api.getBuildingBody(b);
 assert.notEqual(before,after,`${key} must invalidate cached body`);mutation.push({key,body:after});
}
for(const guard of ['marker','core','pavilion']){const b=structuredClone(source);api.getBuildingBody(b);if(guard==='marker')delete b.floorPlanProfile;else if(guard==='core')b.id='core-main';else b.kind='pavilion';assert.equal(api.getBuildingBody(b),null);mutation.push({guard});}
const normalized=structuredClone(source);normalized.basements=0;const normalizedBody=api.getBuildingBody(normalized);delete normalized.basements;assert.equal(api.getBuildingBody(normalized),normalizedBody);
const mutable=structuredClone(source),p=api.getBuildingFloorPlan(mutable,0),point=api.getBuildingUsePoints(mutable,0)[0].position,local=api.buildingLocalPosition(mutable,point);
// Publicly returned arrays are still mutable. No candidate cache can hide a
// newly added fixture, a changed stair surface, or a changed returned panel.
const reads=()=>({support0:api.floorPlanSupport(mutable,0,point,0),support35:api.floorPlanSupport(mutable,0,point,.35),blocked:api.blocksFloorPlanMovement(mutable,0,point,{...point,x:point.x+.1})});
mutation.push({mutable:'initial',reads:reads()});
p.fixtures.push({id:'mutation-fixture',kind:'table',rect:{x0:local.x-.5,x1:local.x+.5,z0:local.z-.5,z1:local.z+.5},bottom:0,top:1});
mutation.push({mutable:'fixture-push',reads:reads()});p.fixtures.at(-1).top=.1;mutation.push({mutable:'fixture-top',reads:reads()});
p.fixtures=p.fixtures.filter(f=>f.id!=='mutation-fixture');mutation.push({mutable:'fixture-array-replacement',reads:reads()});
p.stairTreads.push({id:'mutation-tread',rect:{x0:local.x-.5,x1:local.x+.5,z0:local.z-.5,z1:local.z+.5},bottom:-.2,top:0,fromFloor:0,toFloor:1,kind:'tread'});mutation.push({mutable:'stair-push',reads:reads()});p.stairTreads.at(-1).top=.2;mutation.push({mutable:'stair-top',reads:reads()});
api.wallPanels(p).push({rect:{x0:local.x-.5,x1:local.x+.5,z0:local.z-.5,z1:local.z+.5},bottom:0,top:1,kind:'solid'});mutation.push({mutable:'returned-panel-push',reads:reads()});
result.mutationSHA=write('cache-and-mutation.json',mutation);

const bodyTimes=[],support0Times=[],iterations=2000000,supportIterations=12000;
const sample=fixtures.find(b=>b.kind==='market')??fixtures[0],samplePoint=api.getBuildingUsePoints(sample,0)[0].position;
let checksum=0;
for(let warm=0;warm<10000;warm++)checksum+=api.getBuildingBody(sample).floorPlans.length;
for(let repeat=0;repeat<3;repeat++){
 let start=performance.now();for(let i=0;i<iterations;i++)checksum+=api.getBuildingBody(sample).floorPlans.length;bodyTimes.push(performance.now()-start);
 start=performance.now();for(let i=0;i<supportIterations;i++)checksum+=api.floorPlanSupport(sample,0,samplePoint,0)?.floor??0;support0Times.push(performance.now()-start);
}
result.micro={iterations,bodyTimes,supportIterations,support0Times,checksum};

const sim=new Simulation(world),bank=world.buildings.find(b=>b.kind==='bank'&&b.floorPlanProfile),school=world.buildings.find(b=>b.kind==='school'&&b.floorPlanProfile),bankPoint=api.getBuildingUsePoints(bank,0).find(p=>p.purpose==='service'),workPoint=api.getBuildingUsePoints(school,0).find(p=>p.purpose==='work');
assert.equal(sim.state.player.money,600);assert.equal(sim.state.hour,8);assert.equal(sim.state.speed,1);assert.deepEqual(sim.state.player.identities,['traveler']);
sim.setFocus(bankPoint.position,'walk');assert.equal(sim.command({type:'deposit',targetId:bank.id,value:20}).ok,true);
sim.setFocus(workPoint.position,'walk');assert.equal(sim.command({type:'createWork',targetId:'literature',title:'山城真实日常',text:'沿着真实街道记录山城读者的日常生活、山水与邻里共同经历，这些文字需要真实现场时间完成。'}).ok,true);
result.serviceSites={bank:bank.id,school:school.id};result.walletBeforeTicks=sim.state.player.money;assert.equal(result.walletBeforeTicks,520);
let farRoom;
const plan=api.getBuildingFloorPlan(school,0);
for(const room of plan.interior){for(let z=room.z0+.6;z<room.z1-.6;z+=1.2){for(let x=room.x0+.6;x<room.x1-.6;x+=1.2){const pos=api.buildingWorldPosition(school,{x,y:plan.y,z});if(api.canStandInFloorPlan(plan,x,z,.35)&&api.floorPlanSupport(school,0,pos)?.kind==='room'&&school.functionPoints.every(p=>Math.hypot(p.position.x-pos.x,p.position.y-pos.y,p.position.z-pos.z)>2.1)){farRoom=pos;break;}}if(farRoom)break;}if(farRoom)break;}
assert(farRoom);
const session=new Session();session.connect();const post=(name,params={})=>new Promise((resolve,reject)=>session.post(name,params,(error,result)=>error?reject(error):resolve(result)));
await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:1000});await post('Profiler.start');
const tickTimes=[],tickSaves=[],projectMinutes=[],cpuStart=process.cpuUsage(),tickStart=performance.now();
for(let tick=0;tick<12;tick++){
 if(tick===4)sim.setFocus(farRoom,'walk');if(tick===8)sim.setFocus(workPoint.position,'walk');
 const start=performance.now();sim.step(.25);tickTimes.push(performance.now()-start);
 projectMinutes.push(sim.state.culture.project.workedMinutes);
 const save=sim.exportSave();tickSaves.push({tick:tick+1,bytes:Buffer.byteLength(save),sha:write(`tick-${String(tick+1).padStart(2,'0')}.save.json`,save)});
 console.log(JSON.stringify({label,tick:tick+1,ms:tickTimes.at(-1),worked:projectMinutes.at(-1)}));
}
const elapsed=performance.now()-tickStart,cpu=process.cpuUsage(cpuStart),{profile}=await post('Profiler.stop');session.disconnect();write('services-12ticks.cpuprofile',profile);
assert.equal(sim.state.culture.project.workedMinutes,2);assert.equal(sim.state.player.money,520);assert.equal(sim.state.banking.cash,20);assert.equal(sim.state.banking.accounts.player.deposits,20);
result.services={ticks:12,speed:1,stepMinutes:.25,tickTimes,elapsedMs:elapsed,cpuUserMs:cpu.user/1000,cpuSystemMs:cpu.system/1000,projectMinutes,tickSaves,wallet:sim.state.player.money,bankCash:sim.state.banking.cash,playerDeposits:sim.state.banking.accounts.player.deposits,treasury:sim.state.treasury};
write('result.json',result);console.log(JSON.stringify({label,done:true,elapsedMs:elapsed,micro:result.micro,geometrySHA:result.geometrySHA,mutationSHA:result.mutationSHA}));

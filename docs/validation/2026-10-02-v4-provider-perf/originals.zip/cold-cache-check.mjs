import assert from 'node:assert/strict';
import { readFileSync,writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const root=resolve(process.argv[2]),world=JSON.parse(readFileSync(resolve(root,'results/baseline/world.json'),'utf8'));
const results=[];
for(const label of ['baseline','prototype']){
 const api=await import(pathToFileURL(resolve(root,label,'src/architecture-floor-plan.ts')).href),b=structuredClone(world.buildings.find(b=>b.kind==='market'&&b.floorPlanProfile));
 const body=api.getBuildingBody(b);
 // A caller may replace the public plan objects; the old radius-zero path
 // primed panel/slab caches even though it did not consume their solids.
 body.floorPlans=structuredClone(body.floorPlans);
 const p=api.getBuildingFloorPlan(b,0),point=api.getBuildingUsePoints(b,0)[0].position,local=api.buildingLocalPosition(b,point);
 assert(api.floorPlanSupport(b,0,point,0));
 p.walls.push({a:[local.x-.5,local.z],b:[local.x+.5,local.z],thickness:.2,height:2.8});
 const initial=api.floorPlanSupport(b,0,point,.35);
 const blocked=api.blocksFloorPlanMovement(b,0,{...point,z:point.z-.2},{...point,z:point.z+.2});
 // The newly appended source wall keeps the baseline's existing warmed-panel
 // lifetime. Direct mutations of returned panels and fixtures still apply.
 assert(initial);assert.equal(blocked,false);
 api.wallPanels(p).push({rect:{x0:local.x-.5,x1:local.x+.5,z0:local.z-.5,z1:local.z+.5},bottom:0,top:1,kind:'solid'});
 const after=api.floorPlanSupport(b,0,point,.35);
 assert.equal(after,null);
 results.push({label,initial,blocked,after});
}
assert.deepEqual({...results[0],label:''},{...results[1],label:''});
writeFileSync(resolve(root,'cold-cache-result.json'),JSON.stringify({ok:true,results},null,2)+'\n');
console.log('cold radius-zero cache lifetime / public panel mutation: exact');
